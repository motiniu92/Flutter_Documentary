import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:new_motel/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum AuthStatus {
  authenticated,
  unauthenticated,
}

class Auth with ChangeNotifier {
  AuthStatus status = AuthStatus.unauthenticated;
  String _token;
  bool _busy = false;

  bool get busy => _busy;

  setBusy(bool val) {
    _busy = val;
    notifyListeners();
  }

// // <<<<<<< HEAD
//   // Future<bool> getToken() async {
//   //   SharedPreferences prefs = await SharedPreferences.getInstance();
//   //
//   //   var token = prefs.getString('token');
//   //   if (token != null) {
//   //     _token = token;
//   //     return true;
//   //   }
//   //   return false;
//   // }
//   //
//   // Future<void> saveToken(String token) async {
//   //   SharedPreferences prefs = await SharedPreferences.getInstance();
//   //   prefs.remove('token');
//   //   prefs.setString('token', token);
//   //   token = token;
//   // }
//   //
//   // loginData(String email, String password) async {
//   //   final response = await http.post(
//   //     "https://deshitour.com/api/login/check?appKey=DeshiTour",
//   //     body: {
//   //       "email": email,
//   //       "password": password,
//   //     },
//   //   );
//   //
//   //   try {
//   //     Map data = jsonDecode(response.body);
//   //     print(response.body);
//   //     print(response.statusCode);
//   //     // Check if User's Creds is valid,
//   //     var isSuccess = data['token']; // Write you own condition;
//   //     if (isSuccess != null) {
//   //       setBusy(false);
//   //       status = AuthStatus.authenticated;
//   //       Fluttertoast.showToast(
//   //           msg: ('Login_Successfully'),
//   //           toastLength: Toast.LENGTH_SHORT,
//   //           gravity: ToastGravity.BOTTOM,
//   //           timeInSecForIosWeb: 2,
//   //           backgroundColor: Colors.lightGreen,
//   //           textColor: Colors.white,
//   //           fontSize: 16.0);
//   //     } else {
//   //       setBusy(false);
//   //
//   //       status = AuthStatus.unauthenticated;
//   //     }
//   //   } catch (e) {
//   //     status = AuthStatus.unauthenticated; // meaniful is
//   //   }
//   //
//   //   notifyListeners();
//   // }
//
//   registerData(String firstName, String lastName, String phone, String email,
//       String password) async {
// // // =======
// //   Future<bool> getToken() async {
// //     SharedPreferences prefs = await SharedPreferences.getInstance();
// //
// //     var token = prefs.getString('token');
// //     if (token != null) {
// //       _token = token;
// //       return true;
// //     }
// //     return false;
// //   }
//
//   Future<void> saveToken(String token) async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     prefs.remove('token');
//     prefs.setString('token', token);
//     token = token;
//   }
//
//   Future loginData(String email, String password) async {
//     setBusy(true);
//
//     final response = await http.post(
//       "https://deshitour.com/api/login/check?appKey=DeshiTour",
//       body: {
//         "email": email,
//         "password": password,
//       },
//     );
//
//     try {
//       var data = jsonDecode(response.body);
//       print(response.body);
//       // Check if User's Creds is valid,
//       var isSuccess = data['response'] == true; // Write you own condition;
//       if (isSuccess) {
//         status = AuthStatus.authenticated;
//         Fluttertoast.showToast(
//             msg: ('Login_Successfully'),
//             toastLength: Toast.LENGTH_SHORT,
//             gravity: ToastGravity.BOTTOM,
//             timeInSecForIosWeb: 2,
//             backgroundColor: Colors.lightGreen,
//             textColor: Colors.white,
//             fontSize: 16.0);
//         saveToken(data['token']);
//         print(data['token']);
//
//         setBusy(false);
//       } else {
//         setBusy(true);
//         status = AuthStatus.unauthenticated;
//       }
//     } catch (e) {
//       status = AuthStatus.unauthenticated; // meaniful is
//     }
//
//     notifyListeners();
//   }

  Future<String> registerData(String firstName, String lastName, String phone,
      String email, String password) async {
    setBusy(true);
    final response = await http.post(
      "https://deshitour.com/api/login/signup?appKey=DeshiTour",
      body: {
        "email": email,
        "password": password,
        "first_name": firstName,
        "last_name": lastName,
        "phone": phone
      },
    );

    try {
      Map data = jsonDecode(response.body);
      // Check if User's Creds is valid,
      print(response.body);
      var isSuccess = data['response'] == true; // Write you own condition;
      if (isSuccess) {
        setBusy(false);
        status = AuthStatus.authenticated;
        Fluttertoast.showToast(
            msg: ('Account Created Successfully'),
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 2,
            backgroundColor: Colors.indigo,
            textColor: Colors.white,
            fontSize: 16.0);
      } else {
        setBusy(false);
        status = AuthStatus.unauthenticated;
      }
    } catch (e) {}

    notifyListeners();
  }
}
