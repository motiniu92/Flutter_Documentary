import 'package:flutter/material.dart';
import 'package:new_motel/models/hotelList/hotelDetails.dart';
import 'package:new_motel/service/room_details_services.dart';

class HotelRommDetailsProvider extends ChangeNotifier {
  // CategoryModel _categoryModel = CategoryModel();
  // CategoryModel get categoryModel => _categoryModel;
  //
  // CategorySerice _categorySerice = CategorySerice();

  RoomDetailsServices _categorySerice = RoomDetailsServices();

  List<Rooms> _categoryModel = [];
  List<Rooms> get myCategoryModel => _categoryModel;

  set myCategoryModel(List<Rooms> myModel) {
    _categoryModel = myCategoryModel;
    notifyListeners();
  }

  Future<void> fetchData() async {
    if (_categoryModel.isNotEmpty) return;
    // category fetch data
    var datafetch = await _categorySerice.getProductList();
    // category
    _categoryModel.addAll(datafetch);

    // productListFetchdata...

    notifyListeners();
  }

  // fetchCategoryData() async {
  //   var data = await _categorySerice.getProducts();
  //
  //   print('Fetch Category Data -> $data');
  // }
}
