// // import 'package:dio/dio.dart';
// // import 'package:flutter/material.dart';
// //
// // class ProfileProvider with ChangeNotifier {
// //   getProfile() async {
// //     final dio = Dio();
// //
// //     var res = await dio.get(
// //       'https://deshitour.com/api/login/profile?appKey=DeshiTour',
// //     );
// //     print(res.data);
// //     return res.data['accounts_id'];
// //   }
// // }
// import 'package:flutter/material.dart';
// import 'package:new_motel/model/profile_model.dart';
// import 'package:new_motel/service/profile_services.dart';
//
// class ProductListProvider extends ChangeNotifier {
//   ProfileServices _categorySerice = ProfileServices();
//   List<ProfileModel> _productListDataList = [];
//
//   List<ProfileModel> get productListDataList => _productListDataList;
//
//   set productListDataList(List<ProfileModel> myModel) {
//     _productListDataList = productListDataList;
//     notifyListeners();
//   }
//
//   Future<void> productListDataListFetchData() async {
//     if (_productListDataList.isNotEmpty) return;
//     var productlistdata = await _categorySerice.getProducts();
//     // product List
//     _productListDataList.addAll(productlistdata);
//     notifyListeners();
//   }
// }
// import 'package:flutter/material.dart';
// import 'package:provider_json_fetch_data/Models/cart_model.dart';
// import 'package:provider_json_fetch_data/Models/profile_model.dart';
// import 'package:provider_json_fetch_data/Services/cart_services.dart';
// import 'package:provider_json_fetch_data/Services/profile_service.dart';
//
// class ProfileProvider extends ChangeNotifier {
//   ProfileService _ps = ProfileService();
//   List<ProfileDataList> _profileData = [];
//
//   List<ProfileDataList> get profileData => _profileData;
//
//   set cartList(List<ProfileDataList> myModel) {
//     _profileData = profileData;
//     notifyListeners();
//   }
//
//   Future<void> profile() async {
//     var pfData = await _ps.getProfile();
//     print(pfData);
//     _profileData.addAll(pfData);
//     // Cart  List Get .....
//
//     notifyListeners();
//   }
// }
// // import 'package:dio/dio.dart';
// // import 'package:flutter/material.dart';
// // import 'package:shared_preferences/shared_preferences.dart';
//
// // class ProfileProvider with ChangeNotifier {
// //   getProfile() async {
// //     Dio dio = Dio();
// //     SharedPreferences sp = await SharedPreferences.getInstance();
// //     String token = sp.getString('token');
// //     dio.options.headers['Accept'] = 'application/json';
// //     dio.options.headers['authorization'] = 'Bearer ' + token;
// //     var res = await dio.get('https://gagro.com.bd/api/profile');
// //     return res.data['data']['data_list'];
// //   }
// // }
// import 'package:dio/dio.dart';
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// class ProfileProvider with ChangeNotifier {
//   getProfile() async {
//     Dio dio = Dio();
//     SharedPreferences sp = await SharedPreferences.getInstance();
//     String token = sp.getString(
//         'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjcxMzAyMDM3MzkyODUyMmQyNTRmYWJlNjU0YjVmOWFlNWEzOGFiYTg3ZDVhMTkyODE2ODE5OTcwNzc3YjliYWQ1ODZjOTViMGZlZTRiOGZhIn0.eyJhdWQiOiI1IiwianRpIjoiNzEzMDIwMzczOTI4NTIyZDI1NGZhYmU2NTRiNWY5YWU1YTM4YWJhODdkNWExOTI4MTY4MTk5NzA3NzdiOWJhZDU4NmM5NWIwZmVlNGI4ZmEiLCJpYXQiOjE2MDk1MzEwNjQsIm5iZiI6MTYwOTUzMTA2NCwiZXhwIjoxNjQxMDY3MDY0LCJzdWIiOiIyMzAiLCJzY29wZXMiOltdfQ.fx1ZqljaFIHerp2OFODBISqFGjQ7Pu5esr811PC2xAPuDp9_qf-my03ADay4H5PpUX0nfYO9TelkNNxYyVjTKzzB7w-Ab3SVD75BBqysElMY7HeIhP5y5H_gKFKFyZS1qPWFp9PvBzTbd4QTB1ZW9xHAeIkQipI43pYkkJyX-1roEhX_-8Tri40RTfOtP4CcZZr9oNNtXmLmR3vwTZuBmPreCfkw9lOHApiflAVomYiPH0rlZE_lDNvWbQFhR3mCLxfXPeGNdx5zaNYVmeL4NNyAaR8QpcCZ4evLKg5c42fNsTb10mIx2cJY-gL0_ZSe0fJHGagkxr6MERwA8M1jrXcvdx3DslFCI-mlTU1acOPpk_PTiiNP6OTJVkGvnH0YOPGuWgNQ5jv-ph7dRFlme-4h7lRioMD31_ZqN6sae2eWT3hqunnJ5FfBvSRCvdJ2w-g4W1-kj98nGQsCiRXNTpj0L9fsmYx8CrIsm7wpP3irgsJmPwHQAyGHE-99JPILdJfoHwkqQEkJTXv-iNmAcsK3mq3ETDpCA_hGyPiPWfC8sv_-NfeSCLHe05AQPEvOogK8rAqCQ5jLun7Lex11zp9-M1_kTO5k-biU17jSC6eX62eo6gyF9cbLAEedwololmI1UKQK4nGnsWykaKsTH1hpaGfnWV1sVNPHmA3zOH8');
//     dio.options.headers['Accept'] = 'application/json';
//     dio.options.headers['authorization'] = 'Bearer ' + token;
//     var res = await dio.get('https://gagro.com.bd/api/profile');
//     print(res.data);
//     return res.data['data']['data_list'];
//   }
// }
// // 'Accept': 'application/json',
// // 'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjcxMzAyMDM3MzkyODUyMmQyNTRmYWJlNjU0YjVmOWFlNWEzOGFiYTg3ZDVhMTkyODE2ODE5OTcwNzc3YjliYWQ1ODZjOTViMGZlZTRiOGZhIn0.eyJhdWQiOiI1IiwianRpIjoiNzEzMDIwMzczOTI4NTIyZDI1NGZhYmU2NTRiNWY5YWU1YTM4YWJhODdkNWExOTI4MTY4MTk5NzA3NzdiOWJhZDU4NmM5NWIwZmVlNGI4ZmEiLCJpYXQiOjE2MDk1MzEwNjQsIm5iZiI6MTYwOTUzMTA2NCwiZXhwIjoxNjQxMDY3MDY0LCJzdWIiOiIyMzAiLCJzY29wZXMiOltdfQ.fx1ZqljaFIHerp2OFODBISqFGjQ7Pu5esr811PC2xAPuDp9_qf-my03ADay4H5PpUX0nfYO9TelkNNxYyVjTKzzB7w-Ab3SVD75BBqysElMY7HeIhP5y5H_gKFKFyZS1qPWFp9PvBzTbd4QTB1ZW9xHAeIkQipI43pYkkJyX-1roEhX_-8Tri40RTfOtP4CcZZr9oNNtXmLmR3vwTZuBmPreCfkw9lOHApiflAVomYiPH0rlZE_lDNvWbQFhR3mCLxfXPeGNdx5zaNYVmeL4NNyAaR8QpcCZ4evLKg5c42fNsTb10mIx2cJY-gL0_ZSe0fJHGagkxr6MERwA8M1jrXcvdx3DslFCI-mlTU1acOPpk_PTiiNP6OTJVkGvnH0YOPGuWgNQ5jv-ph7dRFlme-4h7lRioMD31_ZqN6sae2eWT3hqunnJ5FfBvSRCvdJ2w-g4W1-kj98nGQsCiRXNTpj0L9fsmYx8CrIsm7wpP3irgsJmPwHQAyGHE-99JPILdJfoHwkqQEkJTXv-iNmAcsK3mq3ETDpCA_hGyPiPWfC8sv_-NfeSCLHe05AQPEvOogK8rAqCQ5jLun7Lex11zp9-M1_kTO5k-biU17jSC6eX62eo6gyF9cbLAEedwololmI1UKQK4nGnsWykaKsTH1hpaGfnWV1sVNPHmA3zOH8'
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProfileProvider with ChangeNotifier {
  getProfile() async {
    Dio dio = Dio();
    var res = await dio.get(
      'https://deshitour.com/api/login/profile?appKey=DeshiTour',

      options: Options(
        headers: {"Authorization": getToken},
      ),

      // options: Options(
      //   headers: {'token': 'b3725c6ca0998413f46353923fc37d13483228ed'},
      // ),
    );
    // getToken();
    // notifyListeners();
    print("Tokennnnnnnn.....>>>>> ${getToken()}");

    return res.data['response'];
  }

  getToken() async {
    SharedPreferences _sharedPreferences =
        await SharedPreferences.getInstance();
    return _sharedPreferences.get("token");
  }
}
