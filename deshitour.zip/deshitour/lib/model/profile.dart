// // // // To parse this JSON data, do
// // // //
// // // //     final profileModelResponse = profileModelResponseFromJson(jsonString);
// // //
// // // import 'dart:convert';
// // //
// // // ProfileModelResponse profileModelResponseFromJson(String str) =>
// // //     ProfileModelResponse.fromJson(json.decode(str));
// // //
// // // String profileModelResponseToJson(ProfileModelResponse data) =>
// // //     json.encode(data.toJson());
// // //
// // // class ProfileModelResponse {
// // //   ProfileModelResponse({
// // //     this.response,
// // //     this.error,
// // //   });
// // //
// // //   DataList response;
// // //   Error error;
// // //
// // //   factory ProfileModelResponse.fromJson(Map<String, dynamic> json) =>
// // //       ProfileModelResponse(
// // //         response: DataList.fromJson(json["response"]),
// // //         error: Error.fromJson(json["error"]),
// // //       );
// // //
// // //   Map<String, dynamic> toJson() => {
// // //         "response": response.toJson(),
// // //         "error": error.toJson(),
// // //       };
// // // }
// // //
// // // class Error {
// // //   Error({
// // //     this.status,
// // //     this.msg,
// // //   });
// // //
// // //   bool status;
// // //   String msg;
// // //
// // //   factory Error.fromJson(Map<String, dynamic> json) => Error(
// // //         status: json["status"],
// // //         msg: json["msg"],
// // //       );
// // //
// // //   Map<String, dynamic> toJson() => {
// // //         "status": status,
// // //         "msg": msg,
// // //       };
// // // }
// // //
// // // class DataList {
// // //   DataList({
// // //     this.accountsId,
// // //     this.aiTitle,
// // //     this.aiFirstName,
// // //     this.aiLastName,
// // //     this.accountsEmail,
// // //     this.aiDob,
// // //     this.aiCountry,
// // //     this.aiState,
// // //     this.aiCity,
// // //     this.aiAddress1,
// // //     this.aiAddress2,
// // //     this.aiMobile,
// // //     this.aiFax,
// // //     this.aiPostalCode,
// // //     this.accountsStatus,
// // //     this.accountsVerified,
// // //     this.agent,
// // //     this.photo,
// // //   });
// // //
// // //   String accountsId;
// // //   dynamic aiTitle;
// // //   String aiFirstName;
// // //   String aiLastName;
// // //   String accountsEmail;
// // //   dynamic aiDob;
// // //   dynamic aiCountry;
// // //   dynamic aiState;
// // //   dynamic aiCity;
// // //   dynamic aiAddress1;
// // //   dynamic aiAddress2;
// // //   String aiMobile;
// // //   dynamic aiFax;
// // //   dynamic aiPostalCode;
// // //   String accountsStatus;
// // //   String accountsVerified;
// // //   String agent;
// // //   dynamic photo;
// // //
// // //   factory DataList.fromJson(Map<String, dynamic> json) => DataList(
// // //         accountsId: json["accounts_id"],
// // //         aiTitle: json["ai_title"],
// // //         aiFirstName: json["ai_first_name"],
// // //         aiLastName: json["ai_last_name"],
// // //         accountsEmail: json["accounts_email"],
// // //         aiDob: json["ai_dob"],
// // //         aiCountry: json["ai_country"],
// // //         aiState: json["ai_state"],
// // //         aiCity: json["ai_city"],
// // //         aiAddress1: json["ai_address_1"],
// // //         aiAddress2: json["ai_address_2"],
// // //         aiMobile: json["ai_mobile"],
// // //         aiFax: json["ai_fax"],
// // //         aiPostalCode: json["ai_postal_code"],
// // //         accountsStatus: json["accounts_status"],
// // //         accountsVerified: json["accounts_verified"],
// // //         agent: json["agent"],
// // //         photo: json["photo"],
// // //       );
// // //
// // //   Map<String, dynamic> toJson() => {
// // //         "accounts_id": accountsId,
// // //         "ai_title": aiTitle,
// // //         "ai_first_name": aiFirstName,
// // //         "ai_last_name": aiLastName,
// // //         "accounts_email": accountsEmail,
// // //         "ai_dob": aiDob,
// // //         "ai_country": aiCountry,
// // //         "ai_state": aiState,
// // //         "ai_city": aiCity,
// // //         "ai_address_1": aiAddress1,
// // //         "ai_address_2": aiAddress2,
// // //         "ai_mobile": aiMobile,
// // //         "ai_fax": aiFax,
// // //         "ai_postal_code": aiPostalCode,
// // //         "accounts_status": accountsStatus,
// // //         "accounts_verified": accountsVerified,
// // //         "agent": agent,
// // //         "photo": photo,
// // //       };
// // // }
// //
// // class ProfileData {
// //   final String accounts_id;
// //   final String ai_title;
// //   final String ai_first_name;
// //   final String ai_last_name;
// //   final String accounts_email;
// //   final String ai_dob;
// //   final String ai_country;
// //   final String ai_state;
// //   final String ai_city;
// //   final String ai_address_1;
// //   final String ai_address_2;
// //   final String ai_mobile;
// //   final String ai_fax;
// //   final String ai_postal_code;
// //   final String accounts_status;
// //   final String accounts_verified;
// //   final String agent;
// //   final String photo;
// //
// //   ProfileData({
// //     this.accounts_id,
// //     this.ai_title,
// //     this.ai_first_name,
// //     this.ai_last_name,
// //     this.accounts_email,
// //     this.ai_dob,
// //     this.ai_country,
// //     this.ai_state,
// //     this.ai_city,
// //     this.ai_address_1,
// //     this.ai_address_2,
// //     this.ai_mobile,
// //     this.ai_fax,
// //     this.ai_postal_code,
// //     this.accounts_status,
// //     this.accounts_verified,
// //     this.agent,
// //     this.photo,
// //   });
// //
// //   factory ProfileData.fromJson(Map<String, dynamic> json) {
// //     return ProfileData(
// //       accounts_id: json["status"]['accounts_id'],
// //       ai_title: json["status"]['ai_title'],
// //       ai_first_name: json["status"]['ai_first_name'],
// //       ai_last_name: json["status"]['ai_last_name'],
// //       accounts_email: json["status"]['accounts_email'],
// //       ai_dob: json["status"]['ai_dob'],
// //       ai_country: json["status"]['ai_country'],
// //       ai_state: json["status"]['ai_state'],
// //       ai_city: json["status"]['ai_city'],
// //       ai_address_1: json["status"]['ai_address_1'],
// //       ai_address_2: json["status"]['ai_address_2'],
// //       ai_mobile: json["status"]['ai_mobile'],
// //       ai_fax: json["status"]['ai_fax'],
// //       ai_postal_code: json["status"]['ai_postal_code'],
// //       accounts_status: json["status"]['accounts_status'],
// //       accounts_verified: json["status"]['accounts_verified'],
// //       agent: json["status"]['agent'],
// //       photo: json["status"]['photo'],
// //     );
// //   }
// // }
//
// class ProfileInfo {
//   ProfileInfo({
//     this.accountsId,
//     this.aiTitle,
//     this.aiFirstName,
//     this.aiLastName,
//     this.accountsEmail,
//     this.aiDob,
//     this.aiCountry,
//     this.aiState,
//     this.aiCity,
//     this.aiAddress1,
//     this.aiAddress2,
//     this.aiMobile,
//     this.aiFax,
//     this.aiPostalCode,
//     this.accountsStatus,
//     this.accountsVerified,
//     this.agent,
//     this.photo,
//   });
//
//   String accountsId;
//   dynamic aiTitle;
//   String aiFirstName;
//   String aiLastName;
//   String accountsEmail;
//   dynamic aiDob;
//   dynamic aiCountry;
//   dynamic aiState;
//   dynamic aiCity;
//   dynamic aiAddress1;
//   dynamic aiAddress2;
//   String aiMobile;
//   dynamic aiFax;
//   dynamic aiPostalCode;
//   String accountsStatus;
//   String accountsVerified;
//   String agent;
//   dynamic photo;
//
//   factory ProfileInfo.fromJson(Map<String, dynamic> json) => ProfileInfo(
//         accountsId: json["accounts_id"],
//         aiTitle: json["ai_title"],
//         aiFirstName: json["ai_first_name"],
//         aiLastName: json["ai_last_name"],
//         accountsEmail: json["accounts_email"],
//         aiDob: json["ai_dob"],
//         aiCountry: json["ai_country"],
//         aiState: json["ai_state"],
//         aiCity: json["ai_city"],
//         aiAddress1: json["ai_address_1"],
//         aiAddress2: json["ai_address_2"],
//         aiMobile: json["ai_mobile"],
//         aiFax: json["ai_fax"],
//         aiPostalCode: json["ai_postal_code"],
//         accountsStatus: json["accounts_status"],
//         accountsVerified: json["accounts_verified"],
//         agent: json["agent"],
//         photo: json["photo"],
//       );
//
//   Map<String, dynamic> toJson() => {
//         "accounts_id": accountsId,
//         "ai_title": aiTitle,
//         "ai_first_name": aiFirstName,
//         "ai_last_name": aiLastName,
//         "accounts_email": accountsEmail,
//         "ai_dob": aiDob,
//         "ai_country": aiCountry,
//         "ai_state": aiState,
//         "ai_city": aiCity,
//         "ai_address_1": aiAddress1,
//         "ai_address_2": aiAddress2,
//         "ai_mobile": aiMobile,
//         "ai_fax": aiFax,
//         "ai_postal_code": aiPostalCode,
//         "accounts_status": accountsStatus,
//         "accounts_verified": accountsVerified,
//         "agent": agent,
//         "photo": photo,
//       };
// }
// To parse this JSON data, do
//
//     final profileResponse = profileResponseFromJson(jsonString);

import 'dart:convert';

ProfileResponse profileResponseFromJson(String str) =>
    ProfileResponse.fromJson(json.decode(str));

String profileResponseToJson(ProfileResponse data) =>
    json.encode(data.toJson());

class ProfileResponse {
  ProfileResponse({
    this.status,
    this.profileInfo,
  });

  int status;
  ProfileInfo profileInfo;

  factory ProfileResponse.fromJson(Map<String, dynamic> json) =>
      ProfileResponse(
        status: json["status"],
        profileInfo: ProfileInfo.fromJson(json["profile_info"]),
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "profile_info": profileInfo.toJson(),
      };
}

class ProfileInfo {
  ProfileInfo({
    this.accountsId,
    this.aiTitle,
    this.aiFirstName,
    this.aiLastName,
    this.accountsEmail,
    this.aiDob,
    this.aiCountry,
    this.aiState,
    this.aiCity,
    this.aiAddress1,
    this.aiAddress2,
    this.aiMobile,
    this.aiFax,
    this.aiPostalCode,
    this.accountsStatus,
    this.accountsVerified,
    this.agent,
    this.photo,
  });

  String accountsId;
  dynamic aiTitle;
  String aiFirstName;
  String aiLastName;
  String accountsEmail;
  dynamic aiDob;
  dynamic aiCountry;
  dynamic aiState;
  dynamic aiCity;
  dynamic aiAddress1;
  dynamic aiAddress2;
  String aiMobile;
  dynamic aiFax;
  dynamic aiPostalCode;
  String accountsStatus;
  String accountsVerified;
  String agent;
  dynamic photo;

  factory ProfileInfo.fromJson(Map<String, dynamic> json) => ProfileInfo(
        accountsId: json["accounts_id"],
        aiTitle: json["ai_title"],
        aiFirstName: json["ai_first_name"],
        aiLastName: json["ai_last_name"],
        accountsEmail: json["accounts_email"],
        aiDob: json["ai_dob"],
        aiCountry: json["ai_country"],
        aiState: json["ai_state"],
        aiCity: json["ai_city"],
        aiAddress1: json["ai_address_1"],
        aiAddress2: json["ai_address_2"],
        aiMobile: json["ai_mobile"],
        aiFax: json["ai_fax"],
        aiPostalCode: json["ai_postal_code"],
        accountsStatus: json["accounts_status"],
        accountsVerified: json["accounts_verified"],
        agent: json["agent"],
        photo: json["photo"],
      );

  Map<String, dynamic> toJson() => {
        "accounts_id": accountsId,
        "ai_title": aiTitle,
        "ai_first_name": aiFirstName,
        "ai_last_name": aiLastName,
        "accounts_email": accountsEmail,
        "ai_dob": aiDob,
        "ai_country": aiCountry,
        "ai_state": aiState,
        "ai_city": aiCity,
        "ai_address_1": aiAddress1,
        "ai_address_2": aiAddress2,
        "ai_mobile": aiMobile,
        "ai_fax": aiFax,
        "ai_postal_code": aiPostalCode,
        "accounts_status": accountsStatus,
        "accounts_verified": accountsVerified,
        "agent": agent,
        "photo": photo,
      };
}
