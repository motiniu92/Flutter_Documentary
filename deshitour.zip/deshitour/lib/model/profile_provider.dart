// import 'package:flutter/material.dart';
// import 'package:new_motel/model/profile_model.dart';
// import 'package:new_motel/model/profile_service.dart';
//
// class ProductListProvider extends ChangeNotifier {
//   ProfileService _categorySerice = ProfileService();
//   List<DataList> _productListDataList = [];
//
//   List<DataList> get productListDataList => _productListDataList;
//
//   set productListDataList(List<DataList> myModel) {
//     _productListDataList = productListDataList;
//     notifyListeners();
//   }
//
//   Future<void> productListDataListFetchData() async {
//     if (_productListDataList.isNotEmpty) return;
//     var productlistdata = await _categorySerice.fetchProfile();
//     // product List
//     _productListDataList.addAll(productlistdata);
//     notifyListeners();
//   }
// }
