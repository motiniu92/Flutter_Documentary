// import 'dart:io';
//
// import 'package:dio/dio.dart';
// import 'package:flutter/material.dart';
// import 'package:new_motel/model/profile_model.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// class ProfileService with ChangeNotifier {
//   Future<List<DataList>> fetchProfile() async {
//     final _dio = Dio();
//     SharedPreferences prefsss = await SharedPreferences.getInstance();
//     String tokennn = prefsss.get("token");
//     Map<String, dynamic> requestHeaders = {
//       'Content-type': 'application/json',
//       'Accept': 'application/json',
//       HttpHeaders.acceptHeader: tokennn,
//     };
//     try {
//       final Response response = await _dio.get(
//           "https://deshitour.com/api/login/profile?appKey=DeshiTour",
//           options: Options(
//             headers: requestHeaders,
//           ));
//       print(response.data);
//
//       return (response.data['response'] as List)
//           .map((e) => DataList.fromJson(e))
//           .toList();
//     } on DioError catch (dioError) {
//       print(dioError);
//     }
//   }
// }
