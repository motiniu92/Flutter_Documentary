// // To parse this JSON data, do
// //
// //     final hotelDetailsRoom = hotelDetailsRoomFromJson(jsonString);
//
// import 'dart:convert';
//
// HotelDetailsRoom hotelDetailsRoomFromJson(String str) =>
//     HotelDetailsRoom.fromJson(json.decode(str));
//
// String hotelDetailsRoomToJson(HotelDetailsRoom data) =>
//     json.encode(data.toJson());
//
// class HotelDetailsRoom {
//   HotelDetailsRoom({
//     this.response,
//     this.error,
//   });
//
//   Response response;
//   Error error;
//
//   factory HotelDetailsRoom.fromJson(Map<String, dynamic> json) =>
//       HotelDetailsRoom(
//         response: Response.fromJson(json["response"]),
//         error: Error.fromJson(json["error"]),
//       );
//
//   Map<String, dynamic> toJson() => {
//         "response": response.toJson(),
//         "error": error.toJson(),
//       };
// }
//
// class Error {
//   Error({
//     this.status,
//     this.msg,
//   });
//
//   bool status;
//   String msg;
//
//   factory Error.fromJson(Map<String, dynamic> json) => Error(
//         status: json["status"],
//         msg: json["msg"],
//       );
//
//   Map<String, dynamic> toJson() => {
//         "status": status,
//         "msg": msg,
//       };
// }
//
// class Response {
//   Response({
//     this.hotel,
//     this.rooms,
//     this.tripadvisorinfo,
//     this.reviews,
//     this.avgReviews,
//   });
//
//   Hotel hotel;
//   List<Room> rooms;
//   String tripadvisorinfo;
//   List<Review> reviews;
//   Reviews avgReviews;
//
//   factory Response.fromJson(Map<String, dynamic> json) => Response(
//         hotel: Hotel.fromJson(json["hotel"]),
//         rooms: List<Room>.from(json["rooms"].map((x) => Room.fromJson(x))),
//         tripadvisorinfo: json["tripadvisorinfo"],
//         reviews:
//             List<Review>.from(json["reviews"].map((x) => Review.fromJson(x))),
//         avgReviews: Reviews.fromJson(json["avgReviews"]),
//       );
//
//   Map<String, dynamic> toJson() => {
//         "hotel": hotel.toJson(),
//         "rooms": List<dynamic>.from(rooms.map((x) => x.toJson())),
//         "tripadvisorinfo": tripadvisorinfo,
//         "reviews": List<dynamic>.from(reviews.map((x) => x.toJson())),
//         "avgReviews": avgReviews.toJson(),
//       };
// }
//
// class Reviews {
//   Reviews({
//     this.clean,
//     this.comfort,
//     this.location,
//     this.facilities,
//     this.staff,
//     this.totalReviews,
//     this.overall,
//   });
//
//   double clean;
//   double comfort;
//   double location;
//   double facilities;
//   double staff;
//   String totalReviews;
//   double overall;
//
//   factory Reviews.fromJson(Map<String, dynamic> json) => Reviews(
//         clean: json["clean"].toDouble(),
//         comfort: json["comfort"].toDouble(),
//         location: json["location"].toDouble(),
//         facilities: json["facilities"].toDouble(),
//         staff: json["staff"].toDouble(),
//         totalReviews: json["totalReviews"],
//         overall: json["overall"].toDouble(),
//       );
//
//   Map<String, dynamic> toJson() => {
//         "clean": clean,
//         "comfort": comfort,
//         "location": location,
//         "facilities": facilities,
//         "staff": staff,
//         "totalReviews": totalReviews,
//         "overall": overall,
//       };
// }
//
// class Hotel {
//   Hotel({
//     this.id,
//     this.title,
//     this.slug,
//     this.bookingSlug,
//     this.thumbnail,
//     this.stars,
//     this.starsCount,
//     this.location,
//     this.desc,
//     this.amenities,
//     this.latitude,
//     this.longitude,
//     this.sliderImages,
//     this.relatedItems,
//     this.paymentOptions,
//     this.defcheckin,
//     this.defcheckout,
//     this.metadesc,
//     this.keywords,
//     this.policy,
//     this.tripadvisorid,
//     this.mapAddress,
//     this.hotelCancelationTime,
//     this.popularAmenities,
//     this.restaurant,
//     this.adminComment,
//     this.finePrint,
//     this.airportDistance,
//     this.videoLink,
//     this.fooddiscount,
//     this.hostedby,
//     this.breakfastCharge,
//     this.airportPickup,
//     this.cityCenterDistance,
//     this.beachDistance,
//     this.portDistance,
//     this.hotelLogo,
//     this.specialfeatures,
//     this.popularAmenitiesNote,
//     this.areainfo,
//     this.popularRoomAmenities,
//     this.taxType,
//     this.taxValue,
//     this.hotelReviews,
//     this.basicPrice,
//     this.countries,
//     this.taxval,
//   });
//
//   String id;
//   String title;
//   String slug;
//   String bookingSlug;
//   String thumbnail;
//   String stars;
//   String starsCount;
//   String location;
//   String desc;
//   List<Amenity> amenities;
//   String latitude;
//   String longitude;
//   List<Image> sliderImages;
//   List<RelatedItem> relatedItems;
//   List<Amenity> paymentOptions;
//   String defcheckin;
//   String defcheckout;
//   String metadesc;
//   String keywords;
//   String policy;
//   dynamic tripadvisorid;
//   String mapAddress;
//   String hotelCancelationTime;
//   List<Amenity> popularAmenities;
//   String restaurant;
//   String adminComment;
//   String finePrint;
//   String airportDistance;
//   String videoLink;
//   String fooddiscount;
//   String hostedby;
//   String breakfastCharge;
//   int airportPickup;
//   String cityCenterDistance;
//   String beachDistance;
//   String portDistance;
//   String hotelLogo;
//   String specialfeatures;
//   String popularAmenitiesNote;
//   String areainfo;
//   List<Amenity> popularRoomAmenities;
//   String taxType;
//   String taxValue;
//   Reviews hotelReviews;
//   String basicPrice;
//   Map<String, String> countries;
//   String taxval;
//
//   factory Hotel.fromJson(Map<String, dynamic> json) => Hotel(
//         id: json["id"],
//         title: json["title"],
//         slug: json["slug"],
//         bookingSlug: json["bookingSlug"],
//         thumbnail: json["thumbnail"],
//         stars: json["stars"],
//         starsCount: json["starsCount"],
//         location: json["location"],
//         desc: json["desc"],
//         amenities: List<Amenity>.from(
//             json["amenities"].map((x) => Amenity.fromJson(x))),
//         latitude: json["latitude"],
//         longitude: json["longitude"],
//         sliderImages: List<Image>.from(
//             json["sliderImages"].map((x) => Image.fromJson(x))),
//         relatedItems: List<RelatedItem>.from(
//             json["relatedItems"].map((x) => RelatedItem.fromJson(x))),
//         paymentOptions: List<Amenity>.from(
//             json["paymentOptions"].map((x) => Amenity.fromJson(x))),
//         defcheckin: json["defcheckin"],
//         defcheckout: json["defcheckout"],
//         metadesc: json["metadesc"],
//         keywords: json["keywords"],
//         policy: json["policy"],
//         tripadvisorid: json["tripadvisorid"],
//         mapAddress: json["mapAddress"],
//         hotelCancelationTime: json["hotel_cancelation_time"],
//         popularAmenities: List<Amenity>.from(
//             json["popular_amenities"].map((x) => Amenity.fromJson(x))),
//         restaurant: json["restaurant"],
//         adminComment: json["admin_comment"],
//         finePrint: json["fine_print"],
//         airportDistance: json["airportDistance"],
//         videoLink: json["videoLink"],
//         fooddiscount: json["fooddiscount"],
//         hostedby: json["hostedby"],
//         breakfastCharge: json["breakfastCharge"],
//         airportPickup: json["airportPickup"],
//         cityCenterDistance: json["cityCenterDistance"],
//         beachDistance: json["beachDistance"],
//         portDistance: json["portDistance"],
//         hotelLogo: json["hotel_logo"],
//         specialfeatures: json["specialfeatures"],
//         popularAmenitiesNote: json["popular_amenities_note"],
//         areainfo: json["areainfo"],
//         popularRoomAmenities: List<Amenity>.from(
//             json["popular_room_amenities"].map((x) => Amenity.fromJson(x))),
//         taxType: json["tax_type"],
//         taxValue: json["tax_value"],
//         hotelReviews: Reviews.fromJson(json["hotelReviews"]),
//         basicPrice: json["basicPrice"],
//         countries: Map.from(json["countries"])
//             .map((k, v) => MapEntry<String, String>(k, v)),
//         taxval: json["taxval"],
//       );
//
//   Map<String, dynamic> toJson() => {
//         "id": id,
//         "title": title,
//         "slug": slug,
//         "bookingSlug": bookingSlug,
//         "thumbnail": thumbnail,
//         "stars": stars,
//         "starsCount": starsCount,
//         "location": location,
//         "desc": desc,
//         "amenities": List<dynamic>.from(amenities.map((x) => x.toJson())),
//         "latitude": latitude,
//         "longitude": longitude,
//         "sliderImages": List<dynamic>.from(sliderImages.map((x) => x.toJson())),
//         "relatedItems": List<dynamic>.from(relatedItems.map((x) => x.toJson())),
//         "paymentOptions":
//             List<dynamic>.from(paymentOptions.map((x) => x.toJson())),
//         "defcheckin": defcheckin,
//         "defcheckout": defcheckout,
//         "metadesc": metadesc,
//         "keywords": keywords,
//         "policy": policy,
//         "tripadvisorid": tripadvisorid,
//         "mapAddress": mapAddress,
//         "hotel_cancelation_time": hotelCancelationTime,
//         "popular_amenities":
//             List<dynamic>.from(popularAmenities.map((x) => x.toJson())),
//         "restaurant": restaurant,
//         "admin_comment": adminComment,
//         "fine_print": finePrint,
//         "airportDistance": airportDistance,
//         "videoLink": videoLink,
//         "fooddiscount": fooddiscount,
//         "hostedby": hostedby,
//         "breakfastCharge": breakfastCharge,
//         "airportPickup": airportPickup,
//         "cityCenterDistance": cityCenterDistance,
//         "beachDistance": beachDistance,
//         "portDistance": portDistance,
//         "hotel_logo": hotelLogo,
//         "specialfeatures": specialfeatures,
//         "popular_amenities_note": popularAmenitiesNote,
//         "areainfo": areainfo,
//         "popular_room_amenities":
//             List<dynamic>.from(popularRoomAmenities.map((x) => x.toJson())),
//         "tax_type": taxType,
//         "tax_value": taxValue,
//         "hotelReviews": hotelReviews.toJson(),
//         "basicPrice": basicPrice,
//         "countries":
//             Map.from(countries).map((k, v) => MapEntry<String, dynamic>(k, v)),
//         "taxval": taxval,
//       };
// }
//
// class Amenity {
//   Amenity({
//     this.icon,
//     this.name,
//   });
//
//   String icon;
//   String name;
//
//   factory Amenity.fromJson(Map<String, dynamic> json) => Amenity(
//         icon: json["icon"],
//         name: json["name"],
//       );
//
//   Map<String, dynamic> toJson() => {
//         "icon": icon,
//         "name": name,
//       };
// }
//
// class RelatedItem {
//   RelatedItem({
//     this.id,
//     this.title,
//     this.desc,
//     this.slug,
//     this.thumbnail,
//     this.stars,
//     this.starsCount,
//     this.location,
//     this.price,
//     this.currCode,
//     this.currSymbol,
//     this.avgReviews,
//     this.latitude,
//     this.longitude,
//   });
//
//   String id;
//   String title;
//   String desc;
//   String slug;
//   String thumbnail;
//   String stars;
//   String starsCount;
//   String location;
//   String price;
//   String currCode;
//   String currSymbol;
//   Reviews avgReviews;
//   String latitude;
//   String longitude;
//
//   factory RelatedItem.fromJson(Map<String, dynamic> json) => RelatedItem(
//         id: json["id"],
//         title: json["title"],
//         desc: json["desc"],
//         slug: json["slug"],
//         thumbnail: json["thumbnail"],
//         stars: json["stars"],
//         starsCount: json["starsCount"],
//         location: json["location"],
//         price: json["price"],
//         currCode: json["currCode"],
//         currSymbol: json["currSymbol"],
//         avgReviews: Reviews.fromJson(json["avgReviews"]),
//         latitude: json["latitude"],
//         longitude: json["longitude"],
//       );
//
//   Map<String, dynamic> toJson() => {
//         "id": id,
//         "title": title,
//         "desc": desc,
//         "slug": slug,
//         "thumbnail": thumbnail,
//         "stars": stars,
//         "starsCount": starsCount,
//         "location": location,
//         "price": price,
//         "currCode": currCode,
//         "currSymbol": currSymbol,
//         "avgReviews": avgReviews.toJson(),
//         "latitude": latitude,
//         "longitude": longitude,
//       };
// }
//
// class Image {
//   Image({
//     this.fullImage,
//     this.thumbImage,
//   });
//
//   String fullImage;
//   String thumbImage;
//
//   factory Image.fromJson(Map<String, dynamic> json) => Image(
//         fullImage: json["fullImage"],
//         thumbImage: json["thumbImage"],
//       );
//
//   Map<String, dynamic> toJson() => {
//         "fullImage": fullImage,
//         "thumbImage": thumbImage,
//       };
// }
//
// class Review {
//   Review({
//     this.reviewOverall,
//     this.reviewName,
//     this.reviewComment,
//     this.reviewDate,
//     this.maxRating,
//   });
//
//   String reviewOverall;
//   String reviewName;
//   String reviewComment;
//   String reviewDate;
//   int maxRating;
//
//   factory Review.fromJson(Map<String, dynamic> json) => Review(
//         reviewOverall: json["review_overall"],
//         reviewName: json["review_name"],
//         reviewComment: json["review_comment"],
//         reviewDate: json["review_date"],
//         maxRating: json["maxRating"],
//       );
//
//   Map<String, dynamic> toJson() => {
//         "review_overall": reviewOverall,
//         "review_name": reviewName,
//         "review_comment": reviewComment,
//         "review_date": reviewDate,
//         "maxRating": maxRating,
//       };
// }
//
// class Room {
//   Room({
//     this.id,
//     this.title,
//     this.desc,
//     this.maxAdults,
//     this.maxChild,
//     this.maxQuantity,
//     this.maxAvailablity,
//     this.thumbnail,
//     this.images,
//     this.amenities,
//     this.price,
//     this.currRate,
//     this.currCode,
//     this.currSymbol,
//     this.info,
//     this.extraBeds,
//     this.extrabedCharges,
//     this.singlebed,
//     this.doublebed,
//     this.roomSize,
//   });
//
//   String id;
//   String title;
//   String desc;
//   String maxAdults;
//   String maxChild;
//   String maxQuantity;
//   String maxAvailablity;
//   String thumbnail;
//   List<Image> images;
//   List<Amenity> amenities;
//   String price;
//   String currRate;
//   String currCode;
//   String currSymbol;
//   Info info;
//   String extraBeds;
//   int extrabedCharges;
//   String singlebed;
//   String doublebed;
//   String roomSize;
//
//   factory Room.fromJson(Map<String, dynamic> json) => Room(
//         id: json["id"],
//         title: json["title"],
//         desc: json["desc"],
//         maxAdults: json["maxAdults"],
//         maxChild: json["maxChild"],
//         maxQuantity: json["maxQuantity"],
//         maxAvailablity: json["maxAvailablity"],
//         thumbnail: json["thumbnail"],
//         images: List<Image>.from(json["Images"].map((x) => Image.fromJson(x))),
//         amenities: List<Amenity>.from(
//             json["Amenities"].map((x) => Amenity.fromJson(x))),
//         price: json["price"],
//         currRate: json["currRate"],
//         currCode: json["currCode"],
//         currSymbol: json["currSymbol"],
//         info: Info.fromJson(json["Info"]),
//         extraBeds: json["extraBeds"],
//         extrabedCharges: json["extrabedCharges"],
//         singlebed: json["singlebed"],
//         doublebed: json["doublebed"],
//         roomSize: json["room_size"],
//       );
//
//   Map<String, dynamic> toJson() => {
//         "id": id,
//         "title": title,
//         "desc": desc,
//         "maxAdults": maxAdults,
//         "maxChild": maxChild,
//         "maxQuantity": maxQuantity,
//         "maxAvailablity": maxAvailablity,
//         "thumbnail": thumbnail,
//         "Images": List<dynamic>.from(images.map((x) => x.toJson())),
//         "Amenities": List<dynamic>.from(amenities.map((x) => x.toJson())),
//         "price": price,
//         "currRate": currRate,
//         "currCode": currCode,
//         "currSymbol": currSymbol,
//         "Info": info.toJson(),
//         "extraBeds": extraBeds,
//         "extrabedCharges": extrabedCharges,
//         "singlebed": singlebed,
//         "doublebed": doublebed,
//         "room_size": roomSize,
//       };
// }
//
// class Info {
//   Info({
//     this.roomId,
//     this.perNight,
//     this.stay,
//     this.totalPrice,
//     this.checkin,
//     this.checkout,
//     this.extrabed,
//     this.maxAdults,
//     this.maxChild,
//     this.quantity,
//     this.totalpricewithouttax,
//     this.discount,
//   });
//
//   String roomId;
//   int perNight;
//   int stay;
//   int totalPrice;
//   DateTime checkin;
//   DateTime checkout;
//   int extrabed;
//   String maxAdults;
//   String maxChild;
//   String quantity;
//   int totalpricewithouttax;
//   int discount;
//
//   factory Info.fromJson(Map<String, dynamic> json) => Info(
//         roomId: json["roomID"],
//         perNight: json["perNight"],
//         stay: json["stay"],
//         totalPrice: json["totalPrice"],
//         checkin: DateTime.parse(json["checkin"]),
//         checkout: DateTime.parse(json["checkout"]),
//         extrabed: json["extrabed"],
//         maxAdults: json["maxAdults"],
//         maxChild: json["maxChild"],
//         quantity: json["quantity"],
//         totalpricewithouttax: json["totalpricewithouttax"],
//         discount: json["discount"],
//       );
//
//   Map<String, dynamic> toJson() => {
//         "roomID": roomId,
//         "perNight": perNight,
//         "stay": stay,
//         "totalPrice": totalPrice,
//         "checkin":
//             "${checkin.year.toString().padLeft(4, '0')}-${checkin.month.toString().padLeft(2, '0')}-${checkin.day.toString().padLeft(2, '0')}",
//         "checkout":
//             "${checkout.year.toString().padLeft(4, '0')}-${checkout.month.toString().padLeft(2, '0')}-${checkout.day.toString().padLeft(2, '0')}",
//         "extrabed": extrabed,
//         "maxAdults": maxAdults,
//         "maxChild": maxChild,
//         "quantity": quantity,
//         "totalpricewithouttax": totalpricewithouttax,
//         "discount": discount,
//       };
// }
