class RoomBookingRequest{
  String itemid;
  List<BkroomInf> bkroomInf;
  String userId;
  String currCode;
  String currRate;
  String currSymbol;
  String purpose;
  String officeLeisure;
  String paymethod;

  RoomBookingRequest(
        this.itemid,
        this.bkroomInf,
        this.userId,
        this.currCode,
        this.currRate,
        this.currSymbol,
        this.purpose,
        this.officeLeisure,
        this.paymethod);

  RoomBookingRequest.fromJson(Map<String, dynamic> json) {
    itemid = json['itemid'];
    if (json['bkroom_inf'] != null) {
      bkroomInf = new List<BkroomInf>();
      json['bkroom_inf'].forEach((v) {
        bkroomInf.add(new BkroomInf.fromJson(v));
      });
    }
    userId = json['user_id'];
    currCode = json['currCode'];
    currRate = json['currRate'];
    currSymbol = json['currSymbol'];
    purpose = json['purpose'];
    officeLeisure = json['officeLeisure'];
    paymethod = json['paymethod'];

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['itemid'] = this.itemid;
    if (this.bkroomInf != null) {
      data['bkroom_inf'] = this.bkroomInf.map((v) => v.toJson()).toList();
    }
    data['user_id'] = this.userId;
    data['currCode'] = this.currCode;
    data['currRate'] = this.currRate;
    data['currSymbol'] = this.currSymbol;
    data['purpose'] = this.purpose;
    data['officeLeisure'] = this.officeLeisure;
    data['paymethod'] = this.paymethod;
    return data;
  }
}

class BkroomInf {
  String id;
  String price;
  String count;
  String tax;
  String rckin;
  String rckout;

  BkroomInf(this.id, this.price, this.count, this.tax, this.rckin, this.rckout);

  BkroomInf.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    price = json['price'];
    count = json['count'];
    tax = json['tax'];
    rckin = json['rckin'];
    rckout = json['rckout'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['price'] = this.price;
    data['count'] = this.count;
    data['tax'] = this.tax;
    data['rckin'] = this.rckin;
    data['rckout'] = this.rckout;
    return data;
  }
}