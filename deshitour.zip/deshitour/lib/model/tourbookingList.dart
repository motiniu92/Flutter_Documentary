class TourBookingList{
  String name;
  String passport;
  String age;
  TourBookingList(this.name, this.passport, this.age);


}