// To parse this JSON data, do
//
//     final tourCountryFilter = tourCountryFilterFromJson(jsonString);

import 'dart:convert';

TourCountryFilter tourCountryFilterFromJson(String str) => TourCountryFilter.fromJson(json.decode(str));

String tourCountryFilterToJson(TourCountryFilter data) => json.encode(data.toJson());

class TourCountryFilter {
    TourCountryFilter({
        this.response,
        this.error,
    });

    List<TourCountry> response;
    Error error;

    factory TourCountryFilter.fromJson(Map<String, dynamic> json) => TourCountryFilter(
        response: List<TourCountry>.from(json["response"].map((x) => TourCountry.fromJson(x))),
        error: Error.fromJson(json["error"]),
    );

    Map<String, dynamic> toJson() => {
        "response": List<dynamic>.from(response.map((x) => x.toJson())),
        "error": error.toJson(),
    };
}

class Error {
    Error({
        this.status,
        this.msg,
    });

    bool status;
    String msg;

    factory Error.fromJson(Map<String, dynamic> json) => Error(
        status: json["status"],
        msg: json["msg"],
    );

    Map<String, dynamic> toJson() => {
        "status": status,
        "msg": msg,
    };
}

class TourCountry {
    TourCountry({
        this.tourCountry,
    });

    String tourCountry;

    factory TourCountry.fromJson(Map<String, dynamic> json) => TourCountry(
        tourCountry: json["tour_country"],
    );

    Map<String, dynamic> toJson() => {
        "tour_country": tourCountry,
    };
}
