class LoginResponse {
  Response response;
  Error error;

  LoginResponse({this.response, this.error});

  LoginResponse.fromJson(Map<String, dynamic> json) {
    response = json['response'] != null
        ? new Response.fromJson(json['response'])
        : null;
    error = json['error'] != null ? new Error.fromJson(json['error']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.response != null) {
      data['response'] = this.response.toJson();
    }
    if (this.error != null) {
      data['error'] = this.error.toJson();
    }
    return data;
  }
}

class Response {
  Verify verify;
  String token;

  Response({this.verify, this.token});

  Response.fromJson(Map<String, dynamic> json) {
    verify =
    json['verify'] != null ? new Verify.fromJson(json['verify']) : null;
    token = json['token'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.verify != null) {
      data['verify'] = this.verify.toJson();
    }
    data['token'] = this.token;
    return data;
  }
}

class Verify {
  bool status;
  bool isVerified;
  UserData userData;

  Verify({this.status, this.isVerified, this.userData});

  Verify.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    isVerified = json['isVerified'];
    userData = json['userData'] != null
        ? new UserData.fromJson(json['userData'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['isVerified'] = this.isVerified;
    if (this.userData != null) {
      data['userData'] = this.userData.toJson();
    }
    return data;
  }
}

class UserData {
  String email;
  String id;
  String firstName;
  String lastName;
  String status;

  UserData({this.email, this.id, this.firstName, this.lastName, this.status});

  UserData.fromJson(Map<String, dynamic> json) {
    email = json['email'];
    id = json['id'];
    firstName = json['firstName'];
    lastName = json['lastName'];
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['email'] = this.email;
    data['id'] = this.id;
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    data['status'] = this.status;
    return data;
  }
}

class Error {
  bool status;
  String msg;

  Error({this.status, this.msg});

  Error.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    msg = json['msg'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['msg'] = this.msg;
    return data;
  }
}

