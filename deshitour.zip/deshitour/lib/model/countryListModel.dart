// /*
// class CountryListModel {
//   List<CountryListResponse> countryListResponse;
//
//   CountryListModel({this.countryListResponse});
//
//   CountryListModel.fromJson(Map<String, dynamic> json) {
//     if (json['response'] != null) {
//       // ignore: deprecated_member_use
//       countryListResponse = new List<CountryListResponse>();
//       json['response'].forEach((v) {
//         countryListResponse.add(new CountryListResponse.fromJson(v));
//       });
//     }
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     if (this.countryListResponse != null) {
//       data['response'] = this.countryListResponse.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }
//
// class CountryListResponse {
//   String name;
//   String code;
//
//   CountryListResponse({this.name, this.code});
//
//   CountryListResponse.fromJson(Map<String, dynamic> json) {
//     name = json['name'];
//     code = json['code'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['name'] = this.name;
//     data['code'] = this.code;
//     return data;
//   }
// }
// */
// To parse this JSON data, do
//
//     final signupSearch = signupSearchFromJson(jsonString);

import 'dart:convert';

SignupSearch signupSearchFromJson(String str) => SignupSearch.fromJson(json.decode(str));

String signupSearchToJson(SignupSearch data) => json.encode(data.toJson());

class SignupSearch {
  SignupSearch({
    this.response,
  });

  List<ResponseSearch> response;

  factory SignupSearch.fromJson(Map<String, dynamic> json) => SignupSearch(
    response: List<ResponseSearch>.from(json["response"].map((x) => ResponseSearch.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "response": List<dynamic>.from(response.map((x) => x.toJson())),
  };
}

class ResponseSearch {
  ResponseSearch({
    this.name,
    this.code,
  });

  String name;
  String code;

  factory ResponseSearch.fromJson(Map<String, dynamic> json) => ResponseSearch(
    name: json["name"],
    code: json["code"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "code": code,
  };
}
