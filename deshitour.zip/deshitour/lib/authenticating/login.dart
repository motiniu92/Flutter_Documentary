// // // import 'dart:async';
// //
// // // import 'package:flutter/material.dart';
// // // import 'package:get/route_manager.dart';
// // // import 'package:new_motel/authenticating/register.dart';
// // // import 'package:new_motel/widget/custom_TextField.dart';
// //
// // // class Login extends StatefulWidget {
// // //   @override
// // //   _LoginState createState() => _LoginState();
// // // }
// //
// // // class _LoginState extends State<Login> {
// // //   final TextEditingController _emailEditingController = TextEditingController();
// // //   final TextEditingController _passwordEditingController =
// // //       TextEditingController();
// // //   final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
// //
// // //   @override
// // //   Widget build(BuildContext context) {
// // //     double _screenWidth = MediaQuery.of(context).size.width,
// // //         _screenHeight = MediaQuery.of(context).size.height;
// // //     return SafeArea(
// // //       child: Scaffold(
// // //         body: Center(
// // //           child: Container(
// // //             child: SingleChildScrollView(
// // //               child: Column(
// // //                 mainAxisAlignment: MainAxisAlignment.center,
// // //                 children: [
// // //                   Form(
// // //                     key: _formKey,
// // //                     child: Column(
// // //                       children: [
// // //                         CustomTextField(
// // //                           controller: _emailEditingController,
// // //                           hintText: "Email",
// // //                           isObsecure: false,
// // //                           data: Icons.mail_outline,
// // //                         ),
// // //                         CustomTextField(
// // //                             controller: _passwordEditingController,
// // //                             hintText: "Password",
// // //                             isObsecure: true,
// // //                             data: Icons.lock_open),
// // //                         SizedBox(
// // //                           height: 8,
// // //                         ),
// // //                         Container(
// // //                           height: 45,
// // //                           width: 200,
// // //                           child: RaisedButton(
// // //                             shape: RoundedRectangleBorder(
// // //                                 borderRadius: BorderRadius.circular(10)),
// // //                             onPressed: () {},
// // //                             color: Colors.indigo[800],
// // //                             child: Text(
// // //                               "Login",
// // //                               style:
// // //                                   TextStyle(fontSize: 17, color: Colors.white),
// // //                             ),
// // //                           ),
// // //                         ),
// // //                         SizedBox(
// // //                           height: 18,
// // //                         ),
// // //                         Row(
// // //                           mainAxisAlignment: MainAxisAlignment.center,
// // //                           children: [
// // //                             Text(
// // //                               'Don\'t have account?',
// // //                               style: TextStyle(
// // //                                   fontSize: 16, color: Colors.indigo[800]),
// // //                             ),
// // //                             SizedBox(
// // //                               width: 5,
// // //                             ),
// // //                             GestureDetector(
// // //                               onTap: () {
// // //                                 Navigator.push(
// // //                                     context,
// // //                                     MaterialPageRoute(
// // //                                         builder: (context) => Register()));
// // //                               },
// // //                               child: Text(
// // //                                 'Sign up',
// // //                                 style: TextStyle(
// // //                                     fontWeight: FontWeight.bold,
// // //                                     fontSize: 19,
// // //                                     color: Colors.indigo[800],
// // //                                     decoration: TextDecoration.underline,
// // //                                     decorationThickness: 2),
// // //                               ),
// // //                             ),
// // //                           ],
// // //                         ),
// // //                         SizedBox(
// // //                           height: 25,
// // //                         ),
// // //                         SizedBox(
// // //                           height: 18,
// // //                         ),
// // //                       ],
// // //                     ),
// // //                   ),
// // //                 ],
// // //               ),
// // //             ),
// // //           ),
// // //         ),
// // //       ),
// // //     );
// // //   }
// // // }
// //
// // import 'dart:convert';
// // import 'dart:io';
// // import 'dart:math';
// // import 'package:flutter/material.dart';
// // import 'package:fluttertoast/fluttertoast.dart';
// // import 'package:new_motel/appTheme.dart';
// // import 'package:new_motel/authenticating/login_model.dart';
// // import 'package:new_motel/authenticating/register.dart';
// // import 'package:new_motel/loaderPage.dart';
// // import 'package:new_motel/models/bookingDetails.dart';
// // import 'package:new_motel/models/hotelList/hotelDetails.dart';
// // import 'package:new_motel/models/tour/toursDetails.dart';
// // import 'package:new_motel/modules/bottomTab/bottomTabScreen.dart';
// // import 'package:new_motel/modules/login/forgotPassword.dart';
// // import 'package:new_motel/modules/profile/profileScreen.dart';
// // import 'package:new_motel/modules/profile/userProfile.dart';
// // import 'package:new_motel/provider/authenticate.dart';
// // import 'package:new_motel/screens/hotel_room_details_screen.dart';
// // import 'package:new_motel/screens/profile_page.dart';
// // import 'package:new_motel/screens/sign_up_screen.dart';
// // import 'package:new_motel/tourBooking/tourBookingScreen.dart';
// // import 'package:new_motel/tourBooking/tourDetails.dart';
// // import 'package:new_motel/tourBooking/tour_details_screen.dart';
// // import 'package:new_motel/utils/constants.dart';
// // import 'package:new_motel/widget/register_widget.dart';
// // import 'package:provider/provider.dart';
// // import 'package:shared_preferences/shared_preferences.dart';
// // import 'package:http/http.dart' as http;
// //
// // class LoginWidget extends StatefulWidget {
// //   final List<BookingDetails> rr;
// //   final int days;
// //   final HotelDetailsResponse hotelDetails;
// //   final String type;
// //
// //   final int totalGuest;
// //   final int adults;
// //   final int child;
// //   final Tour tour;
// //   final String total_amount;
// //   final String deposit;
// //
// //   const LoginWidget(
// //       {Key key,
// //       @required this.hotelDetails,
// //       @required this.rr,
// //       @required this.days,
// //       @required this.type,
// //       @required this.totalGuest,
// //       @required this.adults,
// //       @required this.child,
// //       @required this.tour,
// //       @required this.total_amount,
// //       @required this.deposit})
// //       : super(key: key);
// //   @override
// //   _LoginWidgetState createState() => _LoginWidgetState();
// // }
// //
// // class _LoginWidgetState extends State<LoginWidget> {
// //   List<BookingDetails> bookingList = List<BookingDetails>();
// //   // List<BookingDetails> finalBookingList = List<BookingDetails>();
// //
// //   final emailController = TextEditingController();
// //   final passcontroller = TextEditingController();
// //   bool isLoading = false;
// //   bool _showPassword = false;
// //   final _key = GlobalKey<FormState>();
// //   String email, password;
// //   LoginRequestModel loginRequestModel;
// //   bool status;
// //   String errorMessage;
// //   //bool isLoading = false;
// //
// //   //<---------------------------Save Token
// //   Future saveToken(value) async {
// //     // Async func to handle Futures easier; or use Future.then
// //     SharedPreferences prefs = await SharedPreferences.getInstance();
// //     prefs.setString('apiToken', value);
// //     return prefs.setString("apiToken", value);
// //   }
// //
// //   login(LoginRequestModel requestModel) async {
// //     String url = "https://deshitour.com/api/login/check?appKey=DeshiTour";
// //     try {
// //       setState(() {
// //         isLoading = true;
// //       });
// //       final response = await http.post(
// //         url,
// //         body: requestModel.toJson(),
// //       );
// //
// //       //     .timeout(
// //       //   Duration(seconds: 60),
// //       //   onTimeout: () {
// //       //     // time has run out, do what you wanted to do
// //       //     Fluttertoast.showToast(msg: "Request Login Server timeout");
// //       //
// //       //     return null;
// //       //   },
// //       // );
// //       print('API ${response.statusCode}\n API${json.decode(response.body)}');
// //
// //       // return LoginResponseModel.fromJson();
// //       bool isSuccess = response.statusCode == 200;
// //       status = json.decode(response.body)['error']['status'];
// //       var data = json.decode(response.body);
// //       print("Login Token....>>>$data");
// //       print(
// //           "Login Token.....status...>>>${json.decode(response.body)['error']['status']}");
// //       errorMessage = json.decode(response.body)['error']['msg'];
// //
// //       return {
// //         'isSuccess': isSuccess,
// //         'token': isSuccess ? data['response']['token'] : null,
// //         "firstName": isSuccess
// //             ? data['response']['verify']['userData']['firstName']
// //             : null,
// //         "lastName": isSuccess
// //             ? data['response']['verify']['userData']['lastName']
// //             : null,
// //         "email":
// //             isSuccess ? data['response']['verify']['userData']['email'] : null,
// //         "phone":
// //             isSuccess ? data['response']['verify']['userData']['phone'] : null,
// //         "id": isSuccess ? data['response']['verify']['userData']['id'] : null,
// //         'error': isSuccess ? null : data['error']['msg'],
// //       };
// //     } catch (e) {
// //       setState(() {
// //         isLoading = false;
// //       });
// //     }
// //   }
// //
// //   final _scaffoldKey = GlobalKey<ScaffoldState>();
// //   _showMsg(msg) {
// //     final snackBar = SnackBar(
// //       content: Text(msg),
// //       action: SnackBarAction(
// //         label: 'Close',
// //         onPressed: () {
// //           // Some code to undo the change!
// //         },
// //       ),
// //     );
// //     _scaffoldKey.currentState.showSnackBar(snackBar);
// //   }
// //
// //   // checkApiLogin() async {
// //   //   final form = _key.currentState;
// //   //   if (form.validate()) {
// //   //     setState(() {
// //   //       isLoading = true;
// //   //     });
// //   //     form.save();
// //   //     login();
// //   //     //      print("$name  $password");
// //   //   } else {
// //   //     setState(() {
// //   //       isLoading = false;
// //   //     });
// //   //   }
// //   // }
// //
// //   // login() async {
// //   //   var response = await http.post(
// //   //     "https://deshitour.com/api/login/check?appKey=DeshiTour",
// //   //     body: {"email": email, "password": password},
// //   //   );
// //   //
// //   //   final data = json.decode(response.body);
// //   //   print(data);
// //   //
// //   //   bool success = data["response"];
// //   //   String pMessage = data["msg"];
// //   //
// //   //   if (success) {
// //   //     Map user = json.decode(response.body);
// //   //     if (user['response']['token'] != null) {
// //   //       print(user['response']['token']);
// //   //       Navigator.of(context).pushAndRemoveUntil(
// //   //           MaterialPageRoute(
// //   //             builder: (BuildContext context) => ProfileScreenPage(),
// //   //           ),
// //   //           (Route<dynamic> route) => false);
// //   //       // Navigator.push(context,
// //   //       //     MaterialPageRoute(builder: (context) => ProfileScreenPage()));
// //   //       Fluttertoast.showToast(
// //   //           msg: ('login_successfully'),
// //   //           toastLength: Toast.LENGTH_SHORT,
// //   //           gravity: ToastGravity.BOTTOM,
// //   //           timeInSecForIosWeb: 2,
// //   //           backgroundColor: Colors.indigo,
// //   //           textColor: Colors.white,
// //   //           fontSize: 16.0);
// //   //
// //   //       print(pMessage);
// //   //     }
// //   //   } else {
// //   //     setState(() {
// //   //       isLoading = false;
// //   //     });
// //   //     _showMsg(data['msg']);
// //   //   }
// //   // }
// //
// //   bool _autoValidate = false;
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     loginRequestModel = LoginRequestModel();
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return isLoading
// //         ? Center(
// //             child: LoaderPage(),
// //           )
// //         : SafeArea(
// //             child: Scaffold(
// //               key: _scaffoldKey,
// //               backgroundColor: Colors.white,
// //               appBar: AppBar(
// //                 title: RichText(
// //                   text: TextSpan(
// //                       text: DESHI,
// //                       style: TextStyle(
// //                         fontSize: 30,
// //                         fontFamily: 'Impact',
// //                         color: HexColor("#26408A"),
// //                       ),
// //                       children: <TextSpan>[
// //                         TextSpan(
// //                             text: TOUR,
// //                             style: TextStyle(
// //                               fontSize: 30,
// //                               fontFamily: 'Impact',
// //                               color: HexColor("#118ACB"),
// //                             )),
// //                       ]),
// //                 ),
// //                 backgroundColor: Colors.white,
// //                 elevation: 1,
// //                 leading: IconButton(
// //                     icon: Icon(
// //                       Icons.arrow_back,
// //                       color: Colors.black,
// //                     ),
// //                     onPressed: () {
// //                       Navigator.pop(context);
// //                       // Navigator.push(
// //                       //     context,
// //                       //     MaterialPageRoute(
// //                       //         builder: (context) => ProfileScreen()));
// //                     }),
// //               ),
// //               body: Center(
// //                 child: Padding(
// //                   padding: const EdgeInsets.symmetric(horizontal: 5),
// //                   child: SingleChildScrollView(
// //                     child: Form(
// //                       autovalidate: _autoValidate,
// //                       key: _key,
// //                       child: Column(
// //                         children: [
// //                           SizedBox(
// //                             height: 30,
// //                           ),
// //                           Container(
// //                             child: Padding(
// //                               padding: const EdgeInsets.symmetric(
// //                                   horizontal: 10, vertical: 15),
// //                               child: Column(
// //                                 crossAxisAlignment: CrossAxisAlignment.end,
// //                                 mainAxisAlignment: MainAxisAlignment.center,
// //                                 children: [
// //                                   Padding(
// //                                     padding: const EdgeInsets.only(
// //                                         left: 24, right: 24),
// //                                     child: Container(
// //                                       decoration: BoxDecoration(
// //                                         color:
// //                                             AppTheme.getTheme().backgroundColor,
// //                                         borderRadius: BorderRadius.all(
// //                                             Radius.circular(38)),
// //                                         // border: Border.all(
// //                                         //   color: HexColor("#757575").withOpacity(0.6),
// //                                         // ),
// //                                         boxShadow: <BoxShadow>[
// //                                           BoxShadow(
// //                                             color: AppTheme.getTheme()
// //                                                 .dividerColor,
// //                                             blurRadius: 8,
// //                                             offset: Offset(4, 4),
// //                                           ),
// //                                         ],
// //                                       ),
// //                                       child: Padding(
// //                                         padding: const EdgeInsets.only(
// //                                             left: 16, right: 16),
// //                                         child: Container(
// //                                           height: 48,
// //                                           child: Center(
// //                                             child: TextFormField(
// //                                               // autovalidate: true,
// //                                               controller: emailController,
// //                                               keyboardType:
// //                                                   TextInputType.emailAddress,
// //                                               validator: (value) {
// //                                                 if (value.isEmpty) {
// //                                                   return 'Enter your email';
// //                                                 }
// //
// //                                                 return null;
// //                                               },
// //                                               onChanged: (numVal) {
// //                                                 loginRequestModel.email =
// //                                                     numVal;
// //                                                 setState(() {
// //                                                   email = numVal.trim();
// //                                                 });
// //                                               },
// //                                               maxLines: 1,
// //                                               style: TextStyle(
// //                                                 fontSize: 16,
// //                                               ),
// //                                               cursorColor: AppTheme.getTheme()
// //                                                   .primaryColor,
// //                                               decoration: new InputDecoration(
// //                                                 errorText: null,
// //                                                 border: InputBorder.none,
// //                                                 hintText: "Email",
// //                                                 hintStyle: TextStyle(
// //                                                     color: AppTheme.getTheme()
// //                                                         .disabledColor),
// //                                               ),
// //                                             ),
// //                                           ),
// //                                         ),
// //                                       ),
// //                                     ),
// //                                   ),
// //                                   SizedBox(
// //                                     height: 16,
// //                                   ),
// //
// //                                   Padding(
// //                                     padding: const EdgeInsets.only(
// //                                         left: 24, right: 24),
// //                                     child: Container(
// //                                       decoration: BoxDecoration(
// //                                         color:
// //                                             AppTheme.getTheme().backgroundColor,
// //                                         borderRadius: BorderRadius.all(
// //                                             Radius.circular(38)),
// //                                         // border: Border.all(
// //                                         //   color: HexColor("#757575").withOpacity(0.6),
// //                                         // ),
// //                                         boxShadow: <BoxShadow>[
// //                                           BoxShadow(
// //                                             color: AppTheme.getTheme()
// //                                                 .dividerColor,
// //                                             blurRadius: 8,
// //                                             offset: Offset(4, 4),
// //                                           ),
// //                                         ],
// //                                       ),
// //                                       child: Padding(
// //                                         padding: const EdgeInsets.only(
// //                                             left: 16, right: 16),
// //                                         child: Container(
// //                                           height: 48,
// //                                           child: Center(
// //                                             child: TextFormField(
// //                                               //   autovalidate: true,
// //                                               controller: passcontroller,
// //                                               onChanged: (numVal) {
// //                                                 loginRequestModel.password =
// //                                                     numVal;
// //
// //                                                 setState(() {
// //                                                   password = numVal.trim();
// //                                                 });
// //                                               },
// //                                               validator: (value) {
// //                                                 if (value == null ||
// //                                                     value.isEmpty) {
// //                                                   return ('Enter your valid password');
// //                                                 }
// //                                                 return null;
// //                                               },
// //                                               obscureText: !_showPassword,
// //                                               style: TextStyle(
// //                                                 fontSize: 16,
// //                                               ),
// //                                               cursorColor: AppTheme.getTheme()
// //                                                   .primaryColor,
// //                                               decoration: new InputDecoration(
// //                                                 errorText: null,
// //                                                 border: InputBorder.none,
// //                                                 suffixIcon: GestureDetector(
// //                                                   onTap: () {
// //                                                     setState(() {
// //                                                       _showPassword =
// //                                                           !_showPassword;
// //                                                     });
// //                                                   },
// //                                                   child: Icon(_showPassword
// //                                                       ? Icons.visibility
// //                                                       : Icons.visibility_off),
// //                                                 ),
// //                                                 hintText: "Password",
// //                                                 hintStyle: TextStyle(
// //                                                     color: AppTheme.getTheme()
// //                                                         .disabledColor),
// //                                               ),
// //                                             ),
// //                                           ),
// //                                         ),
// //                                       ),
// //                                     ),
// //                                   ),
// //                                   InkWell(
// //                                     onTap: () {
// //                                       Navigator.push(
// //                                           context,
// //                                           MaterialPageRoute(
// //                                               builder: (context) =>
// //                                                   ForgotPasswordScreen()));
// //                                     },
// //                                     child: Padding(
// //                                       padding: const EdgeInsets.only(
// //                                           right: 40.0, top: 10),
// //                                       child: Text(
// //                                         "Forgot Password",
// //                                         style: TextStyle(
// //                                             fontSize: 18, color: Colors.black),
// //                                       ),
// //                                     ),
// //                                   ),
// //
// //                                   SizedBox(
// //                                     height: 20,
// //                                   ),
// //
// //                                   // TextFormField(
// //                                   //   validator: (value) {
// //                                   //     if (value == null || value.isEmpty) {
// //                                   //       return ('enter_your_valid_email_address');
// //                                   //     }
// //                                   //     return null;
// //                                   //   },
// //                                   //   onChanged: (numVal) {
// //                                   //     loginRequestModel.email = numVal;
// //                                   //     setState(() {
// //                                   //       email = numVal.trim();
// //                                   //     });
// //                                   //   },
// //                                   //   controller: emailController,
// //                                   //   keyboardType: TextInputType.text,
// //                                   //   decoration: InputDecoration(
// //                                   //     fillColor: Colors.grey[300],
// //                                   //     filled: true,
// //                                   //     border: OutlineInputBorder(
// //                                   //       borderSide: BorderSide.none,
// //                                   //       borderRadius: BorderRadius.circular(15),
// //                                   //     ),
// //                                   //     prefixIcon: Icon(
// //                                   //       Icons.email,
// //                                   //       color: Colors.indigo[800],
// //                                   //     ),
// //                                   //     hintText: "Email",
// //                                   //   ),
// //                                   // ),
// //                                   // SizedBox(
// //                                   //   height: 15,
// //                                   // ),
// //
// //                                   Padding(
// //                                     padding: const EdgeInsets.only(
// //                                         left: 24,
// //                                         right: 24,
// //                                         bottom: 8,
// //                                         top: 16),
// //                                     child: Container(
// //                                       height: 48,
// //                                       decoration: BoxDecoration(
// //                                         color: AppTheme.getTheme().primaryColor,
// //                                         borderRadius: BorderRadius.all(
// //                                             Radius.circular(24.0)),
// //                                         boxShadow: <BoxShadow>[
// //                                           BoxShadow(
// //                                             color: AppTheme.getTheme()
// //                                                 .dividerColor,
// //                                             blurRadius: 8,
// //                                             offset: Offset(4, 4),
// //                                           ),
// //                                         ],
// //                                       ),
// //                                       child: Material(
// //                                         color: Colors.transparent,
// //                                         child: InkWell(
// //                                           borderRadius: BorderRadius.all(
// //                                               Radius.circular(24.0)),
// //                                           highlightColor: Colors.transparent,
// //                                           onTap: () {
// //                                             setState(() {
// //                                               if (_key.currentState
// //                                                   .validate()) {
// //                                                 login(loginRequestModel)
// //                                                     .then((value) async {
// //                                                   if (!status) {
// //                                                     if (value['isSuccess']) {
// //                                                       saveToken(value['token']);
// //                                                       SharedPreferences
// //                                                           sharedPref =
// //                                                           await SharedPreferences
// //                                                               .getInstance();
// //                                                       sharedPref.setString(
// //                                                           'email',
// //                                                           value['email']);
// //                                                       sharedPref.setString(
// //                                                           'firstName',
// //                                                           value['firstName']);
// //                                                       sharedPref.setString(
// //                                                           'lastName',
// //                                                           value['lastName']);
// //                                                       sharedPref.setString(
// //                                                           'id', value['id']);
// //                                                       sharedPref.setString(
// //                                                           'phone',
// //                                                           value['phone']);
// //                                                       sharedPref.setString(
// //                                                           'token',
// //                                                           value['token']);
// //                                                       print(widget.type);
// //                                                       setState(() {
// //                                                         isLoading = true;
// //                                                       });
// //                                                       Fluttertoast.showToast(
// //                                                           msg:
// //                                                               ('Login Successfully'),
// //                                                           toastLength: Toast
// //                                                               .LENGTH_SHORT,
// //                                                           gravity: ToastGravity
// //                                                               .BOTTOM,
// //                                                           timeInSecForIosWeb: 2,
// //                                                           backgroundColor:
// //                                                               Colors.indigo,
// //                                                           textColor:
// //                                                               Colors.white,
// //                                                           fontSize: 16.0);
// //
// //                                                       //   Navigator.of(context).pop();
// //
// //                                                       Navigator.pop(
// //                                                           context, '1');
// //
// //                                                       if (widget.type ==
// //                                                           "hotel") {
// //                                                         Navigator.push(
// //                                                             context,
// //                                                             MaterialPageRoute(
// //                                                                 builder:
// //                                                                     (context) =>
// //                                                                         HotelRoomFormPage(
// //                                                                           days:
// //                                                                               widget.days,
// //                                                                           rr: widget
// //                                                                               .rr,
// //                                                                           hotel:
// //                                                                               widget.hotelDetails,
// //                                                                         )));
// //                                                       } else {
// //                                                         // Fluttertoast.showToast(
// //                                                         //     msg: ('Login Failed'),
// //                                                         //     toastLength:
// //                                                         //         Toast.LENGTH_SHORT,
// //                                                         //     gravity:
// //                                                         //         ToastGravity.BOTTOM,
// //                                                         //     timeInSecForIosWeb: 2,
// //                                                         //     backgroundColor:
// //                                                         //         Colors.indigo,
// //                                                         //     textColor: Colors.white,
// //                                                         //     fontSize: 16.0);
// //                                                       }
// //
// //                                                       print(
// //                                                           "\n\nTOKEN>>>>${value['token']}");
// //                                                     }
// //                                                   } else {
// //                                                     setState(() {
// //                                                       isLoading = false;
// //                                                     });
// //                                                     Fluttertoast.showToast(
// //                                                         msg: errorMessage,
// //                                                         toastLength:
// //                                                             Toast.LENGTH_SHORT,
// //                                                         gravity:
// //                                                             ToastGravity.BOTTOM,
// //                                                         timeInSecForIosWeb: 4,
// //                                                         backgroundColor:
// //                                                             Colors.indigo,
// //                                                         textColor: Colors.white,
// //                                                         fontSize: 20.0);
// //                                                   }
// //                                                   Navigator.of(context);
// //
// //                                                   setState(() {});
// //                                                 });
// //                                               } else {
// //                                                 setState(() {
// //                                                   _autoValidate = true;
// //                                                 });
// //                                               }
// //                                             });
// //                                           },
// //                                           child: Center(
// //                                             child: Text(
// //                                               "Sign In",
// //                                               style: TextStyle(
// //                                                   fontWeight: FontWeight.w500,
// //                                                   fontSize: 16,
// //                                                   color: Colors.white),
// //                                             ),
// //                                           ),
// //                                         ),
// //                                       ),
// //                                     ),
// //                                   ),
// //                                   SizedBox(
// //                                     height: 10,
// //                                   ),
// //
// //                                   Row(
// //                                     mainAxisAlignment: MainAxisAlignment.center,
// //                                     crossAxisAlignment:
// //                                         CrossAxisAlignment.center,
// //                                     children: [
// //                                       Text(
// //                                         "Don't have an account?  ",
// //                                         style: TextStyle(fontSize: 17),
// //                                       ),
// //                                       GestureDetector(
// //                                           onTap: () {
// //                                             Navigator.push(
// //                                                 context,
// //                                                 MaterialPageRoute(
// //                                                     builder: (context) =>
// //                                                         SignUpSreen()));
// //                                           },
// //                                           child: Container(
// //                                               child: Text(
// //                                             "SignUp",
// //                                             style: TextStyle(
// //                                                 fontSize: 20,
// //                                                 fontWeight: FontWeight.bold,
// //                                                 color: Colors.indigo[800]),
// //                                           ))),
// //                                     ],
// //                                   ),
// //                                 ],
// //                               ),
// //                             ),
// //                           ),
// //                         ],
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //               ),
// //             ),
// //           );
// //   }
// // }
//
// // import 'dart:async';
//
// // import 'package:flutter/material.dart';
// // import 'package:get/route_manager.dart';
// // import 'package:new_motel/authenticating/register.dart';
// // import 'package:new_motel/widget/custom_TextField.dart';
//
// // class Login extends StatefulWidget {
// //   @override
// //   _LoginState createState() => _LoginState();
// // }
//
// // class _LoginState extends State<Login> {
// //   final TextEditingController _emailEditingController = TextEditingController();
// //   final TextEditingController _passwordEditingController =
// //       TextEditingController();
// //   final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
//
// //   @override
// //   Widget build(BuildContext context) {
// //     double _screenWidth = MediaQuery.of(context).size.width,
// //         _screenHeight = MediaQuery.of(context).size.height;
// //     return SafeArea(
// //       child: Scaffold(
// //         body: Center(
// //           child: Container(
// //             child: SingleChildScrollView(
// //               child: Column(
// //                 mainAxisAlignment: MainAxisAlignment.center,
// //                 children: [
// //                   Form(
// //                     key: _formKey,
// //                     child: Column(
// //                       children: [
// //                         CustomTextField(
// //                           controller: _emailEditingController,
// //                           hintText: "Email",
// //                           isObsecure: false,
// //                           data: Icons.mail_outline,
// //                         ),
// //                         CustomTextField(
// //                             controller: _passwordEditingController,
// //                             hintText: "Password",
// //                             isObsecure: true,
// //                             data: Icons.lock_open),
// //                         SizedBox(
// //                           height: 8,
// //                         ),
// //                         Container(
// //                           height: 45,
// //                           width: 200,
// //                           child: RaisedButton(
// //                             shape: RoundedRectangleBorder(
// //                                 borderRadius: BorderRadius.circular(10)),
// //                             onPressed: () {},
// //                             color: Colors.indigo[800],
// //                             child: Text(
// //                               "Login",
// //                               style:
// //                                   TextStyle(fontSize: 17, color: Colors.white),
// //                             ),
// //                           ),
// //                         ),
// //                         SizedBox(
// //                           height: 18,
// //                         ),
// //                         Row(
// //                           mainAxisAlignment: MainAxisAlignment.center,
// //                           children: [
// //                             Text(
// //                               'Don\'t have account?',
// //                               style: TextStyle(
// //                                   fontSize: 16, color: Colors.indigo[800]),
// //                             ),
// //                             SizedBox(
// //                               width: 5,
// //                             ),
// //                             GestureDetector(
// //                               onTap: () {
// //                                 Navigator.push(
// //                                     context,
// //                                     MaterialPageRoute(
// //                                         builder: (context) => Register()));
// //                               },
// //                               child: Text(
// //                                 'Sign up',
// //                                 style: TextStyle(
// //                                     fontWeight: FontWeight.bold,
// //                                     fontSize: 19,
// //                                     color: Colors.indigo[800],
// //                                     decoration: TextDecoration.underline,
// //                                     decorationThickness: 2),
// //                               ),
// //                             ),
// //                           ],
// //                         ),
// //                         SizedBox(
// //                           height: 25,
// //                         ),
// //                         SizedBox(
// //                           height: 18,
// //                         ),
// //                       ],
// //                     ),
// //                   ),
// //                 ],
// //               ),
// //             ),
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// // }
// import 'dart:convert';
//
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:http/http.dart' as http;
// import 'package:new_motel/appTheme.dart';
// import 'package:new_motel/authenticating/login_model.dart';
// import 'package:new_motel/loaderPage.dart';
// import 'package:new_motel/models/bookingDetails.dart';
// import 'package:new_motel/models/hotelList/hotelDetails.dart';
// import 'package:new_motel/models/tour/toursDetails.dart';
// import 'package:new_motel/modules/login/forgotPassword.dart';
// import 'package:new_motel/screens/hotel_room_details_screen.dart';
// import 'package:new_motel/screens/sign_up_screen.dart';
// import 'package:new_motel/utils/constants.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// class LoginWidget extends StatefulWidget {
//   final List<BookingDetails> rr;
//   final HotelDetailsResponse hotelDetails;
//   final String type;
//   final int days;
//   final int totalGuest;
//   final int adults;
//   final int child;
//   final Tour tour;
//   final String total_amount;
//   final String deposit;
//
//   const LoginWidget(
//       {Key key,
//       @required this.hotelDetails,
//       @required this.rr,
//       this.days,
//       @required this.type,
//       @required this.totalGuest,
//       @required this.adults,
//       @required this.child,
//       @required this.tour,
//       @required this.total_amount,
//       @required this.deposit})
//       : super(key: key);
//   @override
//   _LoginWidgetState createState() => _LoginWidgetState();
// }
//
// class _LoginWidgetState extends State<LoginWidget> {
//   List<BookingDetails> bookingList = List<BookingDetails>();
//   // List<BookingDetails> finalBookingList = List<BookingDetails>();
//
//   final emailController = TextEditingController();
//   final passcontroller = TextEditingController();
//   bool isLoading = false;
//   bool _showPassword = false;
//   final _key = GlobalKey<FormState>();
//   String email, password;
//   LoginRequestModel loginRequestModel;
//   int status;
//   String errorMessage;
//   //bool isLoading = false;
//
//   //<---------------------------Save Token
//   Future saveToken(value) async {
//     // Async func to handle Futures easier; or use Future.then
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     prefs.setString('apiToken', value);
//     return prefs.setString("apiToken", value);
//   }
//
//   login(LoginRequestModel requestModel) async {
//     String url = "https://deshitour.com/api/login/check?appKey=DeshiTour";
//     try {
//       setState(() {
//         isLoading = true;
//       });
//       final response = await http.post(
//         url,
//         body: requestModel.toJson(),
//       );
//
//       //     .timeout(
//       //   Duration(seconds: 60),
//       //   onTimeout: () {
//       //     // time has run out, do what you wanted to do
//       //     Fluttertoast.showToast(msg: "Request Login Server timeout");
//       //
//       //     return null;
//       //   },
//       // );
//       print('API ${response.statusCode}\n API${json.decode(response.body)}');
//
//       // return LoginResponseModel.fromJson();
//       status = json.decode(response.body)['status'];
//       print("Status ${json.decode(response.body)['status']}");
//
//       bool isSuccess = false;
//       if (response.statusCode == 200) {
//         isSuccess = true;
//       }
//       print("Login status code....>>>$isSuccess");
//       var data = json.decode(response.body);
//       print("Login Token....>>>$data");
//       print(
//           "Login Token.....status...>>>${json.decode(response.body)['status']}");
//       errorMessage = json.decode(response.body)['msg'];
//
//       return {
//         'isSuccess': isSuccess,
//         'token': isSuccess ? data['token'] : null,
//         "firstName": isSuccess ? data['profile_info']['firstName'] : null,
//         "lastName": isSuccess ? data['profile_info']['lastName'] : null,
//         "email": isSuccess ? data['profile_info']['email'] : null,
//         "phone": isSuccess ? data['profile_info']['phone'] : null,
//         "id": isSuccess ? data['profile_info']['id'] : null,
//         'error': data['msg'],
//       };
//     } catch (e) {
//       setState(() {
//         isLoading = false;
//       });
//     }
//   }
//
//   final _scaffoldKey = GlobalKey<ScaffoldState>();
//   _showMsg(msg) {
//     final snackBar = SnackBar(
//       content: Text(msg),
//       action: SnackBarAction(
//         label: 'Close',
//         onPressed: () {
//           // Some code to undo the change!
//         },
//       ),
//     );
//     _scaffoldKey.currentState.showSnackBar(snackBar);
//   }
//
//   // checkApiLogin() async {
//   //   final form = _key.currentState;
//   //   if (form.validate()) {
//   //     setState(() {
//   //       isLoading = true;
//   //     });
//   //     form.save();
//   //     login();
//   //     //      print("$name  $password");
//   //   } else {
//   //     setState(() {
//   //       isLoading = false;
//   //     });
//   //   }
//   // }
//
//   // login() async {
//   //   var response = await http.post(
//   //     "https://deshitour.com/api/login/check?appKey=DeshiTour",
//   //     body: {"email": email, "password": password},
//   //   );
//   //
//   //   final data = json.decode(response.body);
//   //   print(data);
//   //
//   //   bool success = data["response"];
//   //   String pMessage = data["msg"];
//   //
//   //   if (success) {
//   //     Map user = json.decode(response.body);
//   //     if (user['response']['token'] != null) {
//   //       print(user['response']['token']);
//   //       Navigator.of(context).pushAndRemoveUntil(
//   //           MaterialPageRoute(
//   //             builder: (BuildContext context) => ProfileScreenPage(),
//   //           ),
//   //           (Route<dynamic> route) => false);
//   //       // Navigator.push(context,
//   //       //     MaterialPageRoute(builder: (context) => ProfileScreenPage()));
//   //       Fluttertoast.showToast(
//   //           msg: ('login_successfully'),
//   //           toastLength: Toast.LENGTH_SHORT,
//   //           gravity: ToastGravity.BOTTOM,
//   //           timeInSecForIosWeb: 2,
//   //           backgroundColor: Colors.indigo,
//   //           textColor: Colors.white,
//   //           fontSize: 16.0);
//   //
//   //       print(pMessage);
//   //     }
//   //   } else {
//   //     setState(() {
//   //       isLoading = false;
//   //     });
//   //     _showMsg(data['msg']);
//   //   }
//   // }
//
//   bool _autoValidate = false;
//
//   @override
//   void initState() {
//     super.initState();
//     loginRequestModel = LoginRequestModel();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return isLoading
//         ? Center(
//             child: LoaderPage(),
//           )
//         : SafeArea(
//             child: Scaffold(
//               key: _scaffoldKey,
//               backgroundColor: Colors.white,
//               appBar: AppBar(
//                 title: RichText(
//                   text: TextSpan(
//                       text: DESHI,
//                       style: TextStyle(
//                         fontSize: 30,
//                         fontFamily: 'Impact',
//                         color: HexColor("#26408A"),
//                       ),
//                       children: <TextSpan>[
//                         TextSpan(
//                             text: TOUR,
//                             style: TextStyle(
//                               fontSize: 30,
//                               fontFamily: 'Impact',
//                               color: HexColor("#118ACB"),
//                             )),
//                       ]),
//                 ),
//                 backgroundColor: Colors.white,
//                 elevation: 1,
//                 leading: IconButton(
//                     icon: Icon(
//                       Icons.arrow_back,
//                       color: Colors.black,
//                     ),
//                     onPressed: () {
//                       Navigator.pop(context);
//                       // Navigator.push(
//                       //     context,
//                       //     MaterialPageRoute(
//                       //         builder: (context) => ProfileScreen()));
//                     }),
//               ),
//               body: Center(
//                 child: Padding(
//                   padding: const EdgeInsets.symmetric(horizontal: 5),
//                   child: SingleChildScrollView(
//                     child: Form(
//                       autovalidate: _autoValidate,
//                       key: _key,
//                       child: Column(
//                         children: [
//                           SizedBox(
//                             height: 30,
//                           ),
//                           Container(
//                             child: Padding(
//                               padding: const EdgeInsets.symmetric(
//                                   horizontal: 10, vertical: 15),
//                               child: Column(
//                                 crossAxisAlignment: CrossAxisAlignment.end,
//                                 mainAxisAlignment: MainAxisAlignment.center,
//                                 children: [
//                                   Padding(
//                                     padding: const EdgeInsets.only(
//                                         left: 24, right: 24),
//                                     child: Container(
//                                       decoration: BoxDecoration(
//                                         color:
//                                             AppTheme.getTheme().backgroundColor,
//                                         borderRadius: BorderRadius.all(
//                                             Radius.circular(38)),
//                                         // border: Border.all(
//                                         //   color: HexColor("#757575").withOpacity(0.6),
//                                         // ),
//                                         boxShadow: <BoxShadow>[
//                                           BoxShadow(
//                                             color: AppTheme.getTheme()
//                                                 .dividerColor,
//                                             blurRadius: 8,
//                                             offset: Offset(4, 4),
//                                           ),
//                                         ],
//                                       ),
//                                       child: Padding(
//                                         padding: const EdgeInsets.only(
//                                             left: 16, right: 16),
//                                         child: Container(
//                                           height: 48,
//                                           child: Center(
//                                             child: TextFormField(
//                                               // autovalidate: true,
//                                               controller: emailController,
//                                               keyboardType:
//                                                   TextInputType.emailAddress,
//                                               validator: (value) {
//                                                 if (value.isEmpty) {
//                                                   return 'Enter your email';
//                                                 }
//
//                                                 return null;
//                                               },
//                                               onChanged: (numVal) {
//                                                 loginRequestModel.email =
//                                                     numVal;
//                                                 setState(() {
//                                                   email = numVal.trim();
//                                                 });
//                                               },
//                                               maxLines: 1,
//                                               style: TextStyle(
//                                                 fontSize: 16,
//                                               ),
//                                               cursorColor: AppTheme.getTheme()
//                                                   .primaryColor,
//                                               decoration: new InputDecoration(
//                                                 errorText: null,
//                                                 border: InputBorder.none,
//                                                 hintText: "Email",
//                                                 hintStyle: TextStyle(
//                                                     color: AppTheme.getTheme()
//                                                         .disabledColor),
//                                               ),
//                                             ),
//                                           ),
//                                         ),
//                                       ),
//                                     ),
//                                   ),
//                                   SizedBox(
//                                     height: 16,
//                                   ),
//
//                                   Padding(
//                                     padding: const EdgeInsets.only(
//                                         left: 24, right: 24),
//                                     child: Container(
//                                       decoration: BoxDecoration(
//                                         color:
//                                             AppTheme.getTheme().backgroundColor,
//                                         borderRadius: BorderRadius.all(
//                                             Radius.circular(38)),
//                                         // border: Border.all(
//                                         //   color: HexColor("#757575").withOpacity(0.6),
//                                         // ),
//                                         boxShadow: <BoxShadow>[
//                                           BoxShadow(
//                                             color: AppTheme.getTheme()
//                                                 .dividerColor,
//                                             blurRadius: 8,
//                                             offset: Offset(4, 4),
//                                           ),
//                                         ],
//                                       ),
//                                       child: Padding(
//                                         padding: const EdgeInsets.only(
//                                             left: 16, right: 16),
//                                         child: Container(
//                                           height: 48,
//                                           child: Center(
//                                             child: TextFormField(
//                                               //   autovalidate: true,
//                                               controller: passcontroller,
//                                               onChanged: (numVal) {
//                                                 loginRequestModel.password =
//                                                     numVal;
//
//                                                 setState(() {
//                                                   password = numVal.trim();
//                                                 });
//                                               },
//                                               validator: (value) {
//                                                 if (value == null ||
//                                                     value.isEmpty) {
//                                                   return ('Enter your valid password');
//                                                 }
//                                                 return null;
//                                               },
//                                               obscureText: !_showPassword,
//                                               style: TextStyle(
//                                                 fontSize: 16,
//                                               ),
//                                               cursorColor: AppTheme.getTheme()
//                                                   .primaryColor,
//                                               decoration: new InputDecoration(
//                                                 errorText: null,
//                                                 border: InputBorder.none,
//                                                 suffixIcon: GestureDetector(
//                                                   onTap: () {
//                                                     setState(() {
//                                                       _showPassword =
//                                                           !_showPassword;
//                                                     });
//                                                   },
//                                                   child: Icon(_showPassword
//                                                       ? Icons.visibility
//                                                       : Icons.visibility_off),
//                                                 ),
//                                                 hintText: "Password",
//                                                 hintStyle: TextStyle(
//                                                     color: AppTheme.getTheme()
//                                                         .disabledColor),
//                                               ),
//                                             ),
//                                           ),
//                                         ),
//                                       ),
//                                     ),
//                                   ),
//                                   InkWell(
//                                     onTap: () {
//                                       Navigator.push(
//                                           context,
//                                           MaterialPageRoute(
//                                               builder: (context) =>
//                                                   ForgotPasswordScreen()));
//                                     },
//                                     child: Padding(
//                                       padding: const EdgeInsets.only(
//                                           right: 40.0, top: 10),
//                                       child: Text(
//                                         "Forgot Password",
//                                         style: TextStyle(
//                                             fontSize: 18, color: Colors.black),
//                                       ),
//                                     ),
//                                   ),
//
//                                   SizedBox(
//                                     height: 20,
//                                   ),
//
//                                   // TextFormField(
//                                   //   validator: (value) {
//                                   //     if (value == null || value.isEmpty) {
//                                   //       return ('enter_your_valid_email_address');
//                                   //     }
//                                   //     return null;
//                                   //   },
//                                   //   onChanged: (numVal) {
//                                   //     loginRequestModel.email = numVal;
//                                   //     setState(() {
//                                   //       email = numVal.trim();
//                                   //     });
//                                   //   },
//                                   //   controller: emailController,
//                                   //   keyboardType: TextInputType.text,
//                                   //   decoration: InputDecoration(
//                                   //     fillColor: Colors.grey[300],
//                                   //     filled: true,
//                                   //     border: OutlineInputBorder(
//                                   //       borderSide: BorderSide.none,
//                                   //       borderRadius: BorderRadius.circular(15),
//                                   //     ),
//                                   //     prefixIcon: Icon(
//                                   //       Icons.email,
//                                   //       color: Colors.indigo[800],
//                                   //     ),
//                                   //     hintText: "Email",
//                                   //   ),
//                                   // ),
//                                   // SizedBox(
//                                   //   height: 15,
//                                   // ),
//
//                                   Padding(
//                                     padding: const EdgeInsets.only(
//                                         left: 24,
//                                         right: 24,
//                                         bottom: 8,
//                                         top: 16),
//                                     child: Container(
//                                       height: 48,
//                                       decoration: BoxDecoration(
//                                         color: AppTheme.getTheme().primaryColor,
//                                         borderRadius: BorderRadius.all(
//                                             Radius.circular(24.0)),
//                                         boxShadow: <BoxShadow>[
//                                           BoxShadow(
//                                             color: AppTheme.getTheme()
//                                                 .dividerColor,
//                                             blurRadius: 8,
//                                             offset: Offset(4, 4),
//                                           ),
//                                         ],
//                                       ),
//                                       child: Material(
//                                         color: Colors.transparent,
//                                         child: InkWell(
//                                           borderRadius: BorderRadius.all(
//                                               Radius.circular(24.0)),
//                                           highlightColor: Colors.transparent,
//                                           onTap: () {
//                                             setState(() {
//                                               if (_key.currentState
//                                                   .validate()) {
//                                                 login(loginRequestModel)
//                                                     .then((value) async {
//                                                   print("Value: $value");
//                                                   if (value['isSuccess']) {
//                                                     if (status == 1) {
//                                                       saveToken(value['token']);
//                                                       SharedPreferences
//                                                           sharedPref =
//                                                           await SharedPreferences
//                                                               .getInstance();
//                                                       sharedPref.setString(
//                                                           'email',
//                                                           value['email']);
//                                                       sharedPref.setString(
//                                                           'firstName',
//                                                           value['firstName']);
//                                                       sharedPref.setString(
//                                                           'lastName',
//                                                           value['lastName']);
//                                                       sharedPref.setString(
//                                                           'id', value['id']);
//                                                       sharedPref.setString(
//                                                           'phone',
//                                                           value['phone']);
//                                                       sharedPref.setString(
//                                                           'token',
//                                                           value['token']);
//                                                       print(widget.type);
//                                                       setState(() {
//                                                         isLoading = true;
//                                                       });
//                                                       Fluttertoast.showToast(
//                                                           msg:
//                                                               ('Login Successfully'),
//                                                           toastLength: Toast
//                                                               .LENGTH_SHORT,
//                                                           gravity: ToastGravity
//                                                               .BOTTOM,
//                                                           timeInSecForIosWeb: 2,
//                                                           backgroundColor:
//                                                               Colors.indigo,
//                                                           textColor:
//                                                               Colors.white,
//                                                           fontSize: 16.0);
//
//                                                       //   Navigator.of(context).pop();
//
//                                                       Navigator.pop(
//                                                           context, '1');
//
//                                                       if (widget.type ==
//                                                           "hotel") {
//                                                         Navigator.push(
//                                                             context,
//                                                             MaterialPageRoute(
//                                                                 builder:
//                                                                     (context) =>
//                                                                         HotelRoomFormPage(
//                                                                           days:
//                                                                               widget.days,
//                                                                           rr: widget
//                                                                               .rr,
//                                                                           hotel:
//                                                                               widget.hotelDetails,
//                                                                         )));
//                                                       } else {
//                                                         // Fluttertoast.showToast(
//                                                         //     msg: ('Login Failed'),
//                                                         //     toastLength:
//                                                         //         Toast.LENGTH_SHORT,
//                                                         //     gravity:
//                                                         //         ToastGravity.BOTTOM,
//                                                         //     timeInSecForIosWeb: 2,
//                                                         //     backgroundColor:
//                                                         //         Colors.indigo,
//                                                         //     textColor: Colors.white,
//                                                         //     fontSize: 16.0);
//                                                       }
//
//                                                       print(
//                                                           "\n\nTOKEN>>>>${value['token']}");
//                                                     }
//                                                   } else {
//                                                     setState(() {
//                                                       isLoading = false;
//                                                     });
//                                                     Fluttertoast.showToast(
//                                                         msg: errorMessage,
//                                                         toastLength:
//                                                             Toast.LENGTH_SHORT,
//                                                         gravity:
//                                                             ToastGravity.BOTTOM,
//                                                         timeInSecForIosWeb: 4,
//                                                         backgroundColor:
//                                                             Colors.indigo,
//                                                         textColor: Colors.white,
//                                                         fontSize: 20.0);
//                                                   }
//                                                   Navigator.of(context);
//
//                                                   setState(() {});
//                                                 });
//                                               } else {
//                                                 setState(() {
//                                                   _autoValidate = true;
//                                                 });
//                                               }
//                                             });
//                                           },
//                                           child: Center(
//                                             child: Text(
//                                               "Sign In",
//                                               style: TextStyle(
//                                                   fontWeight: FontWeight.w500,
//                                                   fontSize: 16,
//                                                   color: Colors.white),
//                                             ),
//                                           ),
//                                         ),
//                                       ),
//                                     ),
//                                   ),
//                                   SizedBox(
//                                     height: 10,
//                                   ),
//
//                                   Row(
//                                     mainAxisAlignment: MainAxisAlignment.center,
//                                     crossAxisAlignment:
//                                         CrossAxisAlignment.center,
//                                     children: [
//                                       Text(
//                                         "Don't have an account?  ",
//                                         style: TextStyle(fontSize: 17),
//                                       ),
//                                       GestureDetector(
//                                           onTap: () {
//                                             Navigator.push(
//                                                 context,
//                                                 MaterialPageRoute(
//                                                     builder: (context) =>
//                                                         SignUpSreen()));
//                                           },
//                                           child: Container(
//                                               child: Text(
//                                             "SignUp",
//                                             style: TextStyle(
//                                                 fontSize: 20,
//                                                 fontWeight: FontWeight.bold,
//                                                 color: Colors.indigo[800]),
//                                           ))),
//                                     ],
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//           );
//   }
// }
// import 'dart:async';

// import 'package:flutter/material.dart';
// import 'package:get/route_manager.dart';
// import 'package:new_motel/authenticating/register.dart';
// import 'package:new_motel/widget/custom_TextField.dart';

// class Login extends StatefulWidget {
//   @override
//   _LoginState createState() => _LoginState();
// }

// class _LoginState extends State<Login> {
//   final TextEditingController _emailEditingController = TextEditingController();
//   final TextEditingController _passwordEditingController =
//       TextEditingController();
//   final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

//   @override
//   Widget build(BuildContext context) {
//     double _screenWidth = MediaQuery.of(context).size.width,
//         _screenHeight = MediaQuery.of(context).size.height;
//     return SafeArea(
//       child: Scaffold(
//         body: Center(
//           child: Container(
//             child: SingleChildScrollView(
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Form(
//                     key: _formKey,
//                     child: Column(
//                       children: [
//                         CustomTextField(
//                           controller: _emailEditingController,
//                           hintText: "Email",
//                           isObsecure: false,
//                           data: Icons.mail_outline,
//                         ),
//                         CustomTextField(
//                             controller: _passwordEditingController,
//                             hintText: "Password",
//                             isObsecure: true,
//                             data: Icons.lock_open),
//                         SizedBox(
//                           height: 8,
//                         ),
//                         Container(
//                           height: 45,
//                           width: 200,
//                           child: RaisedButton(
//                             shape: RoundedRectangleBorder(
//                                 borderRadius: BorderRadius.circular(10)),
//                             onPressed: () {},
//                             color: Colors.indigo[800],
//                             child: Text(
//                               "Login",
//                               style:
//                                   TextStyle(fontSize: 17, color: Colors.white),
//                             ),
//                           ),
//                         ),
//                         SizedBox(
//                           height: 18,
//                         ),
//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           children: [
//                             Text(
//                               'Don\'t have account?',
//                               style: TextStyle(
//                                   fontSize: 16, color: Colors.indigo[800]),
//                             ),
//                             SizedBox(
//                               width: 5,
//                             ),
//                             GestureDetector(
//                               onTap: () {
//                                 Navigator.push(
//                                     context,
//                                     MaterialPageRoute(
//                                         builder: (context) => Register()));
//                               },
//                               child: Text(
//                                 'Sign up',
//                                 style: TextStyle(
//                                     fontWeight: FontWeight.bold,
//                                     fontSize: 19,
//                                     color: Colors.indigo[800],
//                                     decoration: TextDecoration.underline,
//                                     decorationThickness: 2),
//                               ),
//                             ),
//                           ],
//                         ),
//                         SizedBox(
//                           height: 25,
//                         ),
//                         SizedBox(
//                           height: 18,
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
//
// import 'dart:convert';
//
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:http/http.dart' as http;
// import 'package:new_motel/appTheme.dart';
// import 'package:new_motel/authenticating/login_model.dart';
// import 'package:new_motel/authenticating/login_response.dart';
// import 'package:new_motel/loaderPage.dart';
// import 'package:new_motel/models/bookingDetails.dart';
// import 'package:new_motel/models/hotelList/hotelDetails.dart';
// import 'package:new_motel/models/tour/toursDetails.dart';
// import 'package:new_motel/modules/login/forgotPassword.dart';
// import 'package:new_motel/screens/hotel_room_details_screen.dart';
// import 'package:new_motel/screens/sign_up_screen.dart';
// import 'package:new_motel/utils/constants.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// class LoginWidget extends StatefulWidget {
//   final List<BookingDetails> rr;
//   final HotelDetailsResponse hotelDetails;
//   final String type;
//   final int days;
//   final int totalGuest;
//   final int adults;
//   final int child;
//   final Tour tour;
//   final String total_amount;
//   final String deposit;
//
//   const LoginWidget(
//       {Key key,
//       @required this.hotelDetails,
//       @required this.rr,
//       @required this.days,
//       @required this.type,
//       @required this.totalGuest,
//       @required this.adults,
//       @required this.child,
//       @required this.tour,
//       @required this.total_amount,
//       @required this.deposit})
//       : super(key: key);
//
//   @override
//   _LoginWidgetState createState() => _LoginWidgetState();
// }
//
// class _LoginWidgetState extends State<LoginWidget> {
//   List<BookingDetails> bookingList = List<BookingDetails>();
//
//   // List<BookingDetails> finalBookingList = List<BookingDetails>();
//
//   LoginResponse loginResponse;
//
//   final emailController = TextEditingController();
//   final passcontroller = TextEditingController();
//   bool isLoading = false;
//   bool _showPassword = false;
//   final _key = GlobalKey<FormState>();
//   String email, password;
//   LoginRequestModel loginRequestModel;
//   bool status;
//   String errorMessage;
//
//   //bool isLoading = false;
//   bool isSuccess;
//
//   //<---------------------------Save Token
//   Future saveToken(value) async {
//     // Async func to handle Futures easier; or use Future.then
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     prefs.setString('apiToken', value);
//     return prefs.setString("apiToken", value);
//   }
//
//   login(LoginRequestModel requestModel) async {
//     String url = "https://deshitour.com/api/login/check?appKey=DeshiTour";
//     try {
//       setState(() {
//         isLoading = true;
//       });
//       final response = await http.post(
//         url,
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: requestModel.toJson(),
//       );
//
//       //     .timeout(
//       //   Duration(seconds: 60),
//       //   onTimeout: () {
//       //     // time has run out, do what you wanted to do
//       //     Fluttertoast.showToast(msg: "Request Login Server timeout");
//       //
//       //     return null;
//       //   },
//       // );
//       print('API ${response.statusCode}\n API${json.decode(response.body)}');
//       errorMessage = json.decode(response.body)['msg'];
//
//       // return LoginResponseModel.fromJson();
//       loginResponse = LoginResponse.fromJson(json.decode(response.body));
//       print('bghbhdjsfbhsj ${loginResponse.status}');
//       print('Logjhfjdhfkdhgkd...>>> ${loginResponse.profileInfo.firstName}');
//
//       //loginResponse.profileInfo=data["profile_info"];
//
//       if (loginResponse.status == 1) {
//         isSuccess = true;
//       } else {
//         isSuccess = false;
//       }
//       // status = json.decode(response.body)['error']['status'];
//       // print(
//       //     "Login Token.....status...>>>${json.decode(response.body)['error']['status']}");
//
//       return {
//         'isSuccess': isSuccess,
//         'token': isSuccess ? loginResponse.token : null,
//         "firstName": isSuccess ? loginResponse.profileInfo.firstName : null,
//         "lastName": isSuccess ? loginResponse.profileInfo.lastName : null,
//         "email": isSuccess ? loginResponse.profileInfo.email : null,
//         "phone": isSuccess ? loginResponse.profileInfo.phone : null,
//         "id": isSuccess ? loginResponse.profileInfo.id : null,
//         'status': isSuccess ? loginResponse.profileInfo.status : null,
//       };
//     } catch (e) {
//       setState(() {
//         isLoading = false;
//       });
//     }
//   }
//
//   final _scaffoldKey = GlobalKey<ScaffoldState>();
//
//   _showMsg(msg) {
//     final snackBar = SnackBar(
//       content: Text(msg),
//       action: SnackBarAction(
//         label: 'Close',
//         onPressed: () {
//           // Some code to undo the change!
//         },
//       ),
//     );
//     _scaffoldKey.currentState.showSnackBar(snackBar);
//   }
//
//   // checkApiLogin() async {
//   //   final form = _key.currentState;
//   //   if (form.validate()) {
//   //     setState(() {
//   //       isLoading = true;
//   //     });
//   //     form.save();
//   //     login();
//   //     //      print("$name  $password");
//   //   } else {
//   //     setState(() {
//   //       isLoading = false;
//   //     });
//   //   }
//   // }
//
//   // login() async {
//   //   var response = await http.post(
//   //     "https://deshitour.com/api/login/check?appKey=DeshiTour",
//   //     body: {"email": email, "password": password},
//   //   );
//   //
//   //   final data = json.decode(response.body);
//   //   print(data);
//   //
//   //   bool success = data["response"];
//   //   String pMessage = data["msg"];
//   //
//   //   if (success) {
//   //     Map user = json.decode(response.body);
//   //     if (user['response']['token'] != null) {
//   //       print(user['response']['token']);
//   //       Navigator.of(context).pushAndRemoveUntil(
//   //           MaterialPageRoute(
//   //             builder: (BuildContext context) => ProfileScreenPage(),
//   //           ),
//   //           (Route<dynamic> route) => false);
//   //       // Navigator.push(context,
//   //       //     MaterialPageRoute(builder: (context) => ProfileScreenPage()));
//   //       Fluttertoast.showToast(
//   //           msg: ('login_successfully'),
//   //           toastLength: Toast.LENGTH_SHORT,
//   //           gravity: ToastGravity.BOTTOM,
//   //           timeInSecForIosWeb: 2,
//   //           backgroundColor: Colors.indigo,
//   //           textColor: Colors.white,
//   //           fontSize: 16.0);
//   //
//   //       print(pMessage);
//   //     }
//   //   } else {
//   //     setState(() {
//   //       isLoading = false;
//   //     });
//   //     _showMsg(data['msg']);
//   //   }
//   // }
//
//   bool _autoValidate = false;
//
//   @override
//   void initState() {
//     super.initState();
//     loginRequestModel = LoginRequestModel();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return isLoading
//         ? Center(
//             child: LoaderPage(),
//           )
//         : SafeArea(
//             child: Scaffold(
//               key: _scaffoldKey,
//               backgroundColor: Colors.white,
//               appBar: AppBar(
//                 title: RichText(
//                   text: TextSpan(
//                       text: DESHI,
//                       style: TextStyle(
//                         fontSize: 30,
//                         fontFamily: 'Impact',
//                         color: HexColor("#26408A"),
//                       ),
//                       children: <TextSpan>[
//                         TextSpan(
//                             text: TOUR,
//                             style: TextStyle(
//                               fontSize: 30,
//                               fontFamily: 'Impact',
//                               color: HexColor("#118ACB"),
//                             )),
//                       ]),
//                 ),
//                 backgroundColor: Colors.white,
//                 elevation: 1,
//                 leading: IconButton(
//                     icon: Icon(
//                       Icons.arrow_back,
//                       color: Colors.black,
//                     ),
//                     onPressed: () {
//                       Navigator.pop(context);
//                       // Navigator.push(
//                       //     context,
//                       //     MaterialPageRoute(
//                       //         builder: (context) => ProfileScreen()));
//                     }),
//               ),
//               body: Center(
//                 child: Padding(
//                   padding: const EdgeInsets.symmetric(horizontal: 5),
//                   child: SingleChildScrollView(
//                     child: Form(
//                       autovalidate: _autoValidate,
//                       key: _key,
//                       child: Column(
//                         children: [
//                           SizedBox(
//                             height: 30,
//                           ),
//                           Container(
//                             child: Padding(
//                               padding: const EdgeInsets.symmetric(
//                                   horizontal: 10, vertical: 15),
//                               child: Column(
//                                 crossAxisAlignment: CrossAxisAlignment.end,
//                                 mainAxisAlignment: MainAxisAlignment.center,
//                                 children: [
//                                   Padding(
//                                     padding: const EdgeInsets.only(
//                                         left: 24, right: 24),
//                                     child: Container(
//                                       decoration: BoxDecoration(
//                                         color:
//                                             AppTheme.getTheme().backgroundColor,
//                                         borderRadius: BorderRadius.all(
//                                             Radius.circular(38)),
//                                         // border: Border.all(
//                                         //   color: HexColor("#757575").withOpacity(0.6),
//                                         // ),
//                                         boxShadow: <BoxShadow>[
//                                           BoxShadow(
//                                             color: AppTheme.getTheme()
//                                                 .dividerColor,
//                                             blurRadius: 8,
//                                             offset: Offset(4, 4),
//                                           ),
//                                         ],
//                                       ),
//                                       child: Padding(
//                                         padding: const EdgeInsets.only(
//                                             left: 16, right: 16),
//                                         child: Container(
//                                           height: 48,
//                                           child: Center(
//                                             child: TextFormField(
//                                               // autovalidate: true,
//                                               controller: emailController,
//                                               keyboardType:
//                                                   TextInputType.emailAddress,
//                                               validator: (value) {
//                                                 if (value.isEmpty) {
//                                                   return 'Enter your email';
//                                                 }
//
//                                                 return null;
//                                               },
//                                               onChanged: (numVal) {
//                                                 loginRequestModel.email =
//                                                     numVal;
//                                                 setState(() {
//                                                   email = numVal.trim();
//                                                 });
//                                               },
//                                               maxLines: 1,
//                                               style: TextStyle(
//                                                 fontSize: 16,
//                                               ),
//                                               cursorColor: AppTheme.getTheme()
//                                                   .primaryColor,
//                                               decoration: new InputDecoration(
//                                                 errorText: null,
//                                                 border: InputBorder.none,
//                                                 hintText: "Email",
//                                                 hintStyle: TextStyle(
//                                                     color: AppTheme.getTheme()
//                                                         .disabledColor),
//                                               ),
//                                             ),
//                                           ),
//                                         ),
//                                       ),
//                                     ),
//                                   ),
//                                   SizedBox(
//                                     height: 16,
//                                   ),
//
//                                   Padding(
//                                     padding: const EdgeInsets.only(
//                                         left: 24, right: 24),
//                                     child: Container(
//                                       decoration: BoxDecoration(
//                                         color:
//                                             AppTheme.getTheme().backgroundColor,
//                                         borderRadius: BorderRadius.all(
//                                             Radius.circular(38)),
//                                         // border: Border.all(
//                                         //   color: HexColor("#757575").withOpacity(0.6),
//                                         // ),
//                                         boxShadow: <BoxShadow>[
//                                           BoxShadow(
//                                             color: AppTheme.getTheme()
//                                                 .dividerColor,
//                                             blurRadius: 8,
//                                             offset: Offset(4, 4),
//                                           ),
//                                         ],
//                                       ),
//                                       child: Padding(
//                                         padding: const EdgeInsets.only(
//                                             left: 16, right: 16),
//                                         child: Container(
//                                           height: 48,
//                                           child: Center(
//                                             child: TextFormField(
//                                               //   autovalidate: true,
//                                               controller: passcontroller,
//                                               onChanged: (numVal) {
//                                                 loginRequestModel.password =
//                                                     numVal;
//
//                                                 setState(() {
//                                                   password = numVal.trim();
//                                                 });
//                                               },
//                                               validator: (value) {
//                                                 if (value == null ||
//                                                     value.isEmpty) {
//                                                   return ('Enter your valid password');
//                                                 }
//                                                 return null;
//                                               },
//                                               obscureText: !_showPassword,
//                                               style: TextStyle(
//                                                 fontSize: 16,
//                                               ),
//                                               cursorColor: AppTheme.getTheme()
//                                                   .primaryColor,
//                                               decoration: new InputDecoration(
//                                                 errorText: null,
//                                                 border: InputBorder.none,
//                                                 suffixIcon: GestureDetector(
//                                                   onTap: () {
//                                                     setState(() {
//                                                       _showPassword =
//                                                           !_showPassword;
//                                                     });
//                                                   },
//                                                   child: Icon(_showPassword
//                                                       ? Icons.visibility
//                                                       : Icons.visibility_off),
//                                                 ),
//                                                 hintText: "Password",
//                                                 hintStyle: TextStyle(
//                                                     color: AppTheme.getTheme()
//                                                         .disabledColor),
//                                               ),
//                                             ),
//                                           ),
//                                         ),
//                                       ),
//                                     ),
//                                   ),
//                                   InkWell(
//                                     onTap: () {
//                                       Navigator.push(
//                                           context,
//                                           MaterialPageRoute(
//                                               builder: (context) =>
//                                                   ForgotPasswordScreen()));
//                                     },
//                                     child: Padding(
//                                       padding: const EdgeInsets.only(
//                                           right: 40.0, top: 10),
//                                       child: Text(
//                                         "Forgot Password",
//                                         style: TextStyle(
//                                             fontSize: 18, color: Colors.black),
//                                       ),
//                                     ),
//                                   ),
//
//                                   SizedBox(
//                                     height: 20,
//                                   ),
//
//                                   // TextFormField(
//                                   //   validator: (value) {
//                                   //     if (value == null || value.isEmpty) {
//                                   //       return ('enter_your_valid_email_address');
//                                   //     }
//                                   //     return null;
//                                   //   },
//                                   //   onChanged: (numVal) {
//                                   //     loginRequestModel.email = numVal;
//                                   //     setState(() {
//                                   //       email = numVal.trim();
//                                   //     });
//                                   //   },
//                                   //   controller: emailController,
//                                   //   keyboardType: TextInputType.text,
//                                   //   decoration: InputDecoration(
//                                   //     fillColor: Colors.grey[300],
//                                   //     filled: true,
//                                   //     border: OutlineInputBorder(
//                                   //       borderSide: BorderSide.none,
//                                   //       borderRadius: BorderRadius.circular(15),
//                                   //     ),
//                                   //     prefixIcon: Icon(
//                                   //       Icons.email,
//                                   //       color: Colors.indigo[800],
//                                   //     ),
//                                   //     hintText: "Email",
//                                   //   ),
//                                   // ),
//                                   // SizedBox(
//                                   //   height: 15,
//                                   // ),
//
//                                   Padding(
//                                     padding: const EdgeInsets.only(
//                                         left: 24,
//                                         right: 24,
//                                         bottom: 8,
//                                         top: 16),
//                                     child: Container(
//                                       height: 48,
//                                       decoration: BoxDecoration(
//                                         color: AppTheme.getTheme().primaryColor,
//                                         borderRadius: BorderRadius.all(
//                                             Radius.circular(24.0)),
//                                         boxShadow: <BoxShadow>[
//                                           BoxShadow(
//                                             color: AppTheme.getTheme()
//                                                 .dividerColor,
//                                             blurRadius: 8,
//                                             offset: Offset(4, 4),
//                                           ),
//                                         ],
//                                       ),
//                                       child: Material(
//                                         color: Colors.transparent,
//                                         child: InkWell(
//                                           borderRadius: BorderRadius.all(
//                                               Radius.circular(24.0)),
//                                           highlightColor: Colors.transparent,
//                                           onTap: () {
//                                             setState(() {
//                                               if (_key.currentState
//                                                   .validate()) {
//                                                 login(loginRequestModel)
//                                                     .then((value) async {
//                                                   if (isSuccess) {
//                                                     if (value['isSuccess']) {
//                                                       saveToken(value['token']);
//                                                       SharedPreferences
//                                                           sharedPref =
//                                                           await SharedPreferences
//                                                               .getInstance();
//                                                       sharedPref.setString(
//                                                           'email',
//                                                           value['email']);
//                                                       sharedPref.setString(
//                                                           'firstName',
//                                                           value['firstName']);
//                                                       sharedPref.setString(
//                                                           'lastName',
//                                                           value['lastName']);
//                                                       sharedPref.setString(
//                                                           'status',
//                                                           value['status']);
//                                                       sharedPref.setString(
//                                                           'id', value['id']);
//                                                       sharedPref.setString(
//                                                           'phone',
//                                                           value['phone']);
//                                                       sharedPref.setString(
//                                                           'token',
//                                                           value['token']);
//                                                       print(widget.type);
//                                                       setState(() {
//                                                         isLoading = true;
//                                                       });
//                                                       Fluttertoast.showToast(
//                                                           msg:
//                                                               ('Login Successfully'),
//                                                           toastLength: Toast
//                                                               .LENGTH_SHORT,
//                                                           gravity: ToastGravity
//                                                               .BOTTOM,
//                                                           timeInSecForIosWeb: 2,
//                                                           backgroundColor:
//                                                               Colors.indigo,
//                                                           textColor:
//                                                               Colors.white,
//                                                           fontSize: 16.0);
//
//                                                       //   Navigator.of(context).pop();
//
//                                                       Navigator.pop(
//                                                           context, '1');
//                                                       if (widget.type ==
//                                                           "hotel") {
//                                                         Navigator.push(
//                                                             context,
//                                                             MaterialPageRoute(
//                                                                 builder:
//                                                                     (context) =>
//                                                                         HotelRoomFormPage(
//                                                                           days:
//                                                                               widget.days,
//                                                                           rr: widget
//                                                                               .rr,
//                                                                           hotel:
//                                                                               widget.hotelDetails,
//                                                                         )));
//                                                       } else {
//                                                         // Fluttertoast.showToast(
//                                                         //     msg: ('Login Failed'),
//                                                         //     toastLength:
//                                                         //         Toast.LENGTH_SHORT,
//                                                         //     gravity:
//                                                         //         ToastGravity.BOTTOM,
//                                                         //     timeInSecForIosWeb: 2,
//                                                         //     backgroundColor:
//                                                         //         Colors.indigo,
//                                                         //     textColor: Colors.white,
//                                                         //     fontSize: 16.0);
//                                                       }
//
//                                                       print(
//                                                           "\n\nTOKEN>>>>${value['token']}");
//                                                     }
//                                                   } else {
//                                                     setState(() {
//                                                       isLoading = false;
//                                                     });
//                                                     Fluttertoast.showToast(
//                                                         msg: errorMessage,
//                                                         toastLength:
//                                                             Toast.LENGTH_SHORT,
//                                                         gravity:
//                                                             ToastGravity.BOTTOM,
//                                                         timeInSecForIosWeb: 4,
//                                                         backgroundColor:
//                                                             Colors.indigo,
//                                                         textColor: Colors.white,
//                                                         fontSize: 20.0);
//                                                   }
//                                                   Navigator.of(context);
//
//                                                   setState(() {});
//                                                 });
//                                               } else {
//                                                 setState(() {
//                                                   _autoValidate = true;
//                                                 });
//                                               }
//                                             });
//                                           },
//                                           child: Center(
//                                             child: Text(
//                                               "Sign In",
//                                               style: TextStyle(
//                                                   fontWeight: FontWeight.w500,
//                                                   fontSize: 16,
//                                                   color: Colors.white),
//                                             ),
//                                           ),
//                                         ),
//                                       ),
//                                     ),
//                                   ),
//                                   SizedBox(
//                                     height: 10,
//                                   ),
//
//                                   Row(
//                                     mainAxisAlignment: MainAxisAlignment.center,
//                                     crossAxisAlignment:
//                                         CrossAxisAlignment.center,
//                                     children: [
//                                       Text(
//                                         "Don't have an account?  ",
//                                         style: TextStyle(fontSize: 17),
//                                       ),
//                                       GestureDetector(
//                                           onTap: () {
//                                             Navigator.push(
//                                                 context,
//                                                 MaterialPageRoute(
//                                                     builder: (context) =>
//                                                         SignUpSreen()));
//                                           },
//                                           child: Container(
//                                               child: Text(
//                                             "SignUp",
//                                             style: TextStyle(
//                                                 fontSize: 20,
//                                                 fontWeight: FontWeight.bold,
//                                                 color: Colors.indigo[800]),
//                                           ))),
//                                     ],
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//           );
//   }
// }

// import 'dart:async';

// import 'package:flutter/material.dart';
// import 'package:get/route_manager.dart';
// import 'package:new_motel/authenticating/register.dart';
// import 'package:new_motel/widget/custom_TextField.dart';

// class Login extends StatefulWidget {
//   @override
//   _LoginState createState() => _LoginState();
// }

// class _LoginState extends State<Login> {
//   final TextEditingController _emailEditingController = TextEditingController();
//   final TextEditingController _passwordEditingController =
//       TextEditingController();
//   final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

//   @override
//   Widget build(BuildContext context) {
//     double _screenWidth = MediaQuery.of(context).size.width,
//         _screenHeight = MediaQuery.of(context).size.height;
//     return SafeArea(
//       child: Scaffold(
//         body: Center(
//           child: Container(
//             child: SingleChildScrollView(
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Form(
//                     key: _formKey,
//                     child: Column(
//                       children: [
//                         CustomTextField(
//                           controller: _emailEditingController,
//                           hintText: "Email",
//                           isObsecure: false,
//                           data: Icons.mail_outline,
//                         ),
//                         CustomTextField(
//                             controller: _passwordEditingController,
//                             hintText: "Password",
//                             isObsecure: true,
//                             data: Icons.lock_open),
//                         SizedBox(
//                           height: 8,
//                         ),
//                         Container(
//                           height: 45,
//                           width: 200,
//                           child: RaisedButton(
//                             shape: RoundedRectangleBorder(
//                                 borderRadius: BorderRadius.circular(10)),
//                             onPressed: () {},
//                             color: Colors.indigo[800],
//                             child: Text(
//                               "Login",
//                               style:
//                                   TextStyle(fontSize: 17, color: Colors.white),
//                             ),
//                           ),
//                         ),
//                         SizedBox(
//                           height: 18,
//                         ),
//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           children: [
//                             Text(
//                               'Don\'t have account?',
//                               style: TextStyle(
//                                   fontSize: 16, color: Colors.indigo[800]),
//                             ),
//                             SizedBox(
//                               width: 5,
//                             ),
//                             GestureDetector(
//                               onTap: () {
//                                 Navigator.push(
//                                     context,
//                                     MaterialPageRoute(
//                                         builder: (context) => Register()));
//                               },
//                               child: Text(
//                                 'Sign up',
//                                 style: TextStyle(
//                                     fontWeight: FontWeight.bold,
//                                     fontSize: 19,
//                                     color: Colors.indigo[800],
//                                     decoration: TextDecoration.underline,
//                                     decorationThickness: 2),
//                               ),
//                             ),
//                           ],
//                         ),
//                         SizedBox(
//                           height: 25,
//                         ),
//                         SizedBox(
//                           height: 18,
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:new_motel/appTheme.dart';
import 'package:new_motel/authenticating/login_model.dart';
import 'package:new_motel/loaderPage.dart';
import 'package:new_motel/models/bookingDetails.dart';
import 'package:new_motel/models/hotelList/hotelDetails.dart';
import 'package:new_motel/models/tour/toursDetails.dart';
import 'package:new_motel/modules/login/forgotPassword.dart';
import 'package:new_motel/screens/hotel_room_details_screen.dart';
import 'package:new_motel/screens/sign_up_screen.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'login_response.dart';

class LoginWidget extends StatefulWidget {
  final List<BookingDetails> rr;
  final HotelDetailsResponse hotelDetails;
  final String type;
  final int days;
  final int totalGuest;
  final int adults;
  final int child;
  final Tour tour;
  final String total_amount;
  final String deposit;

  const LoginWidget(
      {Key key,
      @required this.hotelDetails,
      @required this.rr,
      @required this.days,
      @required this.type,
      @required this.totalGuest,
      @required this.adults,
      @required this.child,
      @required this.tour,
      @required this.total_amount,
      @required this.deposit})
      : super(key: key);

  @override
  _LoginWidgetState createState() => _LoginWidgetState();
}

class LoginResData {
  int type;
  LoginResponse loginResponse;

  LoginResData(this.type, this.loginResponse);
}

class _LoginWidgetState extends State<LoginWidget> {
  List<BookingDetails> bookingList = List<BookingDetails>();

  // List<BookingDetails> finalBookingList = List<BookingDetails>();

  LoginResponse loginResponse;

  final emailController = TextEditingController();
  final passcontroller = TextEditingController();
  bool isLoading = false;
  bool _showPassword = false;
  final _key = GlobalKey<FormState>();
  String email, password;
  LoginRequestModel loginRequestModel;
  bool status;
  String errorMessage;

  //bool isLoading = false;
  bool isSuccess;

  //<---------------------------Save Token
  Future saveToken(value) async {
    // Async func to handle Futures easier; or use Future.then
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('apiToken', value);
    return prefs.setString("apiToken", value);
  }

  Future<LoginResData> login(LoginRequestModel requestModel) async {
    LoginResData loginResData;
    String url = "https://deshitour.com/api/login/check?appKey=DeshiTour";
    try {
      setState(() {
        isLoading = true;
      });
      final response = await http.post(
        url,
        body: requestModel.toJson(),
      );

      //     .timeout(
      //   Duration(seconds: 60),
      //   onTimeout: () {
      //     // time has run out, do what you wanted to do
      //     Fluttertoast.showToast(msg: "Request Login Server timeout");
      //
      //     return null;
      //   },
      // );
      print('API ${response.statusCode}\n API${json.decode(response.body)}');

      // return LoginResponseModel.fromJson();
      loginResponse = LoginResponse.fromJson(json.decode(response.body));
      print('bghbhdjsfbhsj ${loginResponse.status}');
      //   print('Logjhfjdhfkdhgkd...>>> ${loginResponse.profileInfo.firstName}');
      errorMessage = json.decode(response.body)['msg'];
      //loginResponse.profileInfo=data["profile_info"];
      print('Status ${loginResponse.status}');
      print('Messagee  ${loginResponse.msg}');
      print('error mesage  $errorMessage');

      if (loginResponse.status == 1) {
        loginResData = LoginResData(1, loginResponse);
      } else {
        print("Error = $errorMessage");

        loginResData = LoginResData(0, loginResponse);
      }
      // status = json.decode(response.body)['error']['status'];
      // print(
      //     "Login Token.....status...>>>${json.decode(response.body)['error']['status']}");

    } catch (e) {
      setState(() {
        isLoading = false;
      });
    }
    return loginResData;
  }

  final _scaffoldKey = GlobalKey<ScaffoldState>();

  _showMsg(msg) {
    final snackBar = SnackBar(
      content: Text(msg),
      action: SnackBarAction(
        label: 'Close',
        onPressed: () {
          // Some code to undo the change!
        },
      ),
    );
    _scaffoldKey.currentState.showSnackBar(snackBar);
  }

  // checkApiLogin() async {
  //   final form = _key.currentState;
  //   if (form.validate()) {
  //     setState(() {
  //       isLoading = true;
  //     });
  //     form.save();
  //     login();
  //     //      print("$name  $password");
  //   } else {
  //     setState(() {
  //       isLoading = false;
  //     });
  //   }
  // }

  // login() async {
  //   var response = await http.post(
  //     "https://deshitour.com/api/login/check?appKey=DeshiTour",
  //     body: {"email": email, "password": password},
  //   );
  //
  //   final data = json.decode(response.body);
  //   print(data);
  //
  //   bool success = data["response"];
  //   String pMessage = data["msg"];
  //
  //   if (success) {
  //     Map user = json.decode(response.body);
  //     if (user['response']['token'] != null) {
  //       print(user['response']['token']);
  //       Navigator.of(context).pushAndRemoveUntil(
  //           MaterialPageRoute(
  //             builder: (BuildContext context) => ProfileScreenPage(),
  //           ),
  //           (Route<dynamic> route) => false);
  //       // Navigator.push(context,
  //       //     MaterialPageRoute(builder: (context) => ProfileScreenPage()));
  //       Fluttertoast.showToast(
  //           msg: ('login_successfully'),
  //           toastLength: Toast.LENGTH_SHORT,
  //           gravity: ToastGravity.BOTTOM,
  //           timeInSecForIosWeb: 2,
  //           backgroundColor: Colors.indigo,
  //           textColor: Colors.white,
  //           fontSize: 16.0);
  //
  //       print(pMessage);
  //     }
  //   } else {
  //     setState(() {
  //       isLoading = false;
  //     });
  //     _showMsg(data['msg']);
  //   }
  // }

  bool _autoValidate = false;

  @override
  void initState() {
    super.initState();
    loginRequestModel = LoginRequestModel();
  }

  @override
  Widget build(BuildContext context) {
    return isLoading
        ? Center(
            child: LoaderPage(),
          )
        : SafeArea(
            child: Scaffold(
              key: _scaffoldKey,
              backgroundColor: Colors.white,
              appBar: AppBar(
                title: RichText(
                  text: TextSpan(
                      text: DESHI,
                      style: TextStyle(
                        fontSize: 30,
                        fontFamily: 'Impact',
                        color: HexColor("#26408A"),
                      ),
                      children: <TextSpan>[
                        TextSpan(
                            text: TOUR,
                            style: TextStyle(
                              fontSize: 30,
                              fontFamily: 'Impact',
                              color: HexColor("#118ACB"),
                            )),
                      ]),
                ),
                backgroundColor: Colors.white,
                elevation: 1,
                leading: IconButton(
                    icon: Icon(
                      Icons.arrow_back,
                      color: Colors.black,
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                      // Navigator.push(
                      //     context,
                      //     MaterialPageRoute(
                      //         builder: (context) => ProfileScreen()));
                    }),
              ),
              body: Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  child: SingleChildScrollView(
                    child: Form(
                      // ignore: deprecated_member_use
                      autovalidate: _autoValidate,
                      key: _key,
                      child: Column(
                        children: [
                          SizedBox(
                            height: 30,
                          ),
                          Container(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 15),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 24, right: 24),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color:
                                            AppTheme.getTheme().backgroundColor,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(38)),
                                        // border: Border.all(
                                        //   color: HexColor("#757575").withOpacity(0.6),
                                        // ),
                                        boxShadow: <BoxShadow>[
                                          BoxShadow(
                                            color: AppTheme.getTheme()
                                                .dividerColor,
                                            blurRadius: 8,
                                            offset: Offset(4, 4),
                                          ),
                                        ],
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 16, right: 16),
                                        child: Container(
                                          height: 48,
                                          child: Center(
                                            child: TextFormField(
                                              // autovalidate: true,
                                              controller: emailController,
                                              keyboardType:
                                                  TextInputType.emailAddress,
                                              validator: (value) {
                                                if (value.isEmpty) {
                                                  return 'Enter your email';
                                                }

                                                return null;
                                              },
                                              onChanged: (numVal) {
                                                loginRequestModel.email =
                                                    numVal;
                                                setState(() {
                                                  email = numVal.trim();
                                                });
                                              },
                                              maxLines: 1,
                                              style: TextStyle(
                                                fontSize: 16,
                                              ),
                                              cursorColor: AppTheme.getTheme()
                                                  .primaryColor,
                                              decoration: new InputDecoration(
                                                errorText: null,
                                                border: InputBorder.none,
                                                hintText: "Email",
                                                hintStyle: TextStyle(
                                                    color: AppTheme.getTheme()
                                                        .disabledColor),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 16,
                                  ),

                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 24, right: 24),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color:
                                            AppTheme.getTheme().backgroundColor,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(38)),
                                        // border: Border.all(
                                        //   color: HexColor("#757575").withOpacity(0.6),
                                        // ),
                                        boxShadow: <BoxShadow>[
                                          BoxShadow(
                                            color: AppTheme.getTheme()
                                                .dividerColor,
                                            blurRadius: 8,
                                            offset: Offset(4, 4),
                                          ),
                                        ],
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 16, right: 16),
                                        child: Container(
                                          height: 48,
                                          child: Center(
                                            child: TextFormField(
                                              //   autovalidate: true,
                                              controller: passcontroller,
                                              onChanged: (numVal) {
                                                loginRequestModel.password =
                                                    numVal;

                                                setState(() {
                                                  password = numVal.trim();
                                                });
                                              },
                                              validator: (value) {
                                                if (value == null ||
                                                    value.isEmpty) {
                                                  return ('Enter your valid password');
                                                }
                                                return null;
                                              },
                                              obscureText: !_showPassword,
                                              style: TextStyle(
                                                fontSize: 16,
                                              ),
                                              cursorColor: AppTheme.getTheme()
                                                  .primaryColor,
                                              decoration: new InputDecoration(
                                                errorText: null,
                                                border: InputBorder.none,
                                                suffixIcon: GestureDetector(
                                                  onTap: () {
                                                    setState(() {
                                                      _showPassword =
                                                          !_showPassword;
                                                    });
                                                  },
                                                  child: Icon(_showPassword
                                                      ? Icons.visibility
                                                      : Icons.visibility_off),
                                                ),
                                                hintText: "Password",
                                                hintStyle: TextStyle(
                                                    color: AppTheme.getTheme()
                                                        .disabledColor),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  InkWell(
                                    onTap: () {
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  ForgotPasswordScreen()));
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.only(
                                          right: 40.0, top: 10),
                                      child: Text(
                                        "Forgot Password",
                                        style: TextStyle(
                                            fontSize: 18, color: Colors.black),
                                      ),
                                    ),
                                  ),

                                  SizedBox(
                                    height: 20,
                                  ),

                                  // TextFormField(
                                  //   validator: (value) {
                                  //     if (value == null || value.isEmpty) {
                                  //       return ('enter_your_valid_email_address');
                                  //     }
                                  //     return null;
                                  //   },
                                  //   onChanged: (numVal) {
                                  //     loginRequestModel.email = numVal;
                                  //     setState(() {
                                  //       email = numVal.trim();
                                  //     });
                                  //   },
                                  //   controller: emailController,
                                  //   keyboardType: TextInputType.text,
                                  //   decoration: InputDecoration(
                                  //     fillColor: Colors.grey[300],
                                  //     filled: true,
                                  //     border: OutlineInputBorder(
                                  //       borderSide: BorderSide.none,
                                  //       borderRadius: BorderRadius.circular(15),
                                  //     ),
                                  //     prefixIcon: Icon(
                                  //       Icons.email,
                                  //       color: Colors.indigo[800],
                                  //     ),
                                  //     hintText: "Email",
                                  //   ),
                                  // ),
                                  // SizedBox(
                                  //   height: 15,
                                  // ),

                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 24,
                                        right: 24,
                                        bottom: 8,
                                        top: 16),
                                    child: Container(
                                      height: 48,
                                      decoration: BoxDecoration(
                                        color: AppTheme.getTheme().primaryColor,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(24.0)),
                                        boxShadow: <BoxShadow>[
                                          BoxShadow(
                                            color: AppTheme.getTheme()
                                                .dividerColor,
                                            blurRadius: 8,
                                            offset: Offset(4, 4),
                                          ),
                                        ],
                                      ),
                                      child: Material(
                                        color: Colors.transparent,
                                        child: InkWell(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(24.0)),
                                          highlightColor: Colors.transparent,
                                          onTap: () {
                                            setState(() {
                                              if (_key.currentState
                                                  .validate()) {
                                                login(loginRequestModel)
                                                    .then((value) async {
                                                  if (value != null) {
                                                    if (value.type == 1) {
                                                      saveToken(value
                                                          .loginResponse.token);
                                                      SharedPreferences
                                                          sharedPref =
                                                          await SharedPreferences
                                                              .getInstance();
                                                      sharedPref.setString(
                                                          'email',
                                                          value
                                                              .loginResponse
                                                              .profileInfo
                                                              .email);
                                                      sharedPref.setString(
                                                          'firstName',
                                                          value
                                                              .loginResponse
                                                              .profileInfo
                                                              .firstName);
                                                      sharedPref.setString(
                                                          'lastName',
                                                          value
                                                              .loginResponse
                                                              .profileInfo
                                                              .lastName);
                                                      sharedPref.setString(
                                                          'status',
                                                          value
                                                              .loginResponse
                                                              .profileInfo
                                                              .status);
                                                      sharedPref.setString(
                                                          'id',
                                                          value.loginResponse
                                                              .profileInfo.id);
                                                      sharedPref.setString(
                                                          'phone',
                                                          value
                                                              .loginResponse
                                                              .profileInfo
                                                              .phone);
                                                      sharedPref.setString(
                                                          'photo',
                                                          value
                                                              .loginResponse
                                                              .profileInfo
                                                              .photo);
                                                      sharedPref.setString(
                                                          'token',
                                                          value.loginResponse
                                                              .token);
                                                      print(widget.type);
                                                      setState(() {
                                                        isLoading = false;
                                                      });
                                                      Fluttertoast.showToast(
                                                          msg:
                                                              ('Login Successfully'),
                                                          toastLength: Toast
                                                              .LENGTH_SHORT,
                                                          gravity: ToastGravity
                                                              .BOTTOM,
                                                          timeInSecForIosWeb: 2,
                                                          backgroundColor:
                                                              Colors.indigo,
                                                          textColor:
                                                              Colors.white,
                                                          fontSize: 16.0);

                                                      //   Navigator.of(context).pop();

                                                      Navigator.pop(
                                                          context, '1');
                                                      if (widget.type ==
                                                          "hotel") {
                                                        Navigator.push(
                                                            context,
                                                            MaterialPageRoute(
                                                                builder:
                                                                    (context) =>
                                                                        HotelRoomFormPage(
                                                                          days:
                                                                              widget.days,
                                                                          rr: widget
                                                                              .rr,
                                                                          hotel:
                                                                              widget.hotelDetails,
                                                                        )));
                                                      } else {
                                                        // Fluttertoast.showToast(
                                                        //     msg: ('Login Failed'),
                                                        //     toastLength:
                                                        //         Toast.LENGTH_SHORT,
                                                        //     gravity:
                                                        //         ToastGravity.BOTTOM,
                                                        //     timeInSecForIosWeb: 2,
                                                        //     backgroundColor:
                                                        //         Colors.indigo,
                                                        //     textColor: Colors.white,
                                                        //     fontSize: 16.0);
                                                      }
                                                    } else {
                                                      Fluttertoast.showToast(
                                                          msg: errorMessage,
                                                          toastLength: Toast
                                                              .LENGTH_SHORT,
                                                          gravity: ToastGravity
                                                              .BOTTOM,
                                                          timeInSecForIosWeb: 4,
                                                          backgroundColor:
                                                              Colors.indigo,
                                                          textColor:
                                                              Colors.white,
                                                          fontSize: 20.0);
                                                      setState(() {
                                                        isLoading = false;
                                                      });
                                                    }
                                                  } else {
                                                    setState(() {
                                                      isLoading = false;
                                                    });
                                                    Fluttertoast.showToast(
                                                        msg:
                                                            "Something went wrong!",
                                                        toastLength:
                                                            Toast.LENGTH_SHORT,
                                                        gravity:
                                                            ToastGravity.BOTTOM,
                                                        timeInSecForIosWeb: 4,
                                                        backgroundColor:
                                                            Colors.indigo,
                                                        textColor: Colors.white,
                                                        fontSize: 20.0);
                                                  }
                                                  Navigator.of(context);

                                                  setState(() {});
                                                });
                                              } else {
                                                setState(() {
                                                  _autoValidate = true;
                                                });
                                              }
                                            });
                                          },
                                          child: Center(
                                            child: Text(
                                              "Sign In",
                                              style: TextStyle(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 16,
                                                  color: Colors.white),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),

                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Text(
                                        "Don't have an account?  ",
                                        style: TextStyle(fontSize: 17),
                                      ),
                                      GestureDetector(
                                          onTap: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        SignUpSreen()));
                                          },
                                          child: Container(
                                              child: Text(
                                            "SignUp",
                                            style: TextStyle(
                                                fontSize: 20,
                                                fontWeight: FontWeight.bold,
                                                color: Colors.indigo[800]),
                                          ))),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          );
  }
}
