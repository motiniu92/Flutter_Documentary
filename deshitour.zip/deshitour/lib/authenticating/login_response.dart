class LoginResponse {
  int status;
  ProfileInfo profileInfo;
  String token;
  String msg;

  LoginResponse({this.status, this.profileInfo, this.token, this.msg});

  LoginResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    msg = json['msg'] != null ? json['msg'] : "Success";
    profileInfo = json['profile_info'] != null
        ? new ProfileInfo.fromJson(json['profile_info'])
        : null;
    token = json['token'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.profileInfo != null) {
      data['profile_info'] = this.profileInfo.toJson();
    }
    data['token'] = this.token;
    return data;
  }
}

class ProfileInfo {
  String email;
  String id;
  String firstName;
  String lastName;
  String status;
  String phone;
  String photo;

  ProfileInfo({
    this.email,
    this.id,
    this.firstName,
    this.lastName,
    this.status,
    this.phone,
    this.photo,
  });

  ProfileInfo.fromJson(Map<String, dynamic> json) {
    email = json['email'];
    id = json['id'];
    firstName = json['firstName'];
    lastName = json['lastName'];
    status = json['status'];
    phone = json['phone'];
    photo = json['photo'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['email'] = this.email;
    data['id'] = this.id;
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    data['status'] = this.status;
    data['phone'] = this.phone;
    data['photo'] = this.photo;

    return data;
  }
}
