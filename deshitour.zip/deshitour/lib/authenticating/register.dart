// import 'package:flutter/material.dart';
// import 'package:new_motel/appTheme.dart';
// import 'package:new_motel/authenticating/login.dart';
// import 'package:new_motel/models/bookingDetails.dart';
// import 'package:new_motel/models/hotelList/hotelDetails.dart';
// import 'package:new_motel/provider/authenticate.dart';
// import 'package:provider/provider.dart';

// class RegisterWidget extends StatefulWidget {
//   final HotelDetailsResponse hotel;

//   const RegisterWidget({Key key, this.hotel}) : super(key: key);
//   @override
//   _RegisterWidgetState createState() => _RegisterWidgetState();
// }

// class _RegisterWidgetState extends State<RegisterWidget> {
//   final firstNameController = TextEditingController();
//   final lastNameController = TextEditingController();

//   final emailController = TextEditingController();

//   final phoneController = TextEditingController();

//   final passController = TextEditingController();
//   final key = GlobalKey<FormState>();
//   bool _cshowPassword = false;
//   List<BookingDetails> bookingList = List<BookingDetails>();

//   @override
//   Widget build(BuildContext context) {
//     var auth = Provider.of<Auth>(context, listen: false);
//     return auth.busy
//         ? Center(child: CircularProgressIndicator())
//         : InkWell(
//             splashColor: Colors.transparent,
//             highlightColor: Colors.transparent,
//             focusColor: Colors.transparent,
//             onTap: () {
//               FocusScope.of(context).requestFocus(FocusNode());
//             },
//             child: Center(
//               child: Container(
//                 child: Form(
//                   key: key,
//                   child: SingleChildScrollView(
//                     physics: BouncingScrollPhysics(),
//                     child: Column(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: <Widget>[
//                         SizedBox(
//                           height: 50,
//                         ),

//                         Padding(
//                           padding: const EdgeInsets.only(left: 24, right: 24),
//                           child: Container(
//                             decoration: BoxDecoration(
//                               color: AppTheme.getTheme().backgroundColor,
//                               borderRadius:
//                                   BorderRadius.all(Radius.circular(38)),
//                               // border: Border.all(
//                               //   color: HexColor("#757575").withOpacity(0.6),
//                               // ),
//                               boxShadow: <BoxShadow>[
//                                 BoxShadow(
//                                   color: AppTheme.getTheme().dividerColor,
//                                   blurRadius: 8,
//                                   offset: Offset(4, 4),
//                                 ),
//                               ],
//                             ),
//                             // NID TextFields
//                             child: Padding(
//                               padding:
//                                   const EdgeInsets.only(left: 16, right: 16),
//                               child: Container(
//                                 height: 48,
//                                 child: Center(
//                                   child: TextFormField(
//                                     controller: firstNameController,
//                                     validator: (value) {
//                                       if (value.isEmpty) {
//                                         return "Please enter first name";
//                                       }
//                                       return null;
//                                     },
//                                     maxLines: 1,
//                                     onChanged: (String txt) {},
//                                     style: TextStyle(
//                                       fontSize: 16,
//                                     ),
//                                     cursorColor:
//                                         AppTheme.getTheme().primaryColor,
//                                     decoration: new InputDecoration(
//                                       errorText: null,
//                                       border: InputBorder.none,
//                                       hintText: "FirstName",
//                                       hintStyle: TextStyle(
//                                           color: AppTheme.getTheme()
//                                               .disabledColor),
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                         SizedBox(
//                           height: 16,
//                         ),

//                         // Passport TextFields
//                         Padding(
//                           padding: const EdgeInsets.only(left: 24, right: 24),
//                           child: Container(
//                             decoration: BoxDecoration(
//                               color: AppTheme.getTheme().backgroundColor,
//                               borderRadius:
//                                   BorderRadius.all(Radius.circular(38)),
//                               // border: Border.all(
//                               //   color: HexColor("#757575").withOpacity(0.6),
//                               // ),
//                               boxShadow: <BoxShadow>[
//                                 BoxShadow(
//                                   color: AppTheme.getTheme().dividerColor,
//                                   blurRadius: 8,
//                                   offset: Offset(4, 4),
//                                 ),
//                               ],
//                             ),
//                             child: Padding(
//                               padding:
//                                   const EdgeInsets.only(left: 16, right: 16),
//                               child: Container(
//                                 height: 48,
//                                 child: Center(
//                                   child: TextFormField(
//                                     controller: lastNameController,
//                                     validator: (value) {
//                                       if (value.isEmpty) {
//                                         return "Please enter last name";
//                                       }
//                                       return null;
//                                     },
//                                     maxLines: 1,
//                                     onChanged: (String txt) {},
//                                     style: TextStyle(
//                                       fontSize: 16,
//                                     ),
//                                     cursorColor:
//                                         AppTheme.getTheme().primaryColor,
//                                     decoration: new InputDecoration(
//                                       errorText: null,
//                                       border: InputBorder.none,
//                                       hintText: "LastName",
//                                       hintStyle: TextStyle(
//                                           color: AppTheme.getTheme()
//                                               .disabledColor),
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),

//                         SizedBox(
//                           height: 16,
//                         ),

//                         // Driving License TextFields
//                         Padding(
//                           padding: const EdgeInsets.only(left: 24, right: 24),
//                           child: Container(
//                             decoration: BoxDecoration(
//                               color: AppTheme.getTheme().backgroundColor,
//                               borderRadius:
//                                   BorderRadius.all(Radius.circular(38)),
//                               // border: Border.all(
//                               //   color: HexColor("#757575").withOpacity(0.6),
//                               // ),
//                               boxShadow: <BoxShadow>[
//                                 BoxShadow(
//                                   color: AppTheme.getTheme().dividerColor,
//                                   blurRadius: 8,
//                                   offset: Offset(4, 4),
//                                 ),
//                               ],
//                             ),
//                             child: Padding(
//                               padding:
//                                   const EdgeInsets.only(left: 16, right: 16),
//                               child: Container(
//                                 height: 48,
//                                 child: Center(
//                                   child: TextFormField(
//                                     controller: phoneController,
//                                     keyboardType: TextInputType.phone,
//                                     validator: (value) {
//                                       if (value.isEmpty) {
//                                         return "Please enter phone number";
//                                       }
//                                       return null;
//                                     },
//                                     maxLines: 1,
//                                     onChanged: (String txt) {},
//                                     style: TextStyle(
//                                       fontSize: 16,
//                                     ),
//                                     cursorColor:
//                                         AppTheme.getTheme().primaryColor,
//                                     decoration: new InputDecoration(
//                                       errorText: null,
//                                       border: InputBorder.none,
//                                       hintText: "Phone",
//                                       hintStyle: TextStyle(
//                                           color: AppTheme.getTheme()
//                                               .disabledColor),
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),

//                         SizedBox(
//                           height: 16,
//                         ),
//                         Padding(
//                           padding: const EdgeInsets.only(left: 24, right: 24),
//                           child: Container(
//                             decoration: BoxDecoration(
//                               color: AppTheme.getTheme().backgroundColor,
//                               borderRadius:
//                                   BorderRadius.all(Radius.circular(38)),
//                               // border: Border.all(
//                               //   color: HexColor("#757575").withOpacity(0.6),
//                               // ),
//                               boxShadow: <BoxShadow>[
//                                 BoxShadow(
//                                   color: AppTheme.getTheme().dividerColor,
//                                   blurRadius: 8,
//                                   offset: Offset(4, 4),
//                                 ),
//                               ],
//                             ),
//                             child: Padding(
//                               padding:
//                                   const EdgeInsets.only(left: 16, right: 16),
//                               child: Container(
//                                 height: 48,
//                                 child: Center(
//                                   child: TextFormField(
//                                     controller: emailController,
//                                     keyboardType: TextInputType.emailAddress,
//                                     validator: (value) {
//                                       if (value.isEmpty) {
//                                         return "Please enter email address";
//                                       }
//                                       return null;
//                                     },
//                                     maxLines: 1,
//                                     onChanged: (String txt) {},
//                                     style: TextStyle(
//                                       fontSize: 16,
//                                     ),
//                                     cursorColor:
//                                         AppTheme.getTheme().primaryColor,
//                                     decoration: new InputDecoration(
//                                       errorText: null,
//                                       border: InputBorder.none,
//                                       hintText: "Email",
//                                       hintStyle: TextStyle(
//                                           color: AppTheme.getTheme()
//                                               .disabledColor),
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                         SizedBox(
//                           height: 16,
//                         ),
//                         Padding(
//                           padding: const EdgeInsets.only(left: 24, right: 24),
//                           child: Container(
//                             decoration: BoxDecoration(
//                               color: AppTheme.getTheme().backgroundColor,
//                               borderRadius:
//                                   BorderRadius.all(Radius.circular(38)),
//                               // border: Border.all(
//                               //   color: HexColor("#757575").withOpacity(0.6),
//                               // ),
//                               boxShadow: <BoxShadow>[
//                                 BoxShadow(
//                                   color: AppTheme.getTheme().dividerColor,
//                                   blurRadius: 8,
//                                   offset: Offset(4, 4),
//                                 ),
//                               ],
//                             ),
//                             child: Padding(
//                               padding:
//                                   const EdgeInsets.only(left: 16, right: 16),
//                               child: Container(
//                                 height: 48,
//                                 child: Center(
//                                   child: TextFormField(
//                                     controller: passController,
//                                     obscureText: !_cshowPassword,
//                                     validator: (value) {
//                                       if (value.isEmpty) {
//                                         return "Please enter your password";
//                                       }
//                                       return null;
//                                     },
//                                     onChanged: (String txt) {},
//                                     style: TextStyle(
//                                       fontSize: 16,
//                                     ),
//                                     cursorColor:
//                                         AppTheme.getTheme().primaryColor,
//                                     decoration: new InputDecoration(
//                                       errorText: null,
//                                       border: InputBorder.none,
//                                       suffixIcon: GestureDetector(
//                                         onTap: () {
//                                           setState(() {
//                                             _cshowPassword = !_cshowPassword;
//                                           });
//                                         },
//                                         child: Icon(_cshowPassword
//                                             ? Icons.visibility
//                                             : Icons.visibility_off),
//                                       ),
//                                       hintText: "Password",
//                                       hintStyle: TextStyle(
//                                           color: AppTheme.getTheme()
//                                               .disabledColor),
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),

//                         SizedBox(
//                           height: 20,
//                         ),
//                         Padding(
//                           padding: const EdgeInsets.only(
//                               left: 24, right: 24, bottom: 8, top: 16),
//                           child: Container(
//                             height: 48,
//                             decoration: BoxDecoration(
//                               color: AppTheme.getTheme().primaryColor,
//                               borderRadius:
//                                   BorderRadius.all(Radius.circular(24.0)),
//                               boxShadow: <BoxShadow>[
//                                 BoxShadow(
//                                   color: AppTheme.getTheme().dividerColor,
//                                   blurRadius: 8,
//                                   offset: Offset(4, 4),
//                                 ),
//                               ],
//                             ),
//                             child: Material(
//                               color: Colors.transparent,
//                               child: InkWell(
//                                 borderRadius:
//                                     BorderRadius.all(Radius.circular(24.0)),
//                                 highlightColor: Colors.transparent,
//                                 onTap: () {
//                                   if (key.currentState.validate()) {
//                                     auth.registerData(
//                                       firstNameController.text,
//                                       lastNameController.text,
//                                       phoneController.text,
//                                       emailController.text,
//                                       passController.text,
//                                     );
//                                   }
//                                 },
//                                 child: Center(
//                                   child: Text(
//                                     "Sign Up",
//                                     style: TextStyle(
//                                         fontWeight: FontWeight.w500,
//                                         fontSize: 16,
//                                         color: Colors.white),
//                                   ),
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                         SizedBox(
//                           height: 10,
//                         ),

//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           crossAxisAlignment: CrossAxisAlignment.center,
//                           children: [
//                             Text(
//                               "Already Have an Account? ",
//                               style: TextStyle(fontSize: 17),
//                             ),
//                             GestureDetector(
//                                 onTap: () {
//                                   Navigator.push(
//                                       context,
//                                       MaterialPageRoute(
//                                           builder: (context) => LoginWidget(
//                                                 hotelDetails: widget.hotel,
//                                                 rr: bookingList,
//                                               )));
//                                 },
//                                 child: Container(
//                                     child: Text(
//                                   "SignIn",
//                                   style: TextStyle(fontSize: 18),
//                                 ))),
//                           ],
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//           );

//     // SafeArea(
//     //     child: Padding(
//     //       padding: EdgeInsets.only(left: 25, top: 130),
//     //       child: Center(
//     //         child: ListView(children: <Widget>[
//     //           Padding(
//     //             padding: const EdgeInsets.only(left: 28.0, right: 28),
//     //             child: Theme(
//     //               data: new ThemeData(primaryColor: Colors.lightGreen),
//     //               child: TextField(
//     //                 controller: firstNameController,
//     //                 decoration: InputDecoration(
//     //                     prefixIcon: Icon(
//     //                       Icons.person_outline,
//     //                       color: Colors.black54,
//     //                     ),
//     //                     hintText: "Name"),
//     //               ),
//     //             ),
//     //           ),
//     //           SizedBox(
//     //             height: 20,
//     //           ),
//     //           Padding(
//     //             padding: const EdgeInsets.only(left: 28.0, right: 28),
//     //             child: Theme(
//     //               data: new ThemeData(primaryColor: Colors.lightGreen),
//     //               child: TextField(
//     //                 keyboardType: TextInputType.text,
//     //                 controller: lastNameController,
//     //                 decoration: InputDecoration(
//     //                     prefixIcon: Icon(
//     //                       Icons.person_outline,
//     //                       color: Colors.black54,
//     //                     ),
//     //                     hintText: 'Last Name'),
//     //               ),
//     //             ),
//     //           ),
//     //           SizedBox(
//     //             height: 20,
//     //           ),
//     //           Padding(
//     //             padding: const EdgeInsets.only(left: 28.0, right: 28),
//     //             child: Theme(
//     //               data: new ThemeData(primaryColor: Colors.lightGreen),
//     //               child: TextField(
//     //                 keyboardType: TextInputType.phone,
//     //                 controller: phoneController,
//     //                 decoration: InputDecoration(
//     //                     prefixIcon: Icon(
//     //                       Icons.phone,
//     //                       color: Colors.black54,
//     //                     ),
//     //                     hintText: 'Phone'),
//     //               ),
//     //             ),
//     //           ),
//     //           SizedBox(
//     //             height: 20,
//     //           ),
//     //           Padding(
//     //             padding: const EdgeInsets.only(left: 28.0, right: 28),
//     //             child: Theme(
//     //               data: new ThemeData(primaryColor: Colors.lightGreen),
//     //               child: TextField(
//     //                 controller: emailController,
//     //                 decoration: InputDecoration(
//     //                     prefixIcon: Icon(
//     //                       Icons.email,
//     //                       color: Colors.black54,
//     //                     ),
//     //                     hintText: 'Email'),
//     //               ),
//     //             ),
//     //           ),
//     //           SizedBox(
//     //             height: 20,
//     //           ),
//     //           Padding(
//     //             padding: const EdgeInsets.only(left: 28.0, right: 28),
//     //             child: Theme(
//     //               data: new ThemeData(primaryColor: Colors.lightGreen),
//     //               child: TextField(
//     //                 controller: passController,
//     //                 decoration: InputDecoration(
//     //                     prefixIcon: Icon(
//     //                       Icons.vpn_key,
//     //                       color: Colors.black54,
//     //                     ),
//     //                     hintText: 'Password'),
//     //               ),
//     //             ),
//     //           ),
//     //           SizedBox(
//     //             height: 10,
//     //           ),
//     //           Padding(
//     //             padding: const EdgeInsets.all(40.0),
//     //             child: Container(
//     //               height: 45,
//     //               width: 230,
//     //               child: RaisedButton(
//     //                 onPressed: () {
//     // auth.registerData(
//     //   firstNameController.text,
//     //   lastNameController.text,
//     //   phoneController.text,
//     //   emailController.text,
//     //   passController.text,
//     // );
//     //                 },
//     //                 color: Colors.indigo[800],
//     //                 child: Text(
//     //                   ('Register'),
//     //                   style: TextStyle(fontSize: 15, color: Colors.white),
//     //                 ),
//     //                 shape: RoundedRectangleBorder(
//     //                   borderRadius: BorderRadius.circular(20),
//     //                 ),
//     //               ),
//     //             ),
//     //           ),
//     //           SizedBox(
//     //             height: 30,
//     //           ),
//     //         ]),
//     //       ),
//     //     ),
//     //   );
//   }
// }
