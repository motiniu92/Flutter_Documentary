import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

class LoaderPage extends StatelessWidget {

  final String msg;

  const LoaderPage({Key key, @required this.msg})
      : super(key: key);


  @override
  Widget build(BuildContext context) {
    return  Builder(
        builder: (context) => SafeArea(
          child: Center(
            child: Container(
              child: Center(
                child: SpinKitCircle(color: Colors.blue),
              ),
              height: 200.0,
              width: 200.0,
              margin: EdgeInsets.only(left: 20.0, right: 20.0),
            ),

          ),
        ),

    );
  }

  double screenHeight(BuildContext context) =>
      MediaQuery.of(context).size.height;

  double screenWidth(BuildContext context) => MediaQuery.of(context).size.width;

  void showInSnackBar(BuildContext context, String value) {
    Scaffold.of(context).showSnackBar(new SnackBar(
        backgroundColor: Colors.white,
        content: new Text(
          value,
          style: TextStyle(
              color: Colors.red, fontSize: 25, fontWeight: FontWeight.bold),
        )));
  }
}
