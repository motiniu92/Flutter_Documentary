// import 'package:flutter/material.dart';
//
// class CompleteBookingScreen extends StatefulWidget {
//   @override
//   _CompleteBookingScreenState createState() => _CompleteBookingScreenState();
// }
//
// class _CompleteBookingScreenState extends State<CompleteBookingScreen> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Booking Screen"),
//         backgroundColor: Colors.indigo,
//       ),
//       body: Container(),
//     );
//   }
// }
