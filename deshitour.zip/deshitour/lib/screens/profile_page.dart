// // // <<<<<<< HEAD
// // // =======
// // // import 'dart:convert';
// // // import 'dart:io';
// // // import 'dart:ui';
// // //
// // // import 'package:flutter/material.dart';
// // // import 'package:new_motel/model/profile.dart';
// // // import 'package:new_motel/provider/authenticate.dart';
// // // import 'package:new_motel/provider/profile_provider.dart';
// // // import 'package:new_motel/service/apiService.dart';
// // // import 'package:new_motel/widget/login_widget.dart';
// // // import 'package:provider/provider.dart';
// // //
// // // import 'package:http/http.dart' as http;
// // // import 'package:shared_preferences/shared_preferences.dart';
// // //
// // // class ProfilePage extends StatefulWidget {
// // //   @override
// // //   _ProfilePageState createState() => _ProfilePageState();
// // // }
// // //
// // // class _ProfilePageState extends State<ProfilePage> {
// // // //   Future<String> getToken() async {
// // // //     SharedPreferences _sharedPreferences =
// // // //     await SharedPreferences.getInstance();
// // // //     return _sharedPreferences.getString("token");
// // // //
// // // // }
// // // //   @override
// // // //   void initState() {
// // // //     super.initState();
// // // //     // print('Token.....>>>> ${getToken()}');
// // // //     // getToken();
// // // //   }
// // //   ProfileResponse profile;
// // //
// // //   List<ProfileResponse> p;
// // //
// // //   Future<String> _startLoadScreen() async {
// // //     SharedPreferences _sharedPreferences =
// // //         await SharedPreferences.getInstance();
// // //     String token = _sharedPreferences.getString("access_token");
// // //
// // //
// // //     var response = await http.get(
// // //         'https://deshitour.com/api/login/profile?appKey=DeshiTour',
// // //         headers: {
// // //           "Authorization": token,
// // //         });
// // //     setState(() {
// // //       if (response.statusCode == 200) {
// // //         profile = Profile.fromJson(json.decode(response.body)).response;
// // //         print("profile=======>>>${profile.aiFirstName}");
// // //         print(response.body);
// // //       } else {
// // //         print("failed");
// // //         print("$token");
// // //       }
// // //     });
// // //   }
// // //
// // //   @override
// // //   void initState() async {
// // //     super.initState();
// // //     SharedPreferences _sharedPreferences =await
// // //     SharedPreferences.getInstance();
// // //     String token = _sharedPreferences.getString("token");
// // //
// // //     print("gdgfusgfuysgfusgfugsuf$token");
// // //     //getToken();
// // //     _startLoadScreen();
// // //   }
// // //
// // //   @override
// // //   Widget build(BuildContext context)  {
// // //     //print("Token=====>> $token");
// // //
// // //     //ProfileProvider profile = Provider.of<ProfileProvider>(context);'
// // //
// // //
// // //
// // //     return Scaffold(
// // //       appBar: AppBar(),
// // //       body: Container(
// // //         child: ListView.builder(
// // //           itemCount: p == null ? 0 : p.length,
// // //           itemBuilder: (context, index) {
// // //             return Text(profile.aiFirstName);
// // //           },
// // //         ),
// // //       ),
// // //     );
// // //   }
// // //
// // //   _getToken(String token) async {
// // //     SharedPreferences localStorage = await SharedPreferences.getInstance();
// // //     var token = localStorage.getString('token');
// // //     return '?token=$token';
// // //   }
// // // }
// // // //
// // // >>>>>>> 1850955794eb86f2d1a44c32b604748b8266b596
// // // import 'dart:convert';
// // // import 'dart:io';
// // // import 'dart:ui';
// // //
// // // import 'package:flutter/material.dart';
// // // import 'package:new_motel/model/profile.dart';
// // // import 'package:new_motel/provider/authenticate.dart';
// // // import 'package:new_motel/provider/profile_provider.dart';
// // // import 'package:new_motel/service/apiService.dart';
// // // import 'package:new_motel/widget/login_widget.dart';
// // // import 'package:provider/provider.dart';
// // //
// // // import 'package:http/http.dart' as http;
// // // import 'package:shared_preferences/shared_preferences.dart';
// // //
// // // class ProfilePage extends StatefulWidget {
// // //   @override
// // //   _ProfilePageState createState() => _ProfilePageState();
// // // }
// // //
// // // class _ProfilePageState extends State<ProfilePage> {
// // // //   Future<String> getToken() async {
// // // //     SharedPreferences _sharedPreferences =
// // // //     await SharedPreferences.getInstance();
// // // //     return _sharedPreferences.getString("token");
// // // //
// // // // }
// // // //   @override
// // // //   void initState() {
// // // //     super.initState();
// // // //     // print('Token.....>>>> ${getToken()}');
// // // //     // getToken();
// // // //   }
// // //
// // //
// // //   Future<String> _startLoadScreen() async {
// // //     SharedPreferences _sharedPreferences =
// // //         await SharedPreferences.getInstance();
// // //     String token = _sharedPreferences.getString("token");
// // //     var response = await http.get(
// // //         'https://deshitour.com/api/login/profile?appKey=DeshiTour',
// // //         headers: {
// // //           "Authorization": _getToken(token),
// // //         });
// // //     setState(() {
// // //       if (response.statusCode == 200) {
// // //         profile = Profile.fromJson(json.decode(response.body)).response;
// // //         _sharedPreferences.getString('token');
// // //         print(response.body);
// // //       } else {
// // //         print("failed");
// // //         print("$token");
// // //       }
// // //     });
// // //   }
// // //
// // //   @override
// // //   void initState() {
// // //     super.initState();
// // //     //getToken();
// // //     _startLoadScreen();
// // //   }
// // //
// // //   @override
// // //   Widget build(BuildContext context) {
// // //     //print("Token=====>> $token");
// // //
// // //     //ProfileProvider profile = Provider.of<ProfileProvider>(context);
// // //     return Scaffold(
// // //       appBar: AppBar(
// // //         title: Text("Profile"),
// // //       ),
// // //       body: Container(
// // //         child: ListView.builder(
// // //           itemCount: p == null ? 0 : p.length,
// // //           itemBuilder: (context, index) {
// // //             return Text(profile.aiFirstName);
// // //           },
// // //         ),
// // //       ),
// // //     );
// // //   }
// // //
// // //   _getToken(String token) async {
// // //     SharedPreferences localStorage = await SharedPreferences.getInstance();
// // //     var token = localStorage.getString('token');
// // //     return '?token=$token';
// // //   }
// // // }
// // // //
// // // // import 'dart:convert';
// // // //
// // // // import 'package:flutter/material.dart';
// // // // import 'package:http/http.dart' as http;
// // // // import 'package:new_motel/model/logonResponse.dart';
// // // // import 'package:shared_preferences/shared_preferences.dart';
// // // //
// // // // class LoginPage extends StatefulWidget {
// // // //   @override
// // // //   _LoginPageState createState() => _LoginPageState();
// // // // }
// // // //
// // // // class _LoginPageState extends State<LoginPage> {
// // // //   String token;
// // // //
// // // //   Future<void> login(String email, String password) async {
// // // //     final response = await http.post(
// // // //       "https://deshitour.com/api/login/profile?appKey=DeshiTour",
// // // //       body: {
// // // //         "email": email,
// // // //         "password": password,
// // // //       },
// // // //     );
// // // //
// // // //     savePref(token);
// // // //     print(response.body);
// // // //     final data = json.decode(response.body);
// // // //     print(data);
// // // //
// // // //     bool success = data["response"];
// // // //     String pMessage = data["message"];
// // // //
// // // //     if (success) {
// // // //       Map user = json.decode(response.body);
// // // //       if (user['data']['access_token'] != null) {
// // // //         print(user['data']['access_token']);
// // // //
// // // //         print(pMessage);
// // // //       }
// // // //     }
// // // //   }
// // // //
// // // //   @override
// // // //   Widget build(BuildContext context) {
// // // //     return Scaffold(
// // // //       appBar: AppBar(
// // // //         title: Text("Login"),
// // // //       ),
// // // //       body: Container(
// // // //         child: Column(
// // // //           children: [
// // // //             TextFormField(),
// // // //           ],
// // // //         ),
// // // //       ),
// // // //     );
// // // //   }
// // // //
// // // //   savePref(String token) async {
// // // //     SharedPreferences preferences = await SharedPreferences.getInstance();
// // // //
// // // //     return preferences.setString("token", token);
// // // //   }
// // // // }
// // // //
//
// // import 'dart:convert';
// // import 'dart:io';
//
// // import 'package:flutter/material.dart';
// // import 'package:new_motel/model/profile_model.dart';
// // import 'package:new_motel/utils/constants.dart';
// // import 'package:shared_preferences/shared_preferences.dart';
// // import 'package:http/http.dart' as http;
//
// // class ProfileScreenPage extends StatefulWidget {
// //   final String token;
//
// //   const ProfileScreenPage({Key key, this.token}) : super(key: key);
// //   @override
// //   _ProfileScreenPageState createState() => _ProfileScreenPageState();
// // }
//
// // class _ProfileScreenPageState extends State<ProfileScreenPage> {
// //   // Future<List<DataList>> fetchProfile() async {
// //   //
// //   //
// //   //
// //   // }  //<---------------------------Load Token
// //   Future loadToken() async {
// //     SharedPreferences prefs = await SharedPreferences.getInstance();
//
// //     prefs.getString('apiToken');
// //     return prefs.getString('apiToken');
// //   }
//
// //   Future<ProfileData> getProfile() async {
// //     SharedPreferences prefs = await SharedPreferences.getInstance();
// //     String token = prefs.getString('apiToken');
// //     String id = prefs.getString('id');
// //     String url =
// //         "https://deshitour.com/api/login/profile?appKey=DeshiTour&id=$id";
// //     String _token = await loadToken();
// //     print("PRofileTOken..$url $_token");
// //     var response = await http.get(url, headers: {
// //       HttpHeaders.authorizationHeader: token,
// //       HttpHeaders.contentTypeHeader: "application/json"
// //     });
// //     print('API ${response.statusCode}\n API${json.decode(response.body)}');
// //     if (response.statusCode == 200) {
// //       return ProfileData.fromJson(json.decode(response.body));
// //     } else {
// //       throw Exception(FAILED_MASSAGE);
// //     }
// //   }
//
// //   Future<ProfileData> futureProfileData;
// //   @override
// //   void initState() {
// //     super.initState();
// //     futureProfileData = getProfile();
// //   }
//
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: Text(PROFILE),
// //       ),
// //       body: FutureBuilder<ProfileData>(
// //         future: futureProfileData,
// //         builder: (buildContext, snapshot) {
// //           if (!snapshot.hasError) {
// //             return Text(snapshot.data.ai_first_name);
// //           } else {
// //             return Text(snapshot.error.toString());
// //           }
// //         },
// //       ),
// //     );
// //   }
// // }
//
//
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'dart:convert';
// import 'package:autocomplete_textfield/autocomplete_textfield.dart';
// import 'package:new_motel/model/countryListModel.dart';
//
// class AutoCompleteDemo extends StatefulWidget {
//
//   AutoCompleteDemo() : super();
//
//   final String title = "AutoComplete Demo";
//
//   @override
//   _AutoCompleteDemoState createState() => _AutoCompleteDemoState();
// }
//
// class _AutoCompleteDemoState extends State<AutoCompleteDemo> {
//
//   AutoCompleteTextField searchAutoTextField;
//   GlobalKey<AutoCompleteTextFieldState<CountryListResponse>> key = new GlobalKey();
//   // ignore: deprecated_member_use
//   static List<CountryListResponse> countries = new List<CountryListResponse>();
//   bool loading = true;
//
//   void getUsers() async {
//     try {
//       final response =
//       await http.get("https://jsonplaceholder.typicode.com/users");
//       if (response.statusCode == 200) {
//         users = loadUsers(response.body);
//         print('Users: ${users.length}');
//         setState(() {
//           loading = false;
//         });
//       } else {
//         print("Error getting users.");
//       }
//     } catch (e) {
//       print("Error getting users.");
//     }
//   }
//
//   static List<User> loadUsers(String jsonString) {
//     final parsed = json.decode(jsonString).cast<Map<String, dynamic>>();
//     return parsed.map<User>((json) => User.fromJson(json)).toList();
//   }
//
//   @override
//   void initState() {
//     getUsers();
//     super.initState();
//   }
//
//   Widget row(User user) {
//     return Row(
//       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       children: <Widget>[
//         Text(
//           user.name,
//           style: TextStyle(fontSize: 16.0),
//         ),
//         SizedBox(
//           width: 10.0,
//         ),
//         Text(
//           user.email,
//         ),
//       ],
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text(widget.title),
//       ),
//       body: Column(
//         mainAxisAlignment: MainAxisAlignment.start,
//         children: <Widget>[
//           loading
//               ? CircularProgressIndicator()
//               : searchTextField = AutoCompleteTextField<User>(
//             key: key,
//             clearOnSubmit: false,
//             suggestions: users,
//             style: TextStyle(color: Colors.black, fontSize: 16.0),
//             decoration: InputDecoration(
//               contentPadding: EdgeInsets.fromLTRB(10.0, 30.0, 10.0, 20.0),
//               hintText: "Search Name",
//               hintStyle: TextStyle(color: Colors.black),
//             ),
//             itemFilter: (item, query) {
//               return item.name
//                   .toLowerCase()
//                   .startsWith(query.toLowerCase());
//             },
//             itemSorter: (a, b) {
//               return a.name.compareTo(b.name);
//             },
//             itemSubmitted: (item) {
//               setState(() {
//                 searchTextField.textField.controller.text = item.name;
//               });
//             },
//             itemBuilder: (context, item) {
//               // ui for the autocompelete row
//               return row(item);
//             },
//           ),
//         ],
//       ),
//     );
//   }
// }
