import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:new_motel/modules/bottomTab/bottomTabScreen.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../appTheme.dart';

class MyWebView extends StatefulWidget {
  final String title;
  final String selectedUrl;

  MyWebView({
    @required this.title,
    @required this.selectedUrl,
  });

  @override
  _MyWebViewState createState() => _MyWebViewState();
}

class _MyWebViewState extends State<MyWebView> {
  final Completer<WebViewController> _controller =
      Completer<WebViewController>();
  InAppWebViewController _webViewController;

  @override
  Widget build(BuildContext context) {
    print("${widget.selectedUrl}");
    return Scaffold(
      appBar: AppBar(
        title: RichText(
          text: TextSpan(
              text: DESHI,
              style: TextStyle(
                fontSize: 30,
                fontFamily: 'Impact',
                color: HexColor("#26408A"),
              ),
              children: <TextSpan>[
                TextSpan(
                    text: TOUR,
                    style: TextStyle(
                      fontSize: 30,
                      fontFamily: 'Impact',
                      color: HexColor("#118ACB"),
                    )),
              ]),
        ),
        backgroundColor: Colors.white,
        elevation: 1,
        leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.black,
            ),
            onPressed: () {
              Navigator.pushAndRemoveUntil<dynamic>(
                context,
                MaterialPageRoute<dynamic>(
                  builder: (BuildContext context) => BottomTabScreen(),
                ),
                (route) =>
                    false, //if you want to disable back feature set to false
              );
              // Navigator.pop(context);
              // Navigator.push(
              //     context,
              //     MaterialPageRoute(
              //         builder: (context) => ProfileScreen()));
            }),
      ),
      body: InAppWebView(
          initialUrl: widget.selectedUrl,
          initialOptions: InAppWebViewGroupOptions(
            crossPlatform: InAppWebViewOptions(
              mediaPlaybackRequiresUserGesture: false,
              debuggingEnabled: true,
            ),
          ),
          onWebViewCreated: (InAppWebViewController controller) {
            _webViewController = controller;
          },
          androidOnPermissionRequest: (InAppWebViewController controller,
              String origin, List<String> resources) async {
            return PermissionRequestResponse(
                resources: resources,
                action: PermissionRequestResponseAction.GRANT);
          }),

      // WebView(
      //   initialUrl: widget.selectedUrl,
      //   javascriptMode: JavascriptMode.unrestricted,
      //   userAgent:
      //       'Mozilla/5.0 (Linux; <Android Version>; <Build Tag etc.>) AppleWebKit/<WebKit Rev> (KHTML, like Gecko) Chrome/<Chrome Rev> Mobile Safari/<WebKit Rev>',
      //   onWebViewCreated: (WebViewController webViewController) {
      //     _controller.complete(webViewController);
      //   },
      // ),
    );
  }
}
