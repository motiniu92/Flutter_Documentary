// import 'dart:async';
// import 'dart:convert';
// import 'dart:io';
// import 'dart:ui';
//
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/widgets.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:http/http.dart' as http;
// import 'package:intl/intl.dart';
// import 'package:new_motel/appTheme.dart';
// import 'package:new_motel/model/roomBookingRequest.dart';
// import 'package:new_motel/models/bookingDetails.dart';
// import 'package:new_motel/models/hotelList/hotelDetails.dart';
// import 'package:new_motel/modules/hotelDetailes/hotel_confirmation_screen.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:toggle_switch/toggle_switch.dart';
//
// import '../models/hotelList/hotelDetails.dart';
//
// class HotelRoomFormPage extends StatefulWidget {
//   final List<BookingDetails> rr;
//   final int days;
//   final HotelDetailsResponse hotel;
//
//   const HotelRoomFormPage({
//     Key key,
//     this.days,
//     this.rr,
//     @required this.hotel,
//   }) : super(key: key);
//
//   @override
//   _HotelRoomFormPageState createState() => _HotelRoomFormPageState();
// }
//
// //enum BestTutorSite { I am the main Guest, w3schools}
// enum BestTutorSite { MAIN_GUEST2, BOOKING_ELSE }
//
// class _HotelRoomFormPageState extends State<HotelRoomFormPage> {
//   bool rememberMe = false;
//
//   bool rememberMe2 = false;
//
//   int _groupValue = -1;
//   int _groupValue2 = 1;
//   String selectedItem;
//
//   int room = 0;
//   int price = 0;
//
//   GlobalKey<FormState> _key = GlobalKey<FormState>();
//
//   void _onRememberMeChanged(bool newValue) {
//     setState(() {
//       rememberMe = newValue;
//     });
//   }
//
//   void _onRememberMeChanged2(bool newValue2) {
//     setState(() {
//       rememberMe2 = newValue2;
//     });
//   }
//
//   List adult = [1, 2];
//   List smok = ['Smoking', 'Non-Smoking'];
//   List<BookingDetails> bookingList;
//
//   /// Complte this Booking Post API.............
//
//   bool isLoading = false;
//   String facilities;
//
//   // Map<String, dynamic> roomBooking = {};
//   RoomBookingRequest bookingDetailsModel;
//   String sessionId;
//
//   Future<void> checkHotelRoomBooking(
//     String itemid,
//     List<BkroomInf> bkroomInf,
//     String userId,
//     String currCode,
//     String currRate,
//     String currSymbol,
//     String purpose,
//     String officeLeisure,
//     String paymethod,
//   ) async {
//     final body = {
//       "itemid": itemid,
//       "bkroom_inf": bkroomInf,
//       "user_id": userId,
//       "currCode": currCode,
//       "currRate": currRate,
//       "currSymbol": currSymbol,
//       "purpose": '1',
//       "officeLeisure": officeLeisure,
//       "paymethod": paymethod,
//     };
//     print("Room Booking User Id ...$userId");
//
//     final jsonString = json.encode(body);
//     print("JSonEncoded.....>>>>$jsonString");
//     final headers = {HttpHeaders.contentTypeHeader: 'application/json'};
//
//     final response = await http.post(
//         "https://deshitour.com//api/hotels/hotelbook?appKey=DeshiTour",
//         headers: headers,
//         body: jsonString);
//     try {
//       var data = json.decode(response.body);
//       setState(() {
//         isLoading = true;
//       });
//       print("AAAAAAAAAA$data");
//       print("response==>>  ${data['response']}");
//       sessionId = data['response'];
//
//       print("Room Booking Abir Response... ...$sessionId");
//       // Check if User's Creds is valid,
//       // var isSuccess = data['response'] == true; // Write you own condition;
//       Fluttertoast.showToast(
//           msg: ('Successfully Booking Room'),
//           toastLength: Toast.LENGTH_SHORT,
//           gravity: ToastGravity.BOTTOM,
//           timeInSecForIosWeb: 2,
//           backgroundColor: Colors.indigo[800],
//           textColor: Colors.white,
//           fontSize: 16.0);
//       setState(() {
//         setState(() {
//           isLoading = true;
//         });
//         setButton(sessionId);
//       });
//     } catch (e) {
//       setState(() {
//         isLoading = false;
//       });
//       print(e);
//     }
//   }
//
//   List<String> maxAvailablity;
//   BookingDetails bookingDetails;
//   int value;
//
//   BkroomInf bkroomInf;
//   List<BkroomInf> bkroomInfList = List<BkroomInf>();
//   List<String> noOfGuest;
//   List<String> guestCountry;
//   List<String> nameOfGuest;
//   List<String> smokingPrefer;
//   List<String> idOfRoom;
//
//   String currRate1;
//
//   final email = TextEditingController();
//   final firstName = TextEditingController();
//   final lastName = TextEditingController();
//   final phone = TextEditingController();
//   final addressController = TextEditingController();
//   final countryListController = TextEditingController();
//
//   // var email;
//   // var firstName;
//   // var lastName;
//   // var phone;
//   BuildContext context1;
//
//   Future<String> getUserData() async {
//     // set User Data....>>>>
//     SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
//
//     // get User Data....>>>
//     email.text = sharedPreferences.getString('email');
//     print("SharedData>>>>${sharedPreferences.getString('email')}");
//     firstName.text = sharedPreferences.getString('firstName');
//     print("SharedData>>>>${sharedPreferences.getString('firstName')}");
//
//     lastName.text = sharedPreferences.getString('lastName');
//     print("SharedData>>>>${sharedPreferences.getString('lastName')}");
//     phone.text = sharedPreferences.getString('phone');
//     print("SharedData>>>>${sharedPreferences.getString('phone')}");
//     print("SharedData>>>>${sharedPreferences.getString('phone')}");
//
//     // sharedPreferences.getString(phoneController.text);
//     sharedPreferences.getString(addressController.text);
//     sharedPreferences.getString(countryListController.text);
//     setState(() {});
//   }
//
//   var checkBox1 = true;
//
//   List<bool> isSelected;
//   //BestTutorSite _site = BestTutorSite.javatpoint;
//   BestTutorSite _site = BestTutorSite.MAIN_GUEST2;
//
//   @override
//   void initState() {
//     super.initState();
//     isSelected = [true, false];
//     getUserData();
//     callApi();
//     // checkHotelRoomBooking();
//
//     print("Days 710: ${widget.days}");
//     // if (Platform.isAndroid) WebView.platform = SurfaceAndroidWebView();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     room = 0;
//     price = 0;
//     for (BookingDetails bookingDetails in widget.rr) {
//       print("Bijoy: Book count: ${bookingDetails.book_room_count}");
//       print("Bijoy: Book price: ${bookingDetails.bookingPrice}");
//
//       room += bookingDetails.book_room_count;
//       price += bookingDetails.book_room_count * bookingDetails.bookingPrice;
//     }
//
//     print("=====room Lenght====>>>>>${widget.rr.length}");
//
//     // widget.rr.forEach((car) => print("${car.book_room_name} is electric? ${car.adultsCount}"));
//     //  for(var item in widget.rr ) {
//     //    List<BookingDetails>list=List<BookingDetails>();
//     //    list.add(item);
//     //    for(var item2 in list){
//     //      if(item2.book_room_name!=item.book_room_name){
//     //        print("dultscount ${item2.adultsCount}");
//     //      }
//     //    }
//     //  }
//
//     // for(var i = 0; i< widget.rr.length; i++) {
//     //   print("${widget.rr[0].adultsCount} is electric? ${widget.rr[0].book_room_name}");
//     // }
//     bookingList = List<BookingDetails>();
//     maxAvailablity = List<String>();
//
//     for (var i = 0; i < 5 + 1; i++) {
//       maxAvailablity.add(i.toString());
//       print("===>>>>>max value>>>${i}");
// // =======
// //     for (var car in widget.rr) {
// //       value = car.adultsCount;
// //       print("===>>>>>car count>>>${value}");
// //       for (var i = 0; i < car.adultsCount + 1; i++) {
// //         maxAvailablity.add(i.toString());
// //         print("===>>>>>max value>>>${i}");
// //       }
// //       print("===>>>>>>>>${car.book_room_name} $value ${maxAvailablity.length}");
// //       for (int i = 0; i < widget.rr.length; i++) {
// //         if (car.book_room_name != widget.rr[i].book_room_name) {
// //           for (int j = 0; j < car.book_room_count; j++) {
// //             BookingDetails bookingDetails =
// //                 BookingDetails(j + 1, car.book_room_name, car.adultsCount);
// //             bookingList.add(bookingDetails);
// //             print("${bookingList.length}");
// //           }
// //         }
// //       }
// // >>>>>>> dd440ce80db8ea61a44e490a67705a7b1d2e7807
//     }
//
//     return SafeArea(
//       child: Scaffold(
//         backgroundColor: Colors.white,
//         appBar: AppBar(
//           title: Text(
//             "Booking Details",
//             style: TextStyle(color: Colors.black),
//           ),
//           leading: IconButton(
//             icon: Icon(Icons.arrow_back, color: Colors.black),
//             onPressed: () => Navigator.of(context).pop(),
//           ),
//           backgroundColor: Colors.white,
//           elevation: 1,
//         ),
//         body: Container(
//           child: Form(
//             key: _key,
//             child: ListView(
//               children: [
//                 Expanded(
//                   flex: 3,
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Container(
//                         decoration: BoxDecoration(
//                           color: Colors.black12,
//                           borderRadius: BorderRadius.all(Radius.circular(2)),
//                           boxShadow: <BoxShadow>[
//                             BoxShadow(
//                               color: AppTheme.getTheme().dividerColor,
//                               blurRadius: 8,
//                               offset: Offset(4, 4),
//                             ),
//                           ],
//                         ),
//                         height: 55,
//                         child: new Row(
//                           children: [
//                             // Left Expanded
//                             Expanded(
//                               child: Container(
//                                 width: MediaQuery.of(context).size.width / 2,
//                                 child: Column(
//                                   mainAxisAlignment: MainAxisAlignment.end,
//                                   children: [
//                                     Align(
//                                       alignment: Alignment.center,
//                                       child: Text(
//                                         "ROOM",
//                                         style: TextStyle(
//                                           fontWeight: FontWeight.bold,
//                                           fontSize: 18,
//                                         ),
//                                         textAlign: TextAlign.center,
//                                       ),
//                                     ),
//                                     SizedBox(
//                                       width:
//                                           MediaQuery.of(context).size.width / 2,
//                                       child: Text(
//                                         "$room",
//                                         // "0",
//                                         // widget.rooms,
//                                         style: TextStyle(
//                                           fontWeight: FontWeight.bold,
//                                           fontSize: 18,
//                                         ),
//                                         textAlign: TextAlign.center,
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                             ),
//
//                             VerticalDivider(
//                               width: 20,
//                               color: Colors.white,
//                             ),
//
//                             // Right Expanded
//                             Expanded(
//                               child: Container(
//                                 width: MediaQuery.of(context).size.width / 2,
//                                 child: Column(
//                                   mainAxisAlignment: MainAxisAlignment.end,
//                                   children: [
//                                     Align(
//                                       alignment: Alignment.center,
//                                       child: Text(
//                                         "BDT",
//                                         style: TextStyle(
//                                           fontWeight: FontWeight.bold,
//                                           fontSize: 18,
//                                         ),
//                                         textAlign: TextAlign.center,
//                                       ),
//                                     ),
//                                     SizedBox(
//                                       width:
//                                           MediaQuery.of(context).size.width / 2,
//                                       child: Text(
//                                         "${price}",
//                                         style: TextStyle(
//                                           fontWeight: FontWeight.bold,
//                                           fontSize: 18,
//                                         ),
//                                         textAlign: TextAlign.center,
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),
//                       Padding(
//                         padding:
//                             const EdgeInsets.only(left: 18, right: 24, top: 16),
//                         child: Container(
//                           decoration: BoxDecoration(
//                             color: AppTheme.getTheme().backgroundColor,
//                             borderRadius: BorderRadius.all(Radius.circular(38)),
//                             // border: Border.all(
//                             //   color: HexColor("#757575").withOpacity(0.6),
//                             // ),
//                             boxShadow: <BoxShadow>[
//                               BoxShadow(
//                                 color: AppTheme.getTheme().dividerColor,
//                                 blurRadius: 8,
//                                 offset: Offset(4, 4),
//                               ),
//                             ],
//                           ),
//                           // NID TextFields
//                           child: Padding(
//                             padding: const EdgeInsets.only(left: 16, right: 16),
//                             child: Container(
//                               height: 48,
//                               child: Center(
//                                 child: TextFormField(
//                                   controller: firstName,
//                                   validator: (value) {
//                                     if (value.isEmpty) {
//                                       return "Please enter first name";
//                                     }
//                                     return null;
//                                   },
//                                   maxLines: 1,
//                                   onChanged: (String txt) {},
//                                   style: TextStyle(
//                                     fontSize: 20,
//                                     fontWeight: FontWeight.bold,
//                                   ),
//                                   cursorColor: AppTheme.getTheme().primaryColor,
//                                   decoration: new InputDecoration(
//                                     errorText: null,
//                                     border: InputBorder.none,
//                                     // hintText: firstName,
//                                     hintStyle: TextStyle(
//                                         fontSize: 20,
//                                         fontWeight: FontWeight.bold,
//                                         color:
//                                             AppTheme.getTheme().disabledColor),
//                                   ),
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                       ),
//                       SizedBox(
//                         height: 16,
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(left: 18, right: 24),
//                         child: Container(
//                           decoration: BoxDecoration(
//                             color: AppTheme.getTheme().backgroundColor,
//                             borderRadius: BorderRadius.all(Radius.circular(38)),
//                             // border: Border.all(
//                             //   color: HexColor("#757575").withOpacity(0.6),
//                             // ),
//                             boxShadow: <BoxShadow>[
//                               BoxShadow(
//                                 color: AppTheme.getTheme().dividerColor,
//                                 blurRadius: 8,
//                                 offset: Offset(4, 4),
//                               ),
//                             ],
//                           ),
//                           // NID TextFields
//                           child: Padding(
//                             padding: const EdgeInsets.only(left: 16, right: 16),
//                             child: Container(
//                               height: 48,
//                               child: Center(
//                                 child: TextFormField(
//                                   controller: lastName,
//                                   validator: (value) {
//                                     if (value.isEmpty) {
//                                       return "Please enter last name";
//                                     }
//                                     return null;
//                                   },
//                                   maxLines: 1,
//                                   onChanged: (String txt) {},
//                                   style: TextStyle(
//                                     fontSize: 20,
//                                     fontWeight: FontWeight.bold,
//                                   ),
//                                   cursorColor: AppTheme.getTheme().primaryColor,
//                                   decoration: new InputDecoration(
//                                     errorText: null,
//                                     border: InputBorder.none,
//                                     // hintText: lastName,
//                                     hintStyle: TextStyle(
//                                         fontSize: 20,
//                                         fontWeight: FontWeight.bold,
//                                         color:
//                                             AppTheme.getTheme().disabledColor),
//                                   ),
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                       ),
//                       SizedBox(
//                         height: 16,
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(left: 18, right: 24),
//                         child: Container(
//                           decoration: BoxDecoration(
//                             color: AppTheme.getTheme().backgroundColor,
//                             borderRadius: BorderRadius.all(Radius.circular(38)),
//                             // border: Border.all(
//                             //   color: HexColor("#757575").withOpacity(0.6),
//                             // ),
//                             boxShadow: <BoxShadow>[
//                               BoxShadow(
//                                 color: AppTheme.getTheme().dividerColor,
//                                 blurRadius: 8,
//                                 offset: Offset(4, 4),
//                               ),
//                             ],
//                           ),
//                           // NID TextFields
//                           child: Padding(
//                             padding: const EdgeInsets.only(left: 16, right: 16),
//                             child: Container(
//                               height: 48,
//                               child: Center(
//                                 child: TextFormField(
//                                   controller: email,
//                                   enabled: false,
//                                   validator: (value) {
//                                     if (value.isEmpty) {
//                                       return "Please enter email address";
//                                     }
//                                     return null;
//                                   },
//                                   maxLines: 1,
//                                   onChanged: (String txt) {},
//                                   style: TextStyle(
//                                     fontSize: 20,
//                                   ),
//                                   cursorColor: AppTheme.getTheme().primaryColor,
//                                   decoration: new InputDecoration(
//                                     errorText: null,
//                                     border: InputBorder.none,
//
//                                     // hintText: email,
//                                     hintStyle: TextStyle(
//                                         fontSize: 20,
//                                         fontWeight: FontWeight.bold,
//                                         color:
//                                             AppTheme.getTheme().disabledColor),
//                                   ),
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                       ),
//                       SizedBox(
//                         height: 16,
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(left: 18, right: 24),
//                         child: Container(
//                           decoration: BoxDecoration(
//                             color: AppTheme.getTheme().backgroundColor,
//                             borderRadius: BorderRadius.all(Radius.circular(38)),
//                             // border: Border.all(
//                             //   color: HexColor("#757575").withOpacity(0.6),
//                             // ),
//                             boxShadow: <BoxShadow>[
//                               BoxShadow(
//                                 color: AppTheme.getTheme().dividerColor,
//                                 blurRadius: 8,
//                                 offset: Offset(4, 4),
//                               ),
//                             ],
//                           ),
//                           // NID TextFields
//                           child: Padding(
//                             padding: const EdgeInsets.only(left: 16, right: 16),
//                             child: Container(
//                               height: 48,
//                               child: Center(
//                                 child: TextFormField(
//                                   controller: phone,
//                                   validator: (value) {
//                                     if (value.isEmpty) {
//                                       return "Please enter your phone Number";
//                                     }
//                                     return null;
//                                   },
//                                   maxLines: 1,
//                                   onChanged: (String txt) {},
//                                   style: TextStyle(
//                                     fontSize: 20,
//                                     fontWeight: FontWeight.bold,
//                                   ),
//                                   cursorColor: AppTheme.getTheme().primaryColor,
//                                   decoration: new InputDecoration(
//                                     errorText: null,
//                                     border: InputBorder.none,
//                                     // hintText: phone,
//                                     hintStyle: TextStyle(
//                                         fontSize: 20,
//                                         color:
//                                             AppTheme.getTheme().disabledColor),
//                                   ),
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                       ),
//                       SizedBox(
//                         height: 16,
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(left: 18, right: 24),
//                         child: Container(
//                           decoration: BoxDecoration(
//                             color: AppTheme.getTheme().backgroundColor,
//                             borderRadius: BorderRadius.all(Radius.circular(38)),
//                             // border: Border.all(
//                             //   color: HexColor("#757575").withOpacity(0.6),
//                             // ),
//                             boxShadow: <BoxShadow>[
//                               BoxShadow(
//                                 color: AppTheme.getTheme().dividerColor,
//                                 blurRadius: 8,
//                                 offset: Offset(4, 4),
//                               ),
//                             ],
//                           ),
//                           // NID TextFields
//                           child: Padding(
//                             padding: const EdgeInsets.only(left: 16, right: 16),
//                             child: Container(
//                               height: 48,
//                               child: Center(
//                                 child: TextFormField(
//                                   validator: (value) {
//                                     if (value.isEmpty) {
//                                       return "Please enter your address";
//                                     }
//                                     return null;
//                                   },
//                                   maxLines: 1,
//                                   onChanged: (String txt) {},
//                                   style: TextStyle(
//                                     fontSize: 16,
//                                   ),
//                                   cursorColor: AppTheme.getTheme().primaryColor,
//                                   decoration: new InputDecoration(
//                                     errorText: null,
//                                     border: InputBorder.none,
//                                     hintText: "Address",
//                                     hintStyle: TextStyle(
//                                         fontSize: 17,
//                                         color:
//                                             AppTheme.getTheme().disabledColor),
//                                   ),
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                       ),
//                       SizedBox(
//                         height: 16,
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(left: 18, right: 24),
//                         child: Container(
//                           decoration: BoxDecoration(
//                             color: AppTheme.getTheme().backgroundColor,
//                             borderRadius: BorderRadius.all(Radius.circular(38)),
//                             // border: Border.all(
//                             //   color: HexColor("#757575").withOpacity(0.6),
//                             // ),
//                             boxShadow: <BoxShadow>[
//                               BoxShadow(
//                                 color: AppTheme.getTheme().dividerColor,
//                                 blurRadius: 8,
//                                 offset: Offset(4, 4),
//                               ),
//                             ],
//                           ),
//                           // NID TextFields
//                           child: Padding(
//                             padding: const EdgeInsets.only(left: 16, right: 16),
//                             child: Container(
//                               height: 48,
//                               child: Center(
//                                 child: TextFormField(
//                                   validator: (value) {
//                                     if (value.isEmpty) {
//                                       return "Please enter your select country";
//                                     }
//                                     return null;
//                                   },
//                                   maxLines: 1,
//                                   onChanged: (String txt) {},
//                                   style: TextStyle(
//                                     fontSize: 16,
//                                   ),
//                                   cursorColor: AppTheme.getTheme().primaryColor,
//                                   decoration: new InputDecoration(
//                                     errorText: null,
//                                     border: InputBorder.none,
//                                     hintText: "Country",
//                                     hintStyle: TextStyle(
//                                         fontSize: 17,
//                                         color:
//                                             AppTheme.getTheme().disabledColor),
//                                   ),
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                       ),
//                       SizedBox(
//                         height: 16,
//                       ),
//                       Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         mainAxisAlignment: MainAxisAlignment.start,
//                         children: [
//                           Padding(
//                             padding: const EdgeInsets.only(left: 18.0, top: 25),
//                             child: ToggleSwitch(
//                               minWidth: 110.0,
//                               initialLabelIndex: 1,
//                               cornerRadius: 30.0,
//                               activeFgColor: Colors.black,
//                               inactiveBgColor: Colors.blueGrey,
//                               inactiveFgColor: Colors.white,
//                               labels: ['Personal ', 'Official'],
//                               activeBgColors: [Colors.white, Colors.white],
//                               onToggle: (index) {
//                                 print('switched to: $index');
//                               },
//                             ),
//                           ),
//                           SizedBox(
//                             height: 10,
//                           ),
//                           Padding(
//                             padding: const EdgeInsets.only(left: 18.0, top: 10),
//                             child: Text(
//                               "Purpose of Travel",
//                               style: TextStyle(fontSize: 17),
//                             ),
//                           ),
//                           SizedBox(
//                             height: 10,
//                           ),
//                           Padding(
//                             padding: const EdgeInsets.only(left: 18.0, top: 5),
//                             child: Container(
//                               height: 40,
//                               width: 170,
//                               child: TextField(
//                                 decoration: InputDecoration(
//                                   hintText: " Ex: Leisure",
//                                   contentPadding:
//                                       EdgeInsets.only(top: 3, left: 15),
//                                   border: OutlineInputBorder(
//                                       borderRadius: BorderRadius.circular(15)),
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                       SizedBox(
//                         height: 10,
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(left: 18.0, right: 18),
//                         child: Divider(
//                           color: Colors.grey,
//                           thickness: 1,
//                         ),
//                       ),
//                       SizedBox(
//                         height: 10,
//                       ),
//                       Center(
//                           child: Text(
//                               "Priority of Early Check in & Late Check out !")),
//                       SizedBox(
//                         height: 10,
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(left: 18.0, right: 18),
//                         child: Divider(
//                           color: Colors.grey,
//                           thickness: 1,
//                         ),
//                       ),
//                       SizedBox(
//                         height: 10,
//                       ),
//                     ],
//                   ),
//                 ),
//                 Expanded(
//                   child: ListView.builder(
//                     shrinkWrap: true,
//                     primary: false,
//                     itemCount: widget.rr == null ? 0 : widget.rr.length,
//                     itemBuilder: (_, index) {
//                       return ClipRRect(
//                         borderRadius: BorderRadius.circular(10),
//                         child: Card(
//                           margin:
//                               EdgeInsets.symmetric(horizontal: 10, vertical: 8),
//                           elevation: 1,
//                           child: Padding(
//                             padding: const EdgeInsets.only(left: 8.0, right: 0),
//                             child: Padding(
//                               padding: const EdgeInsets.only(top: 5.0),
//                               child: Container(
//                                 height: 80,
//                                 child: Row(
//                                   mainAxisAlignment:
//                                       MainAxisAlignment.spaceAround,
//                                   children: [
//                                     OutlineButton(
//                                       onPressed: () {},
//                                       child: Text(
//                                         "Room  x  ${widget.rr[index].book_room_count}",
//                                         style: TextStyle(fontSize: 17),
//                                       ),
//                                     ),
//                                     SizedBox(
//                                       width: 15,
//                                     ),
//                                     Expanded(
//                                       child: Padding(
//                                         padding: const EdgeInsets.all(8.0),
//                                         child: Container(
//                                           child: Text(
//                                             "${widget.rr[index].book_room_name}",
//                                             maxLines: 3,
//                                             // widget.rr[index].title,
//                                             style: TextStyle(
//                                               fontSize: 17,
//                                             ),
//                                           ),
//                                         ),
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                       );
//                     },
//                   ),
//                 ),
//                 SizedBox(
//                   height: 15,
//                 ),
//                 Row(
//                   children: [
//                     Padding(
//                       padding: const EdgeInsets.only(left: 10.0),
//                       child: Checkbox(
//                         value: this.checkBox1,
//                         onChanged: (bool value) {
//                           setState(() {
//                             this.checkBox1 = value;
//                           });
//                         },
//                       ),
//                     ),
//                     Expanded(
//                       child: Text(
//                           'I have read and agree to the Terms and Conditions and Hotel Policy'),
//                     ),
//                   ],
//                 ),
//                 SizedBox(
//                   height: 15,
//                 ),
//                 Padding(
//                   padding: EdgeInsets.only(
//                       left: 16,
//                       right: 16,
//                       bottom: 16 + MediaQuery.of(context).padding.bottom,
//                       top: 8),
//                   child: Container(
//                     height: 48,
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().primaryColor,
//                       borderRadius: BorderRadius.all(Radius.circular(24.0)),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Material(
//                       color: Colors.transparent,
//                       child: InkWell(
//                         borderRadius: BorderRadius.all(Radius.circular(24.0)),
//                         highlightColor: Colors.transparent,
//                         onTap: () async {
//                           for (var bkoo in bkroomInfList) {
//                             print(
//                                 "book list ${bkoo.id} , ${bkoo.price} , ${bkoo.count}");
//                           }
//                           SharedPreferences sharedPreferences =
//                               await SharedPreferences.getInstance();
//                           String itemid = widget.hotel.hotel.id;
//                           List<BkroomInf> bkroomInf = bkroomInfList;
//                           String userId = sharedPreferences.getString('id');
//                           String currCode = widget.hotel.rooms[0].currCode;
//                           String currRate = widget.hotel.rooms[0].currRate;
//                           String currSymbol = widget.hotel.rooms[0].currSymbol;
//                           String purpose = "";
//                           String officeLeisure = "Leisure";
//                           String paymethod =
//                               widget.hotel.hotel.paymentOptions[0].name;
//
//                           print("USERID-> $userId");
//                           checkHotelRoomBooking(
//                             itemid,
//                             bkroomInf,
//                             userId,
//                             currCode,
//                             currRate,
//                             currSymbol,
//                             purpose,
//                             officeLeisure,
//                             paymethod,
//                           );
//                           // setState(() {
//                           //   isLoading = true;
//                           // });
//
//                           // Fluttertoast.showToast(
//                           //     msg: ('Successfully Booking Room'),
//                           //     toastLength: Toast.LENGTH_SHORT,
//                           //     gravity: ToastGravity.BOTTOM,
//                           //     timeInSecForIosWeb: 2,
//                           //     backgroundColor: Colors.indigo[800],
//                           //     textColor: Colors.white,
//                           //     fontSize: 16.0);
//
//                           // final Completer<WebViewController> _controller =
//                           //     Completer<WebViewController>();
//
//                           // WebView(
//                           //   initialUrl:
//                           //       "https:\/\/deshitour.com\/invoice$itemid",
//                           //   javascriptMode: JavascriptMode.unrestricted,
//                           //   onWebViewCreated:
//                           //       (WebViewController webViewController) {
//                           //     _controller.complete(webViewController);
//                           //   },
//                           // );
//                         },
//                         child: Center(
//                           child: Text(
//                             "Complete This Booking",
//                             style: TextStyle(
//                                 fontWeight: FontWeight.bold,
//                                 fontSize: 19,
//                                 color: Colors.white),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 SizedBox(
//                   height: 10,
//                 ),
//                 Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   mainAxisAlignment: MainAxisAlignment.start,
//                   children: [
//                     Padding(
//                       padding: const EdgeInsets.only(left: 16.0, top: 25),
//                       child: ToggleButtons(
//                         borderColor: Colors.grey,
//                         fillColor: HexColor("#26408A"),
//                         borderWidth: 2,
//                         selectedBorderColor: Colors.black,
//                         selectedColor: Colors.white,
//                         borderRadius: BorderRadius.circular(18),
//                         children: <Widget>[
//                           Padding(
//                             padding: const EdgeInsets.all(14.0),
//                             child: Text(
//                               'Personal',
//                               style: TextStyle(fontSize: 16),
//                             ),
//                           ),
//                           Padding(
//                             padding: const EdgeInsets.all(14.0),
//                             child: Text(
//                               'Official',
//                               style: TextStyle(fontSize: 16),
//                             ),
//                           ),
//                         ],
//                         onPressed: (int index) {
//                           setState(() {
//                             for (int i = 0; i < isSelected.length; i++) {
//                               isSelected[i] = i == index;
//                             }
//                           });
//                         },
//                         isSelected: isSelected,
//                       ),
//                     ),
//                     SizedBox(
//                       height: 10,
//                     ),
//                     Padding(
//                       padding: const EdgeInsets.only(left: 18.0, top: 10),
//                       child: Text(
//                         "Purpose of Travel",
//                         style: TextStyle(fontSize: 17),
//                       ),
//                     ),
//                     SizedBox(
//                       height: 10,
//                     ),
//                     Padding(
//                       padding: const EdgeInsets.only(left: 18.0, top: 5),
//                       child: Container(
//                         height: 40,
//                         width: 170,
//                         child: TextField(
//                           decoration: InputDecoration(
//                             hintText: " Ex: Leisure",
//                             contentPadding: EdgeInsets.only(top: 3, left: 15),
//                             border: OutlineInputBorder(
//                                 borderRadius: BorderRadius.circular(15)),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//                 // _myRadioButton(
//                 //   title: "I am the main Guest",
//                 //   value: 0,
//                 //   onChanged: (newValue) =>
//                 //       setState(() => _groupValue2 = newValue),
//                 // ),
//                 // _myRadioButton(
//                 //   title: "Booking is for someone else",
//                 //   value: 1,
//                 //   onChanged: (newValue) =>
//                 //       setState(() => _groupValue = newValue),
//                 // ),
//
//                 Padding(
//                   padding: const EdgeInsets.only(left: 0.0),
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     children: [
//                       ListTile(
//                         title: const Text('I am the main Guest'),
//                         leading: Radio(
//                           value: BestTutorSite.MAIN_GUEST2,
//                           groupValue: _site,
//                           onChanged: (BestTutorSite value) {
//                             setState(() {
//                               _site = value;
//                             });
//                           },
//                         ),
//                       ),
//                       ListTile(
//                         title: const Text('Booking is for someone else'),
//                         leading: Radio(
//                           value: BestTutorSite.BOOKING_ELSE,
//                           groupValue: _site,
//                           onChanged: (BestTutorSite value) {
//                             setState(() {
//                               _site = value;
//                             });
//                           },
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//
//                 SizedBox(
//                   height: 10,
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.only(left: 18.0, right: 18),
//                   child: Divider(
//                     color: Colors.grey,
//                     thickness: 1,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   void callApi() {
//     double taxCount = double.parse(widget.hotel.hotel.taxval);
//
//     for (var i = 0; i < widget.rr.length; i++) {
//       for (var j = 0; j < widget.hotel.rooms.length; j++) {
//         if (widget.rr[i].id == widget.hotel.rooms[j].id) {
//           var parts = widget.hotel.rooms[j].price.split(',');
//           var bbb = parts[0].trim(); // prefix: "date"
//           var bbb1 = parts[1].trim(); // prefix: "date"
//           var calculation = int.parse(bbb + bbb1);
//
//           var taxCaulation = calculation * taxCount / 100;
//           var checkIn = getDateFormate(widget.hotel.rooms[j].info.checkin);
//           var checkOut = getDateFormate(widget.hotel.rooms[j].info.checkout);
//
//           // var checkIn=f.parse();
//           String id = widget.hotel.rooms[j].id;
//           String price = calculation.toString();
//           String count = widget.rr[i].book_room_count.toString();
//           String tax = taxCaulation.toString();
//           String rckin = checkIn.toString();
//           String rckout = checkOut.toString();
//
//           bkroomInf = BkroomInf(
//             id,
//             price,
//             count,
//             tax,
//             rckin,
//             rckout,
//           );
//
//           print(
//               "room list ${taxCaulation.toString()} ${widget.rr[i].book_room_count} $checkIn $checkOut");
//         }
//       }
//       bkroomInfList.add(bkroomInf);
//     }
//   }
//
//   // Widget _myRadioButton({String title, int value, Function onChanged}) {
//   //   return RadioListTile<int>(
//   //     value: value,
//   //     groupValue: _groupValue,
//   //     onChanged: onChanged,
//   //     title: Text(title),
//   //   );
//   // }
//
//   getDateFormate(String date) {
//     DateTime parseDate = new DateFormat("yyyy-MM-dd").parse(date);
//     var inputDate = DateTime.parse(parseDate.toString());
//     var outputFormat = DateFormat('dd/MM/yyyy');
//     var output = outputFormat.format(inputDate);
//     return output;
//   }
//
//   void setButton(String body) async {
//     SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
//     var userId = sharedPreferences.getString('id');
//
//     print("==>>> $userId $body");
//     Navigator.of(context).pop();
//     Navigator.push(
//         context,
//         MaterialPageRoute(
//             builder: (BuildContext context) =>
//                 HotelConfirmationScreen(url: body)));
//
//     // Navigator.push(
//     //     context,
//     //     MaterialPageRoute(
//     //         builder: (BuildContext context) =>
//     //             MyWebView(title: "Invoice", selectedUrl: body)));
//   }
// }
//
// class RoomBookingDetailsScreen extends StatefulWidget {
//   final BookingDetails bookingDetails;
//
//   const RoomBookingDetailsScreen({Key key, @required this.bookingDetails})
//       : super(key: key);
//
//   @override
//   _RoomBookingDetailsScreenState createState() =>
//       _RoomBookingDetailsScreenState();
// }
//
// class _RoomBookingDetailsScreenState extends State<RoomBookingDetailsScreen> {
//   String selectedItem;
//
//   List<String> maxAvailablity;
//
//   @override
//   Widget build(BuildContext context) {
//     maxAvailablity = List<String>();
//     int num = widget.bookingDetails.adultsCount;
//     for (var i = 0; i < num + 1; i++) {
//       setState(() {
//         maxAvailablity.add(i.toString());
//       });
//     }
//
//     return Padding(
//       padding: const EdgeInsets.only(left: 8.0, right: 0),
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.spaceAround,
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Padding(
//             padding: const EdgeInsets.only(top: 15.0),
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.spaceAround,
//               children: [
//                 OutlineButton(
//                   onPressed: () {},
//                   child: Text(
//                     "Room ${widget.bookingDetails.book_room_count}",
//                     style: TextStyle(fontSize: 17),
//                   ),
//                 ),
//                 SizedBox(
//                   width: 15,
//                 ),
//                 Expanded(
//                   child: Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: Container(
//                       child: Text(
//                         "${widget.bookingDetails.book_room_name}",
//                         maxLines: 3,
//                         // widget.rr[index].title,
//                         style: TextStyle(
//                           fontSize: 17,
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           Padding(
//             padding: const EdgeInsets.only(top: 15.0),
//             child: Row(
//               // mainAxisAlignment: MainAxisAlignment.spaceAround,
//               children: [
//                 Container(
//                   height: 40,
//                   width: 180,
//                   child: TextFormField(
//                     decoration: InputDecoration(
//                         hintText: "Guest Name", border: OutlineInputBorder()),
//                   ),
//                 ),
//                 SizedBox(
//                   width: 15,
//                 ),
//                 Container(
//                   height: 40,
//                   width: 120,
//                   child: Center(
//                     child: DropdownButtonFormField(
//                       isDense: false,
//                       itemHeight: 65,
//                       decoration: InputDecoration(
//                           border: OutlineInputBorder(
//                             borderRadius: const BorderRadius.all(
//                               const Radius.circular(5.0),
//                             ),
//                           ),
//                           filled: true,
//                           hintStyle:
//                               TextStyle(fontSize: 15, color: Colors.black),
//                           hintText: maxAvailablity[0],
//                           fillColor: Colors.white),
//                       value: selectedItem,
//                       onChanged: (String value) {
//                         setState(() {
//                           selectedItem = value;
//                           // _storeLoggedInStatus(widget.roomData.id);
//                           // _storeData(facilities);
//                           // getFunction(widget.roomData.id, facilities);
//                           //    firstFunction(int.parse(facilities), widget.roomData.price);
//                         });
//
//                         //     setState(() {
//                         //String room_id= await _getLoggedInStatus();
//                         //   var value1 = int.parse(facilities);
//                         //   var str = widget.roomData.price;
//                         //
//                         //
//                         //    int price = int.parse(c);
//                         //   var total_price = value1 * price;
//                         //
//                         //   if (total_price != null)
//                         //     price1 += total_price;
//                         //   else
//                         //     price1 -= total_price;
//                         //   print(
//                         //       " value change ${total_price.toString()}");
//                         // });
//                         //
//                         // print("room ${price1}");
//                         //
//                         // widget.callBack(price1);
//                       },
//                       items: maxAvailablity
//                           .map((cityTitle) => DropdownMenuItem(
//                               value: cityTitle, child: Text("$cityTitle")))
//                           .toList(),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           SizedBox(
//             height: 14,
//           ),
//           Row(
//             // mainAxisAlignment: MainAxisAlignment.spaceAround,
//             children: [
//               Container(
//                 height: 40,
//                 width: 150,
//                 child: TextFormField(
//                   decoration: InputDecoration(
//                       hintText: "Bangladesh", border: OutlineInputBorder()),
//                 ),
//               ),
//               SizedBox(
//                 width: 15,
//               ),
//               Container(
//                 height: 40,
//                 width: 160,
//                 child: TextFormField(
//                   decoration: InputDecoration(
//                     hintText: "Smoking",
//                     border: OutlineInputBorder(),
//                     suffixIcon: Icon(
//                       Icons.keyboard_arrow_down_rounded,
//                       size: 30,
//                     ),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }
// }
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:new_motel/appTheme.dart';
import 'package:new_motel/model/roomBookingRequest.dart';
import 'package:new_motel/models/bookingDetails.dart';
import 'package:new_motel/models/hotelList/hotelDetails.dart';
import 'package:new_motel/modules/hotelDetailes/hotel_confirmation_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../loaderPage.dart';
import '../models/hotelList/hotelDetails.dart';

class HotelRoomFormPage extends StatefulWidget {
  final List<BookingDetails> rr;
  final int days;
  final HotelDetailsResponse hotel;

  const HotelRoomFormPage({
    Key key,
    this.days,
    this.rr,
    @required this.hotel,
  }) : super(key: key);

  @override
  _HotelRoomFormPageState createState() => _HotelRoomFormPageState();
}

//enum BestTutorSite { I am the main Guest, w3schools}
enum BestTutorSite { MAIN_GUEST2, BOOKING_ELSE }

class _HotelRoomFormPageState extends State<HotelRoomFormPage> {
  bool rememberMe = false;

  bool rememberMe2 = false;

  int _groupValue = -1;
  int _groupValue2 = 1;
  String selectedItem;

  int room = 0;
  int price = 0;

  GlobalKey<FormState> _key = GlobalKey<FormState>();

  void _onRememberMeChanged(bool newValue) {
    setState(() {
      rememberMe = newValue;
    });
  }

  void _onRememberMeChanged2(bool newValue2) {
    setState(() {
      rememberMe2 = newValue2;
    });
  }

  List adult = [1, 2];
  List smok = ['Smoking', 'Non-Smoking'];
  List<BookingDetails> bookingList;

  /// Complte this Booking Post API.............

  bool isLoading = false;
  String facilities;

  // Map<String, dynamic> roomBooking = {};
  RoomBookingRequest bookingDetailsModel;
  String sessionId;

  Future<void> checkHotelRoomBooking(
    String itemid,
    List<BkroomInf> bkroomInf,
    String userId,
    String currCode,
    String currRate,
    String currSymbol,
    String purpose,
    String officeLeisure,
    String paymethod,
  ) async {
    final body = {
      "itemid": itemid,
      "bkroom_inf": bkroomInf,
      "user_id": userId,
      "currCode": currCode,
      "currRate": currRate,
      "currSymbol": currSymbol,
      "purpose": '1',
      "officeLeisure": officeLeisure,
      "paymethod": paymethod,
      "no_of_guest": '',
      "guest_country": '',
      "name_of_guest": '',
    };
    print("Room Booking User Id ...$userId");

    final jsonString = json.encode(body);
    print("JSonEncoded.....>>>>$jsonString");
    final headers = {HttpHeaders.contentTypeHeader: 'application/json'};

    final response = await http.post(
        "https://deshitour.com/api/hotels/hotelbook?appKey=DeshiTour",
        headers: headers,
        body: jsonString);
    // try {
    //   var data = json.decode(response.body);
    //   print("response==>>  ${data['response']}");
    //   sessionId = data['response'];
    //   print("Room Booking Response Session ...$sessionId");
    //   // Check if User's Creds is valid,
    //   // var isSuccess = data['response'] == true; // Write you own condition;
    //   Fluttertoast.showToast(
    //       msg: ('Successfully Booking Room'),
    //       toastLength: Toast.LENGTH_SHORT,
    //       gravity: ToastGravity.BOTTOM,
    //       timeInSecForIosWeb: 2,
    //       backgroundColor: Colors.indigo[800],
    //       textColor: Colors.white,
    //       fontSize: 16.0);
    //   setState(() {
    //     setButton(sessionId);
    //   });
    // } catch (e) {
    //   print(e);
    // }

    //  hotelBookingBooking.....
    try {
      var data = json.decode(response.body);
      print("Abir...$data");
      var status = data['status'];
      var msg = data['msg'];
      if (status == 1) {
        sessionId = data['invoice'];
        Fluttertoast.showToast(
            msg: (msg),
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 2,
            backgroundColor: Colors.indigo[800],
            textColor: Colors.white,
            fontSize: 16.0);
        setState(() {
          setButton(sessionId);
        });
      } else {
        Fluttertoast.showToast(
            msg: (msg),
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 2,
            backgroundColor: Colors.indigo[800],
            textColor: Colors.white,
            fontSize: 16.0);
      }
    } catch (e) {
      print(e);
    }
  }

  List<String> maxAvailablity;
  BookingDetails bookingDetails;
  int value;

  BkroomInf bkroomInf;
  List<BkroomInf> bkroomInfList = [];
  List<String> noOfGuest;
  List<String> guestCountry;
  List<String> nameOfGuest;
  List<String> smokingPrefer;
  List<String> idOfRoom;

  String currRate1;

  final email = TextEditingController();
  final firstName = TextEditingController();
  final lastName = TextEditingController();
  final phone = TextEditingController();
  final addressController = TextEditingController();
  final countryListController = TextEditingController();
  final leisureDataController = TextEditingController();
  String leisureData = "Ex: Leisure";

  // var email;
  // var firstName;
  // var lastName;
  // var phone;
  BuildContext context1;

  Future<String> getUserData() async {
    // set User Data....>>>>
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    // get User Data....>>>
    email.text = sharedPreferences.getString('email');
    print("SharedData>>>>${sharedPreferences.getString('email')}");
    firstName.text = sharedPreferences.getString('firstName');
    print("SharedData>>>>${sharedPreferences.getString('firstName')}");

    lastName.text = sharedPreferences.getString('lastName');
    print("SharedData>>>>${sharedPreferences.getString('lastName')}");
    phone.text = sharedPreferences.getString('phone');
    print("SharedData>>>>${sharedPreferences.getString('phone')}");
    print("SharedData>>>>${sharedPreferences.getString('phone')}");

    // sharedPreferences.getString(phoneController.text);
    sharedPreferences.getString(addressController.text);
    sharedPreferences.getString(countryListController.text);
    setState(() {});
  }

  var checkBox1 = true;
  List<bool> isSelected;
  //BestTutorSite _site = BestTutorSite.javatpoint;
  BestTutorSite _site = BestTutorSite.MAIN_GUEST2;

  @override
  void initState() {
    super.initState();
    isSelected = [true, false];
    getUserData();
    callApi();
    // checkHotelRoomBooking();

    print("Days 710: ${widget.days}");
    // if (Platform.isAndroid) WebView.platform = SurfaceAndroidWebView();
  }

  @override
  Widget build(BuildContext context) {
    room = 0;
    price = 0;
    for (BookingDetails bookingDetails in widget.rr) {
      print("Bijoy: Book count: ${bookingDetails.book_room_count}");
      print("Bijoy: Book price: ${bookingDetails.bookingPrice}");

      room += bookingDetails.book_room_count;
      price += bookingDetails.book_room_count * bookingDetails.bookingPrice;
    }

    print("=====room Lenght====>>>>>${widget.rr.length}");

    // widget.rr.forEach((car) => print("${car.book_room_name} is electric? ${car.adultsCount}"));
    //  for(var item in widget.rr ) {
    //    List<BookingDetails>list=List<BookingDetails>();
    //    list.add(item);
    //    for(var item2 in list){
    //      if(item2.book_room_name!=item.book_room_name){
    //        print("dultscount ${item2.adultsCount}");
    //      }
    //    }
    //  }

    // for(var i = 0; i< widget.rr.length; i++) {
    //   print("${widget.rr[0].adultsCount} is electric? ${widget.rr[0].book_room_name}");
    // }
    bookingList = List<BookingDetails>();
    maxAvailablity = List<String>();

    for (var i = 0; i < 5 + 1; i++) {
      maxAvailablity.add(i.toString());
      print("===>>>>>max value>>>${i}");
// =======
//     for (var car in widget.rr) {
//       value = car.adultsCount;
//       print("===>>>>>car count>>>${value}");
//       for (var i = 0; i < car.adultsCount + 1; i++) {
//         maxAvailablity.add(i.toString());
//         print("===>>>>>max value>>>${i}");
//       }
//       print("===>>>>>>>>${car.book_room_name} $value ${maxAvailablity.length}");
//       for (int i = 0; i < widget.rr.length; i++) {
//         if (car.book_room_name != widget.rr[i].book_room_name) {
//           for (int j = 0; j < car.book_room_count; j++) {
//             BookingDetails bookingDetails =
//                 BookingDetails(j + 1, car.book_room_name, car.adultsCount);
//             bookingList.add(bookingDetails);
//             print("${bookingList.length}");
//           }
//         }
//       }
// >>>>>>> dd440ce80db8ea61a44e490a67705a7b1d2e7807
    }

    return isLoading
        ? Center(
            child: LoaderPage(),
          )
        : SafeArea(
            child: Scaffold(
              backgroundColor: Colors.white,
              appBar: AppBar(
                title: Text(
                  "Booking Details",
                  style: TextStyle(color: Colors.black),
                ),
                leading: IconButton(
                  icon: Icon(Icons.arrow_back, color: Colors.black),
                  onPressed: () => Navigator.of(context).pop(),
                ),
                backgroundColor: Colors.white,
                elevation: 1,
              ),
              body: Container(
                child: Form(
                  key: _key,
                  child: ListView(
                    children: [
                      Expanded(
                        flex: 3,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                color: Colors.black12,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(2)),
                                boxShadow: <BoxShadow>[
                                  BoxShadow(
                                    color: AppTheme.getTheme().dividerColor,
                                    blurRadius: 8,
                                    offset: Offset(4, 4),
                                  ),
                                ],
                              ),
                              height: 55,
                              child: new Row(
                                children: [
                                  // Left Expanded
                                  Expanded(
                                    child: Container(
                                      width:
                                          MediaQuery.of(context).size.width / 2,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Align(
                                            alignment: Alignment.center,
                                            child: Text(
                                              "ROOM",
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 18,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                          SizedBox(
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width /
                                                2,
                                            child: Text(
                                              "$room",
                                              // "0",
                                              // widget.rooms,
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 18,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),

                                  VerticalDivider(
                                    width: 20,
                                    color: Colors.white,
                                  ),

                                  // Right Expanded
                                  Expanded(
                                    child: Container(
                                      width:
                                          MediaQuery.of(context).size.width / 2,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Align(
                                            alignment: Alignment.center,
                                            child: Text(
                                              "BDT",
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 18,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                          SizedBox(
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width /
                                                2,
                                            child: Text(
                                              "${price}",
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 18,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 18, right: 24, top: 16),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: AppTheme.getTheme().backgroundColor,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(38)),
                                  // border: Border.all(
                                  //   color: HexColor("#757575").withOpacity(0.6),
                                  // ),
                                  boxShadow: <BoxShadow>[
                                    BoxShadow(
                                      color: AppTheme.getTheme().dividerColor,
                                      blurRadius: 8,
                                      offset: Offset(4, 4),
                                    ),
                                  ],
                                ),
                                // NID TextFields
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 16, right: 16),
                                  child: Container(
                                    height: 48,
                                    child: Center(
                                      child: TextFormField(
                                        controller: firstName,
                                        validator: (value) {
                                          if (value.isEmpty) {
                                            return "Please enter first name";
                                          }
                                          return null;
                                        },
                                        maxLines: 1,
                                        onChanged: (String txt) {},
                                        style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        cursorColor:
                                            AppTheme.getTheme().primaryColor,
                                        decoration: new InputDecoration(
                                          errorText: null,
                                          border: InputBorder.none,
                                          // hintText: firstName,
                                          hintStyle: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold,
                                              color: AppTheme.getTheme()
                                                  .disabledColor),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 16,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 18, right: 24),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: AppTheme.getTheme().backgroundColor,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(38)),
                                  // border: Border.all(
                                  //   color: HexColor("#757575").withOpacity(0.6),
                                  // ),
                                  boxShadow: <BoxShadow>[
                                    BoxShadow(
                                      color: AppTheme.getTheme().dividerColor,
                                      blurRadius: 8,
                                      offset: Offset(4, 4),
                                    ),
                                  ],
                                ),
                                // NID TextFields
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 16, right: 16),
                                  child: Container(
                                    height: 48,
                                    child: Center(
                                      child: TextFormField(
                                        controller: lastName,
                                        validator: (value) {
                                          if (value.isEmpty) {
                                            return "Please enter last name";
                                          }
                                          return null;
                                        },
                                        maxLines: 1,
                                        onChanged: (String txt) {},
                                        style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        cursorColor:
                                            AppTheme.getTheme().primaryColor,
                                        decoration: new InputDecoration(
                                          errorText: null,
                                          border: InputBorder.none,
                                          // hintText: lastName,
                                          hintStyle: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold,
                                              color: AppTheme.getTheme()
                                                  .disabledColor),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 16,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 18, right: 24),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: AppTheme.getTheme().backgroundColor,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(38)),
                                  // border: Border.all(
                                  //   color: HexColor("#757575").withOpacity(0.6),
                                  // ),
                                  boxShadow: <BoxShadow>[
                                    BoxShadow(
                                      color: AppTheme.getTheme().dividerColor,
                                      blurRadius: 8,
                                      offset: Offset(4, 4),
                                    ),
                                  ],
                                ),
                                // NID TextFields
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 16, right: 16),
                                  child: Container(
                                    height: 48,
                                    child: Center(
                                      child: TextFormField(
                                        controller: email,
                                        enabled: false,
                                        validator: (value) {
                                          if (value.isEmpty) {
                                            return "Please enter email address";
                                          }
                                          return null;
                                        },
                                        maxLines: 1,
                                        onChanged: (String txt) {},
                                        style: TextStyle(
                                          fontSize: 20,
                                        ),
                                        cursorColor:
                                            AppTheme.getTheme().primaryColor,
                                        decoration: new InputDecoration(
                                          errorText: null,
                                          border: InputBorder.none,

                                          // hintText: email,
                                          hintStyle: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold,
                                              color: AppTheme.getTheme()
                                                  .disabledColor),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 16,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 18, right: 24),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: AppTheme.getTheme().backgroundColor,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(38)),
                                  // border: Border.all(
                                  //   color: HexColor("#757575").withOpacity(0.6),
                                  // ),
                                  boxShadow: <BoxShadow>[
                                    BoxShadow(
                                      color: AppTheme.getTheme().dividerColor,
                                      blurRadius: 8,
                                      offset: Offset(4, 4),
                                    ),
                                  ],
                                ),
                                // NID TextFields
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 16, right: 16),
                                  child: Container(
                                    height: 48,
                                    child: Center(
                                      child: TextFormField(
                                        controller: phone,
                                        validator: (value) {
                                          if (value.isEmpty) {
                                            return "Please enter your phone Number";
                                          }
                                          return null;
                                        },
                                        maxLines: 1,
                                        onChanged: (String txt) {},
                                        style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        cursorColor:
                                            AppTheme.getTheme().primaryColor,
                                        decoration: new InputDecoration(
                                          errorText: null,
                                          border: InputBorder.none,
                                          // hintText: phone,
                                          hintStyle: TextStyle(
                                              fontSize: 20,
                                              color: AppTheme.getTheme()
                                                  .disabledColor),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 16,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 18, right: 24),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: AppTheme.getTheme().backgroundColor,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(38)),
                                  // border: Border.all(
                                  //   color: HexColor("#757575").withOpacity(0.6),
                                  // ),
                                  boxShadow: <BoxShadow>[
                                    BoxShadow(
                                      color: AppTheme.getTheme().dividerColor,
                                      blurRadius: 8,
                                      offset: Offset(4, 4),
                                    ),
                                  ],
                                ),
                                // NID TextFields
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 16, right: 16),
                                  child: Container(
                                    height: 48,
                                    child: Center(
                                      child: TextFormField(
                                        validator: (value) {
                                          if (value.isEmpty) {
                                            return "Please enter your address";
                                          }
                                          return null;
                                        },
                                        maxLines: 1,
                                        onChanged: (String txt) {},
                                        style: TextStyle(
                                          fontSize: 16,
                                        ),
                                        cursorColor:
                                            AppTheme.getTheme().primaryColor,
                                        decoration: new InputDecoration(
                                          errorText: null,
                                          border: InputBorder.none,
                                          hintText: "Address",
                                          hintStyle: TextStyle(
                                              fontSize: 17,
                                              color: AppTheme.getTheme()
                                                  .disabledColor),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 16,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 18, right: 24),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: AppTheme.getTheme().backgroundColor,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(38)),
                                  // border: Border.all(
                                  //   color: HexColor("#757575").withOpacity(0.6),
                                  // ),
                                  boxShadow: <BoxShadow>[
                                    BoxShadow(
                                      color: AppTheme.getTheme().dividerColor,
                                      blurRadius: 8,
                                      offset: Offset(4, 4),
                                    ),
                                  ],
                                ),
                                // NID TextFields
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 16, right: 16),
                                  child: Container(
                                    height: 48,
                                    child: Center(
                                      child: TextFormField(
                                        validator: (value) {
                                          if (value.isEmpty) {
                                            return "Please enter your select country";
                                          }
                                          return null;
                                        },
                                        maxLines: 1,
                                        onChanged: (String txt) {},
                                        style: TextStyle(
                                          fontSize: 16,
                                        ),
                                        cursorColor:
                                            AppTheme.getTheme().primaryColor,
                                        decoration: new InputDecoration(
                                          errorText: null,
                                          border: InputBorder.none,
                                          hintText: "Country",
                                          hintStyle: TextStyle(
                                              fontSize: 17,
                                              color: AppTheme.getTheme()
                                                  .disabledColor),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 16.0, top: 25),
                                  child: ToggleButtons(
                                    borderColor: Colors.grey,
                                    fillColor: HexColor("#26408A"),
                                    borderWidth: 2,
                                    selectedBorderColor: Colors.black,
                                    selectedColor: Colors.white,
                                    borderRadius: BorderRadius.circular(18),
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.all(14.0),
                                        child: Text(
                                          'Personal',
                                          style: TextStyle(fontSize: 16),
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.all(14.0),
                                        child: Text(
                                          'Official',
                                          style: TextStyle(fontSize: 16),
                                        ),
                                      ),
                                    ],
                                    onPressed: (int index) {
                                      setState(() {
                                        for (int i = 0;
                                            i < isSelected.length;
                                            i++) {
                                          isSelected[i] = i == index;
                                        }
                                      });
                                    },
                                    isSelected: isSelected,
                                  ),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 18.0, top: 10),
                                  child: Text(
                                    "Purpose of Travel",
                                    style: TextStyle(fontSize: 17),
                                  ),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Padding(
                                  padding:
                                      const EdgeInsets.only(left: 18.0, top: 5),
                                  child: Container(
                                    height: 40,
                                    width: 170,
                                    child: TextField(
                                      controller: leisureDataController,
                                      decoration: InputDecoration(
                                        hintText: " Ex: Leisure",
                                        contentPadding:
                                            EdgeInsets.only(top: 3, left: 15),
                                        border: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(15)),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            // _myRadioButton(
                            //   title: "I am the main Guest",
                            //   value: 0,
                            //   onChanged: (newValue) =>
                            //       setState(() => _groupValue2 = newValue),
                            // ),
                            // _myRadioButton(
                            //   title: "Booking is for someone else",
                            //   value: 1,
                            //   onChanged: (newValue) =>
                            //       setState(() => _groupValue = newValue),
                            // ),

                            Padding(
                              padding: const EdgeInsets.only(right: 20),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  ListTile(
                                    title: const Text('I am the main Guest'),
                                    leading: Radio(
                                      value: BestTutorSite.MAIN_GUEST2,
                                      groupValue: _site,
                                      onChanged: (BestTutorSite value) {
                                        setState(() {
                                          _site = value;
                                        });
                                      },
                                    ),
                                  ),
                                  ListTile(
                                    title: const Text(
                                        'Booking is for someone else'),
                                    leading: Radio(
                                      value: BestTutorSite.BOOKING_ELSE,
                                      groupValue: _site,
                                      onChanged: (BestTutorSite value) {
                                        setState(() {
                                          _site = value;
                                        });
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            SizedBox(
                              height: 10,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 18.0, right: 18),
                              child: Divider(
                                color: Colors.grey,
                                thickness: 1,
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Center(
                                child: Text(
                                    "Priority of Early Check in & Late Check out !")),
                            SizedBox(
                              height: 10,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 18.0, right: 18),
                              child: Divider(
                                color: Colors.grey,
                                thickness: 1,
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: ListView.builder(
                          shrinkWrap: true,
                          primary: false,
                          itemCount: widget.rr == null ? 0 : widget.rr.length,
                          itemBuilder: (_, index) {
                            return ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: Card(
                                margin: EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 8),
                                elevation: 1,
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 8.0, right: 0),
                                  child: Padding(
                                    padding: const EdgeInsets.only(top: 5.0),
                                    child: Container(
                                      height: 80,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: [
                                          OutlineButton(
                                            onPressed: () {},
                                            child: Text(
                                              "Room  x  ${widget.rr[index].book_room_count}",
                                              style: TextStyle(fontSize: 17),
                                            ),
                                          ),
                                          SizedBox(
                                            width: 15,
                                          ),
                                          Expanded(
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Container(
                                                child: Text(
                                                  "${widget.rr[index].book_room_name}",
                                                  maxLines: 3,
                                                  // widget.rr[index].title,
                                                  style: TextStyle(
                                                    fontSize: 17,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 10.0),
                            child: Checkbox(
                              value: this.checkBox1,
                              onChanged: (bool value) {
                                setState(() {
                                  this.checkBox1 = value;
                                });
                              },
                            ),
                          ),
                          Expanded(
                            child: Text(
                                'I have read and agree to the Terms and Conditions and Hotel Policy'),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            left: 16,
                            right: 16,
                            bottom: 16 + MediaQuery.of(context).padding.bottom,
                            top: 8),
                        child: Container(
                          height: 48,
                          decoration: BoxDecoration(
                            color: AppTheme.getTheme().primaryColor,
                            borderRadius:
                                BorderRadius.all(Radius.circular(24.0)),
                            boxShadow: <BoxShadow>[
                              BoxShadow(
                                color: AppTheme.getTheme().dividerColor,
                                blurRadius: 8,
                                offset: Offset(4, 4),
                              ),
                            ],
                          ),
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(24.0)),
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                for (var bkoo in bkroomInfList) {
                                  print(
                                      "book list ${bkoo.id} , ${bkoo.price} , ${bkoo.count}");
                                }
                                SharedPreferences sharedPreferences =
                                    await SharedPreferences.getInstance();
                                String itemid = widget.hotel.hotel.id;
                                List<BkroomInf> bkroomInf = bkroomInfList;
                                String userId =
                                    sharedPreferences.getString('id');
                                String currCode =
                                    widget.hotel.rooms[0].currCode;
                                String currRate =
                                    widget.hotel.rooms[0].currRate;
                                String currSymbol =
                                    widget.hotel.rooms[0].currSymbol;
                                String purpose = "";
                                String officeLeisure = "Leisure";
                                String paymethod =
                                    widget.hotel.hotel.paymentOptions[0].name;

                                print("USERID-> $userId");
                                checkHotelRoomBooking(
                                  itemid,
                                  bkroomInf,
                                  userId,
                                  currCode,
                                  currRate,
                                  currSymbol,
                                  purpose,
                                  officeLeisure,
                                  paymethod,
                                );

                                setState(() {
                                  isLoading = true;
                                });

                                // Fluttertoast.showToast(
                                //     msg: ('Successfully Booking Room'),
                                //     toastLength: Toast.LENGTH_SHORT,
                                //     gravity: ToastGravity.BOTTOM,
                                //     timeInSecForIosWeb: 2,
                                //     backgroundColor: Colors.indigo[800],
                                //     textColor: Colors.white,
                                //     fontSize: 16.0);

                                // final Completer<WebViewController> _controller =
                                //     Completer<WebViewController>();

                                // WebView(
                                //   initialUrl:
                                //       "https:\/\/deshitour.com\/invoice$itemid",
                                //   javascriptMode: JavascriptMode.unrestricted,
                                //   onWebViewCreated:
                                //       (WebViewController webViewController) {
                                //     _controller.complete(webViewController);
                                //   },
                                // );
                              },
                              child: Center(
                                child: Text(
                                  "Complete This Booking",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 19,
                                      color: Colors.white),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
  }

  void callApi() {
    double taxCount = double.parse(widget.hotel.hotel.taxval);

    for (var i = 0; i < widget.rr.length; i++) {
      for (var j = 0; j < widget.hotel.rooms.length; j++) {
        if (widget.rr[i].id == widget.hotel.rooms[j].id) {
          var parts = widget.hotel.rooms[j].price.split(',');
          var bbb = parts[0].trim(); // prefix: "date"
          var bbb1 = parts[1].trim(); // prefix: "date"
          var calculation = int.parse(bbb + bbb1);

          var taxCaulation = calculation * taxCount / 100;
          var checkIn = getDateFormate(widget.hotel.rooms[j].info.checkin);
          var checkOut = getDateFormate(widget.hotel.rooms[j].info.checkout);

          // var checkIn=f.parse();
          String id = widget.hotel.rooms[j].id;
          String price = calculation.toString();
          String count = widget.rr[i].book_room_count.toString();
          String tax = taxCaulation.toString();
          String rckin = checkIn.toString();
          String rckout = checkOut.toString();

          bkroomInf = BkroomInf(
            id,
            price,
            count,
            tax,
            rckin,
            rckout,
          );

          print(
              "room list ${taxCaulation.toString()} ${widget.rr[i].book_room_count} $checkIn $checkOut");
        }
      }
      bkroomInfList.add(bkroomInf);
    }
  }

  // Widget _myRadioButton({String title, int value, Function onChanged}) {
  //   return RadioListTile<int>(
  //     value: value,
  //     groupValue: _groupValue,
  //     onChanged: onChanged,
  //     title: Text(title),
  //   );
  // }

  getDateFormate(String date) {
    DateTime parseDate = new DateFormat("yyyy-MM-dd").parse(date);
    var inputDate = DateTime.parse(parseDate.toString());
    var outputFormat = DateFormat('dd/MM/yyyy');
    var output = outputFormat.format(inputDate);
    return output;
  }

  void setButton(String body) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var userId = sharedPreferences.getString('id');

    print("==>>> $userId $body");
    Navigator.of(context).pop();
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (BuildContext context) =>
                HotelConfirmationScreen(url: body)));

    // Navigator.push(
    //     context,
    //     MaterialPageRoute(
    //         builder: (BuildContext context) =>
    //             MyWebView(title: "Invoice", selectedUrl: body)));
  }
}

class RoomBookingDetailsScreen extends StatefulWidget {
  final BookingDetails bookingDetails;

  const RoomBookingDetailsScreen({Key key, @required this.bookingDetails})
      : super(key: key);

  @override
  _RoomBookingDetailsScreenState createState() =>
      _RoomBookingDetailsScreenState();
}

class _RoomBookingDetailsScreenState extends State<RoomBookingDetailsScreen> {
  String selectedItem;

  List<String> maxAvailablity;

  @override
  Widget build(BuildContext context) {
    maxAvailablity = List<String>();
    int num = widget.bookingDetails.adultsCount;
    for (var i = 0; i < num + 1; i++) {
      setState(() {
        maxAvailablity.add(i.toString());
      });
    }

    return Padding(
      padding: const EdgeInsets.only(left: 8.0, right: 0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 15.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                OutlineButton(
                  onPressed: () {},
                  child: Text(
                    "Room ${widget.bookingDetails.book_room_count}",
                    style: TextStyle(fontSize: 17),
                  ),
                ),
                SizedBox(
                  width: 15,
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      child: Text(
                        "${widget.bookingDetails.book_room_name}",
                        maxLines: 3,
                        // widget.rr[index].title,
                        style: TextStyle(
                          fontSize: 17,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 15.0),
            child: Row(
              // mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Container(
                  height: 40,
                  width: 180,
                  child: TextFormField(
                    decoration: InputDecoration(
                        hintText: "Guest Name", border: OutlineInputBorder()),
                  ),
                ),
                SizedBox(
                  width: 15,
                ),
                Container(
                  height: 40,
                  width: 120,
                  child: Center(
                    child: DropdownButtonFormField(
                      isDense: false,
                      itemHeight: 65,
                      decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: const BorderRadius.all(
                              const Radius.circular(5.0),
                            ),
                          ),
                          filled: true,
                          hintStyle:
                              TextStyle(fontSize: 15, color: Colors.black),
                          hintText: maxAvailablity[0],
                          fillColor: Colors.white),
                      value: selectedItem,
                      onChanged: (String value) {
                        setState(() {
                          selectedItem = value;
                          // _storeLoggedInStatus(widget.roomData.id);
                          // _storeData(facilities);
                          // getFunction(widget.roomData.id, facilities);
                          //    firstFunction(int.parse(facilities), widget.roomData.price);
                        });

                        //     setState(() {
                        //String room_id= await _getLoggedInStatus();
                        //   var value1 = int.parse(facilities);
                        //   var str = widget.roomData.price;
                        //
                        //
                        //    int price = int.parse(c);
                        //   var total_price = value1 * price;
                        //
                        //   if (total_price != null)
                        //     price1 += total_price;
                        //   else
                        //     price1 -= total_price;
                        //   print(
                        //       " value change ${total_price.toString()}");
                        // });
                        //
                        // print("room ${price1}");
                        //
                        // widget.callBack(price1);
                      },
                      items: maxAvailablity
                          .map((cityTitle) => DropdownMenuItem(
                              value: cityTitle, child: Text("$cityTitle")))
                          .toList(),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 14,
          ),
          Row(
            // mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Container(
                height: 40,
                width: 150,
                child: TextFormField(
                  decoration: InputDecoration(
                      hintText: "Bangladesh", border: OutlineInputBorder()),
                ),
              ),
              SizedBox(
                width: 15,
              ),
              Container(
                height: 40,
                width: 160,
                child: TextFormField(
                  decoration: InputDecoration(
                    hintText: "Smoking",
                    border: OutlineInputBorder(),
                    suffixIcon: Icon(
                      Icons.keyboard_arrow_down_rounded,
                      size: 30,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
