import 'package:flutter/material.dart';
import 'package:new_motel/appTheme.dart';
import 'package:new_motel/authenticating/login.dart';
import 'package:new_motel/modules/profile/profile_page.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:new_motel/widget/customDrawer.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FlightScreen extends StatefulWidget {
  @override
  _FlightScreenState createState() => _FlightScreenState();
}

class _FlightScreenState extends State<FlightScreen> {
  String token;
  String image;

  Future<String> getToken() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    token = sharedPreferences.getString("token");
    image = sharedPreferences.getString("photo");
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    getToken();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          actions: [
            InkWell(
              onTap: () async {
                SharedPreferences sharedPreferences =
                    await SharedPreferences.getInstance();
                String token = sharedPreferences.getString("token");

                if (token == null) {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => LoginWidget()));
                } else {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ProfilePage(),
                      fullscreenDialog: true,
                    ),
                  );
                }
              },
              child: Padding(
                padding: const EdgeInsets.only(right: 20),
                child: CircleAvatar(
                  backgroundColor: Colors.grey[600],
                  radius: 20.0,
                  child: Center(
                    child: CircleAvatar(
                      backgroundColor: Colors.white,
                      radius: 17.0,
                      backgroundImage: image == null
                          ? AssetImage("assets/images/person.png")
                          : NetworkImage("https://deshitour.com/" + image),
                    ),
                  ),
                ),
              ),
            )
          ],
          iconTheme: IconThemeData(color: Colors.black),
          title: RichText(
            text: TextSpan(
                text: DESHI,
                style: TextStyle(
                  fontSize: 30,
                  fontFamily: 'Impact',
                  color: HexColor("#26408A"),
                ),
                children: <TextSpan>[
                  TextSpan(
                      text: TOUR,
                      style: TextStyle(
                        fontSize: 30,
                        fontFamily: 'Impact',
                        color: HexColor("#118ACB"),
                      )),
                ]),
          ),
          backgroundColor: Colors.white,
          elevation: 1,
        ),
        drawer: CustomDrawer(
          title: DESHITOUR,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                "UPCOMING",
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.normal),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
