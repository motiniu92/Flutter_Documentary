// import 'dart:convert';
//
// import 'package:autocomplete_textfield/autocomplete_textfield.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';
// import 'package:new_motel/model/countryListModel.dart';
// import 'package:http/http.dart' as http;
//
// class CountryListScreen extends StatefulWidget {
//   @override
//   _CountryListScreenState createState() => _CountryListScreenState();
// }
//
// class _CountryListScreenState extends State<CountryListScreen> {
//
//   List<CountryListResponse> country_list_response;
//   AutoCompleteTextField searchTextField;
//   GlobalKey<AutoCompleteTextFieldState<CountryListResponse>> key = new GlobalKey();
//   var response_list;
//   Future<String> getListCountryJSONData() async {
//      response_list = await http
//         .get("https://deshitour.com/api/hotels/countries?appKey=DeshiTour");
//     setState(() {
//       country_list_response =
//           CountryListModel.fromJson(json.decode(response_list.body))
//               .countryListResponse;
//
//       // Get the JSON data
//
//       // hotelList=homeData.response;
//       print("list of country data .... ${response_list.body}");
//     });
//     return "response";
//   }
//
//
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     getListCountryJSONData();
//     setState(() {
// country_list_response = response_list;
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//
//     return Scaffold(
//       body: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children:<Widget> [
//           searchTextField=  AutoCompleteTextField<CountryListResponse>(
//
//             key: key,
//             clearOnSubmit: false,
//             suggestions: country_list_response,
//             style: TextStyle(color: Colors.black, fontSize: 16.0),
//             decoration: InputDecoration(
//               contentPadding: EdgeInsets.fromLTRB(24.0, 10.0, 10.0, 10.0),
//               hintText: "Search Country Name",
//               hintStyle: TextStyle(color: Colors.black),
//             ),
//
//
//               itemFilter: (item, query) {
//                 return item.name
//                     .toLowerCase()
//                     .startsWith(query.toLowerCase());
//               },
//
//
//               itemSorter: (a, b) {
//                 return a.name.compareTo(b.name);
//               },
//
//             itemSubmitted: (item) {
//               setState(() {
//                 searchTextField.controller.text = item.name;
//               });
//             },
//
//
//             itemBuilder: (context, item) {
//               // ui for the autocompelete row
//            return    Text(
//                item.name
//
//            );
//             },
//           )
//         ],
//       ),
//     );
//   }
//
//
// }
