const int INTERNETEE = 1;
const int EMPTY = 2;
const int INIT = 3;
const int OTHER = 4;
const int CONTENT = 5;
const int ERROR = 6;

// const int RES = 1;
// const Errorss = 2;
// const OTHERS = 3;
