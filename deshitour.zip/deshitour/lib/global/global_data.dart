String FIRSTNAME_G = "";
String LASTNAME_G = "";
String CITY_G = "";
String STATE_G = "";
String COUNTRY_G = "";
String ADDRESS1_G = "";
String ADDRESS2_G = "";
String PHONE_G = "";
String FAX_G = "";
String ZIP_G = "";
String PHOTO_G = "";
String EMAIL_G = "";
String PASSWORD_G = "";

