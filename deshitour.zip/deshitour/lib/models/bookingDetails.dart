class BookingDetails {
  String id;
  int book_room_count;
  String book_room_name;
  int adultsCount;
  int bookingPrice;

  BookingDetails(
      this.id, this.book_room_count, this.book_room_name, this.bookingPrice);
}
