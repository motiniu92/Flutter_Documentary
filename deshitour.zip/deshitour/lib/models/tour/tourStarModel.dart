import 'dart:convert';

TourStarModel tourStarModelFromJson(String str) => TourStarModel.fromJson(json.decode(str));

String tourStarModelToJson(TourStarModel data) => json.encode(data.toJson());

class TourStarModel {

  TourStarModel({
    this.responseStar,
    this.error,
    this.totalPages,
  });

  List<ResponseStar> responseStar;
  Error error;
  dynamic totalPages;

  factory TourStarModel.fromJson(Map<String, dynamic> json) => TourStarModel(
    responseStar: List<ResponseStar>.from(json["response"].map((x) => ResponseStar.fromJson(x))),
    error: Error.fromJson(json["error"]),
    totalPages: json["totalPages"],
  );

  Map<String, dynamic> toJson() => {
    "response": List<dynamic>.from(responseStar.map((x) => x.toJson())),
    "error": error.toJson(),
    "totalPages": totalPages,
  };
}

class Error {
  Error({
    this.status,
    this.msg,
  });

  bool status;
  String msg;

  factory Error.fromJson(Map<String, dynamic> json) => Error(
    status: json["status"],
    msg: json["msg"],
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "msg": msg,
  };
}

class ResponseStar {

  ResponseStar({
    this.id,
    this.title,
    this.slug,
    this.thumbnail,
    this.stars,
    this.starsCount,
    this.location,
    this.desc,
    this.price,
    this.currCode,
    this.currSymbol,
    this.inclusions,
    this.avgReviews,
    this.latitude,
    this.longitude,
    this.tourDays,
    this.tourNights,
    this.tourType,
  });

  String id;
  String title;
  String slug;
  String thumbnail;
  String stars;
  String starsCount;
  String location;
  String desc;
  String price;
  String currCode;
  String currSymbol;
  dynamic inclusions;
  AvgReviews avgReviews;
  String latitude;
  String longitude;
  String tourDays;
  String tourNights;
  String tourType;

  bool isSelected;

  factory ResponseStar.fromJson(Map<String, dynamic> json) => ResponseStar(
    id: json["id"],
    title: json["title"],
    slug: json["slug"],
    thumbnail: json["thumbnail"],
    stars: json["stars"],
    starsCount: json["starsCount"],
    location: json["location"],
    desc: json["desc"],
    price: json["price"],
    currCode: json["currCode"],
    currSymbol: json["currSymbol"],
    inclusions: json["inclusions"],
    avgReviews: AvgReviews.fromJson(json["avgReviews"]),
    latitude: json["latitude"],
    longitude: json["longitude"],
    tourDays: json["tourDays"],
    tourNights: json["tourNights"],
    tourType: json["tourType"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "slug": slug,
    "thumbnail": thumbnail,
    "stars": stars,
    "starsCount": starsCount,
    "location": location,
    "desc": desc,
    "price": price,
    "currCode": currCode,
    "currSymbol": currSymbol,
    "inclusions": inclusions,
    "avgReviews": avgReviews.toJson(),
    "latitude": latitude,
    "longitude": longitude,
    "tourDays": tourDays,
    "tourNights": tourNights,
    "tourType": tourType,
  };
}

class AvgReviews {
  AvgReviews({
    this.clean,
    this.comfort,
    this.location,
    this.facilities,
    this.staff,
    this.totalReviews,
    this.overall,
  });

  int clean;
  int comfort;
  int location;
  int facilities;
  int staff;
  String totalReviews;
  double overall;

  factory AvgReviews.fromJson(Map<String, dynamic> json) => AvgReviews(
    clean: json["clean"],
    comfort: json["comfort"],
    location: json["location"],
    facilities: json["facilities"],
    staff: json["staff"],
    totalReviews: json["totalReviews"],
    overall: json["overall"].toDouble(),
  );

  Map<String, dynamic> toJson() => {
    "clean": clean,
    "comfort": comfort,
    "location": location,
    "facilities": facilities,
    "staff": staff,
    "totalReviews": totalReviews,
    "overall": overall,
  };
}
