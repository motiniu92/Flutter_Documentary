class TourList {
  List<TourResponse> response;
  Error error;
  int totalPages;

  TourList({this.response, this.error, this.totalPages});

  TourList.fromJson(Map<String, dynamic> json) {
    if (json['response'] != null) {
      response = new List<TourResponse>();
      json['response'].forEach((v) {
        response.add(new TourResponse.fromJson(v));
      });
    }
    error = json['error'] != null ? new Error.fromJson(json['error']) : null;
    totalPages = json['totalPages'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.response != null) {
      data['response'] = this.response.map((v) => v.toJson()).toList();
    }
    if (this.error != null) {
      data['error'] = this.error.toJson();
    }
    data['totalPages'] = this.totalPages;
    return data;
  }
}

class TourResponse {
  String id;
  String title;
  String slug;
  String thumbnail;
  String stars;
  String starsCount;
  String location;
  String desc;
  String price;
  String currCode;
  String currSymbol;
  Null inclusions;
  AvgReviews avgReviews;
  String latitude;
  String longitude;
  String tourDays;
  String tourNights;
  String tourType;

  TourResponse(
      {this.id,
        this.title,
        this.slug,
        this.thumbnail,
        this.stars,
        this.starsCount,
        this.location,
        this.desc,
        this.price,
        this.currCode,
        this.currSymbol,
        this.inclusions,
        this.avgReviews,
        this.latitude,
        this.longitude,
        this.tourDays,
        this.tourNights,
        this.tourType});

  TourResponse.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    slug = json['slug'];
    thumbnail = json['thumbnail'];
    stars = json['stars'];
    starsCount = json['starsCount'];
    location = json['location'];
    desc = json['desc'];
    price = json['price'];
    currCode = json['currCode'];
    currSymbol = json['currSymbol'];
    inclusions = json['inclusions'];
    avgReviews = json['avgReviews'] != null
        ? new AvgReviews.fromJson(json['avgReviews'])
        : null;
    latitude = json['latitude'];
    longitude = json['longitude'];
    tourDays = json['tourDays'];
    tourNights = json['tourNights'];
    tourType = json['tourType'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['title'] = this.title;
    data['slug'] = this.slug;
    data['thumbnail'] = this.thumbnail;
    data['stars'] = this.stars;
    data['starsCount'] = this.starsCount;
    data['location'] = this.location;
    data['desc'] = this.desc;
    data['price'] = this.price;
    data['currCode'] = this.currCode;
    data['currSymbol'] = this.currSymbol;
    data['inclusions'] = this.inclusions;
    if (this.avgReviews != null) {
      data['avgReviews'] = this.avgReviews.toJson();
    }
    data['latitude'] = this.latitude;
    data['longitude'] = this.longitude;
    data['tourDays'] = this.tourDays;
    data['tourNights'] = this.tourNights;
    data['tourType'] = this.tourType;
    return data;
  }
}

class AvgReviews {
  dynamic clean;
  dynamic comfort;
  dynamic location;
  dynamic facilities;
  dynamic staff;
  String totalReviews;
  dynamic overall;

  AvgReviews(
      {this.clean,
        this.comfort,
        this.location,
        this.facilities,
        this.staff,
        this.totalReviews,
        this.overall});

  AvgReviews.fromJson(Map<String, dynamic> json) {
    clean = json['clean']== null ? 0.0 : json['clean'].toDouble();
    comfort = json['comfort']== null ? 0.0 : json['comfort'].toDouble();
    location = json['location']== null ? 0.0 : json['location'].toDouble();
    facilities = json['facilities']== null ? 0.0 : json['facilities'].toDouble();
    staff = json['staff']== null ? 0.0 : json['staff'].toDouble();
    totalReviews = json['totalReviews'];
    overall = json['overall']== null ? 0.0 : json['overall'].toDouble();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['clean'] = this.clean;
    data['comfort'] = this.comfort;
    data['location'] = this.location;
    data['facilities'] = this.facilities;
    data['staff'] = this.staff;
    data['totalReviews'] = this.totalReviews;
    data['overall'] = this.overall;
    return data;
  }
}

class Error {
  bool status;
  String msg;

  Error({this.status, this.msg});

  Error.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    msg = json['msg'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['msg'] = this.msg;
    return data;
  }
}
