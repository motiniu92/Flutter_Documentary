class TourCountryFilter {
  List<ResponseCountry> responseCountry;
  Error error;

  TourCountryFilter({this.responseCountry, this.error});

  TourCountryFilter.fromJson(Map<String, dynamic> json) {
    if (json['response'] != null) {
      responseCountry = new List<ResponseCountry>();
      json['response'].forEach((v) {
        responseCountry.add(new ResponseCountry.fromJson(v));
      });
    }
    error = json['error'] != null ? new Error.fromJson(json['error']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.responseCountry != null) {
      data['response'] = this.responseCountry.map((v) => v.toJson()).toList();
    }
    if (this.error != null) {
      data['error'] = this.error.toJson();
    }
    return data;
  }
}

class ResponseCountry {
  String tourCountry;

  // new Code
  bool _isSelect=false;
  bool get isSelect => _isSelect;
  set isSelected(bool isSelect) {
    _isSelect = isSelect;
  }

  ResponseCountry({this.tourCountry});

  ResponseCountry.fromJson(Map<String, dynamic> json) {
    tourCountry = json['tour_country'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['tour_country'] = this.tourCountry;
    return data;
  }
}

class Error {
  bool status;
  String msg;

  Error({this.status, this.msg});

  Error.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    msg = json['msg'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['msg'] = this.msg;
    return data;
  }
}