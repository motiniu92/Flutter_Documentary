class ToursDetails {
  Response response;
  Error error;

  ToursDetails({this.response, this.error});

  ToursDetails.fromJson(Map<String, dynamic> json) {
    response = json['response'] != null
        ? new Response.fromJson(json['response'])
        : null;
    error = json['error'] != null ? new Error.fromJson(json['error']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.response != null) {
      data['response'] = this.response.toJson();
    }
    if (this.error != null) {
      data['error'] = this.error.toJson();
    }
    return data;
  }
}

class Response {
  Tour tour;
  List<TourReviews> reviews;
  AvgReviews avgReviews;

  Response({this.tour, this.reviews, this.avgReviews});

  Response.fromJson(Map<String, dynamic> json) {
    tour = json['tour'] != null ? new Tour.fromJson(json['tour']) : null;
    if (json['reviews'] != null) {
      reviews = new List<TourReviews>();
      json['reviews'].forEach((v) {
        reviews.add(new TourReviews.fromJson(v));
      });
    }
    avgReviews = json['avgReviews'] != null
        ? new AvgReviews.fromJson(json['avgReviews'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.tour != null) {
      data['tour'] = this.tour.toJson();
    }
    if (this.reviews != null) {
      data['reviews'] = this.reviews.map((v) => v.toJson()).toList();
    }
    if (this.avgReviews != null) {
      data['avgReviews'] = this.avgReviews.toJson();
    }
    return data;
  }
}

class Tour {
  String id;
  String title;
  String slug;
  String bookingSlug;
  String thumbnail;
  String stars;
  String starsCount;
  String location;
  String desc;
  List<Inclusions> inclusions;
  List<Exclusions> exclusions;
  String latitude;
  String longitude;
  List<SliderImages> sliderImages;
  List<Itineraries> itineraries;
  List<TourDetailsRelatedItems> relatedItems;
  List<PaymentOptions> paymentOptions;
  String metadesc;
  String keywords;
  String policy;
  String website;
  String email;
  String phone;
  String maxAdults;
  String maxChild;
  String maxInfant;
  String adultStatus;
  String childStatus;
  String infantStatus;
  String adultPrice;
  String childPrice;
  String infantPrice;
  String perAdultPrice;
  String perChildPrice;
  String perInfantPrice;
  String currCode;
  String currSymbol;
  String date;
  String totalCost;
  String comType;
  String comValue;
  String taxType;
  String taxValue;
  String tourDays;
  String tourNights;
  dynamic totalDeposit;

  String api_tax_fix;
  String api_tax_per;
  String api_depo_fix;
   String api_depo_per;
   String api_curr_rate;
  String mapAddress;

  Tour(
      {this.id,
        this.title,
        this.slug,
        this.bookingSlug,
        this.thumbnail,
        this.stars,
        this.starsCount,
        this.location,
        this.desc,
        this.inclusions,
        this.exclusions,
        this.latitude,
        this.longitude,
        this.sliderImages,
        this.itineraries,
        this.relatedItems,
        this.paymentOptions,
        this.metadesc,
        this.keywords,
        this.policy,
        this.website,
        this.email,
        this.phone,
        this.maxAdults,
        this.maxChild,
        this.maxInfant,
        this.adultStatus,
        this.childStatus,
        this.infantStatus,
        this.adultPrice,
        this.childPrice,
        this.infantPrice,
        this.perAdultPrice,
        this.perChildPrice,
        this.perInfantPrice,
        this.currCode,
        this.currSymbol,
        this.date,
        this.totalCost,
        this.comType,
        this.comValue,
        this.taxType,
        this.taxValue,
        this.tourDays,
        this.tourNights,
        this.totalDeposit,
        this.mapAddress,
        this.api_curr_rate,
        this.api_depo_fix,
        this.api_depo_per,
        this.api_tax_fix,
        this.api_tax_per,

      });

  Tour.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    slug = json['slug'];
    bookingSlug = json['bookingSlug'];
    thumbnail = json['thumbnail'];
    stars = json['stars'];
    starsCount = json['starsCount'];
    location = json['location'];
    desc = json['desc'];
    if (json['inclusions'] != null) {
      inclusions = new List<Inclusions>();
      json['inclusions'].forEach((v) {
        inclusions.add(new Inclusions.fromJson(v));
      });
    }
    if (json['exclusions'] != null) {
      exclusions = new List<Exclusions>();
      json['exclusions'].forEach((v) {
        exclusions.add(new Exclusions.fromJson(v));
      });
    }
    latitude = json['latitude'];
    longitude = json['longitude'];
    if (json['sliderImages'] != null) {
      sliderImages = new List<SliderImages>();
      json['sliderImages'].forEach((v) {
        sliderImages.add(new SliderImages.fromJson(v));
      });
    }
    if (json['itineraries'] != null) {
      itineraries = new List<Itineraries>();
      json['itineraries'].forEach((v) {
        itineraries.add(new Itineraries.fromJson(v));
      });
    }
    if (json['relatedItems'] != null) {
      relatedItems = new List<TourDetailsRelatedItems>();
      json['relatedItems'].forEach((v) {
        relatedItems.add(new TourDetailsRelatedItems.fromJson(v));
      });
    }
    if (json['paymentOptions'] != null) {
      paymentOptions = new List<PaymentOptions>();
      json['paymentOptions'].forEach((v) {
        paymentOptions.add(new PaymentOptions.fromJson(v));
      });
    }
    metadesc = json['metadesc'];
    keywords = json['keywords'];
    policy = json['policy'];
    website = json['website'];
    email = json['email'];
    phone = json['phone'];
    maxAdults = json['maxAdults'];
    maxChild = json['maxChild'];
    maxInfant = json['maxInfant'];
    adultStatus = json['adultStatus'];
    childStatus = json['childStatus'];
    infantStatus = json['infantStatus'];
    adultPrice = json['adultPrice'];
    childPrice = json['childPrice'];
    infantPrice = json['infantPrice'];
    perAdultPrice = json['perAdultPrice'];
    perChildPrice = json['perChildPrice'];
    perInfantPrice = json['perInfantPrice'];
    currCode = json['currCode'];
    currSymbol = json['currSymbol'];
    date = json['date'];
    totalCost = json['totalCost'];
    comType = json['comType'];
    comValue = json['comValue'];
    taxType = json['taxType'];
    taxValue = json['taxValue'];
    tourDays = json['tourDays'];
    tourNights = json['tourNights'];
    totalDeposit = json['totalDeposit']== null ? 0.0 : json['totalDeposit'].toDouble();
    mapAddress = json['mapAddress'];
    api_tax_fix = json['api_tax_fix'];
    api_tax_per = json['api_tax_per'];
    api_depo_fix = json['api_depo_fix'];
    api_depo_per = json['api_depo_per'];
    api_curr_rate = json['api_curr_rate'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['title'] = this.title;
    data['slug'] = this.slug;
    data['bookingSlug'] = this.bookingSlug;
    data['thumbnail'] = this.thumbnail;
    data['stars'] = this.stars;
    data['starsCount'] = this.starsCount;
    data['location'] = this.location;
    data['desc'] = this.desc;
    if (this.inclusions != null) {
      data['inclusions'] = this.inclusions.map((v) => v.toJson()).toList();
    }
    if (this.exclusions != null) {
      data['exclusions'] = this.exclusions.map((v) => v.toJson()).toList();
    }
    data['latitude'] = this.latitude;
    data['longitude'] = this.longitude;
    if (this.sliderImages != null) {
      data['sliderImages'] = this.sliderImages.map((v) => v.toJson()).toList();
    }
    if (this.itineraries != null) {
      data['itineraries'] = this.itineraries.map((v) => v.toJson()).toList();
    }
    if (this.relatedItems != null) {
      data['relatedItems'] = this.relatedItems.map((v) => v.toJson()).toList();
    }
    if (this.paymentOptions != null) {
      data['paymentOptions'] =
          this.paymentOptions.map((v) => v.toJson()).toList();
    }
    data['metadesc'] = this.metadesc;
    data['keywords'] = this.keywords;
    data['policy'] = this.policy;
    data['website'] = this.website;
    data['email'] = this.email;
    data['phone'] = this.phone;
    data['maxAdults'] = this.maxAdults;
    data['maxChild'] = this.maxChild;
    data['maxInfant'] = this.maxInfant;
    data['adultStatus'] = this.adultStatus;
    data['childStatus'] = this.childStatus;
    data['infantStatus'] = this.infantStatus;
    data['adultPrice'] = this.adultPrice;
    data['childPrice'] = this.childPrice;
    data['infantPrice'] = this.infantPrice;
    data['perAdultPrice'] = this.perAdultPrice;
    data['perChildPrice'] = this.perChildPrice;
    data['perInfantPrice'] = this.perInfantPrice;
    data['currCode'] = this.currCode;
    data['currSymbol'] = this.currSymbol;
    data['date'] = this.date;
    data['totalCost'] = this.totalCost;
    data['comType'] = this.comType;
    data['comValue'] = this.comValue;
    data['taxType'] = this.taxType;
    data['taxValue'] = this.taxValue;
    data['tourDays'] = this.tourDays;
    data['tourNights'] = this.tourNights;
    data['totalDeposit'] = this.totalDeposit;
    data['mapAddress'] = this.mapAddress;
    data['api_tax_fix']=this.api_tax_fix;
    data['api_tax_per']=  this.api_tax_per  ;
    data['api_depo_fix']=this.api_depo_fix ;
    data['api_depo_per']=this.api_depo_per ;
    data['api_curr_rate']=this.api_curr_rate ;
    return data;
  }
}

class PaymentOptions {

  String icon;
  String id;
  String name;

  PaymentOptions({this.icon, this.id, this.name});

  PaymentOptions.fromJson(Map<String, dynamic> json) {
    icon = json['icon'];
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['icon'] = this.icon;
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }

}

// Create New Class
class Exclusions {
  String icon;
  String id;
  String name;

  Exclusions({this.icon, this.id, this.name});

  Exclusions.fromJson(Map<String, dynamic> json) {
    icon = json['icon'];
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['icon'] = this.icon;
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

class Inclusions {
  String icon;
  String id;
  String name;

  Inclusions({this.icon, this.id, this.name});

  Inclusions.fromJson(Map<String, dynamic> json) {
    icon = json['icon'];
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['icon'] = this.icon;
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

class SliderImages {
  String fullImage;
  String thumbImage;

  SliderImages({this.fullImage, this.thumbImage});

  SliderImages.fromJson(Map<String, dynamic> json) {
    fullImage = json['fullImage'];
    thumbImage = json['thumbImage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['fullImage'] = this.fullImage;
    data['thumbImage'] = this.thumbImage;
    return data;
  }
}

class Itineraries {
  String id;
  String tourId;
  String dayplan;
  String details;
  String placeimg;

  Itineraries(
      {this.id, this.tourId, this.dayplan, this.details, this.placeimg});

  Itineraries.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    tourId = json['tour_id'];
    dayplan = json['dayplan'];
    details = json['details'];
    placeimg = json['placeimg'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['tour_id'] = this.tourId;
    data['dayplan'] = this.dayplan;
    data['details'] = this.details;
    data['placeimg'] = this.placeimg;
    return data;
  }
}

class TourDetailsRelatedItems {
  String id;
  String title;
  String slug;
  String thumbnail;
  String stars;
  String starsCount;
  String location;
  String price;
  String currCode;
  String currSymbol;
  String latitude;
  String longitude;
  AvgReviews avgReviews;

  TourDetailsRelatedItems(
      {this.id,
        this.title,
        this.slug,
        this.thumbnail,
        this.stars,
        this.starsCount,
        this.location,
        this.price,
        this.currCode,
        this.currSymbol,
        this.latitude,
        this.longitude,
        this.avgReviews});

  TourDetailsRelatedItems.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    slug = json['slug'];
    thumbnail = json['thumbnail'];
    stars = json['stars'];
    starsCount = json['starsCount'];
    location = json['location'];
    price = json['price'];
    currCode = json['currCode'];
    currSymbol = json['currSymbol'];
    latitude = json['latitude'];
    longitude = json['longitude'];
    avgReviews = json['avgReviews'] != null
        ? new AvgReviews.fromJson(json['avgReviews'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['title'] = this.title;
    data['slug'] = this.slug;
    data['thumbnail'] = this.thumbnail;
    data['stars'] = this.stars;
    data['starsCount'] = this.starsCount;
    data['location'] = this.location;
    data['price'] = this.price;
    data['currCode'] = this.currCode;
    data['currSymbol'] = this.currSymbol;
    data['latitude'] = this.latitude;
    data['longitude'] = this.longitude;
    if (this.avgReviews != null) {
      data['avgReviews'] = this.avgReviews.toJson();
    }
    return data;
  }
}

class AvgReviews {
  dynamic clean;
  dynamic comfort;
  dynamic location;
  dynamic facilities;
  dynamic staff;
  String totalReviews;
  dynamic overall;

  AvgReviews(
      {this.clean,
        this.comfort,
        this.location,
        this.facilities,
        this.staff,
        this.totalReviews,
        this.overall});

  AvgReviews.fromJson(Map<String, dynamic> json) {
    clean = json['clean']== null ? 0.0 : json['clean'].toDouble();
    comfort = json['comfort']== null ? 0.0 : json['comfort'].toDouble();
    location = json['location']== null ? 0.0 : json['location'].toDouble();
    facilities = json['facilities']== null ? 0.0 : json['facilities'].toDouble();
    staff = json['staff']== null ? 0.0 : json['staff'].toDouble();
    totalReviews = json['totalReviews'];
    overall = json['overall']== null ? 0.0 : json['overall'].toDouble();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['clean'] = this.clean;
    data['comfort'] = this.comfort;
    data['location'] = this.location;
    data['facilities'] = this.facilities;
    data['staff'] = this.staff;
    data['totalReviews'] = this.totalReviews;
    data['overall'] = this.overall;
    return data;
  }
}

class TourReviews {
  String rating;
  String reviewBy;
  String reviewComment;
  String reviewDate;

  TourReviews({this.rating, this.reviewBy, this.reviewComment, this.reviewDate});

  TourReviews.fromJson(Map<String, dynamic> json) {
    rating = json['rating'];
    reviewBy = json['review_by'];
    reviewComment = json['review_comment'];
    reviewDate = json['review_date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['rating'] = this.rating;
    data['review_by'] = this.reviewBy;
    data['review_comment'] = this.reviewComment;
    data['review_date'] = this.reviewDate;
    return data;
  }
}



class Error {
  bool status;
  String msg;

  Error({this.status, this.msg});

  Error.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    msg = json['msg'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['msg'] = this.msg;
    return data;
  }
}