class TourTypes {
  List<ResponseTours> responseTours;
  Error error;

  TourTypes({this.responseTours, this.error});

  TourTypes.fromJson(Map<String, dynamic> json) {
    if (json['response'] != null) {
      responseTours = new List<ResponseTours>();
      json['response'].forEach((v) {
        responseTours.add(new ResponseTours.fromJson(v));
      });
    }
    error = json['error'] != null ? new Error.fromJson(json['error']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.responseTours != null) {
      data['response'] = this.responseTours.map((v) => v.toJson()).toList();
    }
    if (this.error != null) {
      data['error'] = this.error.toJson();
    }
    return data;
  }
}

class ResponseTours {
  String id;
  String name;
  bool _isSelect=false;
  bool get isSelect => _isSelect;
  set isSelected(bool isSelect) {
    _isSelect = isSelect;
  }

  ResponseTours({this.id, this.name});

  ResponseTours.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

class Error {
  bool status;
  String msg;

  Error({this.status, this.msg});

  Error.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    msg = json['msg'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['msg'] = this.msg;
    return data;
  }
}