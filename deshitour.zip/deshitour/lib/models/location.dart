import 'package:new_motel/models/home/home.dart';

class Location{
    int locaton_id;
   String locaton_name;
   String checkIn;
   String checkOut;
   bool isSearch;
   AllLocation allLocation;

   // Location(this.locaton_id, this.locaton_name, this.checkIn, this.checkOut,
   //    this.isSearch,AllLocation allLocation){
   //   this.locaton_id=locaton_id;
   //   this.locaton_name=locaton_name;
   //   this.checkIn=checkIn;
   //   this.checkOut=checkOut;
   //   this.isSearch=isSearch;
   //   this.allLocation=allLocation;
   // }

    int get locationId {
      return locaton_id;
    }

    void set locationId(int locatonId) {
      locaton_id = locatonId;
    }
    String get locationname {
      return locaton_name;
    }

    void set locationname(String locatonName) {
      locaton_name = locatonName;
    }

    String get checkin {
      return checkIn;
    }

    void set checkin(String checkIn) {
      checkIn = checkIn;
    }

    String get checkout {
      return checkOut;
    }

    void set checkout(String checkOut) {
      checkOut = checkOut;
    }

    AllLocation get getAllLocation{
      return allLocation;
    }

    void  set setAllLocation(AllLocation allLocation){
    allLocation=allLocation;
    }
}