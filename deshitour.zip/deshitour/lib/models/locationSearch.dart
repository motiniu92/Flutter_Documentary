class LocationSearch {
  List<Response> response;
  Error error;
  int totalPages;

  LocationSearch({this.response, this.error, this.totalPages});

  LocationSearch.fromJson(Map<String, dynamic> json) {
    if (json['response'] != null) {
      response = new List<Response>();
      json['response'].forEach((v) {
        response.add(new Response.fromJson(v));
      });
    }
    error = json['error'] != null ? new Error.fromJson(json['error']) : null;
    totalPages = json['totalPages'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.response != null) {
      data['response'] = this.response.map((v) => v.toJson()).toList();
    }
    if (this.error != null) {
      data['error'] = this.error.toJson();
    }
    data['totalPages'] = this.totalPages;
    return data;
  }
}

class Response {
  String id;
  String title;
  String slug;
  String thumbnail;
  String stars;
  String starsCount;
  String payarr;
  String location;
  String desc;
  String price;
  String currCode;
  String currSymbol;
  List<Amenities> amenities;
  AvgReviews avgReviews;
  String latitude;
  String longitude;
  String address;
  String airportDistance;
  String citycenterDistance;
  String beachDistance;
  String portDistance;
  Null lastBooking;
  List<PopularAminities> popularAminities;
  Null policy;
  int basicprice;

  Response(
      {this.id,
        this.title,
        this.slug,
        this.thumbnail,
        this.stars,
        this.starsCount,
        this.payarr,
        this.location,
        this.desc,
        this.price,
        this.currCode,
        this.currSymbol,
        this.amenities,
        this.avgReviews,
        this.latitude,
        this.longitude,
        this.address,
        this.airportDistance,
        this.citycenterDistance,
        this.beachDistance,
        this.portDistance,
        this.lastBooking,
        this.popularAminities,
        this.policy,
        this.basicprice});

  Response.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    slug = json['slug'];
    thumbnail = json['thumbnail'];
    stars = json['stars'];
    starsCount = json['starsCount'];
    payarr = json['payarr'];
    location = json['location'];
    desc = json['desc'];
    price = json['price'];
    currCode = json['currCode'];
    currSymbol = json['currSymbol'];
    if (json['amenities'] != null) {
      amenities = new List<Amenities>();
      json['amenities'].forEach((v) {
        amenities.add(new Amenities.fromJson(v));
      });
    }
    avgReviews = json['avgReviews'] != null
        ? new AvgReviews.fromJson(json['avgReviews'])
        : null;
    latitude = json['latitude'];
    longitude = json['longitude'];
    address = json['address'];
    airportDistance = json['airport_distance'];
    citycenterDistance = json['citycenter_distance'];
    beachDistance = json['beachDistance'];
    portDistance = json['portDistance'];
    lastBooking = json['last_booking'];
    if (json['popular_aminities'] != null) {
      popularAminities = new List<PopularAminities>();
      json['popular_aminities'].forEach((v) {
        popularAminities.add(new PopularAminities.fromJson(v));
      });
    }
    policy = json['policy'];
    basicprice = json['basicprice'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['title'] = this.title;
    data['slug'] = this.slug;
    data['thumbnail'] = this.thumbnail;
    data['stars'] = this.stars;
    data['starsCount'] = this.starsCount;
    data['payarr'] = this.payarr;
    data['location'] = this.location;
    data['desc'] = this.desc;
    data['price'] = this.price;
    data['currCode'] = this.currCode;
    data['currSymbol'] = this.currSymbol;
    if (this.amenities != null) {
      data['amenities'] = this.amenities.map((v) => v.toJson()).toList();
    }
    if (this.avgReviews != null) {
      data['avgReviews'] = this.avgReviews.toJson();
    }
    data['latitude'] = this.latitude;
    data['longitude'] = this.longitude;
    data['address'] = this.address;
    data['airport_distance'] = this.airportDistance;
    data['citycenter_distance'] = this.citycenterDistance;
    data['beachDistance'] = this.beachDistance;
    data['portDistance'] = this.portDistance;
    data['last_booking'] = this.lastBooking;
    if (this.popularAminities != null) {
      data['popular_aminities'] =
          this.popularAminities.map((v) => v.toJson()).toList();
    }
    data['policy'] = this.policy;
    data['basicprice'] = this.basicprice;
    return data;
  }
}

class Amenities {
  String icon;
  String name;

  Amenities({this.icon, this.name});

  Amenities.fromJson(Map<String, dynamic> json) {
    icon = json['icon'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['icon'] = this.icon;
    data['name'] = this.name;
    return data;
  }
}

class AvgReviews {
  int clean;
  int comfort;
  int location;
  int facilities;
  int staff;
  String totalReviews;
  double overall;

  AvgReviews(
      {this.clean,
        this.comfort,
        this.location,
        this.facilities,
        this.staff,
        this.totalReviews,
        this.overall});

  AvgReviews.fromJson(Map<String, dynamic> json) {
    clean = json['clean'];
    comfort = json['comfort'];
    location = json['location'];
    facilities = json['facilities'];
    staff = json['staff'];
    totalReviews = json['totalReviews'];
    overall = json['overall'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['clean'] = this.clean;
    data['comfort'] = this.comfort;
    data['location'] = this.location;
    data['facilities'] = this.facilities;
    data['staff'] = this.staff;
    data['totalReviews'] = this.totalReviews;
    data['overall'] = this.overall;
    return data;
  }
}

class PopularAminities {
  String icon;
  String name;

  PopularAminities({this.icon, this.name});

  PopularAminities.fromJson(Map<String, dynamic> json) {
    icon = json['icon'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['icon'] = this.icon;
    data['name'] = this.name;
    return data;
  }
}

class Error {
  bool status;
  String msg;

  Error({this.status, this.msg});

  Error.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    msg = json['msg'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['msg'] = this.msg;
    return data;
  }
}