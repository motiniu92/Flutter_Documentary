class StarCountListData {
  String starCount;
  bool isSelected;

  StarCountListData({
    this.starCount = '',
    this.isSelected = false,
  });

  static List<StarCountListData> starList = [
    StarCountListData(
      starCount: '1',
      isSelected: false,
    ),
    StarCountListData(
      starCount: '2',
      isSelected: false,
    ),
    StarCountListData(
      starCount: '3',
      isSelected: false,
    ),
    StarCountListData(
      starCount: '4',
      isSelected: false,
    ),
    StarCountListData(
      starCount: '5',
      isSelected: false,
    ),
  ];

}
