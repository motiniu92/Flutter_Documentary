class FunList {
  List<FunResponse> response;

  FunList({this.response});

  FunList.fromJson(Map<String, dynamic> json) {
    if (json['response'] != null) {
      response = new List<FunResponse>();
      json['response'].forEach((v) {
        response.add(new FunResponse.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.response != null) {
      data['response'] = this.response.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class FunResponse {
  String settId;
  String settName;
  bool _isSelect = false;
  bool get isSelect => _isSelect;
  set isSelected(bool isSelect) {
    _isSelect = isSelect;
  }

  FunResponse({this.settId, this.settName});

  FunResponse.fromJson(Map<String, dynamic> json) {
    settId = json['sett_id'];
    settName = json['sett_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['sett_id'] = this.settId;
    data['sett_name'] = this.settName;
    return data;
  }
}
