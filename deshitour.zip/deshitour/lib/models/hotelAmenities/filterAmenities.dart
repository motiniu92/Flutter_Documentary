class AmenitiesList {
  List<AmenitiesResponse> response;

  AmenitiesList({this.response});

  AmenitiesList.fromJson(Map<String, dynamic> json) {
    if (json['response'] != null) {
      response = new List<AmenitiesResponse>();
      json['response'].forEach((v) {
        response.add(new AmenitiesResponse.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.response != null) {
      data['response'] = this.response.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class AmenitiesResponse {
  String settId;
  String settName;
  bool _isSelect=false;
  bool get isSelect => _isSelect;
  set isSelected(bool isSelect) {
    _isSelect = isSelect;
  }
  AmenitiesResponse({this.settId, this.settName});

  AmenitiesResponse.fromJson(Map<String, dynamic> json) {
    settId = json['sett_id'];
    settName = json['sett_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['sett_id'] = this.settId;
    data['sett_name'] = this.settName;
    return data;
  }
}