class FilterData{
  int star;
  int isSearch;
  FilterData({this.star, this.isSearch});
}