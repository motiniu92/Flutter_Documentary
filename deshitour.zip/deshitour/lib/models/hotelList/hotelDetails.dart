class HotelDetails {
  HotelDetailsResponse response;
  Error error;

  HotelDetails({this.response, this.error});

  HotelDetails.fromJson(Map<String, dynamic> json) {
    response = json['response'] != null
        ? new HotelDetailsResponse.fromJson(json['response'])
        : null;
    error = json['error'] != null ? new Error.fromJson(json['error']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.response != null) {
      data['response'] = this.response.toJson();
    }
    if (this.error != null) {
      data['error'] = this.error.toJson();
    }
    return data;
  }
}

class HotelDetailsResponse {
  Hotel hotel;
  Info infos;
  List<Rooms> rooms;
  String tripadvisorinfo;
  List<Reviews> HotelDetailsReviews;

  AvgReviews avgReviews;

  HotelDetailsResponse(
      {this.hotel,
        this.rooms,
        this.tripadvisorinfo,
        this.HotelDetailsReviews,
        this.infos,
        this.avgReviews});

  HotelDetailsResponse.fromJson(Map<String, dynamic> json) {
    hotel = json['hotel'] != null ? new Hotel.fromJson(json['hotel']) : null;
    if (json['rooms'] != null) {
      rooms = new List<Rooms>();
      json['rooms'].forEach((v) {
        rooms.add(new Rooms.fromJson(v));
      });
    }
    tripadvisorinfo = json['tripadvisorinfo'];
    if (json['reviews'] != null) {
      HotelDetailsReviews = new List<Reviews>();
      json['reviews'].forEach((v) {
        HotelDetailsReviews.add(new Reviews.fromJson(v));
      });
    }
    avgReviews = json['avgReviews'] != null
        ? new AvgReviews.fromJson(json['avgReviews'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.hotel != null) {
      data['hotel'] = this.hotel.toJson();
    }
    if (this.rooms != null) {
      data['rooms'] = this.rooms.map((v) => v.toJson()).toList();
    }
    data['tripadvisorinfo'] = this.tripadvisorinfo;
    // if (this.reviews != null) {
    //   data['reviews'] = this.reviews.map((v) => v.toJson()).toList();
    // }
    if (this.avgReviews != null) {
      data['avgReviews'] = this.avgReviews.toJson();
    }
    return data;
  }
}

class Hotel {
  String id;
  String title;
  String slug;
  String bookingSlug;
  String thumbnail;
  String stars;
  String starsCount;
  String location;
  String desc;
  List<HotelDetailsAmenities> amenities;
  String latitude;
  String longitude;
  List<SliderImages> sliderImages;
  List<HotelDetailsRelatedItems> relatedItems;
  List<PaymentOptions> paymentOptions;
  String defcheckin;
  String defcheckout;
  String metadesc;
  String keywords;
  String policy;
  Null tripadvisorid;
  String mapAddress;
  String hotelCancelationTime;
  List<HotelDetailsPopularAmenities> popularAmenities;
  String restaurant;
  String adminComment;
  String finePrint;
  String airportDistance;
  String videoLink;
  String fooddiscount;
  String hostedby;
  String breakfastCharge;
  int airportPickup;
  String cityCenterDistance;
  String beachDistance;
  String portDistance;
  String hotelLogo;
  String specialfeatures;
  String popularAmenitiesNote;
  String areainfo;
  List<PopularRoomAmenities> popularRoomAmenities;
  String taxType;
  String taxValue;
  AvgReviews hotelReviews;
  String basicPrice;
  Countries countries;
  String taxval;

  Hotel(
      {this.id,
        this.title,
        this.slug,
        this.bookingSlug,
        this.thumbnail,
        this.stars,
        this.starsCount,
        this.location,
        this.desc,
        this.amenities,
        this.latitude,
        this.longitude,
        this.sliderImages,
        this.relatedItems,
        this.paymentOptions,
        this.defcheckin,
        this.defcheckout,
        this.metadesc,
        this.keywords,
        this.policy,
        this.tripadvisorid,
        this.mapAddress,
        this.hotelCancelationTime,
        this.popularAmenities,
        this.restaurant,
        this.adminComment,
        this.finePrint,
        this.airportDistance,
        this.videoLink,
        this.fooddiscount,
        this.hostedby,
        this.breakfastCharge,
        this.airportPickup,
        this.cityCenterDistance,
        this.beachDistance,
        this.portDistance,
        this.hotelLogo,
        this.specialfeatures,
        this.popularAmenitiesNote,
        this.areainfo,
        this.popularRoomAmenities,
        this.taxType,
        this.taxValue,
        this.hotelReviews,
        this.basicPrice,
        this.countries,
        this.taxval});

  Hotel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    slug = json['slug'];
    bookingSlug = json['bookingSlug'];
    thumbnail = json['thumbnail'];
    stars = json['stars'];
    starsCount = json['starsCount'];
    location = json['location'];
    desc = json['desc'];
    if (json['amenities'] != null) {
      amenities = new List<HotelDetailsAmenities>();
      json['amenities'].forEach((v) {
        amenities.add(new HotelDetailsAmenities.fromJson(v));
      });
    }
    latitude = json['latitude'];
    longitude = json['longitude'];
    if (json['sliderImages'] != null) {
      sliderImages = new List<SliderImages>();
      json['sliderImages'].forEach((v) {
        sliderImages.add(new SliderImages.fromJson(v));
      });
    }
    if (json['relatedItems'] != null) {
      relatedItems = new List<HotelDetailsRelatedItems>();
      json['relatedItems'].forEach((v) {
        relatedItems.add(new HotelDetailsRelatedItems.fromJson(v));
      });
    }
    if (json['paymentOptions'] != null) {
      paymentOptions = new List<PaymentOptions>();
      json['paymentOptions'].forEach((v) {
        paymentOptions.add(new PaymentOptions.fromJson(v));
      });
    }
    defcheckin = json['defcheckin'];
    defcheckout = json['defcheckout'];
    metadesc = json['metadesc'];
    keywords = json['keywords'];
    policy = json['policy'];
    tripadvisorid = json['tripadvisorid'];
    mapAddress = json['mapAddress'];
    hotelCancelationTime = json['hotel_cancelation_time'];
    if (json['popular_amenities'] != null) {
      popularAmenities = new List<HotelDetailsPopularAmenities>();
      json['popular_amenities'].forEach((v) {
        popularAmenities.add(new HotelDetailsPopularAmenities.fromJson(v));
      });
    }
    restaurant = json['restaurant'];
    adminComment = json['admin_comment'];
    finePrint = json['fine_print'];
    airportDistance = json['airportDistance'];
    videoLink = json['videoLink'];
    fooddiscount = json['fooddiscount'];
    hostedby = json['hostedby'];
    breakfastCharge = json['breakfastCharge'];
    airportPickup = json['airportPickup'];
    cityCenterDistance = json['cityCenterDistance'];
    beachDistance = json['beachDistance'];
    portDistance = json['portDistance'];
    hotelLogo = json['hotel_logo'];
    specialfeatures = json['specialfeatures'];
    popularAmenitiesNote = json['popular_amenities_note'];
    areainfo = json['areainfo'];
    if (json['popular_room_amenities'] != null) {
      popularRoomAmenities = new List<PopularRoomAmenities>();
      json['popular_room_amenities'].forEach((v) {
        popularRoomAmenities.add(new PopularRoomAmenities.fromJson(v));
      });
    }
    taxType = json['tax_type'];
    taxValue = json['tax_value'];
    hotelReviews = json['hotelReviews'] != null
        ? new AvgReviews.fromJson(json['hotelReviews'])
        : null;
    basicPrice = json['basicPrice'];
    countries = json['countries'] != null
        ? new Countries.fromJson(json['countries'])
        : null;
    taxval = json['taxval'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['title'] = this.title;
    data['slug'] = this.slug;
    data['bookingSlug'] = this.bookingSlug;
    data['thumbnail'] = this.thumbnail;
    data['stars'] = this.stars;
    data['starsCount'] = this.starsCount;
    data['location'] = this.location;
    data['desc'] = this.desc;
    if (this.amenities != null) {
      data['amenities'] = this.amenities.map((v) => v.toJson()).toList();
    }
    data['latitude'] = this.latitude;
    data['longitude'] = this.longitude;
    if (this.sliderImages != null) {
      data['sliderImages'] = this.sliderImages.map((v) => v.toJson()).toList();
    }
    if (this.relatedItems != null) {
      data['relatedItems'] = this.relatedItems.map((v) => v.toJson()).toList();
    }
    if (this.paymentOptions != null) {
      data['paymentOptions'] =
          this.paymentOptions.map((v) => v.toJson()).toList();
    }
    data['defcheckin'] = this.defcheckin;
    data['defcheckout'] = this.defcheckout;
    data['metadesc'] = this.metadesc;
    data['keywords'] = this.keywords;
    data['policy'] = this.policy;
    data['tripadvisorid'] = this.tripadvisorid;
    data['mapAddress'] = this.mapAddress;
    data['hotel_cancelation_time'] = this.hotelCancelationTime;
    if (this.popularAmenities != null) {
      data['popular_amenities'] =
          this.popularAmenities.map((v) => v.toJson()).toList();
    }
    data['restaurant'] = this.restaurant;
    data['admin_comment'] = this.adminComment;
    data['fine_print'] = this.finePrint;
    data['airportDistance'] = this.airportDistance;
    data['videoLink'] = this.videoLink;
    data['fooddiscount'] = this.fooddiscount;
    data['hostedby'] = this.hostedby;
    data['breakfastCharge'] = this.breakfastCharge;
    data['airportPickup'] = this.airportPickup;
    data['cityCenterDistance'] = this.cityCenterDistance;
    data['beachDistance'] = this.beachDistance;
    data['portDistance'] = this.portDistance;
    data['hotel_logo'] = this.hotelLogo;
    data['specialfeatures'] = this.specialfeatures;
    data['popular_amenities_note'] = this.popularAmenitiesNote;
    data['areainfo'] = this.areainfo;
    if (this.popularRoomAmenities != null) {
      data['popular_room_amenities'] =
          this.popularRoomAmenities.map((v) => v.toJson()).toList();
    }
    data['tax_type'] = this.taxType;
    data['tax_value'] = this.taxValue;
    if (this.hotelReviews != null) {
      data['hotelReviews'] = this.hotelReviews.toJson();
    }
    data['basicPrice'] = this.basicPrice;
    if (this.countries != null) {
      data['countries'] = this.countries.toJson();
    }
    data['taxval'] = this.taxval;
    return data;
  }
}


class HotelDetailsAmenities {
  String icon;
  String name;

  HotelDetailsAmenities({this.icon, this.name});

  HotelDetailsAmenities.fromJson(Map<String, dynamic> json) {
    icon = json['icon'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['icon'] = this.icon;
    data['name'] = this.name;
    return data;
  }
}

class PopularRoomAmenities {
  String icon;
  String name;

  PopularRoomAmenities({this.icon, this.name});

  PopularRoomAmenities.fromJson(Map<String, dynamic> json) {
    icon = json['icon'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['icon'] = this.icon;
    data['name'] = this.name;
    return data;
  }
}

class HotelDetailsPopularAmenities {
  String icon;
  String name;


  HotelDetailsPopularAmenities.fromJson(Map<String, dynamic> json) {
    icon = json['icon'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['icon'] = this.icon;
    data['name'] = this.name;
    return data;
  }
}

class PaymentOptions {
  String icon;
  String name;

  PaymentOptions({this.icon, this.name});

  PaymentOptions.fromJson(Map<String, dynamic> json) {
    icon = json['icon'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['icon'] = this.icon;
    data['name'] = this.name;
    return data;
  }
}

class SliderImages {
  String fullImage;
  String thumbImage;

  SliderImages({this.fullImage, this.thumbImage});

  SliderImages.fromJson(Map<String, dynamic> json) {
    fullImage = json['fullImage'];
    thumbImage = json['thumbImage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['fullImage'] = this.fullImage;
    data['thumbImage'] = this.thumbImage;
    return data;
  }
}

class HotelDetailsRelatedItems {
  String id;
  String title;
  String desc;
  String slug;
  String thumbnail;
  String stars;
  String starsCount;
  String location;
  String price;
  String currCode;
  String currSymbol;
  AvgReviews avgReviews;
  String latitude;
  String longitude;

  HotelDetailsRelatedItems(
      {this.id,
        this.title,
        this.desc,
        this.slug,
        this.thumbnail,
        this.stars,
        this.starsCount,
        this.location,
        this.price,
        this.currCode,
        this.currSymbol,
        this.avgReviews,
        this.latitude,
        this.longitude});

  HotelDetailsRelatedItems.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    desc = json['desc'];
    slug = json['slug'];
    thumbnail = json['thumbnail'];
    stars = json['stars'];
    starsCount = json['starsCount'];
    location = json['location'];
    price = json['price'];
    currCode = json['currCode'];
    currSymbol = json['currSymbol'];
    avgReviews = json['avgReviews'] != null
        ? new AvgReviews.fromJson(json['avgReviews'])
        : null;
    latitude = json['latitude'];
    longitude = json['longitude'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['title'] = this.title;
    data['desc'] = this.desc;
    data['slug'] = this.slug;
    data['thumbnail'] = this.thumbnail;
    data['stars'] = this.stars;
    data['starsCount'] = this.starsCount;
    data['location'] = this.location;
    data['price'] = this.price;
    data['currCode'] = this.currCode;
    data['currSymbol'] = this.currSymbol;
    if (this.avgReviews != null) {
      data['avgReviews'] = this.avgReviews.toJson();
    }
    data['latitude'] = this.latitude;
    data['longitude'] = this.longitude;
    return data;
  }
}

class AvgReviews {
  dynamic clean;
  dynamic comfort;
  dynamic location;
  dynamic facilities;
  dynamic staff;
  String totalReviews;
  dynamic overall;

  AvgReviews(
      {this.clean,
        this.comfort,
        this.location,
        this.facilities,
        this.staff,
        this.totalReviews,
        this.overall});

  AvgReviews.fromJson(Map<String, dynamic> json) {
    clean = json['clean']== null ? 0.0 : json['clean'].toDouble();
    comfort = json['comfort']== null ? 0.0 : json['comfort'].toDouble();
    location = json['location']== null ? 0.0 : json['location'].toDouble();
    facilities = json['facilities']== null ? 0.0 : json['facilities'].toDouble();
    staff = json['staff']== null ? 0.0 : json['staff'].toDouble();
    totalReviews = json['totalReviews'];
    overall = json['overall']== null ? 0.0 : json['overall'].toDouble();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['clean'] = this.clean;
    data['comfort'] = this.comfort;
    data['location'] = this.location;
    data['facilities'] = this.facilities;
    data['staff'] = this.staff;
    data['totalReviews'] = this.totalReviews;
    data['overall'] = this.overall;
    return data;
  }
}

class Countries {
  String aF;
  String aL;
  String dZ;
  String aS;
  String aD;
  String aO;
  String aI;
  String aQ;
  String aG;
  String aR;
  String aM;
  String aW;
  String aU;
  String aT;
  String aZ;
  String bS;
  String bH;
  String bD;
  String bB;
  String bY;
  String bE;
  String bZ;
  String bJ;
  String bM;
  String bT;
  String bO;
  String bA;
  String bW;
  String bV;
  String bR;
  String iO;
  String bN;
  String bG;
  String bF;
  String bI;
  String kH;
  String cM;
  String cA;
  String cV;
  String kY;
  String cF;
  String tD;
  String cL;
  String cN;
  String cX;
  String cC;
  String cO;
  String kM;
  String cG;
  String cK;
  String cR;
  String cI;
  String hR;
  String cU;
  String cY;
  String cZ;
  String dK;
  String dJ;
  String dM;
  String dO;
  String tL;
  String eC;
  String eG;
  String sV;
  String gQ;
  String eR;
  String eE;
  String eT;
  String fK;
  String fO;
  String fJ;
  String fI;
  String fR;
  String gF;
  String pF;
  String tF;
  String gA;
  String gM;
  String gE;
  String dE;
  String gH;
  String gI;
  String gR;
  String gL;
  String gD;
  String gP;
  String gU;
  String gT;
  String gN;
  String gW;
  String gY;
  String hT;
  String hM;
  String hN;
  String hK;
  String hU;
  String iS;
  String iN;
  String iD;
  String iR;
  String iQ;
  String iE;
  String iL;
  String iT;
  String jM;
  String jP;
  String jO;
  String kZ;
  String kE;
  String kI;
  String kP;
  String kR;
  String kW;
  String kG;
  String lA;
  String lV;
  String lB;
  String lS;
  String lR;
  String lY;
  String lI;
  String lT;
  String lU;
  String mO;
  String mK;
  String mG;
  String mW;
  String mY;
  String mV;
  String mL;
  String mT;
  String mH;
  String mQ;
  String mR;
  String mU;
  String yT;
  String mX;
  String fM;
  String mD;
  String mC;
  String mN;
  String mS;
  String mA;
  String mZ;
  String mM;
  String nA;
  String nR;
  String nP;
  String nL;
  String aN;
  String nC;
  String nZ;
  String nI;
  String nE;
  String nG;
  String nU;
  String nF;
  String mP;
  String nO;
  String oM;
  String pK;
  String pW;
  String pA;
  String pG;
  String pY;
  String pE;
  String pH;
  String pN;
  String pL;
  String pT;
  String pR;
  String qA;
  String rE;
  String rO;
  String rU;
  String rW;
  String kN;
  String lC;
  String vC;
  String wS;
  String sM;
  String sT;
  String sA;
  String sN;
  String sC;
  String sL;
  String sG;
  String sK;
  String sI;
  String sB;
  String sO;
  String zA;
  String gS;
  String eS;
  String lK;
  String sH;
  String pM;
  String sD;
  String sR;
  String sJ;
  String sZ;
  String sE;
  String cH;
  String sY;
  String tW;
  String tJ;
  String tZ;
  String tH;
  String tG;
  String tK;
  String tO;
  String tT;
  String tN;
  String tR;
  String tM;
  String tC;
  String tV;
  String uG;
  String uA;
  String aE;
  String gB;
  String uS;
  String uM;
  String uY;
  String uZ;
  String vU;
  String vA;
  String vE;
  String vN;
  String vG;
  String vI;
  String wF;
  String eH;
  String yE;
  String rS;
  String zM;
  String zW;
  String aX;
  String pS;
  String mE;
  String gG;
  String iM;
  String jE;
  String cW;
  String xK;

  Countries(
      {this.aF,
        this.aL,
        this.dZ,
        this.aS,
        this.aD,
        this.aO,
        this.aI,
        this.aQ,
        this.aG,
        this.aR,
        this.aM,
        this.aW,
        this.aU,
        this.aT,
        this.aZ,
        this.bS,
        this.bH,
        this.bD,
        this.bB,
        this.bY,
        this.bE,
        this.bZ,
        this.bJ,
        this.bM,
        this.bT,
        this.bO,
        this.bA,
        this.bW,
        this.bV,
        this.bR,
        this.iO,
        this.bN,
        this.bG,
        this.bF,
        this.bI,
        this.kH,
        this.cM,
        this.cA,
        this.cV,
        this.kY,
        this.cF,
        this.tD,
        this.cL,
        this.cN,
        this.cX,
        this.cC,
        this.cO,
        this.kM,
        this.cG,
        this.cK,
        this.cR,
        this.cI,
        this.hR,
        this.cU,
        this.cY,
        this.cZ,
        this.dK,
        this.dJ,
        this.dM,
        this.dO,
        this.tL,
        this.eC,
        this.eG,
        this.sV,
        this.gQ,
        this.eR,
        this.eE,
        this.eT,
        this.fK,
        this.fO,
        this.fJ,
        this.fI,
        this.fR,
        this.gF,
        this.pF,
        this.tF,
        this.gA,
        this.gM,
        this.gE,
        this.dE,
        this.gH,
        this.gI,
        this.gR,
        this.gL,
        this.gD,
        this.gP,
        this.gU,
        this.gT,
        this.gN,
        this.gW,
        this.gY,
        this.hT,
        this.hM,
        this.hN,
        this.hK,
        this.hU,
        this.iS,
        this.iN,
        this.iD,
        this.iR,
        this.iQ,
        this.iE,
        this.iL,
        this.iT,
        this.jM,
        this.jP,
        this.jO,
        this.kZ,
        this.kE,
        this.kI,
        this.kP,
        this.kR,
        this.kW,
        this.kG,
        this.lA,
        this.lV,
        this.lB,
        this.lS,
        this.lR,
        this.lY,
        this.lI,
        this.lT,
        this.lU,
        this.mO,
        this.mK,
        this.mG,
        this.mW,
        this.mY,
        this.mV,
        this.mL,
        this.mT,
        this.mH,
        this.mQ,
        this.mR,
        this.mU,
        this.yT,
        this.mX,
        this.fM,
        this.mD,
        this.mC,
        this.mN,
        this.mS,
        this.mA,
        this.mZ,
        this.mM,
        this.nA,
        this.nR,
        this.nP,
        this.nL,
        this.aN,
        this.nC,
        this.nZ,
        this.nI,
        this.nE,
        this.nG,
        this.nU,
        this.nF,
        this.mP,
        this.nO,
        this.oM,
        this.pK,
        this.pW,
        this.pA,
        this.pG,
        this.pY,
        this.pE,
        this.pH,
        this.pN,
        this.pL,
        this.pT,
        this.pR,
        this.qA,
        this.rE,
        this.rO,
        this.rU,
        this.rW,
        this.kN,
        this.lC,
        this.vC,
        this.wS,
        this.sM,
        this.sT,
        this.sA,
        this.sN,
        this.sC,
        this.sL,
        this.sG,
        this.sK,
        this.sI,
        this.sB,
        this.sO,
        this.zA,
        this.gS,
        this.eS,
        this.lK,
        this.sH,
        this.pM,
        this.sD,
        this.sR,
        this.sJ,
        this.sZ,
        this.sE,
        this.cH,
        this.sY,
        this.tW,
        this.tJ,
        this.tZ,
        this.tH,
        this.tG,
        this.tK,
        this.tO,
        this.tT,
        this.tN,
        this.tR,
        this.tM,
        this.tC,
        this.tV,
        this.uG,
        this.uA,
        this.aE,
        this.gB,
        this.uS,
        this.uM,
        this.uY,
        this.uZ,
        this.vU,
        this.vA,
        this.vE,
        this.vN,
        this.vG,
        this.vI,
        this.wF,
        this.eH,
        this.yE,
        this.rS,
        this.zM,
        this.zW,
        this.aX,
        this.pS,
        this.mE,
        this.gG,
        this.iM,
        this.jE,
        this.cW,
        this.xK});

  Countries.fromJson(Map<String, dynamic> json) {
    aF = json['AF'];
    aL = json['AL'];
    dZ = json['DZ'];
    aS = json['AS'];
    aD = json['AD'];
    aO = json['AO'];
    aI = json['AI'];
    aQ = json['AQ'];
    aG = json['AG'];
    aR = json['AR'];
    aM = json['AM'];
    aW = json['AW'];
    aU = json['AU'];
    aT = json['AT'];
    aZ = json['AZ'];
    bS = json['BS'];
    bH = json['BH'];
    bD = json['BD'];
    bB = json['BB'];
    bY = json['BY'];
    bE = json['BE'];
    bZ = json['BZ'];
    bJ = json['BJ'];
    bM = json['BM'];
    bT = json['BT'];
    bO = json['BO'];
    bA = json['BA'];
    bW = json['BW'];
    bV = json['BV'];
    bR = json['BR'];
    iO = json['IO'];
    bN = json['BN'];
    bG = json['BG'];
    bF = json['BF'];
    bI = json['BI'];
    kH = json['KH'];
    cM = json['CM'];
    cA = json['CA'];
    cV = json['CV'];
    kY = json['KY'];
    cF = json['CF'];
    tD = json['TD'];
    cL = json['CL'];
    cN = json['CN'];
    cX = json['CX'];
    cC = json['CC'];
    cO = json['CO'];
    kM = json['KM'];
    cG = json['CG'];
    cK = json['CK'];
    cR = json['CR'];
    cI = json['CI'];
    hR = json['HR'];
    cU = json['CU'];
    cY = json['CY'];
    cZ = json['CZ'];
    dK = json['DK'];
    dJ = json['DJ'];
    dM = json['DM'];
    dO = json['DO'];
    tL = json['TL'];
    eC = json['EC'];
    eG = json['EG'];
    sV = json['SV'];
    gQ = json['GQ'];
    eR = json['ER'];
    eE = json['EE'];
    eT = json['ET'];
    fK = json['FK'];
    fO = json['FO'];
    fJ = json['FJ'];
    fI = json['FI'];
    fR = json['FR'];
    gF = json['GF'];
    pF = json['PF'];
    tF = json['TF'];
    gA = json['GA'];
    gM = json['GM'];
    gE = json['GE'];
    dE = json['DE'];
    gH = json['GH'];
    gI = json['GI'];
    gR = json['GR'];
    gL = json['GL'];
    gD = json['GD'];
    gP = json['GP'];
    gU = json['GU'];
    gT = json['GT'];
    gN = json['GN'];
    gW = json['GW'];
    gY = json['GY'];
    hT = json['HT'];
    hM = json['HM'];
    hN = json['HN'];
    hK = json['HK'];
    hU = json['HU'];
    iS = json['IS'];
    iN = json['IN'];
    iD = json['ID'];
    iR = json['IR'];
    iQ = json['IQ'];
    iE = json['IE'];
    iL = json['IL'];
    iT = json['IT'];
    jM = json['JM'];
    jP = json['JP'];
    jO = json['JO'];
    kZ = json['KZ'];
    kE = json['KE'];
    kI = json['KI'];
    kP = json['KP'];
    kR = json['KR'];
    kW = json['KW'];
    kG = json['KG'];
    lA = json['LA'];
    lV = json['LV'];
    lB = json['LB'];
    lS = json['LS'];
    lR = json['LR'];
    lY = json['LY'];
    lI = json['LI'];
    lT = json['LT'];
    lU = json['LU'];
    mO = json['MO'];
    mK = json['MK'];
    mG = json['MG'];
    mW = json['MW'];
    mY = json['MY'];
    mV = json['MV'];
    mL = json['ML'];
    mT = json['MT'];
    mH = json['MH'];
    mQ = json['MQ'];
    mR = json['MR'];
    mU = json['MU'];
    yT = json['YT'];
    mX = json['MX'];
    fM = json['FM'];
    mD = json['MD'];
    mC = json['MC'];
    mN = json['MN'];
    mS = json['MS'];
    mA = json['MA'];
    mZ = json['MZ'];
    mM = json['MM'];
    nA = json['NA'];
    nR = json['NR'];
    nP = json['NP'];
    nL = json['NL'];
    aN = json['AN'];
    nC = json['NC'];
    nZ = json['NZ'];
    nI = json['NI'];
    nE = json['NE'];
    nG = json['NG'];
    nU = json['NU'];
    nF = json['NF'];
    mP = json['MP'];
    nO = json['NO'];
    oM = json['OM'];
    pK = json['PK'];
    pW = json['PW'];
    pA = json['PA'];
    pG = json['PG'];
    pY = json['PY'];
    pE = json['PE'];
    pH = json['PH'];
    pN = json['PN'];
    pL = json['PL'];
    pT = json['PT'];
    pR = json['PR'];
    qA = json['QA'];
    rE = json['RE'];
    rO = json['RO'];
    rU = json['RU'];
    rW = json['RW'];
    kN = json['KN'];
    lC = json['LC'];
    vC = json['VC'];
    wS = json['WS'];
    sM = json['SM'];
    sT = json['ST'];
    sA = json['SA'];
    sN = json['SN'];
    sC = json['SC'];
    sL = json['SL'];
    sG = json['SG'];
    sK = json['SK'];
    sI = json['SI'];
    sB = json['SB'];
    sO = json['SO'];
    zA = json['ZA'];
    gS = json['GS'];
    eS = json['ES'];
    lK = json['LK'];
    sH = json['SH'];
    pM = json['PM'];
    sD = json['SD'];
    sR = json['SR'];
    sJ = json['SJ'];
    sZ = json['SZ'];
    sE = json['SE'];
    cH = json['CH'];
    sY = json['SY'];
    tW = json['TW'];
    tJ = json['TJ'];
    tZ = json['TZ'];
    tH = json['TH'];
    tG = json['TG'];
    tK = json['TK'];
    tO = json['TO'];
    tT = json['TT'];
    tN = json['TN'];
    tR = json['TR'];
    tM = json['TM'];
    tC = json['TC'];
    tV = json['TV'];
    uG = json['UG'];
    uA = json['UA'];
    aE = json['AE'];
    gB = json['GB'];
    uS = json['US'];
    uM = json['UM'];
    uY = json['UY'];
    uZ = json['UZ'];
    vU = json['VU'];
    vA = json['VA'];
    vE = json['VE'];
    vN = json['VN'];
    vG = json['VG'];
    vI = json['VI'];
    wF = json['WF'];
    eH = json['EH'];
    yE = json['YE'];
    rS = json['RS'];
    zM = json['ZM'];
    zW = json['ZW'];
    aX = json['AX'];
    pS = json['PS'];
    mE = json['ME'];
    gG = json['GG'];
    iM = json['IM'];
    jE = json['JE'];
    cW = json['CW'];
    xK = json['XK'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['AF'] = this.aF;
    data['AL'] = this.aL;
    data['DZ'] = this.dZ;
    data['AS'] = this.aS;
    data['AD'] = this.aD;
    data['AO'] = this.aO;
    data['AI'] = this.aI;
    data['AQ'] = this.aQ;
    data['AG'] = this.aG;
    data['AR'] = this.aR;
    data['AM'] = this.aM;
    data['AW'] = this.aW;
    data['AU'] = this.aU;
    data['AT'] = this.aT;
    data['AZ'] = this.aZ;
    data['BS'] = this.bS;
    data['BH'] = this.bH;
    data['BD'] = this.bD;
    data['BB'] = this.bB;
    data['BY'] = this.bY;
    data['BE'] = this.bE;
    data['BZ'] = this.bZ;
    data['BJ'] = this.bJ;
    data['BM'] = this.bM;
    data['BT'] = this.bT;
    data['BO'] = this.bO;
    data['BA'] = this.bA;
    data['BW'] = this.bW;
    data['BV'] = this.bV;
    data['BR'] = this.bR;
    data['IO'] = this.iO;
    data['BN'] = this.bN;
    data['BG'] = this.bG;
    data['BF'] = this.bF;
    data['BI'] = this.bI;
    data['KH'] = this.kH;
    data['CM'] = this.cM;
    data['CA'] = this.cA;
    data['CV'] = this.cV;
    data['KY'] = this.kY;
    data['CF'] = this.cF;
    data['TD'] = this.tD;
    data['CL'] = this.cL;
    data['CN'] = this.cN;
    data['CX'] = this.cX;
    data['CC'] = this.cC;
    data['CO'] = this.cO;
    data['KM'] = this.kM;
    data['CG'] = this.cG;
    data['CK'] = this.cK;
    data['CR'] = this.cR;
    data['CI'] = this.cI;
    data['HR'] = this.hR;
    data['CU'] = this.cU;
    data['CY'] = this.cY;
    data['CZ'] = this.cZ;
    data['DK'] = this.dK;
    data['DJ'] = this.dJ;
    data['DM'] = this.dM;
    data['DO'] = this.dO;
    data['TL'] = this.tL;
    data['EC'] = this.eC;
    data['EG'] = this.eG;
    data['SV'] = this.sV;
    data['GQ'] = this.gQ;
    data['ER'] = this.eR;
    data['EE'] = this.eE;
    data['ET'] = this.eT;
    data['FK'] = this.fK;
    data['FO'] = this.fO;
    data['FJ'] = this.fJ;
    data['FI'] = this.fI;
    data['FR'] = this.fR;
    data['GF'] = this.gF;
    data['PF'] = this.pF;
    data['TF'] = this.tF;
    data['GA'] = this.gA;
    data['GM'] = this.gM;
    data['GE'] = this.gE;
    data['DE'] = this.dE;
    data['GH'] = this.gH;
    data['GI'] = this.gI;
    data['GR'] = this.gR;
    data['GL'] = this.gL;
    data['GD'] = this.gD;
    data['GP'] = this.gP;
    data['GU'] = this.gU;
    data['GT'] = this.gT;
    data['GN'] = this.gN;
    data['GW'] = this.gW;
    data['GY'] = this.gY;
    data['HT'] = this.hT;
    data['HM'] = this.hM;
    data['HN'] = this.hN;
    data['HK'] = this.hK;
    data['HU'] = this.hU;
    data['IS'] = this.iS;
    data['IN'] = this.iN;
    data['ID'] = this.iD;
    data['IR'] = this.iR;
    data['IQ'] = this.iQ;
    data['IE'] = this.iE;
    data['IL'] = this.iL;
    data['IT'] = this.iT;
    data['JM'] = this.jM;
    data['JP'] = this.jP;
    data['JO'] = this.jO;
    data['KZ'] = this.kZ;
    data['KE'] = this.kE;
    data['KI'] = this.kI;
    data['KP'] = this.kP;
    data['KR'] = this.kR;
    data['KW'] = this.kW;
    data['KG'] = this.kG;
    data['LA'] = this.lA;
    data['LV'] = this.lV;
    data['LB'] = this.lB;
    data['LS'] = this.lS;
    data['LR'] = this.lR;
    data['LY'] = this.lY;
    data['LI'] = this.lI;
    data['LT'] = this.lT;
    data['LU'] = this.lU;
    data['MO'] = this.mO;
    data['MK'] = this.mK;
    data['MG'] = this.mG;
    data['MW'] = this.mW;
    data['MY'] = this.mY;
    data['MV'] = this.mV;
    data['ML'] = this.mL;
    data['MT'] = this.mT;
    data['MH'] = this.mH;
    data['MQ'] = this.mQ;
    data['MR'] = this.mR;
    data['MU'] = this.mU;
    data['YT'] = this.yT;
    data['MX'] = this.mX;
    data['FM'] = this.fM;
    data['MD'] = this.mD;
    data['MC'] = this.mC;
    data['MN'] = this.mN;
    data['MS'] = this.mS;
    data['MA'] = this.mA;
    data['MZ'] = this.mZ;
    data['MM'] = this.mM;
    data['NA'] = this.nA;
    data['NR'] = this.nR;
    data['NP'] = this.nP;
    data['NL'] = this.nL;
    data['AN'] = this.aN;
    data['NC'] = this.nC;
    data['NZ'] = this.nZ;
    data['NI'] = this.nI;
    data['NE'] = this.nE;
    data['NG'] = this.nG;
    data['NU'] = this.nU;
    data['NF'] = this.nF;
    data['MP'] = this.mP;
    data['NO'] = this.nO;
    data['OM'] = this.oM;
    data['PK'] = this.pK;
    data['PW'] = this.pW;
    data['PA'] = this.pA;
    data['PG'] = this.pG;
    data['PY'] = this.pY;
    data['PE'] = this.pE;
    data['PH'] = this.pH;
    data['PN'] = this.pN;
    data['PL'] = this.pL;
    data['PT'] = this.pT;
    data['PR'] = this.pR;
    data['QA'] = this.qA;
    data['RE'] = this.rE;
    data['RO'] = this.rO;
    data['RU'] = this.rU;
    data['RW'] = this.rW;
    data['KN'] = this.kN;
    data['LC'] = this.lC;
    data['VC'] = this.vC;
    data['WS'] = this.wS;
    data['SM'] = this.sM;
    data['ST'] = this.sT;
    data['SA'] = this.sA;
    data['SN'] = this.sN;
    data['SC'] = this.sC;
    data['SL'] = this.sL;
    data['SG'] = this.sG;
    data['SK'] = this.sK;
    data['SI'] = this.sI;
    data['SB'] = this.sB;
    data['SO'] = this.sO;
    data['ZA'] = this.zA;
    data['GS'] = this.gS;
    data['ES'] = this.eS;
    data['LK'] = this.lK;
    data['SH'] = this.sH;
    data['PM'] = this.pM;
    data['SD'] = this.sD;
    data['SR'] = this.sR;
    data['SJ'] = this.sJ;
    data['SZ'] = this.sZ;
    data['SE'] = this.sE;
    data['CH'] = this.cH;
    data['SY'] = this.sY;
    data['TW'] = this.tW;
    data['TJ'] = this.tJ;
    data['TZ'] = this.tZ;
    data['TH'] = this.tH;
    data['TG'] = this.tG;
    data['TK'] = this.tK;
    data['TO'] = this.tO;
    data['TT'] = this.tT;
    data['TN'] = this.tN;
    data['TR'] = this.tR;
    data['TM'] = this.tM;
    data['TC'] = this.tC;
    data['TV'] = this.tV;
    data['UG'] = this.uG;
    data['UA'] = this.uA;
    data['AE'] = this.aE;
    data['GB'] = this.gB;
    data['US'] = this.uS;
    data['UM'] = this.uM;
    data['UY'] = this.uY;
    data['UZ'] = this.uZ;
    data['VU'] = this.vU;
    data['VA'] = this.vA;
    data['VE'] = this.vE;
    data['VN'] = this.vN;
    data['VG'] = this.vG;
    data['VI'] = this.vI;
    data['WF'] = this.wF;
    data['EH'] = this.eH;
    data['YE'] = this.yE;
    data['RS'] = this.rS;
    data['ZM'] = this.zM;
    data['ZW'] = this.zW;
    data['AX'] = this.aX;
    data['PS'] = this.pS;
    data['ME'] = this.mE;
    data['GG'] = this.gG;
    data['IM'] = this.iM;
    data['JE'] = this.jE;
    data['CW'] = this.cW;
    data['XK'] = this.xK;
    return data;
  }
}

class Rooms {
  String id;
  String title;
  String desc;
  String maxAdults;
  String maxChild;
  dynamic maxQuantity;
  dynamic maxAvailablity;
  String thumbnail;
  List<Images> images;
  List<RoomsAmenities> amenities;
  String price;
  String currCode;
  String currRate ;

  String currSymbol;
  Info info;
  String extraBeds;
  int extrabedCharges;
  String singlebed;
  String doublebed;
  String roomSize;

  Rooms(
      {this.id,
        this.title,
        this.desc,
        this.maxAdults,
        this.maxChild,
        this.maxQuantity,
        this.maxAvailablity,
        this.thumbnail,
        this.images,
        this.amenities,
        this.price,
        this.currCode,
        this.currRate,
        this.currSymbol,
        this.info,
        this.extraBeds,
        this.extrabedCharges,
        this.singlebed,
        this.doublebed,
        this.roomSize});

  Rooms.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    desc = json['desc'];
    maxAdults = json['maxAdults'];
    maxChild = json['maxChild'];
    maxQuantity = json['maxQuantity']== null ? "nan" : json['maxQuantity'].toString();
    maxAvailablity = json['maxAvailablity']== null ? "nan" : json['maxAvailablity'].toString();
    thumbnail = json['thumbnail'];
    if (json['Images'] != null) {
      images = new List<Images>();
      json['Images'].forEach((v) {
        images.add(new Images.fromJson(v));
      });
    }
    if (json['Amenities'] != null) {
      amenities = new List<RoomsAmenities>();
      json['Amenities'].forEach((v) {
        amenities.add(new RoomsAmenities.fromJson(v));
      });
    }
    price = json['price'];
    currCode = json['currCode'];
    currRate = json['currRate'];
    currSymbol = json['currSymbol'];
    info = json['Info'] != null ? new Info.fromJson(json['Info']) : null;
    extraBeds = json['extraBeds'];
    extrabedCharges = json['extrabedCharges'];
    singlebed = json['singlebed'];
    doublebed = json['doublebed'];
    roomSize = json['room_size'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['title'] = this.title;
    data['desc'] = this.desc;
    data['maxAdults'] = this.maxAdults;
    data['maxChild'] = this.maxChild;
    data['maxQuantity'] = this.maxQuantity;
    data['maxAvailablity'] = this.maxAvailablity;
    data['thumbnail'] = this.thumbnail;
    if (this.images != null) {
      data['Images'] = this.images.map((v) => v.toJson()).toList();
    }
    if (this.amenities != null) {
      data['Amenities'] = this.amenities.map((v) => v.toJson()).toList();
    }
    data['price'] = this.price;
    data['currCode'] = this.currCode;
    data['currRate'] = this.currRate;
    data['currSymbol'] = this.currSymbol;
    if (this.info != null) {
      data['Info'] = this.info.toJson();
    }
    data['extraBeds'] = this.extraBeds;
    data['extrabedCharges'] = this.extrabedCharges;
    data['singlebed'] = this.singlebed;
    data['doublebed'] = this.doublebed;
    data['room_size'] = this.roomSize;
    return data;
  }
}
class RoomsAmenities {
  String icon;
  String name;

  RoomsAmenities({this.icon, this.name});

  RoomsAmenities.fromJson(Map<String, dynamic> json) {
    icon = json['icon'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['icon'] = this.icon;
    data['name'] = this.name;
    return data;
  }
}

class Reviews {
  String reviewOverall;
  String reviewName;
  String reviewComment;
  String reviewDate;
  int maxRating;

  Reviews(
      {this.reviewOverall,
        this.reviewName,
        this.reviewComment,
        this.reviewDate,
        this.maxRating});

  Reviews.fromJson(Map<String, dynamic> json) {
    reviewOverall = json['review_overall'];
    reviewName = json['review_name'];
    reviewComment = json['review_comment'];
    reviewDate = json['review_date'];
    maxRating = json['maxRating'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['review_overall'] = this.reviewOverall;
    data['review_name'] = this.reviewName;
    data['review_comment'] = this.reviewComment;
    data['review_date'] = this.reviewDate;
    data['maxRating'] = this.maxRating;
    return data;
  }
}




class Images {
  String fullImage;
  String thumbImage;

  Images({this.fullImage, this.thumbImage});

  Images.fromJson(Map<String, dynamic> json) {
    fullImage = json['fullImage'];
    thumbImage = json['thumbImage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['fullImage'] = this.fullImage;
    data['thumbImage'] = this.thumbImage;
    return data;
  }
}

class Info {
  String roomID;
  int perNight;
  int stay;
  int totalPrice;
  String checkin;
  String checkout;
  int extrabed;
  String maxAdults;
  String maxChild;
  String quantity;
  int totalpricewithouttax;
  int discount;

  Info(
      {this.roomID,
        this.perNight,
        this.stay,
        this.totalPrice,
        this.checkin,
        this.checkout,
        this.extrabed,
        this.maxAdults,
        this.maxChild,
        this.quantity,
        this.totalpricewithouttax,
        this.discount});

  Info.fromJson(Map<String, dynamic> json) {
    roomID = json['roomID'];
    perNight = json['perNight'];
    stay = json['stay'];
    totalPrice = json['totalPrice'];
    checkin = json['checkin'];
    checkout = json['checkout'];
    extrabed = json['extrabed'];
    maxAdults = json['maxAdults'];
    maxChild = json['maxChild'];
    quantity = json['quantity'];
    totalpricewithouttax = json['totalpricewithouttax'];
    discount = json['discount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['roomID'] = this.roomID;
    data['perNight'] = this.perNight;
    data['stay'] = this.stay;
    data['totalPrice'] = this.totalPrice;
    data['checkin'] = this.checkin;
    data['checkout'] = this.checkout;
    data['extrabed'] = this.extrabed;
    data['maxAdults'] = this.maxAdults;
    data['maxChild'] = this.maxChild;
    data['quantity'] = this.quantity;
    data['totalpricewithouttax'] = this.totalpricewithouttax;
    data['discount'] = this.discount;
    return data;
  }
}

class Error {
  bool status;
  String msg;

  Error({this.status, this.msg});

  Error.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    msg = json['msg'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['msg'] = this.msg;
    return data;
  }
}
