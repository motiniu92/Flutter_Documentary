class HotelsFilter {
  Response response;
  Error error;

  HotelsFilter({this.response, this.error});

  HotelsFilter.fromJson(Map<String, dynamic> json) {
    response = json['response'] != null
        ? new Response.fromJson(json['response'])
        : null;
    error = json['error'] != null ? new Error.fromJson(json['error']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.response != null) {
      data['response'] = this.response.toJson();
    }
    if (this.error != null) {
      data['error'] = this.error.toJson();
    }
    return data;
  }
}

class Response {
  List<All> all;
  int rows;

  Response({this.all, this.rows});

  Response.fromJson(Map<String, dynamic> json) {
    if (json['all'] != null) {
      all = new List<All>();
      json['all'].forEach((v) {
        all.add(new All.fromJson(v));
      });
    }
    rows = json['rows'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.all != null) {
      data['all'] = this.all.map((v) => v.toJson()).toList();
    }
    data['rows'] = this.rows;
    return data;
  }
}

class All {
  String hotelId;
  String hotelTitle;
  String hotelSlug;
  String hotelDesc;
  Null hotelSurroundings;
  Null hotelServices;
  Null hotelAdminReview;
  String hotelStars;
  Null hotelRatings;
  String hotelIsFeatured;
  String hotelFeaturedFrom;
  String hotelFeaturedTo;
  String hotelOwnedBy;
  String hotelAgent;
  String hotelType;
  String hotelCity;
  String hotelBasicPrice;
  Null hotelBasicDiscount;
  Null hotelMapAddress;
  Null hotelMapZip;
  String hotelMapCity;
  Null hotelMapCountry;
  String hotelLatitude;
  String hotelLongitude;
  String hotelMetaTitle;
  String hotelMetaKeywords;
  String hotelMetaDesc;
  String hotelAmenities;
  String hotelPopularAminities;
  String hotelPopularAminitiesText;
  String hotelPopularRoomAmenities;
  String hotelPaymentOpt;
  Null hotelAdults;
  Null hotelChildren;
  String hotelCheckIn;
  String hotelCheckOut;
  String hotelPolicy;
  String hotelStatus;
  String hotelOrder;
  String hotelRelated;
  String hotelCommFixed;
  String hotelCommPercentage;
  String hotelTaxFixed;
  String hotelTaxPercentage;
  String hotelEmail;
  String hotelPhone;
  String hotelWebsite;
  String hotelFeaturedForever;
  String hotelTrusted;
  String hotelRefundable;
  String hotelBestPrice;
  String hotelArrivalpay;
  Null tripadvisorId;
  String thumbnailImage;
  String module;
  String hotelCreatedAt;
  String hotelAddress;
  String hotelAirportDistance;
  String hotelCityCenterDistance;
  String hotelBeachDistance;
  String hotelPortDistance;
  String hotelAreainfo;
  String hotelRestaurant;
  String hotelCancelationTime;
  String hotelAdminComment;
  String hotelSpecialfeatures;
  String hotelLogo;
  String hotelFinePrint;
  String hotelAirportPickup;
  String hotelBreakfastCharge;
  String hotelVideoLink;
  String hotelHostedBy;
  String hotelFoodDiscount;
  String hotelFunThing;
  String roomId;
  String roomHotel;
  String roomTitle;
  String roomBasicPrice;
  Null roomBasicDiscount;
  String roomDesc;
  String roomAdults;
  String roomChildren;
  String roomSingleBed;
  String roomDoubleBed;
  String roomMinStay;
  String roomAmenities;
  String roomOrder;
  String roomType;
  String extraBed;
  String extraBedCharges;
  String roomAddedOn;
  String roomQuantity;
  String roomStatus;
  String roomSize;
  Null transId;
  Null transTitle;
  Null transDesc;
  Null transPolicy;
  Null metatitle;
  Null metadesc;
  Null metakeywords;
  Null itemId;
  Null transLang;

  All(
      {this.hotelId,
        this.hotelTitle,
        this.hotelSlug,
        this.hotelDesc,
        this.hotelSurroundings,
        this.hotelServices,
        this.hotelAdminReview,
        this.hotelStars,
        this.hotelRatings,
        this.hotelIsFeatured,
        this.hotelFeaturedFrom,
        this.hotelFeaturedTo,
        this.hotelOwnedBy,
        this.hotelAgent,
        this.hotelType,
        this.hotelCity,
        this.hotelBasicPrice,
        this.hotelBasicDiscount,
        this.hotelMapAddress,
        this.hotelMapZip,
        this.hotelMapCity,
        this.hotelMapCountry,
        this.hotelLatitude,
        this.hotelLongitude,
        this.hotelMetaTitle,
        this.hotelMetaKeywords,
        this.hotelMetaDesc,
        this.hotelAmenities,
        this.hotelPopularAminities,
        this.hotelPopularAminitiesText,
        this.hotelPopularRoomAmenities,
        this.hotelPaymentOpt,
        this.hotelAdults,
        this.hotelChildren,
        this.hotelCheckIn,
        this.hotelCheckOut,
        this.hotelPolicy,
        this.hotelStatus,
        this.hotelOrder,
        this.hotelRelated,
        this.hotelCommFixed,
        this.hotelCommPercentage,
        this.hotelTaxFixed,
        this.hotelTaxPercentage,
        this.hotelEmail,
        this.hotelPhone,
        this.hotelWebsite,
        this.hotelFeaturedForever,
        this.hotelTrusted,
        this.hotelRefundable,
        this.hotelBestPrice,
        this.hotelArrivalpay,
        this.tripadvisorId,
        this.thumbnailImage,
        this.module,
        this.hotelCreatedAt,
        this.hotelAddress,
        this.hotelAirportDistance,
        this.hotelCityCenterDistance,
        this.hotelBeachDistance,
        this.hotelPortDistance,
        this.hotelAreainfo,
        this.hotelRestaurant,
        this.hotelCancelationTime,
        this.hotelAdminComment,
        this.hotelSpecialfeatures,
        this.hotelLogo,
        this.hotelFinePrint,
        this.hotelAirportPickup,
        this.hotelBreakfastCharge,
        this.hotelVideoLink,
        this.hotelHostedBy,
        this.hotelFoodDiscount,
        this.hotelFunThing,
        this.roomId,
        this.roomHotel,
        this.roomTitle,
        this.roomBasicPrice,
        this.roomBasicDiscount,
        this.roomDesc,
        this.roomAdults,
        this.roomChildren,
        this.roomSingleBed,
        this.roomDoubleBed,
        this.roomMinStay,
        this.roomAmenities,
        this.roomOrder,
        this.roomType,
        this.extraBed,
        this.extraBedCharges,
        this.roomAddedOn,
        this.roomQuantity,
        this.roomStatus,
        this.roomSize,
        this.transId,
        this.transTitle,
        this.transDesc,
        this.transPolicy,
        this.metatitle,
        this.metadesc,
        this.metakeywords,
        this.itemId,
        this.transLang});

  All.fromJson(Map<String, dynamic> json) {
    hotelId = json['hotel_id'];
    hotelTitle = json['hotel_title'];
    hotelSlug = json['hotel_slug'];
    hotelDesc = json['hotel_desc'];
    hotelSurroundings = json['hotel_surroundings'];
    hotelServices = json['hotel_services'];
    hotelAdminReview = json['hotel_admin_review'];
    hotelStars = json['hotel_stars'];
    hotelRatings = json['hotel_ratings'];
    hotelIsFeatured = json['hotel_is_featured'];
    hotelFeaturedFrom = json['hotel_featured_from'];
    hotelFeaturedTo = json['hotel_featured_to'];
    hotelOwnedBy = json['hotel_owned_by'];
    hotelAgent = json['hotel_agent'];
    hotelType = json['hotel_type'];
    hotelCity = json['hotel_city'];
    hotelBasicPrice = json['hotel_basic_price'];
    hotelBasicDiscount = json['hotel_basic_discount'];
    hotelMapAddress = json['hotel_map_address'];
    hotelMapZip = json['hotel_map_zip'];
    hotelMapCity = json['hotel_map_city'];
    hotelMapCountry = json['hotel_map_country'];
    hotelLatitude = json['hotel_latitude'];
    hotelLongitude = json['hotel_longitude'];
    hotelMetaTitle = json['hotel_meta_title'];
    hotelMetaKeywords = json['hotel_meta_keywords'];
    hotelMetaDesc = json['hotel_meta_desc'];
    hotelAmenities = json['hotel_amenities'];
    hotelPopularAminities = json['hotel_popular_aminities'];
    hotelPopularAminitiesText = json['hotel_popular_aminities_text'];
    hotelPopularRoomAmenities = json['hotel_popular_room_amenities'];
    hotelPaymentOpt = json['hotel_payment_opt'];
    hotelAdults = json['hotel_adults'];
    hotelChildren = json['hotel_children'];
    hotelCheckIn = json['hotel_check_in'];
    hotelCheckOut = json['hotel_check_out'];
    hotelPolicy = json['hotel_policy'];
    hotelStatus = json['hotel_status'];
    hotelOrder = json['hotel_order'];
    hotelRelated = json['hotel_related'];
    hotelCommFixed = json['hotel_comm_fixed'];
    hotelCommPercentage = json['hotel_comm_percentage'];
    hotelTaxFixed = json['hotel_tax_fixed'];
    hotelTaxPercentage = json['hotel_tax_percentage'];
    hotelEmail = json['hotel_email'];
    hotelPhone = json['hotel_phone'];
    hotelWebsite = json['hotel_website'];
    hotelFeaturedForever = json['hotel_featured_forever'];
    hotelTrusted = json['hotel_trusted'];
    hotelRefundable = json['hotel_refundable'];
    hotelBestPrice = json['hotel_best_price'];
    hotelArrivalpay = json['hotel_arrivalpay'];
    tripadvisorId = json['tripadvisor_id'];
    thumbnailImage = json['thumbnail_image'];
    module = json['module'];
    hotelCreatedAt = json['hotel_created_at'];
    hotelAddress = json['hotel_address'];
    hotelAirportDistance = json['hotel_airportDistance'];
    hotelCityCenterDistance = json['hotel_cityCenterDistance'];
    hotelBeachDistance = json['hotel_beachDistance'];
    hotelPortDistance = json['hotel_portDistance'];
    hotelAreainfo = json['hotel_areainfo'];
    hotelRestaurant = json['hotel_restaurant'];
    hotelCancelationTime = json['hotel_cancelation_time'];
    hotelAdminComment = json['hotel_admin_comment'];
    hotelSpecialfeatures = json['hotel_specialfeatures'];
    hotelLogo = json['hotel_logo'];
    hotelFinePrint = json['hotel_fine_print'];
    hotelAirportPickup = json['hotel_airport_pickup'];
    hotelBreakfastCharge = json['hotel_breakfast_charge'];
    hotelVideoLink = json['hotel_video_link'];
    hotelHostedBy = json['hotel_hosted_by'];
    hotelFoodDiscount = json['hotel_food_discount'];
    hotelFunThing = json['hotel_fun_thing'];
    roomId = json['room_id'];
    roomHotel = json['room_hotel'];
    roomTitle = json['room_title'];
    roomBasicPrice = json['room_basic_price'];
    roomBasicDiscount = json['room_basic_discount'];
    roomDesc = json['room_desc'];
    roomAdults = json['room_adults'];
    roomChildren = json['room_children'];
    roomSingleBed = json['room_single_bed'];
    roomDoubleBed = json['room_double_bed'];
    roomMinStay = json['room_min_stay'];
    roomAmenities = json['room_amenities'];
    roomOrder = json['room_order'];
    roomType = json['room_type'];
    extraBed = json['extra_bed'];
    extraBedCharges = json['extra_bed_charges'];
    roomAddedOn = json['room_added_on'];
    roomQuantity = json['room_quantity'];
    roomStatus = json['room_status'];
    roomSize = json['room_size'];
    transId = json['trans_id'];
    transTitle = json['trans_title'];
    transDesc = json['trans_desc'];
    transPolicy = json['trans_policy'];
    metatitle = json['metatitle'];
    metadesc = json['metadesc'];
    metakeywords = json['metakeywords'];
    itemId = json['item_id'];
    transLang = json['trans_lang'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['hotel_id'] = this.hotelId;
    data['hotel_title'] = this.hotelTitle;
    data['hotel_slug'] = this.hotelSlug;
    data['hotel_desc'] = this.hotelDesc;
    data['hotel_surroundings'] = this.hotelSurroundings;
    data['hotel_services'] = this.hotelServices;
    data['hotel_admin_review'] = this.hotelAdminReview;
    data['hotel_stars'] = this.hotelStars;
    data['hotel_ratings'] = this.hotelRatings;
    data['hotel_is_featured'] = this.hotelIsFeatured;
    data['hotel_featured_from'] = this.hotelFeaturedFrom;
    data['hotel_featured_to'] = this.hotelFeaturedTo;
    data['hotel_owned_by'] = this.hotelOwnedBy;
    data['hotel_agent'] = this.hotelAgent;
    data['hotel_type'] = this.hotelType;
    data['hotel_city'] = this.hotelCity;
    data['hotel_basic_price'] = this.hotelBasicPrice;
    data['hotel_basic_discount'] = this.hotelBasicDiscount;
    data['hotel_map_address'] = this.hotelMapAddress;
    data['hotel_map_zip'] = this.hotelMapZip;
    data['hotel_map_city'] = this.hotelMapCity;
    data['hotel_map_country'] = this.hotelMapCountry;
    data['hotel_latitude'] = this.hotelLatitude;
    data['hotel_longitude'] = this.hotelLongitude;
    data['hotel_meta_title'] = this.hotelMetaTitle;
    data['hotel_meta_keywords'] = this.hotelMetaKeywords;
    data['hotel_meta_desc'] = this.hotelMetaDesc;
    data['hotel_amenities'] = this.hotelAmenities;
    data['hotel_popular_aminities'] = this.hotelPopularAminities;
    data['hotel_popular_aminities_text'] = this.hotelPopularAminitiesText;
    data['hotel_popular_room_amenities'] = this.hotelPopularRoomAmenities;
    data['hotel_payment_opt'] = this.hotelPaymentOpt;
    data['hotel_adults'] = this.hotelAdults;
    data['hotel_children'] = this.hotelChildren;
    data['hotel_check_in'] = this.hotelCheckIn;
    data['hotel_check_out'] = this.hotelCheckOut;
    data['hotel_policy'] = this.hotelPolicy;
    data['hotel_status'] = this.hotelStatus;
    data['hotel_order'] = this.hotelOrder;
    data['hotel_related'] = this.hotelRelated;
    data['hotel_comm_fixed'] = this.hotelCommFixed;
    data['hotel_comm_percentage'] = this.hotelCommPercentage;
    data['hotel_tax_fixed'] = this.hotelTaxFixed;
    data['hotel_tax_percentage'] = this.hotelTaxPercentage;
    data['hotel_email'] = this.hotelEmail;
    data['hotel_phone'] = this.hotelPhone;
    data['hotel_website'] = this.hotelWebsite;
    data['hotel_featured_forever'] = this.hotelFeaturedForever;
    data['hotel_trusted'] = this.hotelTrusted;
    data['hotel_refundable'] = this.hotelRefundable;
    data['hotel_best_price'] = this.hotelBestPrice;
    data['hotel_arrivalpay'] = this.hotelArrivalpay;
    data['tripadvisor_id'] = this.tripadvisorId;
    data['thumbnail_image'] = this.thumbnailImage;
    data['module'] = this.module;
    data['hotel_created_at'] = this.hotelCreatedAt;
    data['hotel_address'] = this.hotelAddress;
    data['hotel_airportDistance'] = this.hotelAirportDistance;
    data['hotel_cityCenterDistance'] = this.hotelCityCenterDistance;
    data['hotel_beachDistance'] = this.hotelBeachDistance;
    data['hotel_portDistance'] = this.hotelPortDistance;
    data['hotel_areainfo'] = this.hotelAreainfo;
    data['hotel_restaurant'] = this.hotelRestaurant;
    data['hotel_cancelation_time'] = this.hotelCancelationTime;
    data['hotel_admin_comment'] = this.hotelAdminComment;
    data['hotel_specialfeatures'] = this.hotelSpecialfeatures;
    data['hotel_logo'] = this.hotelLogo;
    data['hotel_fine_print'] = this.hotelFinePrint;
    data['hotel_airport_pickup'] = this.hotelAirportPickup;
    data['hotel_breakfast_charge'] = this.hotelBreakfastCharge;
    data['hotel_video_link'] = this.hotelVideoLink;
    data['hotel_hosted_by'] = this.hotelHostedBy;
    data['hotel_food_discount'] = this.hotelFoodDiscount;
    data['hotel_fun_thing'] = this.hotelFunThing;
    data['room_id'] = this.roomId;
    data['room_hotel'] = this.roomHotel;
    data['room_title'] = this.roomTitle;
    data['room_basic_price'] = this.roomBasicPrice;
    data['room_basic_discount'] = this.roomBasicDiscount;
    data['room_desc'] = this.roomDesc;
    data['room_adults'] = this.roomAdults;
    data['room_children'] = this.roomChildren;
    data['room_single_bed'] = this.roomSingleBed;
    data['room_double_bed'] = this.roomDoubleBed;
    data['room_min_stay'] = this.roomMinStay;
    data['room_amenities'] = this.roomAmenities;
    data['room_order'] = this.roomOrder;
    data['room_type'] = this.roomType;
    data['extra_bed'] = this.extraBed;
    data['extra_bed_charges'] = this.extraBedCharges;
    data['room_added_on'] = this.roomAddedOn;
    data['room_quantity'] = this.roomQuantity;
    data['room_status'] = this.roomStatus;
    data['room_size'] = this.roomSize;
    data['trans_id'] = this.transId;
    data['trans_title'] = this.transTitle;
    data['trans_desc'] = this.transDesc;
    data['trans_policy'] = this.transPolicy;
    data['metatitle'] = this.metatitle;
    data['metadesc'] = this.metadesc;
    data['metakeywords'] = this.metakeywords;
    data['item_id'] = this.itemId;
    data['trans_lang'] = this.transLang;
    return data;
  }
}

class Error {
  bool status;
  String msg;

  Error({this.status, this.msg});

  Error.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    msg = json['msg'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['msg'] = this.msg;
    return data;
  }
}