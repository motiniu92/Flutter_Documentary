import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:new_motel/appTheme.dart';
import 'package:new_motel/model/profile_model.dart';
import 'package:new_motel/modules/bottomTab/bottomTabScreen.dart';
import 'package:new_motel/screens/web_view_screen.dart';
import 'package:new_motel/tourBooking/tourWebView.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class TourConfirmationScreen extends StatefulWidget {
  final String url;
  final String type;

  const TourConfirmationScreen({Key key, this.url, this.type})
      : super(key: key);

  @override
  _TourConfirmationScreenState createState() =>
      _TourConfirmationScreenState();
}

class _TourConfirmationScreenState extends State<TourConfirmationScreen> {
  String name;
  String lastName;
  String email;

  Future loadToken() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    name = prefs.getString("firstName");
    lastName = prefs.getString("lastName");
    email = prefs.getString("email");
    setState(() {});
  }

  // Future<ProfileData> getProfile() async {
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   String token = prefs.getString('apiToken');
  //   String id = prefs.getString('id');
  //   String url = "https://deshitour.com/api/login/profile?appKey=DeshiTour";
  //   print("Profile..>>>>$url");
  //
  //   Map<String, String> requestHeaders = {
  //     'Content-type': 'application/json',
  //     'Accept': 'application/json',
  //     'authorization': token
  //   };
  //   // String _token = await loadToken();
  //   print("PRofileTOken.. $token");
  //   print("Profile..>>>>$id");
  //   var response = await http.get(url, headers: requestHeaders);
  //   print('API ${response.statusCode}\n API${json.decode(response.body)}');
  //
  //   if (response.statusCode == 200) {
  //     // setState(() {
  //     //
  //     // });
  //     return ProfileData.fromJson(json.decode(response.body));
  //   } else {
  //     throw Exception(FAILED_MASSAGE);
  //   }
  // }
  //
  // Future<ProfileData> futureProfileData;

  @override
  void initState() {
    super.initState();
    loadToken();
    // FIRSTNAME = ;
    // EMAIL = user["email"];
    // LASTNAME = user["phone"];
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Scaffold(
        // backgroundColor: AppTheme.getTheme().backgroundColor,
        appBar: AppBar(
          title: RichText(
            text: TextSpan(
                text: DESHI,
                style: TextStyle(
                  fontSize: 30,
                  fontFamily: 'Impact',
                  color: HexColor("#26408A"),
                ),
                children: <TextSpan>[
                  TextSpan(
                      text: TOUR,
                      style: TextStyle(
                        fontSize: 30,
                        fontFamily: 'Impact',
                        color: HexColor("#118ACB"),
                      )),
                ]),
          ),
          backgroundColor: Colors.white,
          elevation: 1,
          leading: IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.black,
              ),
              onPressed: () {
                Navigator.pop(context);
                // Navigator.push(
                //     context,
                //     MaterialPageRoute(
                //         builder: (context) => ProfileScreen()));
              }),
        ),



        body: Container(

          // Right symbol
          child: Column(
            children: [
              SizedBox(
                height: 40,
              ),
              Image.asset(
                "assets/images/ccccc.jpg",
                height: 100,
                width: 100,
              ),


              // Confirmed Fields
              Container(
                alignment: Alignment.center,
                width: MediaQuery.of(context).size.width,
                height: 48,
                child: Text(
                  "Confirmed !",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ),



              Container(
               // width: MediaQuery.of(context).size.width,
               // height: MediaQuery.of(context).size.height,
                child: Column(

                  children: [

                    SizedBox(
                      height: 12,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 22.0, right: 18),
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        child: Row(
                          children: [
                            Text(
                              'Thanks',
                              style: TextStyle(
                                  fontSize: 20, fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              "$name",
                              style: TextStyle(
                                fontSize: 16,
                              ),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              "$lastName",
                              style: TextStyle(
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 12,
                    ),
                    Padding(
                      padding:
                      const EdgeInsets.only(left: 22.0, right: 12, top: 4),
                      child: Container(
                        alignment: Alignment.centerLeft,
                        width: MediaQuery.of(context).size.width,
                        height: 30,
                        child: Text(
                          "Your booking is now confirmed",
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 22.0, right: 12, top: 0.0),
                      child: Container(
                        alignment: Alignment.centerLeft,
                        width: MediaQuery.of(context).size.width,
                        height: 30,
                        child: Text(
                          "We sent your confirmation email to",
                          style: TextStyle(fontSize: 20),
                        ),
                      ),
                    ),

                    Padding(
                      padding: const EdgeInsets.only(
                          left: 22.0, right: 12, top: 0.0),
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        child: Row(
                          children: [
                            Text(
                              "$email",
                              style: TextStyle(
                                  fontSize: 19, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      ),
                    ),

                    SizedBox(
                      height: 50,
                    ),
                    // Button View Confirmation
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 22.0, right: 24.0, bottom: 14.0, top: 6.0),
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        height: 48,
                        decoration: BoxDecoration(
                          color: HexColor("#1d8bcb"),
                          borderRadius: BorderRadius.all(Radius.circular(5.0)),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: AppTheme.getTheme().dividerColor,
                              blurRadius: 8,
                              offset: Offset(4, 4),
                            ),
                          ],
                        ),
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            borderRadius: BorderRadius.all(Radius.circular(24.0)),
                            highlightColor: Colors.transparent,
                            onTap: () {
                              Navigator.of(context).pop();
                              // changeBookingDate(response1[index].id, response1[index], end_date);
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => TourWebView(
                                          title: "", selectedUrl: widget.url)));
                            },
                            child: Center(
                              child: Text(
                                VIEW_CONFIRMATION,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16,
                                    color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 22.0, right: 24.0, bottom: 18, top: 6),
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        height: 48,
                        decoration: BoxDecoration(
                          color: HexColor("#26408A"),
                          borderRadius: BorderRadius.all(Radius.circular(5.0)),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: AppTheme.getTheme().dividerColor,
                              blurRadius: 8,
                              offset: Offset(4, 4),
                            ),
                          ],
                        ),
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            borderRadius: BorderRadius.all(Radius.circular(24.0)),
                            highlightColor: Colors.transparent,
                            onTap: () {
                              Navigator.of(context).pop();
                              // changeBookingDate(response1[index].id, response1[index], end_date);
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => BottomTabScreen()));
                            },
                            child: Center(
                              child: Text(
                                'Back To Home',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16,
                                    color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              // FutureBuilder<ProfileData>(
              //   future: futureProfileData,
              //   builder: (BuildContext context,
              //       AsyncSnapshot<ProfileData> snapshot) {
              //     if (snapshot.hasData) {
              //       return
              //
              //
              //     } else {
              //       return Center(
              //         child: CircularProgressIndicator(),
              //       );
              //     }
              //   },
              // ),

            ],
          ),
        ),




      ),
    );
  }
}
