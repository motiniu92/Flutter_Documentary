import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_connect/http/src/response/response.dart';
import 'package:new_motel/models/tour/tourTypes.dart';
import 'package:http/http.dart' as http;

class TourTypesScreen extends StatefulWidget {

  @override
  _TourTypesScreenState createState() => _TourTypesScreenState();
}

class _TourTypesScreenState extends State<TourTypesScreen> {
  List<ResponseTours> responseTour;
  ResponseTours _responseTours;
  var response;

  Future<String> getJSONData() async {

    var response = await http.get("https://deshitour.com/api/tours/tourtypes?appKey=DeshiTour");
    setState(() {

      responseTour = TourTypes.fromJson(json.decode(response.body)).responseTours;

      // Get the JSON data

      // hotelList=homeData.response;
      print("data Tour Types .... ${responseTour.length}");
    });
    return "value";
  }






  @override
  void initState() {
    // TODO: implement initState
    getJSONData();
    super.initState();


  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
          child: ListView.builder(
            itemCount: responseTour.length,
              itemBuilder: (context, index){
              return Text(responseTour[index].name);
              }),
          ),
        );

  }
}
