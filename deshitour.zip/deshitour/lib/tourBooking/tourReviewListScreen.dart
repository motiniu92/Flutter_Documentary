import 'package:flutter/material.dart';
import 'package:new_motel/models/tour/toursDetails.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';

import '../appTheme.dart';

class TourReviewListScreen extends StatefulWidget {
  final AnimationController animationController;
  final List<TourReviews>tourReviewList;
  const TourReviewListScreen(
      {Key key,  this.animationController,  @required this.tourReviewList})
      : super(key: key);


  @override
  _TourReviewListScreenState createState() => _TourReviewListScreenState();
}

class _TourReviewListScreenState extends State<TourReviewListScreen>
    with TickerProviderStateMixin {
  List<TourReviews> reviewsList ;
  //var reviewsList;
  AnimationController animationController;

  @override
  void initState() {
    animationController = AnimationController(
        duration: Duration(milliseconds: 2000), vsync: this);
    super.initState();
  }

  @override
  void dispose() {
    animationController.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    reviewsList=widget.tourReviewList;

    return Scaffold(
      backgroundColor: AppTheme.getTheme().backgroundColor,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          // Padding(
          //   padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
          //   child: Container(child: appBar()),
          // ),
          Expanded(
            child: ListView.builder(
              shrinkWrap: false,
              physics: BouncingScrollPhysics(),
              padding: EdgeInsets.only(
                  top: 8, bottom: MediaQuery.of(context).padding.bottom + 8),
              itemCount: reviewsList.length,
              itemBuilder: (context, index) {
                var count = reviewsList.length > 10 ? 10 : reviewsList.length;
                var animation = Tween(begin: 0.0, end: 1.0).animate(
                    CurvedAnimation(
                        parent: animationController,
                        curve: Interval((1 / count) * index, 1.0,
                            curve: Curves.fastOutSlowIn)));
                animationController.forward();
                return TourReviewsView(
                  callback: () {},
                  reviews: reviewsList[index],
                  animation: animation,
                  animationController: animationController,
                );


              },
            ),
          ),
        ],
      ),
    );
  }

  Widget appBar() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SizedBox(
          height: AppBar().preferredSize.height,
          child: Padding(
            padding: EdgeInsets.only(top: 8, left: 8),
            child: Container(
              width: AppBar().preferredSize.height - 8,
              height: AppBar().preferredSize.height - 8,
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.all(
                    Radius.circular(32.0),
                  ),
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Icon(Icons.close),
                  ),
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 4, left: 24),
          child: Text(
            "Reviews (20)",
            style: new TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    );
  }
}

class TourReviewsView extends StatelessWidget {

  final VoidCallback callback;
  final TourReviews reviews;
  final AnimationController animationController;
  final Animation animation;

  const TourReviewsView({
    Key key,
    @required this.reviews,
    this.animationController,
    this.animation,
    this.callback,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    String name=reviews.reviewBy;
    // if(reviews.reviewName!=null){
    //   name=reviews.reviewName;
    // }else{
    //   name=tourReviews.reviewBy;
    // }
    return AnimatedBuilder(
      animation: animationController,
      builder: (BuildContext context, Widget child) {
        return FadeTransition(
          opacity: animation,
          child: new Transform(
            transform: new Matrix4.translationValues(
                0.0, 40 * (1.0 - animation.value), 0.0),
            child: Padding(
              padding: const EdgeInsets.only(left: 24, right: 24, top: 16),
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          width: 48,
                          decoration: BoxDecoration(
                            color: AppTheme.getTheme().primaryColor,
                            borderRadius:
                            BorderRadius.all(Radius.circular(25.0)),
                            boxShadow: <BoxShadow>[
                              BoxShadow(
                                color: AppTheme.getTheme().dividerColor,
                                blurRadius: 8,
                                offset: Offset(4, 4),
                              ),
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius:
                            BorderRadius.all(Radius.circular(18.0)),
                            child: AspectRatio(
                              aspectRatio: 1,
                              child: Align(
                                alignment: Alignment.center, // Align however you like (i.e .centerRight, centerLeft)
                                child:
                                // Text((() {
                                //   if(reviews!=null){
                                //     return '${reviews.reviewName[0].toUpperCase()}';}
                                //
                                //   return '${tourReviews.reviewBy[0].toUpperCase()}';
                                // })())

                                Text('${name[0].toUpperCase()}',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          // Text((() {
                          //   if(reviews!=null){
                          //     return '${reviews.reviewName}';}
                          //
                          //   return '${tourReviews.reviewBy}';
                          // })()),
                          Text(
                            reviews.reviewBy,
                            style: new TextStyle(fontWeight: FontWeight.w600),
                          ),
                          Text(
                            "${REVIEWED} : "+reviews.reviewDate,
                            style: new TextStyle(
                              fontWeight: FontWeight.bold,
                              color: AppTheme.getTheme().disabledColor,
                            ),
                          ),
                          Row(
                            children: <Widget>[
                              Text(
                                "(${reviews.rating??"0"})",
                                style: new TextStyle(
                                  fontWeight: FontWeight.w100,
                                ),
                              ),
                              SmoothStarRating(
                                allowHalfRating: true,
                                starCount: 5,
                                rating: double.parse( reviews.rating),
                                size: 16,
                                isReadOnly: true,
                                color: AppTheme.getTheme().primaryColor,
                                borderColor: AppTheme.getTheme().primaryColor,
                              ),
                            ],
                          ),
                        ],
                      )
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      reviews.reviewComment,
                      textAlign: TextAlign.justify,
                      style: new TextStyle(
                        fontWeight: FontWeight.w200,
                        color: kPrimaryDarkenColor,
                      ),
                    ),
                  ),
                  // Row(
                  //   crossAxisAlignment: CrossAxisAlignment.center,
                  //   mainAxisAlignment: MainAxisAlignment.end,
                  //   children: <Widget>[
                  //     Material(
                  //       color: Colors.transparent,
                  //       child: InkWell(
                  //         borderRadius: BorderRadius.all(Radius.circular(4.0)),
                  //         onTap: () {},
                  //         child: Padding(
                  //           padding: const EdgeInsets.only(left: 8),
                  //           child: Row(
                  //             children: <Widget>[
                  //               Text(
                  //                 'Reply',
                  //                 textAlign: TextAlign.left,
                  //                 style: TextStyle(
                  //                   fontWeight: FontWeight.w600,
                  //                   fontSize: 14,
                  //                   color: AppTheme.getTheme().primaryColor,
                  //                 ),
                  //               ),
                  //               SizedBox(
                  //                 height: 38,
                  //                 width: 26,
                  //                 child: Icon(
                  //                   Icons.arrow_forward,
                  //                   size: 14,
                  //                   color: AppTheme.getTheme().primaryColor,
                  //                 ),
                  //               ),
                  //             ],
                  //           ),
                  //         ),
                  //       ),
                  //     ),
                  //   ],
                  // ),
                  Divider(
                    height: 1,
                  )
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

