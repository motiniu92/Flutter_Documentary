import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:new_motel/models/tour/tourCountryModel.dart';
import 'package:new_motel/models/tour/tourTypes.dart';
import 'package:http/http.dart' as http;

class TourCountryFilterScreen extends StatefulWidget {

  @override
  _TourCountryFilterScreenState createState() => _TourCountryFilterScreenState();
}

class _TourCountryFilterScreenState extends State<TourCountryFilterScreen> {
  List<ResponseCountry> responseCountry;
  var response;

  Future<String> getJSONData() async {

    var response = await http.get("https://deshitour.com/api/tours/tourtcountry?appKey=DeshiTour");
    setState(() {

      responseCountry = TourCountryFilter.fromJson(json.decode(response.body)).responseCountry;

      // Get the JSON data

      // hotelList=homeData.response;
      print("data Tour Country Length.... ${responseCountry.length}");
    });
    return "value";
  }






  @override
  void initState() {
    // TODO: implement initState
    getJSONData();
    super.initState();


  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: ListView.builder(
            itemCount: responseCountry.length,
            itemBuilder: (context, index){
              return Text(responseCountry[index].tourCountry);
            }),
      ),
    );

  }
}
