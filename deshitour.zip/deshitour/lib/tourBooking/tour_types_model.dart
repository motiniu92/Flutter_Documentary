class TourTypeFilter {
  List<TourTypeResponse> response;
  Error error;

  TourTypeFilter({this.response, this.error});

  TourTypeFilter.fromJson(Map<String, dynamic> json) {
    if (json['response'] != null) {
      response = new List<TourTypeResponse>();
      json['response'].forEach((v) {
        response.add(new TourTypeResponse.fromJson(v));
      });
    }
    error = json['error'] != null ? new Error.fromJson(json['error']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.response != null) {
      data['response'] = this.response.map((v) => v.toJson()).toList();
    }
    if (this.error != null) {
      data['error'] = this.error.toJson();
    }
    return data;
  }
}

class TourTypeResponse {
  String id;
  String name;
  bool _isSelect = false;
  bool get isSelect => _isSelect;
  set isSelected(bool isSelect) {
    _isSelect = isSelect;
  }

  TourTypeResponse({this.id, this.name});

  TourTypeResponse.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

class Error {
  bool status;
  String msg;

  Error({this.status, this.msg});

  Error.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    msg = json['msg'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['msg'] = this.msg;
    return data;
  }
}
