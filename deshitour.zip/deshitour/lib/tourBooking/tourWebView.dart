import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:new_motel/modules/bottomTab/bottomTabScreen.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../appTheme.dart';

class TourWebView extends StatefulWidget {
  final String title;
  final String selectedUrl;

  TourWebView({
    @required this.title,
    @required this.selectedUrl,
  });

  @override
  _TourWebViewState createState() => _TourWebViewState();
}

class _TourWebViewState extends State<TourWebView> {
  final Completer<WebViewController> _controller =
      Completer<WebViewController>();
  bool isLoading = false;
  InAppWebViewController _webViewController;
  @override
  Widget build(BuildContext context) {
    print("${widget.selectedUrl}");
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: RichText(
          text: TextSpan(
              text: DESHI,
              style: TextStyle(
                fontSize: 30,
                fontFamily: 'Impact',
                color: HexColor("#26408A"),
              ),
              children: <TextSpan>[
                TextSpan(
                    text: TOUR,
                    style: TextStyle(
                      fontSize: 30,
                      fontFamily: 'Impact',
                      color: HexColor("#118ACB"),
                    )),
              ]),
        ),
        backgroundColor: Colors.white,
        elevation: 1,
        leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.black,
            ),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => BottomTabScreen()));
            }),
      ),
      body: InAppWebView(
          initialUrl: widget.selectedUrl,
          initialOptions: InAppWebViewGroupOptions(
            crossPlatform: InAppWebViewOptions(
              mediaPlaybackRequiresUserGesture: false,
              debuggingEnabled: true,
            ),
          ),
          onWebViewCreated: (InAppWebViewController controller) {
            _webViewController = controller;
          },
          androidOnPermissionRequest: (InAppWebViewController controller,
              String origin, List<String> resources) async {
            return PermissionRequestResponse(
                resources: resources,
                action: PermissionRequestResponseAction.GRANT);
          }),
    );
  }
}
