import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:new_motel/models/hotelAmenities/starCount.dart';
import 'package:new_motel/models/popularFilterList.dart';
import 'package:new_motel/tourBooking/tour_coyntry_model.dart';
import 'package:new_motel/tourBooking/tour_types_model.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';

import '../appTheme.dart';
import '../loaderPage.dart';

class FiltersScreenTours extends StatefulWidget {
  @override
  _FiltersScreenToursState createState() => _FiltersScreenToursState();
}

class _FiltersScreenToursState extends State<FiltersScreenTours> {
  // ProgressBar _sendingMsgProgressBar=ProgressBar();
  List<PopularFilterListData> popularFilterListData =
      PopularFilterListData.popularFList;
  List<PopularFilterListData> accomodationListData =
      PopularFilterListData.accomodationList;
  List<StarCountListData> startListData = StarCountListData.starList;

  int starCount = 0;
  List<String> selectedTourType = [];
  String star = "";
  String type = "";

  RangeValues _values = RangeValues(100, 600);
  double distValue = 50.0;
  bool loading;
  int selectedRadio;

  List<TResponse> tourResponse;
  List<TourTypeResponse> tourTypeResponse;

  Future<String> getJSONData() async {
    // showSendingProgressBar();
    loading = true;
    var response = await http
        .get("https://deshitour.com//api/tours/tourtcountry?appKey=DeshiTour");
    var response1 = await http
        .get("https://deshitour.com//api/tours/tourtypes?appKey=DeshiTour");

    setState(() {
      //hideSendingProgressBar();
      loading = false;
      tourResponse =
          TourCountryModel.fromJson(json.decode(response.body)).response;
      tourTypeResponse =
          TourTypeFilter.fromJson(json.decode(response1.body)).response;
    });
    //print(data);
    return "data";
  }

  String choice;
  String country = '';

  void radioButtonChanges(String value) {
    setState(() {
      country = value;
      switch (value) {
        case '1':
          country = value;
          break;
        case '2':
          country = value;
          break;
        case '3':
          country = value;
          break;
      }
      print("Select $choice"); //Debug the choice in console
    });
  }

  @override
  void initState() {
    getJSONData();
    // _sendingMsgProgressBar = ProgressBar();
    super.initState();
    selectedRadio = 0;
  }

  setSelectedRdio(val) {
    setState(() {
      selectedRadio = val;
      star = "${selectedRadio}";
    });
  }

  @override
  Widget build(BuildContext context) {
    // filterData=FilterData(star: starCount, isSearch: 0);
    return Container(
      color: AppTheme.getTheme().backgroundColor,
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.black,
            ),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
          backgroundColor: Colors.white,
          title: RichText(
            text: TextSpan(
                text: DESHI,
                style: TextStyle(
                  fontSize: 30,
                  fontFamily: 'Impact',
                  color: HexColor("#26408A"),
                ),
                children: <TextSpan>[
                  TextSpan(
                      text: TOUR,
                      style: TextStyle(
                        fontSize: 30,
                        fontFamily: 'Impact',
                        color: HexColor("#118ACB"),
                      )),
                ]),
          ),
        ),
        backgroundColor: Colors.transparent,
        body: loading
            ? Center(
                child: LoaderPage(
                  msg: "",
                ),
              )
            : ListView(
                shrinkWrap: true,
                primary: false,
                children: [
                  Padding(
                    padding:
                        const EdgeInsets.only(left: 18.0, top: 15, bottom: 10),
                    child: Text(
                      "Country",
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                  ListView.builder(
                      shrinkWrap: true,
                      primary: false,
                      itemCount: tourResponse.length,
                      itemBuilder: (_, index) {
                        final radioButton = tourResponse[index];
                        choice = radioButton.tourCountry;
                        print("Builder...$country");

                        return RadioListTile(
                          title: Text(tourResponse[index].tourCountry),
                          activeColor: Colors.indigo[800],
                          value: choice,
                          groupValue: country,
                          onChanged: (val) {
                            radioButtonChanges(val);
                          },
                        );
                      }),
                  Padding(
                    padding:
                        const EdgeInsets.only(left: 18.0, top: 15, bottom: 10),
                    child: Text(
                      "Star Guide",
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 11.0),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Radio(
                              value: 1,
                              groupValue: selectedRadio,
                              onChanged: (val) {
                                setSelectedRdio(val);
                              },
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: SmoothStarRating(
                                allowHalfRating: true,
                                starCount: 5,
                                rating: 1,
                                size: 20,
                                isReadOnly: true,
                                color: Colors.amberAccent,
                                borderColor: Colors.amberAccent,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Radio(
                              value: 2,
                              groupValue: selectedRadio,
                              onChanged: (val) {
                                setSelectedRdio(val);
                              },
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: SmoothStarRating(
                                allowHalfRating: true,
                                starCount: 5,
                                rating: 2,
                                size: 20,
                                isReadOnly: true,
                                color: Colors.amberAccent,
                                borderColor: Colors.amberAccent,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Radio(
                              value: 3,
                              groupValue: selectedRadio,
                              onChanged: (val) {
                                setSelectedRdio(val);
                              },
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: SmoothStarRating(
                                allowHalfRating: true,
                                starCount: 5,
                                rating: 3,
                                size: 20,
                                isReadOnly: true,
                                color: Colors.amberAccent,
                                borderColor: Colors.amberAccent,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Radio(
                              value: 4,
                              groupValue: selectedRadio,
                              onChanged: (val) {
                                setSelectedRdio(val);
                              },
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: SmoothStarRating(
                                allowHalfRating: true,
                                starCount: 5,
                                rating: 4,
                                size: 20,
                                isReadOnly: true,
                                color: Colors.amberAccent,
                                borderColor: Colors.amberAccent,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Radio(
                              value: 5,
                              groupValue: selectedRadio,
                              onChanged: (val) {
                                setSelectedRdio(val);
                              },
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: SmoothStarRating(
                                allowHalfRating: true,
                                starCount: 5,
                                rating: 5,
                                size: 20,
                                isReadOnly: true,
                                color: Colors.amberAccent,
                                borderColor: Colors.amberAccent,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  tourCountryFilter(),
                  Padding(
                    padding: EdgeInsets.only(
                        left: 16,
                        right: 16,
                        bottom: 16 + MediaQuery.of(context).padding.bottom,
                        top: 8),
                    child: Container(
                      height: 48,
                      decoration: BoxDecoration(
                        color: AppTheme.getTheme().primaryColor,
                        borderRadius: BorderRadius.all(Radius.circular(24.0)),
                        boxShadow: <BoxShadow>[
                          BoxShadow(
                            color: AppTheme.getTheme().dividerColor,
                            blurRadius: 8,
                            offset: Offset(4, 4),
                          ),
                        ],
                      ),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          borderRadius: BorderRadius.all(Radius.circular(24.0)),
                          highlightColor: Colors.transparent,
                          onTap: () {
                            for (String tourType in selectedTourType) {
                              if (type == "") {
                                type = tourType;
                              } else {
                                type = type + "," + tourType;
                              }
                            }
                            print("Types: $type");

                            Map<String, dynamic> yourMap = {
                              "star": star,
                              "type": type,
                              "country": country,
                            };

                            Navigator.pop(context, yourMap);

                            // Navigator.pop(context,filterData );
                            // Navigator.push(context, MaterialPageRoute(builder: (context)=> TourListScreen()));
                          },
                          child: Center(
                            child: Text(
                              APPLY,
                              style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 18,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              ),
      ),
    );
  }

  // Method PopularFilter Implimenting
  Widget tourCountryFilter() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SizedBox(
          height: 8,
        ),
        Divider(
          height: 1,
        ),
        // Padding(
        //   padding: const EdgeInsets.only(
        //       left: 18.0, right: 8.0, top: 8.0, bottom: 8),
        //   child: Text(
        //     "Star grade",
        //     textAlign: TextAlign.left,
        //     style: TextStyle(
        //         color: Colors.black,
        //         fontSize: MediaQuery.of(context).size.width > 360 ? 18 : 18,
        //         fontWeight: FontWeight.w500),
        //   ),
        // ),
        // SizedBox(
        //   height: 8,
        // ),
        // Padding(
        //   padding: const EdgeInsets.fromLTRB(8.0, 0, 0, 8.0),
        //   child: Column(
        //     children: getStarList(),
        //   ),
        // ),
        Divider(
          height: 1,
        ),
        SizedBox(
          height: 8,
        ),
        Padding(
          padding:
              const EdgeInsets.only(left: 18.0, right: 8.0, top: 16, bottom: 8),
          child: Text(
            "Tour Types",
            textAlign: TextAlign.left,
            style: TextStyle(
                color: Colors.black,
                fontSize: MediaQuery.of(context).size.width > 360 ? 18 : 18,
                fontWeight: FontWeight.w500),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(8.0, 0, 0, 8.0),
          child: Column(
            children: getTourTypesList(),
          ),
        ),
        SizedBox(
          height: 8,
        )
      ],
    );
  }

  // tour Type .... Business Logic

  bool isTourTypeAdded(String id) {
    bool isExist = false;
    for (String tId in selectedTourType) {
      if (tId == id) {
        isExist = true;
        break;
      }
    }
    return isExist;
  }

  // Method getCountryList Implimenting
  // List<Widget> getCountryList() {
  //   var len;
  //   List<Widget> noList = List<Widget>();
  //   var cout = 0;
  //   final columCount = 1;
  //   if (tourResponse != null) {
  //     //hideSendingProgressBar();
  //     len = tourResponse.length;
  //   } else {
  //     // hideSendingProgressBar();
  //     len = 0;
  //   }
  //   for (var i = 0; i < len; i++) {
  //     List<Widget> listUI = List<Widget>();
  //     for (var i = 0; i < columCount; i++) {
  //       try {
  //         final date = tourResponse[cout];
  //         listUI.add(Expanded(
  //           child: Row(
  //             children: <Widget>[
  //               Material(
  //                 color: Colors.transparent,
  //                 child: InkWell(
  //                   borderRadius: BorderRadius.all(Radius.circular(4.0)),
  //                   onTap: () {
  //                     setState(() {
  //                       date.isSelected = !date.isSelect;
  //                       if (isTourCountryAdded(date.tourCountry)) {
  //                         selectedCountry.remove(date.tourCountry);
  //                       } else {
  //                         selectedCountry.add(date.tourCountry);
  //                       }
  //                     });
  //                   },
  //                   child: Padding(
  //                     padding: const EdgeInsets.all(2.0),
  //                     child: Row(
  //                       children: <Widget>[
  //                         Icon(
  //                           date.isSelect
  //                               ? Icons.check_circle
  //                               : Icons.radio_button_off,
  //                           color: date.isSelect
  //                               ? AppTheme.getTheme().primaryColor
  //                               : Colors.grey.withOpacity(0.6),
  //                         ),
  //                         SizedBox(
  //                           width: 4,
  //                         ),
  //                         Text(
  //                           date.tourCountry,
  //                         ),
  //                       ],
  //                     ),
  //                   ),
  //                 ),
  //               ),
  //             ],
  //           ),
  //         ));
  //         cout += 1;
  //       } catch (e) {
  //         print(e);
  //       }
  //     }
  //     noList.add(Row(
  //       mainAxisAlignment: MainAxisAlignment.center,
  //       crossAxisAlignment: CrossAxisAlignment.center,
  //       mainAxisSize: MainAxisSize.min,
  //       children: listUI,
  //     ));
  //   }
  //   return noList;
  // }

  // // getStarList Method Implimenting
  // List<Widget> getStarList() {
  //   List<Widget> noList = List<Widget>();
  //   var cout = 0;
  //   final columCount = 1;
  //   for (var i = 0; i < startListData.length; i++) {
  //     List<Widget> listUI = List<Widget>();
  //     for (var i = 0; i < columCount; i++) {
  //       try {
  //         final date = startListData[cout];
  //         int _selectedIndex = 0;
  //         int _value2 = 0;
  //         listUI.add(Expanded(
  //           child: Row(
  //             children: <Widget>[
  //               Material(
  //                 color: Colors.transparent,
  //                 child: InkWell(
  //                   borderRadius: BorderRadius.all(Radius.circular(4.0)),
  //                   onTap: () {
  //                     setState(() {
  //                       date.isSelected = !date.isSelected;
  //                       starCount = int.parse(date.starCount);
  //                       if (isTourCountryAdded(date.starCount)) {
  //                         selectedStar.remove(date.starCount);
  //                       } else {
  //                         selectedStar.add(date.starCount);
  //                       }
  //                     });
  //                   },
  //                   child: Padding(
  //                     padding: const EdgeInsets.only(left: 1.0),
  //                     child: Row(
  //                       children: <Widget>[
  //                         Radio(
  //                           value: _value2,
  //                           groupValue: _selectedIndex,
  //                           onChanged: (val) {
  //                             setState(() {
  //                               _value2 = val;
  //                             });
  //                           },
  //                         ),
  //                         SizedBox(
  //                           width: 4,
  //                         ),
  //                         Padding(
  //                           padding: const EdgeInsets.all(8.0),
  //                           child: SmoothStarRating(
  //                             allowHalfRating: true,
  //                             starCount: 5,
  //                             rating: double.parse(date.starCount ?? 0),
  //                             size: 20,
  //                             isReadOnly: true,
  //                             color: Colors.amberAccent,
  //                             borderColor: Colors.amberAccent,
  //                           ),
  //                         ),
  //                       ],
  //                     ),
  //                   ),
  //                 ),
  //               ),
  //             ],
  //           ),
  //         ));
  //         cout += 1;
  //       } catch (e) {
  //         print(e);
  //       }
  //     }
  //     noList.add(Row(
  //       mainAxisAlignment: MainAxisAlignment.center,
  //       crossAxisAlignment: CrossAxisAlignment.center,
  //       mainAxisSize: MainAxisSize.min,
  //       children: listUI,
  //     ));
  //   }
  //   return noList;
  // }

  // Method getTourTypeList Implimenting
  List<Widget> getTourTypesList() {
    List<Widget> noList = List<Widget>();
    var len;
    if (tourTypeResponse != null) {
      len = tourTypeResponse.length;
    } else {
      len = 0;
    }

    var cout = 0;
    final columCount = 2;
    for (var i = 0; i < len / columCount; i++) {
      List<Widget> listUI = List<Widget>();
      for (var i = 0; i < columCount; i++) {
        try {
          final date = tourTypeResponse[cout];
          listUI.add(Expanded(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.all(4.0),
              child: Row(
                children: <Widget>[
                  Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.all(Radius.circular(4.0)),
                      onTap: () {
                        setState(() {
                          date.isSelected = !date.isSelect;
                          if (isTourTypeAdded(date.id)) {
                            selectedTourType.remove(date.id);
                          } else {
                            selectedTourType.add(date.id);
                          }
                        });
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(left: 12.0),
                        child: Row(
                          children: <Widget>[
                            Icon(
                              date.isSelect
                                  ? Icons.check_circle
                                  : Icons.check_box_outline_blank,
                              color: date.isSelect
                                  ? AppTheme.getTheme().primaryColor
                                  : Colors.grey.withOpacity(0.6),
                            ),
                            SizedBox(
                              width: 0,
                            ),
                            Padding(
                                padding: EdgeInsets.all(0),
                                child: Text(
                                  date.name,
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.black,
                                  ),
                                )),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ));
          cout += 1;
        } catch (e) {
          print(e);
        }
      }
      noList.add(Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: listUI,
      ));
    }
    return noList;
  }

// Method AppBar Implements
// Widget appBar() {
//   return Row(
//     children: <Widget>[
//       Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: <Widget>[
//           SizedBox(
//             height: AppBar().preferredSize.height,
//             child: Padding(
//               padding: EdgeInsets.only(top: 8, left: 8),
//               child: Container(
//                 width: AppBar().preferredSize.height - 8,
//                 height: AppBar().preferredSize.height - 8,
//                 child: Material(
//                   color: Colors.transparent,
//                   child: InkWell(
//                     borderRadius: BorderRadius.all(
//                       Radius.circular(32.0),
//                     ),
//                     onTap: () {
//                       Navigator.pop(context);
//                     },
//                     child: Padding(
//                       padding: const EdgeInsets.all(8.0),
//                       child: Icon(Icons.close),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//           ),
//           Padding(
//             padding: const EdgeInsets.only(top: 4, left: 24, bottom: 16),
//             child: Text(
//               "Filters",
//               style: new TextStyle(
//                 fontSize: 22,
//                 fontWeight: FontWeight.w700,
//               ),
//             ),
//           ),
//         ],
//       ),
//     ],
//   );
// }
}

class FilterData {
  int star;
  int isSearch;
  FilterData({this.star, this.isSearch});
}
