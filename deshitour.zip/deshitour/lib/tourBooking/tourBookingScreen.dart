import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:new_motel/authenticating/login.dart';
import 'package:new_motel/models/tour/toursDetails.dart';
import 'package:new_motel/modules/bottomTab/bottomTabScreen.dart';
import 'package:new_motel/tourBooking/tour_details_screen.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';

import '../appTheme.dart';

class TourBookingScreen extends StatefulWidget {
  final String hotelName;
  final Tour tour;

  const TourBookingScreen({Key key, this.hotelName, @required this.tour})
      : super(key: key);

  @override
  _RoomBookingScreenState createState() => _RoomBookingScreenState();
}

class _RoomBookingScreenState extends State<TourBookingScreen>
    with TickerProviderStateMixin {
  List<Tour> romeList;
  AnimationController animationController;

  @override
  void initState() {
    animationController = AnimationController(
        duration: Duration(milliseconds: 2000), vsync: this);
    super.initState();
  }

  @override
  void dispose() {
    animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    romeList = List();
    romeList.add(widget.tour);
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            widget.hotelName,
            style: TextStyle(fontSize: 19, color: Colors.black),
          ),
          leading: IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.black,
              ),
              onPressed: () {
                Navigator.pop(context);
                // Navigator.push(
                //     context,
                //     MaterialPageRoute(
                //         builder: (context) => ProfileScreen()));
              }),
          backgroundColor: Colors.white,
          elevation: 1,
        ),
        backgroundColor: AppTheme.getTheme().backgroundColor,
        body: Column(
          children: <Widget>[
            Expanded(
              child: ListView.builder(
                padding: EdgeInsets.all(0.0),
                itemCount: romeList.length,
                itemBuilder: (context, index) {
                  var count = romeList.length > 10 ? 10 : romeList.length;
                  var animation = Tween(begin: 0.0, end: 1.0).animate(
                      CurvedAnimation(
                          parent: animationController,
                          curve: Interval((1 / count) * index, 1.0,
                              curve: Curves.fastOutSlowIn)));
                  animationController.forward();
                  return RoomeBookView(
                    roomData: romeList[index],
                    roomCountCallback:
                        (String room_name, String adultPrice, int roomCount) {
                      setState(() {});
                    },
                    hotelName: widget.hotelName,
                    animation: animation,
                    animationController: animationController,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Widget getAppBarUI() {
  //   return Container(
  //     decoration: BoxDecoration(
  //       color: AppTheme.getTheme().backgroundColor,
  //       boxShadow: <BoxShadow>[
  //         BoxShadow(
  //             color: AppTheme.getTheme().dividerColor,
  //             offset: Offset(0, 2),
  //             blurRadius: 8.0),
  //       ],
  //     ),
  //     child: Padding(
  //       padding: EdgeInsets.only(
  //           top: MediaQuery.of(context).padding.top, left: 8, right: 8),
  //       child: Row(
  //         children: <Widget>[
  //           Container(
  //             alignment: Alignment.centerLeft,
  //             width: AppBar().preferredSize.height,
  //             height: AppBar().preferredSize.height,
  //             child: Material(
  //               color: Colors.transparent,
  //               child: InkWell(
  //                 borderRadius: BorderRadius.all(
  //                   Radius.circular(32.0),
  //                 ),
  //                 onTap: () {
  //                   Navigator.pop(context);
  //                 },
  //                 child: Padding(
  //                   padding: const EdgeInsets.all(0.0),
  //                   child: Icon(Icons.arrow_back),
  //                 ),
  //               ),
  //             ),
  //           ),
  //           Expanded(
  //             child: Center(
  //               child: Text(
  //                 widget.hotelName,
  //                 style: TextStyle(
  //                   fontWeight: FontWeight.w600,
  //                   fontSize: 22,
  //                 ),
  //                 overflow: TextOverflow.ellipsis,
  //               ),
  //             ),
  //           ),
  //           // Container(
  //           //   width: AppBar().preferredSize.height,
  //           //   height: AppBar().preferredSize.height,
  //           //   child: Material(
  //           //     color: Colors.transparent,
  //           //     child: InkWell(
  //           //       borderRadius: BorderRadius.all(
  //           //         Radius.circular(32.0),
  //           //       ),
  //           //       onTap: () {
  //           //         final snackBar = SnackBar(content: Text("Tap"));
  //           //         Scaffold.of(context).showSnackBar(snackBar);
  //           //       },
  //           //       child: Padding(
  //           //         padding: const EdgeInsets.all(8.0),
  //           //         child: Icon(Icons.favorite_border),
  //           //       ),
  //           //     ),
  //           //   ),
  //           // )
  //         ],
  //       ),
  //     ),
  //   );
  // }
}

class RoomeBookView extends StatefulWidget {
  final Tour roomData;
  final AnimationController animationController;
  final Animation animation;
  final String hotelName;
  final Function(String, String, int) roomCountCallback;

  const RoomeBookView(
      {Key key,
      this.roomData,
      this.roomCountCallback,
      this.animationController,
      this.animation,
      this.hotelName})
      : super(key: key);

  @override
  _RoomeBookViewState createState() => _RoomeBookViewState();
}

class _RoomeBookViewState extends State<RoomeBookView> {
  var pageController = PageController(initialPage: 0);
  List<String> maxAvailablity;
  List<String> maxAvailablityOne;
  String facilities;
  String facilities1;
  var price1 = 0, total_room = 0;
  String bbb;
  Map<String, int> roomPriceMap = {};
  Map<String, int> roomPriceMap1 = {};
  int totalAdultPrice = 0;
  int totalchildPrice = 0;

  // int adultDropDown=0;
  // int childDropDown=0;

  // Map<String, dynamic> dropdownData;

  Tour _hotelDetailsResponse;

  ScrollController scrollController = ScrollController(initialScrollOffset: 0);
  // // final format = new DateFormat.yMMMEd('en-US');
  getDateFormate(String date) {
    DateTime parseDate = new DateFormat("yyyy-MM-dd").parse(date);
    var inputDate = DateTime.parse(parseDate.toString());
    var outputFormat = DateFormat('dd/MM/yyyy');
    var output = outputFormat.format(inputDate);
    return output;
  }

  final dateTimeController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // MyController _controller = widget.controller;
    // if (_controller != null) {
    //   _controller.myFunction = firstFunction ;
    // }
  }

  // String firstFunction(int value, String price) {
  //   var str = price;
  //   var parts = str.split(',');
  //   var prefix = parts[0].trim(); // prefix: "date"
  //   var prefix1 = parts[1].trim(); // prefix: "date"
  //   var date = prefix + prefix1;
  //
  //   setState(() {
  //     int price = int.parse(date);
  //     valueChange = value * price;
  //     print(" value change ${valueChange.toString()}");
  //   });
  //   return valueChange;
  // }

  @override
  Widget build(BuildContext context) {
    maxAvailablity = List<String>();
    int num = int.parse(widget.roomData.maxAdults);
    for (var i = 0; i < num + 1; i++) {
      setState(() {
        maxAvailablity.add(i.toString());
      });
    }
    maxAvailablityOne = List<String>();
    int num1 = int.parse(widget.roomData.maxChild);
    for (var i = 0; i < num1 + 1; i++) {
      setState(() {
        maxAvailablityOne.add(i.toString());
      });
    }
    return AnimatedBuilder(
      animation: widget.animationController,
      builder: (BuildContext context, Widget child) {
        return FadeTransition(
          opacity: widget.animation,
          child: new Transform(
            transform: new Matrix4.translationValues(
                0.0, 40 * (1.0 - widget.animation.value), 0.0),
            child: Column(
              children: <Widget>[
                Stack(
                  alignment: Alignment.bottomCenter,
                  children: <Widget>[
                    AspectRatio(
                        aspectRatio: 1.5,
                        child: Image.network(
                          widget.roomData.thumbnail,
                          fit: BoxFit.cover,
                        )),

                    // More Info Button

                    // GestureDetector(
                    //   onTap: () {
                    //     print("Motin");
                    //   },
                    //   child: Padding(
                    //     padding: const EdgeInsets.only(bottom: 28.0),
                    //     child: Center(
                    //       child: ClipRRect(
                    //         borderRadius: BorderRadius.all(Radius.circular(24)),
                    //         child: new BackdropFilter(
                    //           filter: new ImageFilter.blur(
                    //               sigmaX: 10.0, sigmaY: 10.0),
                    //           child: Container(
                    //             color: HexColor("#0f346c"),
                    //             child: Material(
                    //               color: Colors.transparent,
                    //               child: InkWell(
                    //                 highlightColor: Colors.transparent,
                    //                 splashColor: AppTheme.getTheme()
                    //                     .primaryColor
                    //                     .withOpacity(0.2),
                    //                 borderRadius:
                    //                 BorderRadius.all(Radius.circular(38)),
                    //                 onTap: () {
                    //                   try {
                    //                     scrollController.animateTo(
                    //                         MediaQuery.of(context).size.height -
                    //                             MediaQuery.of(context)
                    //                                 .size
                    //                                 .height /
                    //                                 5,
                    //                         duration:
                    //                         Duration(milliseconds: 500),
                    //                         curve: Curves.fastOutSlowIn);
                    //                   } catch (e) {}
                    //                 },
                    //                 child: Padding(
                    //                   padding: const EdgeInsets.only(
                    //                       left: 16,
                    //                       right: 16,
                    //                       top: 4,
                    //                       bottom: 4),
                    //                   child: Row(
                    //                     mainAxisSize: MainAxisSize.min,
                    //                     mainAxisAlignment:
                    //                     MainAxisAlignment.center,
                    //                     crossAxisAlignment:
                    //                     CrossAxisAlignment.center,
                    //                     children: <Widget>[
                    //                       Padding(
                    //                         padding: const EdgeInsets.all(8.0),
                    //                         child: Text(
                    //                           'More Info',
                    //                           style: TextStyle(
                    //                             color: Colors.white,
                    //                             fontWeight: FontWeight.w600,
                    //                           ),
                    //                         ),
                    //                       ),
                    //                       Padding(
                    //                         padding:
                    //                         const EdgeInsets.only(top: 2),
                    //                         child: Icon(
                    //                           Icons.keyboard_arrow_down,
                    //                           color: Colors.white,
                    //                           size: 24,
                    //                         ),
                    //                       )
                    //                     ],
                    //                   ),
                    //                 ),
                    //               ),
                    //             ),
                    //           ),
                    //         ),
                    //       ),
                    //     ),
                    //   ),
                    // ),
                  ],
                ),

                // Modifi Here 16/02/2021
                Padding(
                  padding: const EdgeInsets.only(
                      left: 12, right: 12, bottom: 16, top: 16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      // Row ONe
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: Text(
                              widget.roomData.title,
                              maxLines: 2,
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width / 2.5,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Align(
                                  alignment: Alignment.center,
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 0.0, right: 16),
                                    child: Text(
                                      ' Select Adult',
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                      textAlign: TextAlign.right,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),

                      SizedBox(
                        height: 7,
                      ),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top: 18.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 0.0,
                                      top: 0.0,
                                      right: 4.0,
                                      bottom: 0.0),
                                  child:
                                      // Text((() {
                                      //   if(price1==0){
                                      //     return"${widget.roomData.currCode} ${widget.roomData.adultPrice}";
                                      //   }
                                      //
                                      //
                                      //
                                      //   return"${widget.roomData.currCode} $price1";
                                      //
                                      //
                                      // })())
                                      Text(
                                    "${roomPriceMap.isEmpty ? widget.roomData.perAdultPrice : roomPriceMap.values.reduce((a, b) => a + b)}",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 22,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 26.0),
                            child: SizedBox(
                              width: MediaQuery.of(context).size.width / 3.2,
                              height: 55,
                              child: DropdownButtonFormField(
                                isDense: false,
                                itemHeight: 65,
                                decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius: const BorderRadius.all(
                                        const Radius.circular(5.0),
                                      ),
                                    ),
                                    filled: true,
                                    hintStyle: TextStyle(
                                        fontSize: 15, color: Colors.black),
                                    hintText: maxAvailablity[0],
                                    fillColor: Colors.white),
                                value: facilities,
                                onChanged: (String value) {
                                  setState(() {
                                    facilities = value;
                                    widget.roomCountCallback(
                                        widget.roomData.title,
                                        widget.roomData.perAdultPrice,
                                        int.parse(facilities));
                                    // _storeLoggedInStatus(widget.roomData.id);
                                    // _storeData(facilities);
                                    // getFunction(widget.roomData.id, facilities);
                                    //    firstFunction(int.parse(facilities), widget.roomData.price);
                                    var value1 = int.parse(facilities);

                                    var str = widget.roomData.perAdultPrice;
                                    final alphanumeric = RegExp(',');
                                    int calculation;
                                    if (alphanumeric.hasMatch(str)) {
                                      var parts = str.split(',');
                                      var bbb =
                                          parts[0].trim(); // prefix: "date"
                                      var bbb1 =
                                          parts[1].trim(); // prefix: "date"
                                      calculation = int.parse(bbb + bbb1);
                                      print("===>>> has match $calculation");
                                    } else {
                                      calculation = int.parse(
                                          widget.roomData.perAdultPrice);
                                      print(
                                          "===>>> has not match $calculation");
                                    }

                                    var total_price = value1 * calculation;

                                    roomPriceMap['key'] = total_price;

                                    // if (total_price != null)
                                    //   price1 += total_price;
                                    // else
                                    //   price1 -= total_price;
                                    print(
                                        " value change ${total_price.toString()}");

                                    totalAdultPrice = total_price;
                                  });
                                },
                                items: maxAvailablity
                                    .map((cityTitle) => DropdownMenuItem(
                                        value: cityTitle,
                                        child: Text("$cityTitle")))
                                    .toList(),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                      left: 12, right: 12, bottom: 16, top: 16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      // Row ONe

                      SizedBox(
                        height: 7,
                      ),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top: 18.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 0.0,
                                      top: 0.0,
                                      right: 4.0,
                                      bottom: 0.0),
                                  child: Text(
                                    "${roomPriceMap1.isEmpty ? widget.roomData.perChildPrice : roomPriceMap1.values.reduce((a, b) => a + b)}",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 22,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Column(
                            children: [
                              Text(
                                "Select Child",
                                style: TextStyle(
                                    fontSize: 19, fontWeight: FontWeight.bold),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 26.0),
                                child: SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width / 3.2,
                                  height: 55,
                                  child: DropdownButtonFormField(
                                    isDense: false,
                                    itemHeight: 65,
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                          borderRadius: const BorderRadius.all(
                                            const Radius.circular(5.0),
                                          ),
                                        ),
                                        filled: true,
                                        hintStyle: TextStyle(
                                            fontSize: 15, color: Colors.black),
                                        hintText: maxAvailablityOne[0],
                                        fillColor: Colors.white),
                                    value: facilities1,
                                    onChanged: (String value1) {
                                      setState(() {
                                        facilities1 = value1;
                                        widget.roomCountCallback(
                                            widget.roomData.title,
                                            widget.roomData.perChildPrice,
                                            int.parse(facilities1));
                                        // _storeLoggedInStatus(widget.roomData.id);
                                        // _storeData(facilities);
                                        // getFunction(widget.roomData.id, facilities);
                                        //    firstFunction(int.parse(facilities), widget.roomData.price);
                                        var value2 = int.parse(facilities1);
                                        int calculation;
                                        var str = widget.roomData.perChildPrice;
                                        final alphanumeric = RegExp(',');
                                        if (alphanumeric.hasMatch(str)) {
                                          var parts = str.split(',');
                                          var bbb =
                                              parts[0].trim(); // prefix: "date"
                                          var bbb1 =
                                              parts[1].trim(); // prefix: "date"
                                          calculation = int.parse(bbb + bbb1);
                                          print(
                                              "===>>> has match $calculation");
                                        } else {
                                          calculation = int.parse(
                                              widget.roomData.perChildPrice);
                                          print(
                                              "===>>> has not match $calculation");
                                        }

                                        var total_price1 = value2 * calculation;

                                        roomPriceMap1['key'] = total_price1;

                                        // if (total_price != null)
                                        //   price1 += total_price;
                                        // else
                                        //   price1 -= total_price;
                                        print(
                                            " value changebbk ${total_price1.toString()}");
                                        totalchildPrice = total_price1;

                                        print("room ${price1}");
                                      });
                                    },
                                    items: maxAvailablityOne
                                        .map((cityTitle1) => DropdownMenuItem(
                                            value: cityTitle1,
                                            child: Text("$cityTitle1")))
                                        .toList(),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                SizedBox(
                  height: 20,
                ),
                // Padding(
                //   padding: const EdgeInsets.only(left: 40.0, right: 110),
                //   child: DateTimeField(
                //     format: getDateFormate(widget.roomData.tourDays),
                //     autocorrect: true,
                //     autovalidate: false,
                //     controller: dateTimeController,
                //     // readOnly: true,
                //     // validator: (date) =>
                //     //     date == null ? 'Please enter valid date' : null,
                //     decoration: InputDecoration(
                //         hintText: ('Date Time'),
                //         prefixIcon: Icon(
                //           FontAwesomeIcons.calendar,
                //           size: 24,
                //         )),
                //     // onShowPicker: (context, currentValue) {
                //     //   return showDatePicker(
                //     //     context: context,
                //     //     firstDate: DateTime(1900),
                //     //     initialDate: currentValue ?? DateTime.now(),
                //     //     lastDate: DateTime(2100),
                //     //   );
                //     // },
                //   ),
                // ),

                SizedBox(
                  height: 20,
                ),

                ClipRRect(
                  borderRadius: BorderRadius.circular(25),
                  child: Card(
                    elevation: 2,
                    child: Container(
                      height: 100,
                      width: 350,
                      decoration: BoxDecoration(),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                              "Total Amount: ${totalAdultPrice + totalchildPrice}",
                              style: TextStyle(
                                  fontSize: 19, fontWeight: FontWeight.bold),
                            ),
                          ),
                          Text(
                            "Deposit Now: " + getDeposit(),
                            style: TextStyle(
                                fontSize: 17, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.only(
                      left: 16,
                      right: 16,
                      bottom: 16 + MediaQuery.of(context).padding.bottom,
                      top: 18),
                  child: Container(
                    height: 48,
                    decoration: BoxDecoration(
                      color: AppTheme.getTheme().primaryColor,
                      borderRadius: BorderRadius.all(Radius.circular(24.0)),
                      boxShadow: <BoxShadow>[
                        BoxShadow(
                          color: AppTheme.getTheme().dividerColor,
                          blurRadius: 8,
                          offset: Offset(4, 4),
                        ),
                      ],
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.all(Radius.circular(24.0)),
                        highlightColor: Colors.transparent,
                        onTap: () async {
                          SharedPreferences sharedPreferences =
                              await SharedPreferences.getInstance();
                          String token = sharedPreferences.getString("token");

                          setState(() {
                            if (facilities == null) {
                              Fluttertoast.showToast(
                                  msg: ('Select at least 1 Adult!'),
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.BOTTOM,
                                  timeInSecForIosWeb: 2,
                                  backgroundColor: Colors.indigo,
                                  textColor: Colors.white,
                                  fontSize: 16.0);
                            } else {
                              if (token == null) {
                                if (facilities1 != null) {
                                  var value = int.parse(facilities) +
                                      int.parse(facilities1);
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => LoginWidget(
                                                totalGuest: value,
                                                adults: int.parse(facilities),
                                                child: int.parse(facilities1),
                                                tour: widget.roomData,
                                                total_amount: (totalAdultPrice + totalchildPrice).toString(),
                                                deposit: getDeposit(),
                                              )));
                                } else {
                                  var value = int.parse(facilities) + 0;
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => LoginWidget(
                                                totalGuest: value,
                                                adults: int.parse(facilities),
                                                child: 0,
                                                tour: widget.roomData,
                                            total_amount: (totalAdultPrice + totalchildPrice).toString(),
                                            deposit: getDeposit(),
                                              )));
                                }
                              } else {
                                if (facilities1 != null) {
                                  var value = int.parse(facilities) +
                                      int.parse(facilities1);
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              TourDetailsScreen(
                                                totalGuest: value,
                                                adults: int.parse(facilities),
                                                child: int.parse(facilities1),
                                                tour: widget.roomData,
                                                total_amount: (totalAdultPrice + totalchildPrice).toString(),
                                                deposit: getDeposit(),
                                              )));
                                } else {
                                  var value = int.parse(facilities) + 0;
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              TourDetailsScreen(
                                                totalGuest: value,
                                                adults: int.parse(facilities),
                                                child: 0,
                                                tour: widget.roomData,
                                                total_amount: (totalAdultPrice + totalchildPrice).toString(),
                                                deposit: getDeposit(),
                                              )));
                                }
                              }
                            }
                          });
                        },
                        child: Center(
                          child: Text(
                            "Book Now",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 19,
                                color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

                Divider(
                  height: 1,
                )
              ],
            ),
          ),
        );
      },
    );
  }

  String getDeposit() {
    String value;
    if (int.parse(widget.roomData.api_depo_fix) == 0) {
      var totalAmount = (totalAdultPrice + totalchildPrice);
      var taxCaulation =
          totalAmount * int.parse(widget.roomData.api_depo_per) / 100;
      value = taxCaulation.toString();
    } else {
      var totalCurrent = int.parse(widget.roomData.api_curr_rate) *
          int.parse(widget.roomData.api_depo_fix);
      value = totalCurrent.toString();
    }

    return value;
  }
}
