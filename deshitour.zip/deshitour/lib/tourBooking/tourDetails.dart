import 'dart:convert';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:new_motel/models/tour/toursDetails.dart';
import 'package:new_motel/modules/explore/relatedHotels.dart';
import 'package:new_motel/service/apiService.dart';
import 'package:new_motel/tourBooking/tourBookingScreen.dart';
import 'package:new_motel/tourBooking/tourReviewListScreen.dart';
import 'package:new_motel/tourBooking/tourWriteReviewLiveDetails.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';
import 'package:timeline_tile/timeline_tile.dart';

import '../appTheme.dart';
import '../loaderPage.dart';
import 'expandableListView.dart';

class TourDetails extends StatefulWidget {
  final String tour;

  const TourDetails({Key key, @required this.tour}) : super(key: key);

  @override
  _TourDetailesState createState() => _TourDetailesState();
}

class _TourDetailesState extends State<TourDetails>
    with TickerProviderStateMixin {
  ScrollController scrollController = ScrollController(initialScrollOffset: 0);
  var hoteltext1 = HOTELTEXT1;
  var hoteltext2 = HOTELTEXT2;
  bool isFav = false;
  bool isReadless = false;
  AnimationController animationController;
  var imageHieght = 0.0;
  AnimationController _animationController;
  bool loading;
  var response;
  int starSelectedRadio;

  Response _tourDetailsResponse;

  Future<String> getJSONData() async {
    loading = true;
    if (widget.tour != null) {
      response = await http.get(ApiService.tourDetails + "&id=${widget.tour}");
    } else {
      // response =
      // await http.get(ApiService.hotelDetails + "&id=${widget.relatedItems.id}");
    }

    setState(() {
      loading = false;
      _tourDetailsResponse =
          ToursDetails.fromJson(json.decode(response.body)).response;

      print("hotelData ${_tourDetailsResponse.tour.relatedItems.length}");
    });
    //print(data);
    return "data";
  }

  @override
  void initState() {
    getJSONData();
    animationController = AnimationController(
        duration: Duration(milliseconds: 2000), vsync: this);
    _animationController =
        AnimationController(duration: Duration(milliseconds: 0), vsync: this);
    animationController.forward();
    scrollController.addListener(() {
      if (context != null) {
        if (scrollController.offset < 0) {
          // we static set the just below half scrolling values
          _animationController.animateTo(0.0);
        } else if (scrollController.offset > 0.0 &&
            scrollController.offset < imageHieght) {
          // we need around half scrolling values
          if (scrollController.offset < ((imageHieght / 1.2))) {
            _animationController
                .animateTo((scrollController.offset / imageHieght));
          } else {
            // we static set the just above half scrolling values "around == 0.22"
            _animationController.animateTo((imageHieght / 1.2) / imageHieght);
          }
        }
      }
    });
    super.initState();
    starSelectedRadio = 0;
  }

  @override
  void dispose() {
    animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    imageHieght = MediaQuery.of(context).size.height;
    var hotelDescription;

    if (_tourDetailsResponse != null) {
      hotelDescription = _tourDetailsResponse.tour.desc;
    } else {
      hotelDescription = "";
    }
    return Scaffold(
      backgroundColor: AppTheme.getTheme().backgroundColor,
      body: _tourDetailsResponse == null
          ? Center(
              child: LoaderPage(),
            )
          : SingleChildScrollView(
              child: Stack(
                children: <Widget>[
                  Container(
                    color: AppTheme.getTheme().backgroundColor,
                    child: ListView(
                      primary: false,
                      scrollDirection: Axis.vertical,
                      shrinkWrap: true,
                      controller: scrollController,
                      padding: EdgeInsets.only(top: 10 + imageHieght),
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(left: 24, right: 24),
                          child: getHotelDetails(isInList: true),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Divider(
                            height: 1,
                          ),
                        ),
                        // Padding(
                        //   padding: const EdgeInsets.only(left: 24, right: 24),
                        //   child: Row(
                        //     children: <Widget>[
                        //       Expanded(
                        //         child: Text(
                        //           DESCRIPTION,
                        //           style: TextStyle(
                        //             fontWeight: FontWeight.w600,
                        //             fontSize: 14,
                        //             letterSpacing: 0.5,
                        //           ),
                        //         ),
                        //       ),
                        //     ],
                        //   ),
                        // ),
                        // SizedBox(
                        //   height: 10,
                        // ),
                        //itineraries
                        _tourDetailsResponse.tour.itineraries.length == 0
                            ? Padding(
                                padding: const EdgeInsets.only(
                                    left: 8, right: 0, bottom: 0, top: 0),
                                child: Container(
                                  height: 0,

                                  // child: ListView.builder(
                                  //   itemCount: _hotelDetailsResponse
                                  //       .HotelDetailsReviews.length,
                                  //   scrollDirection: Axis.vertical,
                                  //   itemBuilder: (context, index) {
                                  //     var count = _hotelDetailsResponse
                                  //                 .HotelDetailsReviews.length >
                                  //             10
                                  //         ? 10
                                  //         : _hotelDetailsResponse
                                  //             .HotelDetailsReviews.length;
                                  //     var animation = Tween(begin: 0.0, end: 1.0)
                                  //         .animate(CurvedAnimation(
                                  //             parent: animationController,
                                  //             curve: Interval((1 / count) * index, 1.0,
                                  //                 curve: Curves.fastOutSlowIn)));
                                  //     return
                                  //   },
                                  // ),
                                ),
                              )
                            : Padding(
                                padding:
                                    const EdgeInsets.only(left: 16, right: 8),
                                child: Container(
                                  //    height: MediaQuery.of(context).size.height,
                                  child: Expanded(
                                    child: ListView.builder(
                                      shrinkWrap: true,
                                      primary: false,
                                      itemCount: _tourDetailsResponse
                                          .tour.itineraries.length,
                                      itemBuilder:
                                          (BuildContext context, int index) {
                                        final example = _tourDetailsResponse
                                            .tour.itineraries[index];
                                        return TimelineTile(
                                          alignment: TimelineAlign.manual,
                                          lineXY: 0.1,
                                          isFirst: index == 0,
                                          isLast: index ==
                                              _tourDetailsResponse
                                                      .tour.itineraries.length -
                                                  1,
                                          indicatorStyle: IndicatorStyle(
                                            width: 80,
                                            height: 40,
                                            indicator: _IndicatorExample(
                                                number: '${index + 1}'),
                                            drawGap: false,
                                          ),
                                          beforeLineStyle: LineStyle(
                                            thickness: 1,
                                            color: Colors.blue[900],
                                          ),
                                          endChild: GestureDetector(
                                            child:
                                                _RowExample(example: example),
                                            onTap: () {
                                              // Navigator.push(
                                              //   context,
                                              //   MaterialPageRoute<ShowcaseTimeline>(
                                              //     builder: (_) =>
                                              //         ShowcaseTimeline(example: example),
                                              //   ),
                                              // );
                                            },
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ),
                              ),
                        _tourDetailsResponse.tour.policy.isEmpty
                            ? Padding(
                                padding: const EdgeInsets.only(
                                    left: 0, right: 0, bottom: 0, top: 0),
                                child: Container(
                                  height: 0,

                                  // child: ListView.builder(
                                  //   itemCount: _hotelDetailsResponse
                                  //       .HotelDetailsReviews.length,
                                  //   scrollDirection: Axis.vertical,
                                  //   itemBuilder: (context, index) {
                                  //     var count = _hotelDetailsResponse
                                  //                 .HotelDetailsReviews.length >
                                  //             10
                                  //         ? 10
                                  //         : _hotelDetailsResponse
                                  //             .HotelDetailsReviews.length;
                                  //     var animation = Tween(begin: 0.0, end: 1.0)
                                  //         .animate(CurvedAnimation(
                                  //             parent: animationController,
                                  //             curve: Interval((1 / count) * index, 1.0,
                                  //                 curve: Curves.fastOutSlowIn)));
                                  //     return
                                  //   },
                                  // ),
                                ),
                              )
                            : Padding(
                                padding: const EdgeInsets.only(
                                  left: 24,
                                  right: 24,
                                  top: 0,
                                  bottom: 0,
                                ),
                                child: Container(
                                    padding: EdgeInsets.only(
                                      bottom:
                                          5, // Space between underline and text
                                    ),
                                    decoration: BoxDecoration(
                                        border: Border(
                                            bottom: BorderSide(
                                      color: Colors.amber,
                                      width: 1.0, // Underline thickness
                                    ))),
                                    child: Text(
                                      TOUR_POLICY,
                                      style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black),
                                    )),
                              ),

                        _tourDetailsResponse.tour.policy.isEmpty
                            ? Padding(
                                padding: const EdgeInsets.only(
                                    left: 0, right: 0, bottom: 0, top: 0),
                                child: Container(
                                  height: 0,
                                  // child: ListView.builder(
                                  //   itemCount: _hotelDetailsResponse
                                  //       .HotelDetailsReviews.length,
                                  //   scrollDirection: Axis.vertical,
                                  //   itemBuilder: (context, index) {
                                  //     var count = _hotelDetailsResponse
                                  //                 .HotelDetailsReviews.length >
                                  //             10
                                  //         ? 10
                                  //         : _hotelDetailsResponse
                                  //             .HotelDetailsReviews.length;
                                  //     var animation = Tween(begin: 0.0, end: 1.0)
                                  //         .animate(CurvedAnimation(
                                  //             parent: animationController,
                                  //             curve: Interval((1 / count) * index, 1.0,
                                  //                 curve: Curves.fastOutSlowIn)));
                                  //     return
                                  //   },
                                  // ),
                                ),
                              )
                            : Padding(
                                padding: const EdgeInsets.only(
                                  left: 24,
                                  right: 24,
                                  top: 0,
                                  bottom: 0,
                                ),
                                child: Container(
                                  child: Html(
                                    data: _tourDetailsResponse.tour.policy,
                                    padding: EdgeInsets.all(3),
                                    defaultTextStyle: TextStyle(
                                        fontSize: 18, color: Colors.black),
                                  ),
                                )

                                // Text(
                                //   _tourDetailsResponse.tour.policy,
                                //   style: TextStyle(
                                //       fontSize: 20,
                                //       fontWeight: FontWeight.w200,
                                //       color: Colors.black),
                                // )
                                ),

                        SizedBox(
                          height: 10,
                        ),

                        _tourDetailsResponse.tour.paymentOptions.length == 0
                            ? Padding(
                                padding: const EdgeInsets.only(
                                    left: 0, right: 0, bottom: 0, top: 0),
                                child: Container(
                                  height: 0,
                                  // child: ListView.builder(
                                  //   itemCount: _hotelDetailsResponse
                                  //       .HotelDetailsReviews.length,
                                  //   scrollDirection: Axis.vertical,
                                  //   itemBuilder: (context, index) {
                                  //     var count = _hotelDetailsResponse
                                  //                 .HotelDetailsReviews.length >
                                  //             10
                                  //         ? 10
                                  //         : _hotelDetailsResponse
                                  //             .HotelDetailsReviews.length;
                                  //     var animation = Tween(begin: 0.0, end: 1.0)
                                  //         .animate(CurvedAnimation(
                                  //             parent: animationController,
                                  //             curve: Interval((1 / count) * index, 1.0,
                                  //                 curve: Curves.fastOutSlowIn)));
                                  //     return
                                  //   },
                                  // ),
                                ),
                              )
                            : Padding(
                                padding: const EdgeInsets.only(
                                  left: 24,
                                  right: 24,
                                  top: 0,
                                  bottom: 0,
                                ),
                                child: Container(
                                    padding: EdgeInsets.only(
                                      bottom:
                                          5, // Space between underline and text
                                    ),
                                    decoration: BoxDecoration(
                                        border: Border(
                                            bottom: BorderSide(
                                      color: Colors.amber,
                                      width: 1.0, // Underline thickness
                                    ))),
                                    child: Text(
                                      PAYMENT_OPTION,
                                      style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black),
                                    )),
                              ),

                        _tourDetailsResponse.tour.paymentOptions.length == 0
                            ? Padding(
                                padding: const EdgeInsets.only(
                                    left: 0, right: 0, bottom: 0, top: 0),
                                child: Container(
                                  height: 0,

                                  // child: ListView.builder(
                                  //   itemCount: _hotelDetailsResponse
                                  //       .HotelDetailsReviews.length,
                                  //   scrollDirection: Axis.vertical,
                                  //   itemBuilder: (context, index) {
                                  //     var count = _hotelDetailsResponse
                                  //                 .HotelDetailsReviews.length >
                                  //             10
                                  //         ? 10
                                  //         : _hotelDetailsResponse
                                  //             .HotelDetailsReviews.length;
                                  //     var animation = Tween(begin: 0.0, end: 1.0)
                                  //         .animate(CurvedAnimation(
                                  //             parent: animationController,
                                  //             curve: Interval((1 / count) * index, 1.0,
                                  //                 curve: Curves.fastOutSlowIn)));
                                  //     return
                                  //   },
                                  // ),
                                ),
                              )
                            : Padding(
                                padding: const EdgeInsets.only(
                                  left: 24,
                                  right: 24,
                                  top: 8,
                                  bottom: 0,
                                ),

                                child: Container(
                                  child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          _tourDetailsResponse
                                              .tour.paymentOptions[0].name,
                                          style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w500,
                                              color: Colors.black),
                                        ),
                                        SizedBox(
                                          height: 4,
                                        ),
                                        Row(
                                          children: [
                                            Icon(
                                              Icons.wb_sunny_rounded,
                                              color: Colors.grey,
                                              size: 24.0,
                                              semanticLabel: MODES,
                                            ),
                                            SizedBox(
                                              width: 2,
                                            ),
                                            Text(
                                              "Days : " +
                                                  _tourDetailsResponse
                                                      .tour.tourDays,
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.black),
                                            ),
                                            SizedBox(
                                              width: 2,
                                            ),
                                            Container(
                                              width: 2,
                                              height: 30,
                                              color: Colors.grey,
                                            ),
                                            SizedBox(
                                              width: 3,
                                            ),
                                            Icon(
                                              Icons.nights_stay_outlined,
                                              color: Colors.grey,
                                              size: 24.0,
                                              semanticLabel: MODES,
                                            ),
                                            SizedBox(
                                              width: 2,
                                            ),
                                            Text(
                                              "Nights : " +
                                                  _tourDetailsResponse
                                                      .tour.tourNights,
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.black),
                                            ),
                                            SizedBox(
                                              width: 2,
                                            ),
                                          ],
                                        )
                                      ]),
                                ),
                                // ListView.builder(
                                //   itemCount: _tourDetailsResponse
                                //       .tour.paymentOptions.length,
                                //   scrollDirection: Axis.vertical,
                                //   itemBuilder: (context, index) {
                                //     var count = _tourDetailsResponse
                                //                 .tour.paymentOptions.length >
                                //             10
                                //         ? 10
                                //         : _tourDetailsResponse
                                //             .tour.paymentOptions.length;
                                //     var animation = Tween(begin: 0.0, end: 1.0)
                                //         .animate(CurvedAnimation(
                                //             parent: animationController,
                                //             curve: Interval(
                                //                 (1 / count) * index, 1.0,
                                //                 curve: Curves.fastOutSlowIn)));
                                //      return
                                //      // color: Colors.amber[colorCodes[index]],
                                //       Column(
                                //         mainAxisAlignment: MainAxisAlignment.start,
                                //         children: [
                                //           Text(_tourDetailsResponse.tour.paymentOptions[index].name??"nan")
                                //         ],
                                //
                                //     );
                                //   },
                                // ),
                              ),

                        // Text(
                        //   _tourDetailsResponse.tour.policy,
                        //   style: TextStyle(
                        //       fontSize: 20,
                        //       fontWeight: FontWeight.w200,
                        //       color: Colors.black),
                        // )

                        Padding(
                          padding: const EdgeInsets.only(
                            left: 24,
                            right: 24,
                            top: 8,
                            bottom: 0,
                          ),
                          child: ExpandableListView(
                            title: INCLUSIONS,
                            inclusions: _tourDetailsResponse.tour.inclusions,
                          ),
                          // child: Container(
                          //     height: MediaQuery.of(context).size.height / 3,
                          //     child: Expanded(
                          //       child: ListView.builder(
                          //         itemBuilder: (BuildContext context, int index) {
                          //           return new ExpandableListView(title: _tourDetailsResponse.tour.inclusions[index].name);
                          //         },
                          //         itemCount: _tourDetailsResponse.tour.inclusions.length,
                          //       ),
                          //     ))
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                            left: 24,
                            right: 24,
                            top: 8,
                            bottom: 0,
                          ),
                          child: ExpandableListView(
                            title: EXCLUSIONS,
                            exclusions: _tourDetailsResponse.tour.exclusions,
                          ),
                        ),
                        _tourDetailsResponse.reviews.length == 0
                            ? Padding(
                                padding: const EdgeInsets.only(
                                    left: 0, right: 0, bottom: 0, top: 0),
                                child: Container(
                                  height: 0,

                                  // child: ListView.builder(
                                  //   itemCount: _hotelDetailsResponse
                                  //       .HotelDetailsReviews.length,
                                  //   scrollDirection: Axis.vertical,
                                  //   itemBuilder: (context, index) {
                                  //     var count = _hotelDetailsResponse
                                  //                 .HotelDetailsReviews.length >
                                  //             10
                                  //         ? 10
                                  //         : _hotelDetailsResponse
                                  //             .HotelDetailsReviews.length;
                                  //     var animation = Tween(begin: 0.0, end: 1.0)
                                  //         .animate(CurvedAnimation(
                                  //             parent: animationController,
                                  //             curve: Interval((1 / count) * index, 1.0,
                                  //                 curve: Curves.fastOutSlowIn)));
                                  //     return
                                  //   },
                                  // ),
                                ),
                              )
                            : // HotelRoomeList(_hotelDetailsResponse.hotel?.sliderImages),============>4
                            Padding(
                                padding:
                                    const EdgeInsets.only(left: 8, right: 24),
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: Text(
                                        REVIEW +
                                            "(${_tourDetailsResponse.reviews.length ?? "0"})",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          fontSize: 14,
                                          letterSpacing: 0.5,
                                        ),
                                      ),
                                    ),
                                    Material(
                                      color: Colors.transparent,
                                      child: InkWell(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(4.0)),
                                        onTap: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) =>
                                                  TourWriteReviewLiveDetails(),
                                              fullscreenDialog: true,
                                            ),
                                          );
                                          //  LoaderPage().showInSnackBar(context, "hhkl");
                                        },
                                        child: Padding(
                                          padding:
                                              const EdgeInsets.only(left: 8),
                                          child: Row(
                                            children: <Widget>[
                                              Text(
                                                WRITE_REVIEWED,
                                                textAlign: TextAlign.left,
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 14,
                                                  color: AppTheme.getTheme()
                                                      .primaryColor,
                                                ),
                                              ),
                                              SizedBox(
                                                height: 38,
                                                width: 26,
                                                child: Icon(
                                                  Icons.arrow_forward,
                                                  size: 18,
                                                  color: AppTheme.getTheme()
                                                      .primaryColor,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                        _tourDetailsResponse.reviews.length == 0
                            ? Padding(
                                padding: const EdgeInsets.only(
                                    left: 8, right: 16, bottom: 16, top: 16),
                                child: Container(
                                  height: 0,

                                  // child: ListView.builder(
                                  //   itemCount: _hotelDetailsResponse
                                  //       .HotelDetailsReviews.length,
                                  //   scrollDirection: Axis.vertical,
                                  //   itemBuilder: (context, index) {
                                  //     var count = _hotelDetailsResponse
                                  //                 .HotelDetailsReviews.length >
                                  //             10
                                  //         ? 10
                                  //         : _hotelDetailsResponse
                                  //             .HotelDetailsReviews.length;
                                  //     var animation = Tween(begin: 0.0, end: 1.0)
                                  //         .animate(CurvedAnimation(
                                  //             parent: animationController,
                                  //             curve: Interval((1 / count) * index, 1.0,
                                  //                 curve: Curves.fastOutSlowIn)));
                                  //     return
                                  //   },
                                  // ),
                                ),
                              )
                            : Padding(
                                padding: const EdgeInsets.only(
                                    left: 8, right: 16, bottom: 16, top: 16),
                                child: Container(
                                  height:
                                      MediaQuery.of(context).size.height / 3,
                                  child: TourReviewListScreen(
                                    animationController: animationController,
                                    tourReviewList:
                                        _tourDetailsResponse.reviews,
                                  ),
                                  // child: ListView.builder(
                                  //   itemCount: _hotelDetailsResponse
                                  //       .HotelDetailsReviews.length,
                                  //   scrollDirection: Axis.vertical,
                                  //   itemBuilder: (context, index) {
                                  //     var count = _hotelDetailsResponse
                                  //                 .HotelDetailsReviews.length >
                                  //             10
                                  //         ? 10
                                  //         : _hotelDetailsResponse
                                  //             .HotelDetailsReviews.length;
                                  //     var animation = Tween(begin: 0.0, end: 1.0)
                                  //         .animate(CurvedAnimation(
                                  //             parent: animationController,
                                  //             curve: Interval((1 / count) * index, 1.0,
                                  //                 curve: Curves.fastOutSlowIn)));
                                  //     return
                                  //   },
                                  // ),
                                ),
                              ),
                        SizedBox(
                          height: 16,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 10, right: 24),
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: Text(
                                  RELATED_TOUR +
                                      "(${_tourDetailsResponse.tour.relatedItems.length ?? "0"})",
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 14,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ),
                              // Material(
                              //   color: Colors.transparent,
                              //   child: InkWell(
                              //     borderRadius: BorderRadius.all(Radius.circular(4.0)),
                              //     onTap: () {
                              //       Navigator.push(
                              //         context,
                              //         MaterialPageRoute(
                              //             builder: (context) => ReviewsListScreen(),
                              //             fullscreenDialog: true),
                              //       );
                              //     },
                              //     child: Padding(
                              //       padding: const EdgeInsets.only(left: 8),
                              //       child: Row(
                              //         children: <Widget>[
                              //           Text(
                              //             'View all',
                              //             textAlign: TextAlign.left,
                              //             style: TextStyle(
                              //               fontWeight: FontWeight.w600,
                              //               fontSize: 14,
                              //               color: AppTheme.getTheme().primaryColor,
                              //             ),
                              //           ),
                              //           SizedBox(
                              //             height: 38,
                              //             width: 26,
                              //             child: Icon(
                              //               Icons.arrow_forward,
                              //               size: 14,
                              //               color: AppTheme.getTheme().primaryColor,
                              //             ),
                              //           ),
                              //         ],
                              //       ),
                              //     ),
                              //   ),
                              // )
                            ],
                          ),
                        ),
                        RelatedHotel(
                          relatedTourHotel:
                              _tourDetailsResponse.tour.relatedItems,
                          animationController: animationController,
                          callBack: (index) {
                            // LoaderPage().showInSnackBar(context, _tourDetailsResponse.tour.relatedItems[index].title);

                            // Navigator.push(
                            //   context,
                            //   MaterialPageRoute(
                            //     builder: (context) =>
                            //         HotelDetailes(
                            //           relatedItems: _hotelDetailsResponse.hotel.relatedItems[index],
                            //         ),
                            //   ),
                            // );
                          },
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 16, right: 16, bottom: 16, top: 16),
                          child: Container(
                            height: 48,
                            decoration: BoxDecoration(
                              color: AppTheme.getTheme().primaryColor,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(24.0)),
                              boxShadow: <BoxShadow>[
                                BoxShadow(
                                  color: AppTheme.getTheme().dividerColor,
                                  blurRadius: 8,
                                  offset: Offset(4, 4),
                                ),
                              ],
                            ),
                            child: Material(
                              color: Colors.transparent,
                              child: InkWell(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(24.0)),
                                highlightColor: Colors.transparent,
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => TourBookingScreen(
                                        hotelName:
                                            _tourDetailsResponse.tour.title,
                                        tour: _tourDetailsResponse.tour,
                                      ),
                                      fullscreenDialog: true,
                                    ),
                                  );
                                },
                                child: Center(
                                  child: Text(
                                    BOOK_NOW,
                                    style: TextStyle(
                                        fontWeight: FontWeight.w500,
                                        fontSize: 16,
                                        color: Colors.white),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: MediaQuery.of(context).padding.bottom,
                        ),
                      ],
                    ),
                  ),
                  _backgraoundImageUI(_tourDetailsResponse.tour),
                  Padding(
                    padding: EdgeInsets.only(
                        top: MediaQuery.of(context).padding.top),
                    child: Container(
                      height: AppBar().preferredSize.height,
                      child: Row(
                        children: <Widget>[
                          SizedBox(
                            height: AppBar().preferredSize.height,
                            child: Padding(
                              padding: EdgeInsets.only(top: 8, left: 8),
                              child: Container(
                                width: AppBar().preferredSize.height - 8,
                                height: AppBar().preferredSize.height - 8,
                                decoration: BoxDecoration(
                                    color: AppTheme.getTheme()
                                        .disabledColor
                                        .withOpacity(0.4),
                                    shape: BoxShape.circle),
                                child: Material(
                                  color: Colors.transparent,
                                  child: InkWell(
                                    borderRadius: BorderRadius.all(
                                      Radius.circular(32.0),
                                    ),
                                    onTap: () {
                                      if (scrollController.offset != 0.0) {
                                        scrollController.animateTo(0.0,
                                            duration:
                                                Duration(milliseconds: 480),
                                            curve: Curves.easeInOutQuad);
                                      } else {
                                        Navigator.pop(context);
                                      }
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Icon(Icons.arrow_back,
                                          color: AppTheme.getTheme()
                                              .backgroundColor),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          // Expanded(
                          //   child: SizedBox(),
                          // ),
                          // SizedBox(
                          //   height: AppBar().preferredSize.height,
                          //   child: Padding(
                          //     padding: EdgeInsets.only(top: 8, right: 8),
                          //     child: Container(
                          //       width: AppBar().preferredSize.height - 8,
                          //       height: AppBar().preferredSize.height - 8,
                          //       decoration: BoxDecoration(
                          //           color: AppTheme.getTheme().backgroundColor,
                          //           shape: BoxShape.circle),
                          //       child: Material(
                          //         color: Colors.transparent,
                          //         child: InkWell(
                          //           borderRadius: BorderRadius.all(
                          //             Radius.circular(32.0),
                          //           ),
                          //           onTap: () {
                          //             setState(() {
                          //               isFav = !isFav;
                          //             });
                          //           },
                          //           child: Padding(
                          //             padding: const EdgeInsets.all(8.0),
                          //             child: Icon(
                          //                 isFav
                          //                     ? Icons.favorite
                          //                     : Icons.favorite_border,
                          //                 color:
                          //                     AppTheme.getTheme().primaryColor),
                          //           ),
                          //         ),
                          //       ),
                          //     ),
                          //   ),
                          // ),
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
    );
  }

  Widget getPaymentOption(PaymentOptions paymentOptions) {
    return Padding(
      padding: EdgeInsets.all(4),
      child: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(paymentOptions.name),
          ],
        ),
      ),
    );
  }

  Widget _backgraoundImageUI(Tour hotelData) {
    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      child: AnimatedBuilder(
        animation: _animationController,
        builder: (BuildContext context, Widget child) {
          var opecity = 1.0 -
              (_animationController.value >= ((imageHieght / 1.5) / imageHieght)
                  ? 1.0
                  : _animationController.value);
          return SizedBox(
            height: imageHieght * (1.0 - _animationController.value),
            child: Stack(
              children: <Widget>[
                IgnorePointer(
                  child: Container(
                    decoration: BoxDecoration(
                      color: AppTheme.getTheme().primaryColor,
                      boxShadow: <BoxShadow>[
                        BoxShadow(
                          color: AppTheme.getTheme().dividerColor,
                          blurRadius: 8,
                          offset: Offset(4, 4),
                        ),
                      ],
                    ),
                    child: Stack(
                      alignment: Alignment.bottomCenter,
                      children: <Widget>[
                        Positioned(
                          bottom: 0,
                          left: 0,
                          right: 0,
                          top: 0,
                          child: Container(
                            width: MediaQuery.of(context).size.width,
                            child: FadeInImage(
                              placeholder:
                                  AssetImage('assets/images/bp_loading.gif'),
                              image: hotelData.thumbnail == null
                                  ? Image.asset(
                                      'assets/images/hotel_room_1.png')
                                  : NetworkImage(hotelData.thumbnail),
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  bottom: MediaQuery.of(context).padding.bottom + 16,
                  left: 0,
                  right: 0,
                  child: Opacity(
                    opacity: opecity,
                    child: Column(
                      children: <Widget>[
                        Container(
                          padding: EdgeInsets.only(left: 24, right: 24),
                          child: ClipRRect(
                            borderRadius: BorderRadius.all(Radius.circular(24)),
                            child: new BackdropFilter(
                              filter: new ImageFilter.blur(
                                  sigmaX: 10.0, sigmaY: 10.0),
                              child: Container(
                                color: Colors.black12,
                                padding: const EdgeInsets.all(4.0),
                                child: Column(
                                  children: <Widget>[
                                    SizedBox(
                                      height: 4,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          left: 16, right: 16, top: 8),
                                      child: getHotelDetails(),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          left: 16,
                                          right: 16,
                                          bottom: 16,
                                          top: 16),
                                      child: Container(
                                        height: 48,
                                        decoration: BoxDecoration(
                                          color:
                                              AppTheme.getTheme().primaryColor,
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(24.0)),
                                          boxShadow: <BoxShadow>[
                                            BoxShadow(
                                              color: AppTheme.getTheme()
                                                  .dividerColor,
                                              blurRadius: 8,
                                              offset: Offset(4, 4),
                                            ),
                                          ],
                                        ),
                                        child: Material(
                                          color: Colors.transparent,
                                          child: InkWell(
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(24.0)),
                                            highlightColor: Colors.transparent,
                                            onTap: () {
                                              Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                  builder: (context) =>
                                                      TourBookingScreen(
                                                    hotelName: hotelData.title,
                                                    tour: hotelData,
                                                  ),
                                                  fullscreenDialog: true,
                                                ),
                                              );
                                            },
                                            child: Center(
                                              child: Text(
                                                BOOK_NOW,
                                                style: TextStyle(
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 16,
                                                    color: Colors.white),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 16,
                        ),
                        Center(
                          child: ClipRRect(
                            borderRadius: BorderRadius.all(Radius.circular(24)),
                            child: new BackdropFilter(
                              filter: new ImageFilter.blur(
                                  sigmaX: 10.0, sigmaY: 10.0),
                              child: Container(
                                color: Colors.black12,
                                child: Material(
                                  color: Colors.transparent,
                                  child: InkWell(
                                    highlightColor: Colors.transparent,
                                    splashColor: AppTheme.getTheme()
                                        .primaryColor
                                        .withOpacity(0.2),
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(38)),
                                    onTap: () {
                                      try {
                                        scrollController.animateTo(
                                            MediaQuery.of(context).size.height -
                                                MediaQuery.of(context)
                                                        .size
                                                        .height /
                                                    5,
                                            duration:
                                                Duration(milliseconds: 500),
                                            curve: Curves.fastOutSlowIn);
                                      } catch (e) {}
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.only(
                                          left: 16,
                                          right: 16,
                                          top: 4,
                                          bottom: 4),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: <Widget>[
                                          Text(
                                            MORE_DETAILS,
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                          Padding(
                                            padding:
                                                const EdgeInsets.only(top: 2),
                                            child: Icon(
                                              Icons.keyboard_arrow_down,
                                              color: Colors.white,
                                              size: 24,
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          );
        },
      ),
    );
  }

  // Widget popularFacilities() {
  //   return Container(
  //       padding: EdgeInsets.all(16.0),
  //       child: GridView.builder(
  //           itemCount: popular.length,
  //           gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
  //               crossAxisCount: 3, crossAxisSpacing: 4.0, mainAxisSpacing: 4.0),
  //           itemBuilder: (BuildContext context, int index) {
  //             return Image.network(popular[index].icon);
  //           }));
  // }

  Widget getHotelDetails({bool isInList = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: <Widget>[
        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                "${_tourDetailsResponse.tour == null ? "0" : _tourDetailsResponse.tour.title} ",
                textAlign: TextAlign.left,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 22,
                  color: isInList
                      ? AppTheme.getTheme().textTheme.bodyText1.color
                      : Colors.white,
                ),
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Text(
                    "${_tourDetailsResponse.tour == null ? "0" : _tourDetailsResponse.tour.mapAddress} ",
                    style: TextStyle(
                      fontSize: 10,
                      color: isInList
                          ? AppTheme.getTheme().disabledColor.withOpacity(0.5)
                          : Colors.white,
                    ),
                  ),
                  SizedBox(
                    width: 4,
                  ),
                  // Icon(
                  //   FontAwesomeIcons.mapMarkerAlt,
                  //   size: 12,
                  //   color: AppTheme.getTheme().primaryColor,
                  // ),
                  // Expanded(
                  //   child: Text(
                  //     "${widget.hotelData.citycenterDistance} km to city",
                  //     overflow: TextOverflow.ellipsis,
                  //     style: TextStyle(
                  //       fontSize: 14,
                  //       color: isInList
                  //           ? AppTheme.getTheme().disabledColor.withOpacity(0.5)
                  //           : Colors.white,
                  //     ),
                  //   ),
                  // ),
                ],
              ),
              isInList
                  ? SizedBox()
                  : Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Row(
                        children: <Widget>[
                          SmoothStarRating(
                            allowHalfRating: true,
                            starCount: 5,
                            rating: double.parse(
                                _tourDetailsResponse.tour.starsCount ?? 0),
                            size: 20,
                            isReadOnly: true,
                            color: AppTheme.starColor,
                            borderColor: AppTheme.starColor,
                          ),
                          // Text(
                          //   " ${_tourDetailsResponse.tour == null ? "0" : _tourDetailsResponse.tour.hotelReviews.totalReviews}  Reviews",
                          //   style: TextStyle(
                          //     fontSize: 14,
                          //     color: isInList
                          //         ? AppTheme.getTheme().disabledColor
                          //         : Colors.white,
                          //   ),
                          // ),
                        ],
                      ),
                    ),
            ],
          ),
        ),
        // Column(
        //   mainAxisAlignment: MainAxisAlignment.center,
        //   crossAxisAlignment: CrossAxisAlignment.end,
        //   children: <Widget>[
        //     Text(
        //       "${widget.hotelData.currCode} ${widget.hotelData.price ?? "nan"}",
        //       textAlign: TextAlign.left,
        //       style: TextStyle(
        //         fontWeight: FontWeight.w600,
        //         fontSize: 22,
        //         color: isInList
        //             ? AppTheme.getTheme().textTheme.bodyText1.color
        //             : Colors.white,
        //       ),
        //     ),
        //     // Text(
        //     //   "/per night",
        //     //   style: TextStyle(
        //     //     fontSize: 14,
        //     //     color: isInList
        //     //         ? AppTheme.getTheme().disabledColor.withOpacity(0.5)
        //     //         : Colors.white,
        //     //   ),
        //     // ),
        //   ],
        // ),
      ],
    );
  }
}

class _RowExample extends StatelessWidget {
  const _RowExample({Key key, this.example}) : super(key: key);

  final Itineraries example;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(30),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          AspectRatio(
            aspectRatio: 2,
            child: FadeInImage(
              placeholder: AssetImage('assets/images/bp_loading.gif'),
              image: NetworkImage(
                TOUR_ITINERARY_IMAGE_URL + example.placeimg,
              ),
              //      "assets/images/mapImage.png",
              fit: BoxFit.cover,
            ),
          ),
          Text(
            example.dayplan,
            style: GoogleFonts.jura(
              color: Colors.blue,
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
          ),
          SizedBox(
            height: 12,
          ),
          Text(
            example.details,
            style: GoogleFonts.jura(
              color: Colors.black,
              fontSize: 16,
            ),
          ),
          // const Icon(
          //   Icons.navigate_next,
          //   color: Colors.blueAccent,
          //   size: 26,
          // ),
        ],
      ),
    );
  }
}

class _IndicatorExample extends StatelessWidget {
  const _IndicatorExample({Key key, this.number}) : super(key: key);

  final String number;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.blue[900],
        shape: BoxShape.rectangle,

        // // border: Border.fromBorderSide(
        // //
        // //   BorderSide(
        // //     width: 4,
        // //   ),
        // ),
      ),
      child: Center(
        child: Text(
          "Day " + number,
          style: const TextStyle(fontSize: 16, color: Colors.white),
        ),
      ),
    );
  }
}
