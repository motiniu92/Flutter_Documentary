import 'package:flutter/material.dart';
import 'package:new_motel/models/tour/toursDetails.dart';

class ExpandableListView extends StatefulWidget {
  final String title;
  final List<Inclusions> inclusions;
  final List<Exclusions> exclusions;
  const ExpandableListView(
      {Key key,
      @required this.title,
      @required this.inclusions,
      @required this.exclusions})
      : super(key: key);
  @override
  _ExpandableListViewState createState() => _ExpandableListViewState();
}

class _ExpandableListViewState extends State<ExpandableListView> {
  bool expandFlag = false;

  List<Inclusions> inclusions;
  List<Exclusions> exclusions;
  var expandableListItem;

  @override
  Widget build(BuildContext context) {
    if (widget.inclusions != null) {
      expandableListItem = widget.inclusions;
    } else {
      expandableListItem = widget.exclusions;
    }
    return new Container(
      margin: new EdgeInsets.symmetric(vertical: 1.0),
      child: new Column(
        children: <Widget>[
          GestureDetector(
            onTap: () {
              setState(() {
                expandFlag = !expandFlag;
              });
            },
            child: new Container(
              color: Colors.blue,
              padding: new EdgeInsets.symmetric(horizontal: 8.0),
              child: new Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  new Text(
                    widget.title,
                    style: new TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontSize: 22),
                  ),
                  new IconButton(
                      icon: new Container(
                        height: 50.0,
                        width: 50.0,
                        decoration: new BoxDecoration(
                          color: Colors.orange,
                          shape: BoxShape.circle,
                        ),
                        child: new Center(
                          child: new Icon(
                            expandFlag
                                ? Icons.keyboard_arrow_up
                                : Icons.keyboard_arrow_down,
                            color: Colors.white,
                            size: 30.0,
                          ),
                        ),
                      ),
                      onPressed: () {
                        setState(() {
                          expandFlag = !expandFlag;
                        });
                      })
                ],
              ),
            ),
          ),
          new ExpandableContainer(
              expanded: expandFlag,
              child: new ListView.builder(
                shrinkWrap: true,
                primary: false,
                itemBuilder: (BuildContext context, int index) {
                  return new Container(
                    child: new ListTile(
                      title: new Text(
                        expandableListItem[index].name,
                        style:
                            new TextStyle(color: Colors.black87, fontSize: 16),
                      ),
                      leading: widget.inclusions == null
                          ? new Icon(
                              Icons.clear,
                              color: Colors.red,
                            )
                          : new Icon(
                              Icons.check,
                              color: Colors.blue,
                            ),
                    ),
                  );
                },
                itemCount: expandableListItem.length,
              ))
        ],
      ),
    );
  }
}

class ExpandableContainer extends StatelessWidget {
  final bool expanded;
  final double collapsedHeight;
  final double expandedHeight;
  final Widget child;

  ExpandableContainer({
    @required this.child,
    this.collapsedHeight = 0.0,
    this.expandedHeight = 400.0,
    this.expanded = true,
  });

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.width;
    return new AnimatedContainer(
      duration: new Duration(milliseconds: 500),
      curve: Curves.easeInOut,
      width: screenWidth,
      height: expanded ? height : collapsedHeight,
      child: new Container(
        child: child,
      ),
    );
  }
}
