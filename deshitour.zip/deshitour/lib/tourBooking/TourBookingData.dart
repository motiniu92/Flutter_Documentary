class TourBookingData {
  int id;
  String name;
  String age;
  String passport;

  void setId(int id) {
    this.id = id;
  }
  void setName(String name) {
    this.name = name;
  }

  void setAge(String age) {
    this.age = age;
  }

  void setPassport(String passport) {
    this.passport = passport;
  }

  String getName() {
    return this.name;
  }

  String getAge() {
    return this.age;
  }

  String getPassport() {
    return this.passport;
  }

  TourBookingData(this.id,this.name, this.age, this.passport);

}
