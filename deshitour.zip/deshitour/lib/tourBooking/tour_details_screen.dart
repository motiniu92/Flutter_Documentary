import 'dart:collection';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:new_motel/appTheme.dart';
import 'package:new_motel/loaderPage.dart';
import 'package:new_motel/model/tourbookingList.dart';
import 'package:new_motel/models/tour/toursDetails.dart';
import 'package:new_motel/tourBooking/TourBookingData.dart';
import 'package:new_motel/tourBooking/tourConfirmationScreen.dart';
import 'package:shared_preferences/shared_preferences.dart';

class TourDetailsScreen extends StatefulWidget {
  final int totalGuest;
  final int adults;
  final int child;
  final Tour tour;
  final String total_amount;
  final String deposit;

  const TourDetailsScreen(
      {Key key,
      @required this.totalGuest,
      @required this.adults,
      @required this.child,
      @required this.tour,
      @required this.total_amount,
      @required this.deposit})
      : super(key: key);

  @override
  _TourDetailsScreenState createState() => _TourDetailsScreenState();
}

class _TourDetailsScreenState extends State<TourDetailsScreen> {
  bool rememberMe = false;

  bool rememberMe2 = false;

  String selectedItem;

  bool isLoading = false;

  GlobalKey<FormState> _key = GlobalKey<FormState>();

  void _onRememberMeChanged(bool newValue) {
    setState(() {
      rememberMe = newValue;
    });
  }

  void _onRememberMeChanged2(bool newValue2) {
    setState(() {
      rememberMe2 = newValue2;
    });
  }

  final email = TextEditingController();
  final firstName = TextEditingController();
  final lastName = TextEditingController();
  final phone = TextEditingController();
  final addressController = TextEditingController();
  final countryListController = TextEditingController();

  // booking tour controller
  final nameTourBookingController = TextEditingController();
  final passportTourController = TextEditingController();
  final ageTourBookingController = TextEditingController();
  List<TextEditingController> _controllers1 = new List();
  List<TextEditingController> _controllers2 = new List();
  List<TextEditingController> _controllers3 = new List();
  List<TextEditingController> textEditingControllers = [];

  Map<String, String> name = {};
  Map<String, String> passport = {};
  Map<String, String> age = {};
  String sessionId;

  List<TourBookingData> tourBookingDataList = [];

  Map<String, TourBookingList> tourData = {};

  Future<String> getUserData() async {
    // set User Data....>>>>
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    // get User Data....>>>
    email.text = sharedPreferences.getString('email');
    print("SharedData>>>>${sharedPreferences.getString('email')}");
    firstName.text = sharedPreferences.getString('firstName');
    print("SharedData>>>>${sharedPreferences.getString('firstName')}");

    lastName.text = sharedPreferences.getString('lastName');
    print("SharedData>>>>${sharedPreferences.getString('lastName')}");
    phone.text = sharedPreferences.getString('phone');
    print("SharedData>>>>${sharedPreferences.getString('phone')}");
    print("SharedData>>>>${sharedPreferences.getString('phone')}");

    // sharedPreferences.getString(phoneController.text);
    sharedPreferences.getString(addressController.text);
    sharedPreferences.getString(countryListController.text);
    setState(() {});
  }

  Future<void> checkTourBooking(
    String itemid,
    String user_id,
    Map<String, Map<String, String>> bookMap,
    String adults,
    String children,
    String tdate,
  ) async {
    final body = {
      "itemid": itemid,
      "user_id": user_id,
      "passport": bookMap,
      "adults": adults,
      "children": children,
      "tdate": tdate,
    };
    //print("Room Booking User Id ...$userId");

    final jsonString = json.encode(body);
    print("JSonEncoded.....>>>>$jsonString");
    final headers = {HttpHeaders.contentTypeHeader: 'application/json'};

    final response = await http.post(
        "https://deshitour.com/api/tours/tourbook?appKey=DeshiTour",
        headers: headers,
        body: jsonString);
    try {
      var data = json.decode(response.body);
      print("Abir...$data");
      var status = data['status'];
      var msg = data['msg'];
      if (status == 1) {
        sessionId = data['invoice'];
        Fluttertoast.showToast(
            msg: (msg),
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 2,
            backgroundColor: Colors.indigo[800],
            textColor: Colors.white,
            fontSize: 16.0);
        setState(() {
          setButton(sessionId);
        });
      } else {
        Fluttertoast.showToast(
            msg: (msg),
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 2,
            backgroundColor: Colors.indigo[800],
            textColor: Colors.white,
            fontSize: 16.0);
      }
    } catch (e) {
      print(e);
    }
  }

  @override
  void initState() {
    super.initState();
    getUserData();
    // checkHotelRoomBooking();

    // if (Platform.isAndroid) WebView.platform = SurfaceAndroidWebView();
    tourBookingDataList.clear();

    for (int i = 0; i < widget.totalGuest; i++) {
      tourBookingDataList.add(TourBookingData(i, "", "", ""));
    }
  }

  @override
  Widget build(BuildContext context) {
    print("total ===>>>>> ${widget.totalGuest}");
    return isLoading
        ? Center(
            child: LoaderPage(),
          )
        : SafeArea(
            child: Scaffold(
              appBar: AppBar(
                leading: IconButton(
                  icon: Icon(Icons.arrow_back),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
                iconTheme: IconThemeData(color: Colors.black),
                title: Text(
                  'Tour Details',
                  style: TextStyle(fontSize: 18, color: Colors.black),
                ),
                backgroundColor: Colors.white,
              ),
              body: Container(
                child: Form(
                  child: ListView(
                    shrinkWrap: true,
                    primary: false,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.black12,
                          borderRadius: BorderRadius.all(Radius.circular(2)),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: AppTheme.getTheme().dividerColor,
                              blurRadius: 8,
                              offset: Offset(4, 4),
                            ),
                          ],
                        ),
                        height: 55,
                        child: new Row(
                          children: [
                            // Left Expanded
                            Expanded(
                              child: Container(
                                width: MediaQuery.of(context).size.width / 2,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        "Adults",
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 18,
                                        ),
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                    SizedBox(
                                      width:
                                          MediaQuery.of(context).size.width / 2,
                                      child: Text(
                                        " ${widget.adults ?? '0'}",
                                        // "0",
                                        // widget.rooms,
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 18,
                                        ),
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),

                            VerticalDivider(
                              width: 20,
                              color: Colors.white,
                            ),

                            // Right Expanded
                            Expanded(
                              child: Container(
                                width: MediaQuery.of(context).size.width / 2,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        "Total Amount",
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 18,
                                        ),
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                    SizedBox(
                                      width:
                                          MediaQuery.of(context).size.width / 2,
                                      child: Text(
                                        "${widget.total_amount ?? "0"}",
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 18,
                                        ),
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        flex: 1,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                color: Colors.black12,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(2)),
                                boxShadow: <BoxShadow>[
                                  BoxShadow(
                                    color: AppTheme.getTheme().dividerColor,
                                    blurRadius: 8,
                                    offset: Offset(4, 4),
                                  ),
                                ],
                              ),
                              height: 55,
                              child: new Row(
                                children: [
                                  // Left Expanded
                                  Expanded(
                                    child: Container(
                                      width:
                                          MediaQuery.of(context).size.width / 2,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Align(
                                            alignment: Alignment.center,
                                            child: Text(
                                              "Child",
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 18,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                          SizedBox(
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width /
                                                2,
                                            child: Text(
                                              "${widget.child ?? '0'}",
                                              // "0",
                                              // widget.rooms,
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 18,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),

                                  VerticalDivider(
                                    width: 20,
                                    color: Colors.white,
                                  ),

                                  // Right Expanded
                                  Expanded(
                                    child: Container(
                                      width:
                                          MediaQuery.of(context).size.width / 2,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Align(
                                            alignment: Alignment.center,
                                            child: Text(
                                              "Deposit",
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 18,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                          SizedBox(
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width /
                                                2,
                                            child: Text(
                                              "${widget.deposit ?? "0"}",
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 18,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 18, right: 24, top: 16),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: AppTheme.getTheme().backgroundColor,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(38)),
                                  // border: Border.all(
                                  //   color: HexColor("#757575").withOpacity(0.6),
                                  // ),
                                  boxShadow: <BoxShadow>[
                                    BoxShadow(
                                      color: AppTheme.getTheme().dividerColor,
                                      blurRadius: 8,
                                      offset: Offset(4, 4),
                                    ),
                                  ],
                                ),
                                // NID TextFields
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 16, right: 16),
                                  child: Container(
                                    height: 48,
                                    child: Center(
                                      child: TextFormField(
                                        controller: firstName,
                                        validator: (value) {
                                          if (value.isEmpty) {
                                            return "Please enter first name";
                                          }
                                          return null;
                                        },
                                        maxLines: 1,
                                        onChanged: (String txt) {},
                                        style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        cursorColor:
                                            AppTheme.getTheme().primaryColor,
                                        decoration: new InputDecoration(
                                          errorText: null,
                                          border: InputBorder.none,
                                          // hintText: firstName,
                                          hintStyle: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold,
                                              color: AppTheme.getTheme()
                                                  .disabledColor),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 16,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 18, right: 24),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: AppTheme.getTheme().backgroundColor,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(38)),
                                  // border: Border.all(
                                  //   color: HexColor("#757575").withOpacity(0.6),
                                  // ),
                                  boxShadow: <BoxShadow>[
                                    BoxShadow(
                                      color: AppTheme.getTheme().dividerColor,
                                      blurRadius: 8,
                                      offset: Offset(4, 4),
                                    ),
                                  ],
                                ),
                                // NID TextFields
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 16, right: 16),
                                  child: Container(
                                    height: 48,
                                    child: Center(
                                      child: TextFormField(
                                        controller: lastName,
                                        validator: (value) {
                                          if (value.isEmpty) {
                                            return "Please enter last name";
                                          }
                                          return null;
                                        },
                                        maxLines: 1,
                                        onChanged: (String txt) {},
                                        style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        cursorColor:
                                            AppTheme.getTheme().primaryColor,
                                        decoration: new InputDecoration(
                                          errorText: null,
                                          border: InputBorder.none,
                                          // hintText: lastName,
                                          hintStyle: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold,
                                              color: AppTheme.getTheme()
                                                  .disabledColor),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 16,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 18, right: 24),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: AppTheme.getTheme().backgroundColor,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(38)),
                                  // border: Border.all(
                                  //   color: HexColor("#757575").withOpacity(0.6),
                                  // ),
                                  boxShadow: <BoxShadow>[
                                    BoxShadow(
                                      color: AppTheme.getTheme().dividerColor,
                                      blurRadius: 8,
                                      offset: Offset(4, 4),
                                    ),
                                  ],
                                ),
                                // NID TextFields
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 16, right: 16),
                                  child: Container(
                                    height: 48,
                                    child: Center(
                                      child: TextFormField(
                                        controller: email,
                                        enabled: false,
                                        validator: (value) {
                                          if (value.isEmpty) {
                                            return "Please enter email address";
                                          }
                                          return null;
                                        },
                                        maxLines: 1,
                                        onChanged: (String txt) {},
                                        style: TextStyle(
                                          fontSize: 20,
                                        ),
                                        cursorColor:
                                            AppTheme.getTheme().primaryColor,
                                        decoration: new InputDecoration(
                                          errorText: null,
                                          border: InputBorder.none,

                                          // hintText: email,
                                          hintStyle: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold,
                                              color: AppTheme.getTheme()
                                                  .disabledColor),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 16,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 18, right: 24),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: AppTheme.getTheme().backgroundColor,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(38)),
                                  // border: Border.all(
                                  //   color: HexColor("#757575").withOpacity(0.6),
                                  // ),
                                  boxShadow: <BoxShadow>[
                                    BoxShadow(
                                      color: AppTheme.getTheme().dividerColor,
                                      blurRadius: 8,
                                      offset: Offset(4, 4),
                                    ),
                                  ],
                                ),
                                // NID TextFields
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 16, right: 16),
                                  child: Container(
                                    height: 48,
                                    child: Center(
                                      child: TextFormField(
                                        controller: phone,
                                        validator: (value) {
                                          if (value.isEmpty) {
                                            return "Please enter your phone Number";
                                          }
                                          return null;
                                        },
                                        maxLines: 1,
                                        onChanged: (String txt) {},
                                        style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        cursorColor:
                                            AppTheme.getTheme().primaryColor,
                                        decoration: new InputDecoration(
                                          errorText: null,
                                          border: InputBorder.none,
                                          // hintText: phone,
                                          hintStyle: TextStyle(
                                              fontSize: 20,
                                              color: AppTheme.getTheme()
                                                  .disabledColor),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 16,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 18, right: 24),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: AppTheme.getTheme().backgroundColor,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(38)),
                                  // border: Border.all(
                                  //   color: HexColor("#757575").withOpacity(0.6),
                                  // ),
                                  boxShadow: <BoxShadow>[
                                    BoxShadow(
                                      color: AppTheme.getTheme().dividerColor,
                                      blurRadius: 8,
                                      offset: Offset(4, 4),
                                    ),
                                  ],
                                ),
                                // NID TextFields
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 16, right: 16),
                                  child: Container(
                                    height: 48,
                                    child: Center(
                                      child: TextFormField(
                                        validator: (value) {
                                          if (value.isEmpty) {
                                            return "Please enter your address";
                                          }
                                          return null;
                                        },
                                        maxLines: 1,
                                        onChanged: (String txt) {},
                                        style: TextStyle(
                                          fontSize: 16,
                                        ),
                                        cursorColor:
                                            AppTheme.getTheme().primaryColor,
                                        decoration: new InputDecoration(
                                          errorText: null,
                                          border: InputBorder.none,
                                          hintText: "Address",
                                          hintStyle: TextStyle(
                                              fontSize: 17,
                                              color: AppTheme.getTheme()
                                                  .disabledColor),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 16,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 18, right: 24),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: AppTheme.getTheme().backgroundColor,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(38)),
                                  // border: Border.all(
                                  //   color: HexColor("#757575").withOpacity(0.6),
                                  // ),
                                  boxShadow: <BoxShadow>[
                                    BoxShadow(
                                      color: AppTheme.getTheme().dividerColor,
                                      blurRadius: 8,
                                      offset: Offset(4, 4),
                                    ),
                                  ],
                                ),
                                // NID TextFields
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 16, right: 16),
                                  child: Container(
                                    height: 48,
                                    child: Center(
                                      child: TextFormField(
                                        validator: (value) {
                                          if (value.isEmpty) {
                                            return "Please enter your select country";
                                          }
                                          return null;
                                        },
                                        maxLines: 1,
                                        onChanged: (String txt) {},
                                        style: TextStyle(
                                          fontSize: 16,
                                        ),
                                        cursorColor:
                                            AppTheme.getTheme().primaryColor,
                                        decoration: new InputDecoration(
                                          errorText: null,
                                          border: InputBorder.none,
                                          hintText: "Country",
                                          hintStyle: TextStyle(
                                              fontSize: 17,
                                              color: AppTheme.getTheme()
                                                  .disabledColor),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 16,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 18.0, right: 18),
                              child: Divider(
                                color: Colors.grey,
                                thickness: 1,
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: ListView.builder(
                          shrinkWrap: true,
                          primary: false,
                          itemCount: widget.totalGuest,
                          // ignore: missing_return
                          itemBuilder: (_, index) {
                            return Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Form(
                                child: Card(
                                  elevation: 2,
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceAround,
                                          children: [
                                            Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.all(4.0),
                                                  child: Text(
                                                    "Guest ${index + 1} Name",
                                                    style:
                                                        TextStyle(fontSize: 17),
                                                  ),
                                                ),
                                                Container(
                                                  height: 50,
                                                  width: 300,
                                                  child: TextFormField(
                                                    validator: (value) => value
                                                            .isEmpty
                                                        ? 'Name cannot be blank'
                                                        : null,
                                                    // controller: nameTourBookingController,
                                                    onChanged: (value) {
                                                      name['$index'] = value;
                                                      tourBookingDataList[index]
                                                          .setName(value);
                                                    },
                                                    decoration: InputDecoration(
                                                        hintText: "Name",
                                                        border:
                                                            OutlineInputBorder()),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 6,
                                        ),
                                        Row(
                                          children: [
                                            Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.all(4.0),
                                                  child: Text(
                                                    "Age",
                                                    style:
                                                        TextStyle(fontSize: 17),
                                                  ),
                                                ),
                                                Container(
                                                  height: 50,
                                                  width: 100,
                                                  child: TextFormField(
                                                    validator: (value) => value
                                                            .isEmpty
                                                        ? 'age cannot be blank'
                                                        : null,
                                                    // controller: ageTourBookingController,
                                                    onChanged: (value) {
                                                      age['$index'] = value;
                                                      tourBookingDataList[index]
                                                          .setAge(value);
                                                    },
                                                    decoration: InputDecoration(
                                                        hintText: "age",
                                                        border:
                                                            OutlineInputBorder()),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 8.0),
                                              child: Column(
                                                children: [
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.all(
                                                            4.0),
                                                    child: Text(
                                                      "Guest ${index + 1} Passport Number",
                                                      style: TextStyle(
                                                          fontSize: 17),
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 10,
                                                  ),
                                                  Container(
                                                    height: 50,
                                                    width: 180,
                                                    child: TextFormField(
                                                      validator: (value) => value
                                                              .isEmpty
                                                          ? 'Passport cannot be blank'
                                                          : null,
                                                      // controller: passportTourController,
                                                      // //     controller: _controllers3[index],
                                                      //
                                                      onChanged: (value) {
                                                        passport['$index'] =
                                                            value;
                                                        tourBookingDataList[
                                                                index]
                                                            .setPassport(value);
                                                      },

                                                      decoration: InputDecoration(
                                                          hintText: "passport",
                                                          border:
                                                              OutlineInputBorder()),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            left: 16,
                            right: 16,
                            bottom: 16 + MediaQuery.of(context).padding.bottom,
                            top: 8),
                        child: Container(
                          height: 48,
                          decoration: BoxDecoration(
                            color: AppTheme.getTheme().primaryColor,
                            borderRadius:
                                BorderRadius.all(Radius.circular(24.0)),
                            boxShadow: <BoxShadow>[
                              BoxShadow(
                                color: AppTheme.getTheme().dividerColor,
                                blurRadius: 8,
                                offset: Offset(4, 4),
                              ),
                            ],
                          ),
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(24.0)),
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                SharedPreferences sharedPreferences =
                                    await SharedPreferences.getInstance();
                                String itemid = widget.tour.id;
                                String userId =
                                    sharedPreferences.getString('id');

                                String passport = '';
                                String adults = widget.adults.toString();
                                String child = widget.child.toString();
                                String date = "27/02/2021";

                                var bookingData =
                                    HashMap<String, Map<String, String>>();
                                var dataMap = HashMap<String, String>();
                                for (int i = 0;
                                    i < tourBookingDataList.length;
                                    i++) {
                                  TourBookingData dd = tourBookingDataList[i];
                                  dataMap["name"] = dd.name;
                                  dataMap["age"] = dd.age;
                                  dataMap["passportnumber"] = dd.passport;

                                  bookingData["${i + 1}"] = dataMap;

                                  print("id : ${dd.id}");
                                  print("Name : ${dd.name}");
                                  print("age : ${dd.age}");
                                  print("passport : ${dd.passport}");
                                }

                                checkTourBooking(itemid, userId, bookingData,
                                    adults, child, date);
                                setState(() {
                                  isLoading = true;
                                });
                              },
                              child: Center(
                                child: Text(
                                  "Complete This Booking",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 19,
                                      color: Colors.white),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
  }

  void setButton(String body) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var userId = sharedPreferences.getString('id');

    print("==>>> $userId $body");
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (BuildContext context) =>
                TourConfirmationScreen(url: body)));
    // Navigator.push(
    //     context,
    //     MaterialPageRoute(
    //         builder: (BuildContext context) =>
    //             MyWebView(title: "Invoice", selectedUrl: body)));
  }

  getDateFormate(String date) {
    DateTime parseDate = new DateFormat("yyyy-MM-dd").parse(date);
    var inputDate = DateTime.parse(parseDate.toString());
    var outputFormat = DateFormat('dd/MM/yyyy');
    var output = outputFormat.format(inputDate);
    return output;
  }

  getDataForm() {
    //  tourData.map((e) =>TourBookingList(name: nameTourBookingController.text,
    //
    // age: ageTourBookingController.text,passport: passportTourController.text
    //
    // ) );

    // tourData.map((key, value) => TourBookingList(name: nameTourBookingController.text,
    //
    //      age: ageTourBookingController.text,passport: passportTourController.text));

    //
    List<String> name1 = List<String>();
    List<String> pass1 = List<String>();
    List<String> age1 = List<String>();

    name.forEach((key, value) {
      name1.add(value);
      print("++++ $name1");
    });
    age.forEach((key, value) {
      age1.add(value);
      print("++++ $value");
    });

    passport.forEach((key, value) {
      pass1.add(value);
      print("++++ $value");
    });

    // var name=nameTourBookingController.text.trim();
    // var passport=passportTourController.text.trim();
    // var age=ageTourBookingController.text.trim();
    // TourBookingList tourBookingList=TourBookingList(name, passport, age);
    // String value;
    // for(int i=0;i<_controllers1.length;i++){
    //    value=_controllers1[i].text;
    // }
    //
    // bookingList.add(value);
    // //
    //  print("====>>>>${bookingList.length}");
  }
}
