import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:new_motel/models/tour/tourCountryModel.dart';
import 'package:new_motel/models/tour/tourStarModel.dart';
import 'package:new_motel/models/tour/tourTypes.dart';
import 'package:http/http.dart' as http;

class TourStarFilterScreen extends StatefulWidget {

  @override
  _TourStarFilterScreenState createState() => _TourStarFilterScreenState();
}

class _TourStarFilterScreenState extends State<TourStarFilterScreen> {
  List<ResponseStar> responseStar;
  var response;
  String type = '187';
  String tcountry = 'Bangladesh';
  String stars = '3';

  Future<String> getJSONData() async {

     response = await
    http.get("https://deshitour.com/api/tours/tourtfilter?appKey=DeshiTour&type='$type'&stars='$stars'&tcountry='$tcountry'");
    setState(() {

      responseStar = TourStarModel.fromJson(json.decode(response.body)).responseStar;
      print(" Filter Star .... ${responseStar}");

      // Get the JSON data

      // hotelList=homeData.response;
      print("data Tour Star Length.... ${responseStar.length}");
    });
    return "value";
  }




  @override
  void initState() {
    // TODO: implement initState

    getJSONData();
    super.initState();


  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: ListView.builder(
            itemCount: responseStar == null ? 0 : responseStar.length,
            itemBuilder: (context, index){
              double value ;
              return Text(
               responseStar[index].stars
                  );

            }),
      ),
    );

  }
}
