class TourCountryModel {
  List<TResponse> response;
  Error error;

  TourCountryModel({this.response, this.error});

  TourCountryModel.fromJson(Map<String, dynamic> json) {
    if (json['response'] != null) {
      response = new List<TResponse>();
      json['response'].forEach((v) {
        response.add(new TResponse.fromJson(v));
      });
    }
    error = json['error'] != null ? new Error.fromJson(json['error']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.response != null) {
      data['response'] = this.response.map((v) => v.toJson()).toList();
    }
    if (this.error != null) {
      data['error'] = this.error.toJson();
    }
    return data;
  }
}

class TResponse {
  bool _isSelect = false;
  bool get isSelect => _isSelect;
  set isSelected(bool isSelect) {
    _isSelect = isSelect;
  }

  String tourCountry;

  TResponse({this.tourCountry});

  TResponse.fromJson(Map<String, dynamic> json) {
    tourCountry = json['tour_country'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['tour_country'] = this.tourCountry;
    return data;
  }
}

class Error {
  bool status;
  String msg;

  Error({this.status, this.msg});

  Error.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    msg = json['msg'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['msg'] = this.msg;
    return data;
  }
}
