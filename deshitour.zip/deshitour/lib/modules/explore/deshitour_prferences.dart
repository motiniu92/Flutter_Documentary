class DeshiTourPreference {
  static String LOCATION_ID = "locationId";
  static String LOCATION_NAME = "locationName";
  static String CHECKIN = "checkIn";
  static String CHECKOUT = "checkOut";
}
