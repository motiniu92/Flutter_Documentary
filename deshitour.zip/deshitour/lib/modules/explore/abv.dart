import 'dart:convert';

import 'package:autocomplete_textfield/autocomplete_textfield.dart';
import 'package:date_range_picker/date_range_picker.dart' as DateRagePicker;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:new_motel/authenticating/login.dart';
import 'package:new_motel/models/home/home.dart';
import 'package:new_motel/modules/explore/deshitour_prferences.dart';
import 'package:new_motel/modules/explore/frontTour.dart';
import 'package:new_motel/modules/hotelBooking/roomPopupView.dart';
import 'package:new_motel/modules/profile/profile_page.dart';
import 'package:new_motel/service/apiService.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:new_motel/widget/customDrawer.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../appTheme.dart';
import '../../models/hotelListData.dart';
import '../explore/popularListView.dart';
import '../explore/titleView.dart';
import 'frontHome.dart';

class HomeExploreScreen extends StatefulWidget {
  final AnimationController animationController;
  final HomeData homeData;

  const HomeExploreScreen({Key key, this.animationController, this.homeData})
      : super(key: key);

  @override
  _HomeExploreScreenState createState() => _HomeExploreScreenState();
}

class _HomeExploreScreenState extends State<HomeExploreScreen>
    with TickerProviderStateMixin {
  AutoCompleteTextField searchTextField;
  GlobalKey<AutoCompleteTextFieldState<AllLocation>> key = new GlobalKey();

  var hotelList = HotelListData.hotelList;
  ScrollController controller;
  AnimationController _animationController;
  int room = 0;
  int ad = 1;
  int children = 0;
  String _currentWeather = "";
  bool apiCall = false;
  var checkInDate;
  var checkoutDate;

  // DateTime startDate = DateTime.now();
  // DateTime endDate = DateTime.now().add(Duration(days: 7));
  var sliderImageHieght = 0.0;
  // ignore: non_constant_identifier_names
  List<FrontLocation> fron_location;
  // ignore: non_constant_identifier_names
  List<AllLocation> all_location;
  // ignore: non_constant_identifier_names
  List<FrontHotel> front_hotel;
  // ignore: non_constant_identifier_names
  List<FrontTour> front_tour;
  bool loading = false;
  HomeData homeData;

  // ignore: non_constant_identifier_names
  String location_id;
  // ignore: non_constant_identifier_names
  String location_name;
  SharedPreferences sharedPreferences;
  TextEditingController _controller = TextEditingController();

  // my custom DatePicker.......

  DateTime _startDate = DateTime.now();
  DateTime _endDate = DateTime.now().add(Duration(days: 1));

  Future displayDateRangePicker(BuildContext context) async {
    // ignore: unused_local_variable
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    final List<DateTime> picked = await DateRagePicker.showDatePicker(
        context: context,
        initialFirstDate: _startDate,
        initialLastDate: _endDate,
        firstDate: new DateTime(DateTime.now().year - 50),
        lastDate: new DateTime(DateTime.now().year + 50));
    if (picked != null && picked.length == 2) {
      setState(() {
        _startDate = picked[0];
        _endDate = picked[1];

        // sharedPreferences.setString(CHECK_IN, DateFormat("dd/MM/yyyy").format(_startDate));
        // sharedPreferences.setString(CHECK_OUT, DateFormat("dd/MM/yyyy").format(_endDate));
      });
    }
  }

  Future<String> getJSONData() async {
    loading = true;
    var response = await http.get(ApiService.home_all_data);
    setState(() {
      loading = false;
      HomeData homeData = HomeData.fromJson(json.decode(response.body)[0]);
      fron_location = homeData.frontLocation;
      all_location = homeData.allLocation;
      front_hotel = homeData.frontHotel;
      front_tour = homeData.frontTour;
      // Get the JSON data
      print("fornt Location :${fron_location.length}");
      print("all Location :${all_location.length}");
      print("front hotel :${front_hotel.length}");
      print("front tour :${front_tour.length}");
    });
    //print(data);
    return "data";
  }

  String token;
  String profilePhoto;

  // ignore: missing_return
  Future<String> getToken() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    token = sharedPreferences.getString("token");

    profilePhoto = sharedPreferences.getString("photo");

    setState(() {});
    return null;
  }

  //   Future<String> getUserData() async {
  //   print("Get usewr daTA");
  //   // set User Data....>>>>
  //   SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

  //   print("SharedData>>>>${sharedPreferences.getString('photo')}");

  //   setState(() {});
  // }

  @override
  void initState() {
    //  getJSONData();
    _animationController =
        AnimationController(duration: Duration(milliseconds: 0), vsync: this);
    widget.animationController.forward();
    controller = ScrollController(initialScrollOffset: 0.0);

    controller.addListener(() {
      if (context != null) {
        if (controller.offset < 0) {
          // we static set the just below half scrolling values
          _animationController.animateTo(0.0);
        } else if (controller.offset > 0.0 &&
            controller.offset < sliderImageHieght) {
          // we need around half scrolling values
          if (controller.offset < ((sliderImageHieght / 0))) {
            _animationController
                .animateTo((controller.offset / sliderImageHieght));
          } else {
            // we static set the just above half scrolling values "around == 0.64"
            _animationController
                .animateTo((sliderImageHieght / 0) / sliderImageHieght);
          }
        }
      }
    });
    _startDate.toLocal();
    setState(() {
      getToken();
      setText();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    sliderImageHieght = MediaQuery.of(context).size.width * 0.8;
    homeData = widget.homeData;
    _controller.text = location_name;
    if (homeData == null) {
    } else {
      fron_location = homeData.frontLocation;
      front_hotel = homeData.frontHotel;
      front_tour = homeData.frontTour;
      all_location = homeData.allLocation;
      print("All Location ${homeData.allLocation.length}");
    }
    return AnimatedBuilder(
      animation: widget.animationController,
      builder: (BuildContext context, Widget child) {
        return FadeTransition(
          opacity: widget.animationController,
          // FadeTransition and Transform : just for screen loading animation on fistTime
          child: new Transform(
            transform: new Matrix4.translationValues(
                0.0, 60 * (1.0 - widget.animationController.value), 0.0),
            child: SafeArea(
              child: Scaffold(
                appBar: AppBar(
                  actions: [
                    InkWell(
                      onTap: () async {
                        SharedPreferences sharedPreferences =
                            await SharedPreferences.getInstance();
                        String token = sharedPreferences.getString("token");

                        if (token == null) {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => LoginWidget()));
                        } else {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ProfilePage(),
                              fullscreenDialog: true,
                            ),
                          );
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(right: 20),
                        child: CircleAvatar(
                          backgroundColor: Colors.grey[600],
                          radius: 20.0,
                          child: Center(
                            child: CircleAvatar(
                              backgroundColor: Colors.white,
                              radius: 17.0,
                              backgroundImage: profilePhoto == null
                                  ? AssetImage("assets/images/person.png")
                                  : NetworkImage(
                                      "https://vromonbuzz.com/" + profilePhoto),
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                  centerTitle: true,
                  title: RichText(
                    text: TextSpan(
                        text: DESHI,
                        style: TextStyle(
                          fontSize: 30,
                          fontFamily: 'Impact',
                          color: HexColor("#26408A"),
                        ),
                        children: <TextSpan>[
                          TextSpan(
                              text: TOUR,
                              style: TextStyle(
                                fontSize: 30,
                                fontFamily: 'Impact',
                                color: HexColor("#118ACB"),
                              )),
                        ]),
                  ),
                  iconTheme: IconThemeData(color: Colors.black),
                  backgroundColor: Colors.white,
                  elevation: 1,
                ),
                drawer: CustomDrawer(),
                backgroundColor: AppTheme.getTheme().backgroundColor,
                body: ListView(
                  shrinkWrap: true,
                  primary: false,
                  children: [
                    // SizedBox(height: 50),
                    // ClipRRect(
                    //   borderRadius: BorderRadius.circular(5),
                    //   child: Padding(
                    //     padding: EdgeInsets.only(left: 100, right: 100),
                    //     child: GestureDetector(
                    //       onTap: () {
                    //         Navigator.push(
                    //             context,
                    //             MaterialPageRoute(
                    //                 builder: (context) => HomeBottom(0)));
                    //       },
                    //       child: Container(
                    //         height: 50,
                    //         decoration: BoxDecoration(
                    //           border: Border.all(width: 0),
                    //           borderRadius: BorderRadius.circular(15),
                    //         ),
                    //         child: Row(
                    //           mainAxisAlignment: MainAxisAlignment.center,
                    //           crossAxisAlignment: CrossAxisAlignment.center,
                    //           children: [
                    //             Icon(Icons.hotel, size: 30),
                    //             SizedBox(width: 20),
                    //             Text(
                    //               "Hotels",
                    //               style: TextStyle(
                    //                   fontSize: 20,
                    //                   fontWeight: FontWeight.bold),
                    //             ),
                    //           ],
                    //         ),
                    //       ),
                    //     ),
                    //   ),
                    // ),
                    // SizedBox(height: 20),
                    // ClipRRect(
                    //   borderRadius: BorderRadius.circular(5),
                    //   child: Padding(
                    //     padding: EdgeInsets.only(left: 100, right: 100),
                    //     child: GestureDetector(
                    //       onTap: () {
                    //         Navigator.push(
                    //             context,
                    //             MaterialPageRoute(
                    //                 builder: (context) => HomeBottom(
                    //                   1,
                    //                 )));
                    //       },
                    //       child: Container(
                    //         height: 50,
                    //         decoration: BoxDecoration(
                    //           border: Border.all(width: 0),
                    //           borderRadius: BorderRadius.circular(15),
                    //         ),
                    //         child: Row(
                    //           mainAxisAlignment: MainAxisAlignment.center,
                    //           crossAxisAlignment: CrossAxisAlignment.center,
                    //           children: [
                    //             Icon(Icons.map_outlined, size: 30),
                    //             SizedBox(width: 20),
                    //             Text(
                    //               "Explore BD",
                    //               style: TextStyle(
                    //                   fontSize: 20,
                    //                   fontWeight: FontWeight.bold),
                    //             ),
                    //           ],
                    //         ),
                    //       ),
                    //     ),
                    //   ),
                    // ),
                    // SizedBox(height: 20),
                    // ClipRRect(
                    //   borderRadius: BorderRadius.circular(5),
                    //   child: Padding(
                    //     padding: EdgeInsets.only(left: 100, right: 100),
                    //     child: GestureDetector(
                    //       onTap: () {
                    //         Navigator.push(
                    //             context,
                    //             MaterialPageRoute(
                    //                 builder: (context) => HomeBottom(
                    //                   2,
                    //                 )));
                    //       },
                    //       child: Container(
                    //         height: 50,
                    //         decoration: BoxDecoration(
                    //           border: Border.all(width: 0),
                    //           borderRadius: BorderRadius.circular(15),
                    //         ),
                    //         child: Row(
                    //           mainAxisAlignment: MainAxisAlignment.center,
                    //           crossAxisAlignment: CrossAxisAlignment.center,
                    //           children: [
                    //             Padding(
                    //               padding: const EdgeInsets.only(right: 15.0),
                    //               child: Icon(Icons.tour_outlined, size: 35),
                    //             ),
                    //             SizedBox(width: 20),
                    //             Text(
                    //               "Tours",
                    //               style: TextStyle(
                    //                   fontSize: 20,
                    //                   fontWeight: FontWeight.bold),
                    //             ),
                    //           ],
                    //         ),
                    //       ),
                    //     ),
                    //   ),
                    // ),
                    //
                    // SizedBox(height: 20),

                    // Padding(
                    //   padding: const EdgeInsets.only
                    //   (left:10.0,right: 10,top: 10,bottom: 10),
                    //   child: Container(
                    //         child: Card(
                    //           shape: RoundedRectangleBorder(
                    //             borderRadius: new BorderRadius.circular(0.0),
                    //             side: BorderSide(color: HexColor("#fff201"), width: 3),
                    //           ),
                    //           color: Colors.white,
                    //           elevation: 10,
                    //           child: Column(
                    //             mainAxisSize: MainAxisSize.min,
                    //             children: <Widget>[
                    //               getDropDown(),
                    //               new Divider(
                    //                 thickness: 2,
                    //                 color: HexColor("#fff201"),
                    //               ),
                    //               getTimeDateUI(),
                    //               new Divider(
                    //                 thickness: 2,
                    //                 color: HexColor("#fff201"),
                    //               ),
                    //               getTimeUI(),
                    //               new Divider(
                    //                 thickness: 2,
                    //                 color: HexColor("#fff201"),
                    //               ),
                    //               ButtonTheme(
                    //                 buttonColor: HexColor("#ee3624"),
                    //                 height: 50,
                    //                 // ignore: deprecated_member_use
                    //                 child: RaisedButton(
                    //                   onPressed: () async {
                    //                     sharedPreferences =
                    //                         await SharedPreferences.getInstance();
                    //                     String locationId = sharedPreferences
                    //                         .getString(VromonBuzzPreference.LOCATION_ID);
                    //                     print("location id: $locationId");

                    //                     // ignore: unrelated_type_equality_checks

                    //                     if (locationId != null) {
                    //                       // Navigator.pushNamed(
                    //                       //   context,
                    //                       //   Routes.HoteList,
                    //                       //   arguments: RouteSettings(arguments: {
                    //                       //     'location_id': location_id,
                    //                       //     'checkin': checkInDate,
                    //                       //     'checkout': checkoutDate,
                    //                       //   }),
                    //                       // );
                    //                       Navigator.push(
                    //                         context,
                    //                         MaterialPageRoute(
                    //                             builder: (context) => HotelListHomeScreen(
                    //                                   from: HOME_SEARCH,
                    //                                   locaton_id: location_id,
                    //                                   locaton_name: location_name,
                    //                                   checkIn: checkInDate,
                    //                                   checkOut: checkoutDate,
                    //                                   isSearch: HOME_SEARCH,
                    //                                   allLocation: all_location,
                    //                                   location_property: null,
                    //                                   starCount: null,
                    //                                   locationId: int.parse(location_id),
                    //                                   room: room,
                    //                                   adults: ad,
                    //                                   child: children,
                    //                                 )),
                    //                       );
                    //                     } else {
                    //                       print(
                    //                           "Location_id $location_id $checkInDate $checkoutDate");
                    //                       final snackBar = SnackBar(
                    //                           content: Text("Please select a location "));
                    //                       ScaffoldMessenger.of(context)
                    //                           .showSnackBar(snackBar);
                    //                     }

                    //                     // MaterialPageRoute(
                    //                     //     builder: (context) => HomeExploreScreen(),
                    //                     // settings: RouteSettings(
                    //                     //     arguments: {
                    //                     //     'location_id':location_id,
                    //                     //     'checkin':checkInDate,
                    //                     //     'checkout':checkoutDate,
                    //                     //     }),
                    //                     // );
                    //                   },
                    //                   // child: new Text("Get Weather"),
                    //                   child: Row(
                    //                     mainAxisAlignment: MainAxisAlignment.center,
                    //                     children: <Widget>[
                    //                       Text(
                    //                         SEARCH,
                    //                         style: TextStyle(
                    //                             color: Colors.white,
                    //                             fontWeight: FontWeight.bold,
                    //                             fontSize: 20),
                    //                       ),
                    //                     ],
                    //                   ),
                    //                   // child: const Text('Search',
                    //                   //     style:
                    //                   //     TextStyle(fontSize: 20, color: Colors.white)
                    //                   // ),
                    //                 ),
                    //               )
                    //               /*const ListTile(
                    //          leading: Icon(Icons.search, size: 24),
                    //          title: Text('Heart Shaker', style: TextStyle(color: Colors.white)),

                    //        ),*/

                    //               // ButtonTheme.bar(
                    //               //   child: ButtonBar(
                    //               //     children: <Widget>[
                    //               //       FlatButton(
                    //               //         child: const Text('Edit', style: TextStyle(color: Colors.white)),
                    //               //         onPressed: () {},
                    //               //       ),
                    //               //       FlatButton(
                    //               //         child: const Text('Delete', style: TextStyle(color: Colors.white)),
                    //               //         onPressed: () {},
                    //               //       ),
                    //               //     ],
                    //               //   ),
                    //               // ),
                    //             ],
                    //           ),
                    //         ),
                    //       ),
                    // ),

                    Container(
                      color: AppTheme.getTheme().backgroundColor,
                      child: ListView.builder(
                        shrinkWrap: true,
                        primary: false,
                        controller: controller,
                        itemCount: 6,
                        // physics: NeverScrollableScrollPhysics(),
                        // padding on top is only for we need spec for sider

                        scrollDirection: Axis.vertical,
                        itemBuilder: (context, index) {
                          // some list UI
                          var count = 6;
                          var animation = Tween(begin: 0.0, end: 1.0).animate(
                            CurvedAnimation(
                              parent: widget.animationController,
                              curve: Interval((1 / count) * index, 1.0,
                                  curve: Curves.fastOutSlowIn),
                            ),
                          );
                          if (index == 0) {
                            return TitleView(
                              titleTxt: LOCATION,
                              subTxt: '',
                              animation: animation,
                              animationController: widget.animationController,
                            );
                          } else if (index == 1) {
                            return Padding(
                              padding: const EdgeInsets.only(top: 0),
                              child: PopularListView(
                                frontlocation: fron_location,
                                animationController: widget.animationController,
                                callBack: (index) {
                                  // LoaderPage().showInSnackBar(context, "null");
                                },
                              ),
                            );
                          } else if (index == 2) {
                            return TitleView(
                              titleTxt: TODAYS_TOP_HOTEL,
                              subTxt: '',
                              animation: animation,
                              animationController: widget.animationController,
                            );
                          } else if (index == 3) {
                            return Padding(
                              padding: const EdgeInsets.only(top: 0, left: 12),
                              child: Container(
                                height: 250,
                                child: FrontHome(
                                  frontlocation: front_hotel,
                                  animationController:
                                      widget.animationController,
                                  callBack: (index) {},
                                ),
                              ),
                            );
                          } else if (index == 4) {
                            return Padding(
                              padding: const EdgeInsets.only(top: 0),
                              child: TitleView(
                                titleTxt: EXPLORE_TOUR,
                                subTxt: '',
                                animation: animation,
                                animationController: widget.animationController,
                              ),
                            );
                          } else {
                            return Padding(
                              padding: const EdgeInsets.only(top: 0),
                              child: FrontTourView(
                                frontTour: front_tour,
                                animationController: widget.animationController,
                                callBack: (index) {},
                              ),
                            );
                          }
                          // else {
                          //   return Null;
                          // }
                        },
                      ),
                    ),
                    // sliderUI with 3 images are moving
                    // _sliderUI(),
                    //searchBox(_animationController),
                    // viewHotels Button UI for click event

                    //  _viewHotelsButton(_animationController),

                    //just gradient for see the time and battry Icon on "TopBar"
                    // Container(
                    //   height: 80,
                    //   decoration: BoxDecoration(
                    //       gradient: LinearGradient(
                    //     colors: [
                    //       AppTheme.getTheme().backgroundColor.withOpacity(0.4),
                    //       AppTheme.getTheme().backgroundColor.withOpacity(0.0),
                    //     ],
                    //     begin: Alignment.topCenter,
                    //     end: Alignment.bottomCenter,
                    //   )),
                    // ),

                    // serachUI on Top  Positioned
                    // Positioned(
                    //   //  height: MediaQuery.of(context).padding.right,
                    //   // top: MediaQuery.of(context).padding.top,
                    //   left: 0,
                    //   right: 0,
                    //   top: 20,
                    //   child: Center(
                    //     child: searchBox(_animationController),
                    //   ),
                    // )
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
  //
  // Widget searchBox(AnimationController animationController) {
  //   // ignore: unused_local_variable
  //   final size = MediaQuery.of(context).size;

  //   return AnimatedBuilder(
  //       animation: _animationController,
  //       builder: (BuildContext context, Widget child) {
  //         var opecity = 1.0 -
  //             (_animationController.value >
  //                     0.15 //search box opacity increase decrease
  //                 ? 1.0
  //                 : _animationController.value);
  //         return
  //       });
  // }
  // Widget _sliderUI() {
  //   return AnimatedBuilder(
  //     animation: _animationController,
  //     builder: (BuildContext context, Widget child) {
  //       // we calculate the opecity between 0.64 to 1.0
  //       // ignore: unused_local_variable
  //       var opecity = 1.0 -
  //           (_animationController.value > 0.0
  //               ? 1.0
  //               : _animationController.value);
  //       return SizedBox(
  //         height: sliderImageHieght * (1.0 - _animationController.value),

  //         child: Container(
  //           decoration: BoxDecoration(
  //             color: HexColor("#6fbe44"),
  //             // image: DecorationImage(
  //             //     image: AssetImage("assets/images/bg.jpg"),
  //             //     fit: BoxFit.cover)
  //             //color: popUpBackgroundColor,
  //           ),
  //         ),

  //         // child: HomeExploreSliderView(
  //         //    opValue: opecity,
  //         //    click: () {},
  //         //  ),
  //       );
  //     },
  //   );
  // }

  // Widget _viewHotelsButton(AnimationController _animationController) {
  //   return AnimatedBuilder(
  //     animation: _animationController,
  //     builder: (BuildContext context, Widget child) {
  //       var opecity = 1.0 -
  //           (_animationController.value > 0.6
  //               ? 1.0
  //               : _animationController.value);
  //       return Stack(
  //         children: <Widget>[
  //           Opacity(
  //             opacity: opecity,
  //             child: Container(
  //               height: 48,
  //               decoration: BoxDecoration(
  //                 color: AppTheme.getTheme().primaryColor,
  //                 borderRadius: BorderRadius.all(Radius.circular(24.0)),
  //                 boxShadow: <BoxShadow>[
  //                   BoxShadow(
  //                     color: AppTheme.getTheme().dividerColor,
  //                     blurRadius: 8,
  //                     offset: Offset(4, 4),
  //                   ),
  //                 ],
  //               ),
  //               child: Material(
  //                 color: Colors.transparent,
  //                 child: InkWell(
  //                   borderRadius: BorderRadius.all(Radius.circular(24.0)),
  //                   highlightColor: Colors.transparent,
  //                   onTap: () {
  //                     if (opecity != 0) {
  //                       Navigator.push(
  //                         context,
  //                         MaterialPageRoute(
  //                             builder: (context) => HotelHomeScreen()),
  //                       );
  //                     }
  //                   },
  //                   child: Center(
  //                     child: Padding(
  //                       padding: const EdgeInsets.all(0),
  //                       child: Text(
  //                         VIEW_HOTELS,
  //                         style: TextStyle(
  //                             fontWeight: FontWeight.w500,
  //                             fontSize: 16,
  //                             color: Colors.white),
  //                       ),
  //                     ),
  //                   ),
  //                 ),
  //               ),
  //             ),
  //           ),
  //         ],
  //       );
  //     },
  //   );
  // }

  // Widget getDealListView(int index) {
  //   // var hotelList = HotelListData.hotelList;
  //   List<Widget> list = [];
  //   hotelList.forEach((f) {
  //     // ignore: unused_local_variable
  //     var animation = Tween(begin: 0.0, end: 1.0).animate(
  //       CurvedAnimation(
  //         parent: widget.animationController,
  //         curve: Interval(0, 1.0, curve: Curves.fastOutSlowIn),
  //       ),
  //     );
  //     // list.add(
  //     //   HotelListView(
  //     //     callback: () {
  //     //       Navigator.push(
  //     //         context,
  //     //         MaterialPageRoute(
  //     //             builder: (context) => HotelDetailes(
  //     //                   hotelData: hotelList[index],
  //     //                 ),
  //     //             fullscreenDialog: true),
  //     //       );
  //     //     },
  //     //     hotelData: f,
  //     //     animation: animation,
  //     //     animationController: widget.animationController,
  //     //   ),
  //     // );
  //   });
  //   return Padding(
  //     padding: const EdgeInsets.only(top: 8),
  //     child: Column(
  //       mainAxisAlignment: MainAxisAlignment.start,
  //       children: list,
  //     ),
  //   );
  // }

  // Search Box Method

  Widget getTimeDateUI() {
    final f = new DateFormat('dd/MM/yyyy');
    checkInDate = f.format(_startDate);
    checkoutDate = f.format(_endDate);
    // ignore: unnecessary_brace_in_string_interps
    print("date ${checkInDate} ${checkoutDate}");
    return Container(
      child: Row(
        children: <Widget>[
          Column(
            children: <Widget>[
              Material(
                color: Colors.transparent,
                child: InkWell(
                  focusColor: Colors.transparent,
                  highlightColor: Colors.transparent,
                  hoverColor: Colors.transparent,
                  splashColor: Colors.black.withOpacity(0.2),
                  borderRadius: BorderRadius.all(
                    Radius.circular(4.0),
                  ),
                  onTap: () {
                    FocusScope.of(context).requestFocus(FocusNode());
                    // setState(() {
                    //   isDatePopupOpen = true;
                    // });
                    // showDemoDialog(context: context);
                  },
                  child: Container(
                    alignment: Alignment.topLeft,
                    padding: const EdgeInsets.only(
                        left: 16, right: 0, top: 4, bottom: 4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Icon(
                          Icons.calendar_today_outlined,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width: 16,
                        ),
                        GestureDetector(
                          onTap: () async {
                            await displayDateRangePicker(context);
                          },
                          child: Text(
                            "${DateFormat("dd, MMM").format(_startDate)} - ${DateFormat("dd, MMM").format(_endDate)}",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: Colors.black),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),

          // Padding(
          //   padding: EdgeInsets.only(right: 8),
          //   child: Container(
          //     width: 1,
          //     height: 42,
          //     color: Colors.white,
          //   ),
          // ),
        ],
      ),
    );
  }

  Widget getTimeUI() {
    return Container(
      padding: const EdgeInsets.only(left: 0, bottom: 0),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Column(
              children: <Widget>[
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    focusColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    hoverColor: Colors.transparent,
                    splashColor: Colors.black,
                    borderRadius: BorderRadius.all(
                      Radius.circular(4.0),
                    ),
                    onTap: () {
                      FocusScope.of(context).requestFocus(FocusNode());
                      showDialog(
                        context: context,
                        builder: (BuildContext context) => RoomPopupView(
                          ad: ad,
                          room: room,
                          ch: children,
                          barrierDismissible: true,
                          onChnage: (ro, a, c) {
                            setState(() {
                              room = ro;
                              ad = a;
                              children = c;
                            });
                          },
                        ),
                      );
                    },
                    child: Container(
                      alignment: Alignment.topLeft,
                      padding: const EdgeInsets.only(
                          left: 15, top: 4.0, right: 0.0, bottom: 4.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Icon(
                            Icons.person_rounded,
                            color: Colors.black,
                          ),
                          SizedBox(
                            width: 16,
                          ),
                          Text(
                            " $ad $ADULTS - $children $CHILDREN",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: Colors.black),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Padding(
          //   padding: EdgeInsets.only(right: 8),
          //   child: Container(
          //     width: 1,
          //     height: 42,
          //     color: Colors.white,
          //   ),
          // ),
        ],
      ),
    );
  }

  // Widget row(Location user) {
  //   return Row(
  //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //     children: <Widget>[
  //       Text(
  //         user.name,
  //         style: TextStyle(fontSize: 16.0),
  //       ),
  //       SizedBox(
  //         width: 10.0,
  //       ),
  //       Text(
  //         user.email,
  //       ),
  //     ],
  //   );
  // }
  Widget getDropDown() {
    print("Location Id: $location_id");
    print("Location Name: $location_name");

    print("object");
    return Container(
      alignment: Alignment.center,
      width: MediaQuery.of(context).size.width,
      color: Colors.transparent,
      padding: EdgeInsets.all(4.0),
      // child: DropdownButtonHideUnderline(
      //   child: DropdownButton<String>(
      //       items: hoteslData.map((String val) {
      //         return DropdownMenuItem<String>(
      //           value: _dropDownValue,
      //           child: Container(
      //               margin: EdgeInsets.only(left: 10.0, right: 10.0),
      //               child: Text(val)),
      //         );
      //       }).toList(),
      //       hint: Text(
      //         "Where are you going?",
      //         style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),
      //       ),
      //       onChanged: (String val) {
      //         _dropDownValue = val;
      //         setState(() {
      //           _dropDownValue = val;
      //           // _dropDownValue = hoteslData[val];
      //           print("onChanged Value : " + _dropDownValue);
      //         });
      //       }),
      // ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          all_location == null
              ? CircularProgressIndicator()
              : searchTextField = AutoCompleteTextField<AllLocation>(
                  controller: _controller,
                  key: key,
                  clearOnSubmit: false,
                  suggestions: all_location,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 16.0,
                      fontWeight: FontWeight.bold),
                  // decoration: InputDecoration(
                  //   // border: new OutlineInputBorder(
                  //   //   borderRadius: const BorderRadius.all(
                  //   //     const Radius.circular(10.0),
                  //   //   ),
                  //   // ),
                  //   border: OutlineInputBorder(
                  //     borderRadius: BorderRadius.circular(8),
                  //     borderSide: BorderSide(
                  //       width: 0,
                  //       style: BorderStyle.none,
                  //     ),
                  //   ),
                  //   filled: true,
                  //   contentPadding: EdgeInsets.all(16),
                  //   fillColor: Colors.grey,
                  //  // contentPadding: EdgeInsets.fromLTRB(30.0, 30.0, 30.0, 20.0),
                  //   hintText: "Search Name",
                  //   hintStyle: new TextStyle(color: Colors.white),
                  // ),
                  decoration: new InputDecoration(
                    prefixIcon: Icon(
                      Icons.search,
                      color: Colors.black,
                      size: 20,
                    ),
                    hintText: WHERE_ARE_YOU_GOING,
                    hintStyle: new TextStyle(color: Colors.greenAccent),

                    enabledBorder: InputBorder.none,
                    disabledBorder: InputBorder.none,
                    // focusedBorder: OutlineInputBorder(
                    //   borderRadius: BorderRadius.all(Radius.circular(4.0)),
                    //   borderSide: BorderSide(color: Colors.blue),
                    // ),
                  ),
                  itemFilter: (item, query) {
                    return item.location
                        .toLowerCase()
                        .startsWith(query.toLowerCase());
                  },
                  itemSorter: (a, b) {
                    return a.location.compareTo(b.location);
                  },
                  itemSubmitted: (item) {
                    setState(() async {
                      searchTextField.textField.controller.text = item.location;
                      location_id = item.id;
                      location_name = item.location;
                      // Location().locationId=location_id;
                      // Location().locaton_name =location_name;
                      SharedPreferences sharedPreferences =
                          await SharedPreferences.getInstance();
                      sharedPreferences.setString(
                          DeshiTourPreference.LOCATION_ID, location_id);
                      sharedPreferences.setString(
                          DeshiTourPreference.LOCATION_NAME, location_name);

                      print("Location  Id -> ${item.id}");
                    });
                  },
                  itemBuilder: (context, item) {
                    // ui for the autocompelete row
                    return row(item);
                  },
                ),
        ],
      ),
    );
  }

  // void showDemoDialog({BuildContext context}) {
  //   showDialog(
  //     context: context,
  //     builder: (BuildContext context) => CalendarPopupView(
  //       barrierDismissible: true,
  //       minimumDate: DateTime.now(),
  //       //  maximumDate: DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day + 10),
  //       initialEndDate: endDate,
  //       initialStartDate: startDate,
  //       onApplyClick: (DateTime startData, DateTime endData) {
  //         setState(() {
  //           if (startData != null && endData != null) {
  //             startDate = startData;
  //             endDate = endData;
  //           }
  //         });
  //       },
  //       onCancelClick: () {},
  //     ),
  //   );
  // }

  Widget row(AllLocation item) {
    return Container(
      height: 40,
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
              item != null ? item.location : LOCATION_NOT_FOUND,
              style: TextStyle(fontSize: 18.0, color: Colors.black),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(item != null ? item.country : " ",
                style: TextStyle(
                  fontSize: 18.0,
                  color: Colors.black,
                )),
          )
        ],
      ),
    );
  }

  Widget dataNOtAvailable(String item) {
    return Container(
      height: 40,
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
              item,
              style: TextStyle(fontSize: 18.0, color: Colors.black),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Icon(
              Icons.error,
              color: Colors.red,
            ),
          ),
        ],
      ),
    );
  }

  Widget getProperWidget() {
    if (apiCall)
      return new CircularProgressIndicator();
    else
      return new Text(
        '$_currentWeather',
        // ignore: deprecated_member_use
        style: Theme.of(context).textTheme.display1,
      );
  }

  // Future<HotelList> fetchAlbum() async {
  //   final response = await http.get(ApiService.hotelSearch +
  //       "&checkin=$checkInDate&checkout=$checkoutDate&searching=$location_id");
  //   if (response.statusCode == 200) {
  //     // If the server did return a 200 OK response,
  //     // then parse the JSON.
  //     return HotelList.fromJson(jsonDecode(response.body));
  //   } else {
  //     // If the server did not return a 200 OK response,
  //     // then throw an exception.
  //     throw Exception('Failed to load album');
  //   }
  // }

  // ignore: unused_element
  // void _callWeatherApi() {
  //   var api = new Services();
  //   api.getJSONData(checkInDate, checkoutDate, location_id).then((weather) {
  //     setState(() {
  //       apiCall = false; //Disable Progressbar
  //       _currentWeather = weather.toString();
  //     });
  //   }, onError: (error) {
  //     setState(() {
  //       apiCall = false; //Disable Progressbar
  //       _currentWeather = error.toString();
  //     });
  //   });
  // }

  Future<void> setText() async {
    sharedPreferences = await SharedPreferences.getInstance();
    location_id = sharedPreferences.getString(DeshiTourPreference.LOCATION_ID);
    location_name =
        sharedPreferences.getString(DeshiTourPreference.LOCATION_NAME);

    setState(() {});
  }
}
