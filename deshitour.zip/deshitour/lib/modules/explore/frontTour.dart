import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:new_motel/models/home/home.dart';
import 'package:new_motel/tourBooking/tourDetails.dart';
import 'package:new_motel/utils/constants.dart';


class FrontTourView extends StatefulWidget {
  final Function(int) callBack;
  final AnimationController animationController;
  final List<FrontTour> frontTour;

  const FrontTourView(
      {Key key, this.callBack, this.animationController, this.frontTour})
      : super(key: key);

  @override
  FrontTourViewList createState() => FrontTourViewList();
}

class FrontTourViewList extends State<FrontTourView>
    with TickerProviderStateMixin {
  AnimationController animationController;
  List<FrontTour> homeFront;

  @override
  void initState() {
    animationController = AnimationController(
        duration: Duration(milliseconds: 1000), vsync: this);
    super.initState();
  }

  Future<bool> getData() async {
    await Future.delayed(const Duration(milliseconds: 50));
    return true;
  }

  @override
  Widget build(BuildContext context) {
    MediaQueryData queryData;
    queryData = MediaQuery.of(context);
    homeFront = widget.frontTour;
    return AnimatedBuilder(
      animation: widget.animationController,
      builder: (BuildContext context, Widget child) {
        return FadeTransition(
          opacity: widget.animationController,
          child: new Transform(
            transform: new Matrix4.translationValues(
                0.0, 40 * (1.0 - widget.animationController.value), 0.0),
            child: Container(
              height: queryData.size.height / 2.8,
              width: double.infinity,
              child: FutureBuilder(
                future: getData(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return SizedBox();
                  } else {
                    return homeFront == null
                        ? Center(child: CircularProgressIndicator())
                        : ListView.separated(
                            separatorBuilder:
                                (BuildContext context, int index) => Divider(),
                            itemCount: homeFront.length,
                            scrollDirection: Axis.horizontal,
                            itemBuilder: (context, index) {
                              var count =
                                  homeFront.length > 10 ? 10 : homeFront.length;
                              var animation = Tween(begin: 0.0, end: 1.0)
                                  .animate(CurvedAnimation(
                                      parent: animationController,
                                      curve: Interval((1 / count) * index, 1.0,
                                          curve: Curves.fastOutSlowIn)));
                              Padding(
                                padding: EdgeInsets.all(10),
                              );
                              animationController.forward();
                              return FrontTourList(
                                popularList: homeFront[index],
                                animation: animation,
                                animationController: animationController,
                                callback: () {
                                  widget.callBack(index);
                                },
                              );
                            },
                          );
                  }
                },
              ),
            ),
          ),
        );
      },
    );
  }
}

class FrontTourList extends StatelessWidget {
  final VoidCallback callback;
  final FrontTour popularList;
  final AnimationController animationController;
  final Animation animation;

  const FrontTourList(
      {Key key,
      this.popularList,
      this.animationController,
      this.animation,
      this.callback})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final _LOADING_IMAGE = 'assets/images/bp_loading.gif';

    final _LOCATION_ICON = 'assets/icons/bp_location_icon.svg';
    final _STAR_ICON = 'assets/icons/price_tag.svg';
    final _bodTitleTextStyle = Theme.of(context)
        .textTheme
        .headline5
        .copyWith(color: kPrimaryDarkenColor, fontWeight: FontWeight.w500);
    final _bodBody2TextStyle = Theme.of(context).textTheme.bodyText2;
    final _bodBody1TextStyle = Theme.of(context).textTheme.bodyText1;
    MediaQueryData queryData;
    queryData = MediaQuery.of(context);

    return Padding(
      padding: const EdgeInsets.only(left: 12.0, top: 6),
      child: ClipRRect(
        borderRadius: new BorderRadius.only(
          topLeft: const Radius.circular(26.0),
          topRight: const Radius.circular(26.0),
          bottomLeft: const Radius.circular(20.0),
          bottomRight: const Radius.circular(20.0),
        ),
        child: Card(
          elevation: 0,
          child: Container(
              height: 200,
              width: 300,
              decoration: BoxDecoration(boxShadow: [
                BoxShadow(
                    offset: Offset(0, 10), blurRadius: 50, color: kShadowColor)
              ]),
              child: Column(
                children: [
                  Padding(
                      //padding: EdgeInsets.all(3),
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: ClipRRect(
                        child: Stack(
                          children: [
                            GestureDetector(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => TourDetails(
                                        tour: popularList.id,
                                      ),
                                    ));
                              },
                              child: AspectRatio(
                                aspectRatio: 2,
                                child: Image.network(
                                  popularList.thumbnail,
                                  fit: BoxFit.cover,
                                  loadingBuilder: (BuildContext context,
                                      Widget child,
                                      ImageChunkEvent loadingProgress) {
                                    if (loadingProgress == null) return child;
                                    return Center(
                                      child: CircularProgressIndicator(
                                        value: loadingProgress
                                                    .expectedTotalBytes !=
                                                null
                                            ? loadingProgress
                                                    .cumulativeBytesLoaded /
                                                loadingProgress
                                                    .expectedTotalBytes
                                            : null,
                                      ),
                                    );
                                  },
                                  // IMAGE_URL+popularList.thumbnail,
                                  // fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ],
                        ),
                      )),
                  Padding(
                    padding: EdgeInsets.fromLTRB(10, 2.0, 0.0, 2.0),
                    child: Container(
                        decoration: BoxDecoration(),
                        child: new Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 4,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 0.0, top: 0.0, right: 0.0, bottom: 0.0),
                              child: Text(popularList.title,
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                  )),
                            ),
                            SizedBox(
                              height: 8,
                            ),
                            Row(
                              children: [
                                Padding(
                                  padding: EdgeInsets.fromLTRB(0.0, 0, 0, 0),
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                      padding: const EdgeInsets.only(
                                          left: 0.0,
                                          top: 0.0,
                                          right: 0.0,
                                          bottom: 0.0),
                                      child: Text(popularList.tourType,
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w100,
                                          )),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.only(left: 30),
                                  child: RichText(
                                      text: TextSpan(children: [
                                    TextSpan(
                                        text:
                                            "${popularList.currCode} ${popularList.price}",
                                        style: TextStyle(
                                          fontSize: 14,
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                        )),

                                    // TextSpan(text: ' km', style: TextStyle(fontWeight: Fo)),
                                  ])),
                                ),
                              ],
                            ),
                          ],
                        )),
                  ),
                ],
              )),
        ),
      ),
    );
  }
}
