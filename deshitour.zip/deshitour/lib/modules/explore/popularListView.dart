// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/material.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import 'package:new_motel/models/home/home.dart';
// import 'package:new_motel/modules/hotelBooking/hotelListHomeScreen.dart';
// import 'package:new_motel/modules/hotelDetailes/hotelDetailes.dart';
// import 'package:new_motel/utils/constants.dart';
// import '../../appTheme.dart';
// import '../../models/hotelListData.dart';
//
// class PopularListView extends StatefulWidget {
//   final Function(int) callBack;
//   final AnimationController animationController;
//   final List<FrontLocation> frontlocation;
//   const PopularListView(
//       {Key key, this.callBack, this.animationController, this.frontlocation})
//       : super(key: key);
//
//   @override
//   _PopularListViewState createState() => _PopularListViewState();
// }
//
// class _PopularListViewState extends State<PopularListView>
//     with TickerProviderStateMixin {
//   AnimationController animationController;
//   List<FrontLocation> frontlocation;
//
//   @override
//   void initState() {
//     animationController = AnimationController(
//         duration: Duration(milliseconds: 1000), vsync: this);
//
//     super.initState();
//   }
//
//   Future<bool> getData() async {
//     await Future.delayed(const Duration(milliseconds: 50));
//     return true;
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     frontlocation = widget.frontlocation;
//     return AnimatedBuilder(
//       animation: widget.animationController,
//       builder: (BuildContext context, Widget child) {
//         return FadeTransition(
//           opacity: widget.animationController,
//           child: new Transform(
//             transform: new Matrix4.translationValues(
//                 0.0, 40 * (1.0 - widget.animationController.value), 0.0),
//             child: Container(
//               height: MediaQuery.of(context).size.height / 5.5,
//               width: double.infinity,
//               child: FutureBuilder(
//                 future: getData(),
//                 builder: (context, snapshot) {
//                   if (!snapshot.hasData) {
//                     return SizedBox();
//                   } else {
//                     return frontlocation == null
//                         ? Center(child: CircularProgressIndicator())
//                         : ListView.builder(
//                             padding: const EdgeInsets.only(
//                                 top: 0, bottom: 4, right: 0, left: 8),
//                             itemCount: frontlocation.length,
//                             scrollDirection: Axis.horizontal,
//                             itemBuilder: (context, index) {
//                               var count = frontlocation.length > 10
//                                   ? 10
//                                   : frontlocation.length;
//                               var animation = Tween(begin: 0.0, end: 1.0)
//                                   .animate(CurvedAnimation(
//                                       parent: animationController,
//                                       curve: Interval((1 / count) * index, 1.0,
//                                           curve: Curves.fastOutSlowIn)));
//                               animationController.forward();
//                               return CategoryView(
//                                 popularList: frontlocation[index],
//                                 animation: animation,
//                                 animationController: animationController,
//                                 callback: () {
//                                   widget.callBack(index);
//                                 },
//                               );
//                             },
//                           );
//                   }
//                 },
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }
// }
//
// class CategoryView extends StatelessWidget {
//   final VoidCallback callback;
//   final FrontLocation popularList;
//   final AnimationController animationController;
//   final Animation animation;
//
//   const CategoryView(
//       {Key key,
//       this.popularList,
//       this.animationController,
//       this.animation,
//       this.callback})
//       : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return AnimatedBuilder(
//       animation: animationController,
//       builder: (BuildContext context, Widget child) {
//         return FadeTransition(
//           opacity: animation,
//           child: new Transform(
//             transform: new Matrix4.translationValues(
//                 100 * (1.0 - animation.value), 0.0, 0.0),
//             child: InkWell(
//               splashColor: Colors.transparent,
//               onTap: () {
//                 Navigator.push(
//                     context,
//                     MaterialPageRoute(
//                       builder: (context) => HotelListHomeScreen(
//                         isSearch: 2,
//                         locationId: int.parse(popularList.id),
//                       ),
//                     ));
//               },
//               child: Padding(
//                 padding: const EdgeInsets.only(
//                     left: 0, bottom: 5, top: 10, right: 8),
//                 child: Container(
//                   decoration: BoxDecoration(
//                     borderRadius: BorderRadius.all(Radius.circular(16.0)),
//                     boxShadow: <BoxShadow>[
//                       BoxShadow(
//                         color: AppTheme.getTheme().dividerColor,
//                         offset: Offset(4, 4),
//                         blurRadius: 16,
//                       ),
//                     ],
//                   ),
//                   child: ClipRRect(
//                     borderRadius: BorderRadius.all(Radius.circular(5.0)),
//                     child: Stack(
//                       children: <Widget>[
//                         AspectRatio(
//                           aspectRatio: 2,
//                           child: Image.network(
//                             IMAGE_URL + popularList.thumbnail,
//                             fit: BoxFit.cover,
//                             loadingBuilder: (BuildContext context, Widget child,
//                                 ImageChunkEvent loadingProgress) {
//                               if (loadingProgress == null) return child;
//                               return Center(
//                                 child: CircularProgressIndicator(
//                                   value: loadingProgress.expectedTotalBytes !=
//                                           null
//                                       ? loadingProgress.cumulativeBytesLoaded /
//                                           loadingProgress.expectedTotalBytes
//                                       : null,
//                                 ),
//                               );
//                             },
//                             // IMAGE_URL+popularList.thumbnail,
//                             // fit: BoxFit.cover,
//                           ),
//                         ),
//                         Positioned(
//                           top: 0,
//                           left: 0,
//                           right: 0,
//                           child: Column(
//                             mainAxisAlignment: MainAxisAlignment.start,
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: <Widget>[
//                               Padding(
//                                 padding: const EdgeInsets.only(
//                                     left: 8, bottom: 0, top: 8),
//                                 child: Text(
//                                   popularList.location,
//                                   textAlign: TextAlign.right,
//                                   style: TextStyle(
//                                     fontWeight: FontWeight.w600,
//                                     fontSize: 22,
//                                     color: AppTheme.getTheme().backgroundColor,
//                                   ),
//                                 ),
//                               ),
//                               Row(
//                                 crossAxisAlignment: CrossAxisAlignment.center,
//                                 mainAxisAlignment: MainAxisAlignment.start,
//                                 children: <Widget>[
//                                   Padding(
//                                     padding: const EdgeInsets.only(
//                                         left: 8, bottom: 0, top: 0),
//                                     child: Text(
//                                       popularList.property + PROPERTY,
//                                       style: TextStyle(
//                                         fontSize: 16,
//                                         fontWeight: FontWeight.w100,
//                                         color:
//                                             AppTheme.getTheme().backgroundColor,
//                                       ),
//                                     ),
//                                   ),
//
//                                   // SizedBox(
//                                   //   width: 4,
//                                   // ),
//                                   // Icon(
//                                   //   FontAwesomeIcons.mapMarkerAlt,
//                                   //   size: 12,
//                                   //   color: AppTheme.getTheme().primaryColor,
//                                   // ),
//                                 ],
//                               ),
//                             ],
//                           ),
//                           // Expanded(
//                           //   child: Container(
//                           //
//                           //     decoration: BoxDecoration(
//                           //       gradient: LinearGradient(
//                           //         colors: [
//                           //           AppTheme.getTheme()
//                           //               .dividerColor
//                           //               .withOpacity(0.4),
//                           //           AppTheme.getTheme()
//                           //               .dividerColor
//                           //               .withOpacity(0.0),
//                           //         ],
//                           //         begin: Alignment.topCenter,
//                           //         end: Alignment.bottomCenter,
//                           //       ),
//                           //     ),
//                           //     child: Padding(
//                           //       padding: const EdgeInsets.only(
//                           //           left: 8, bottom: 32, top: 8),
//                           //       child: Text(
//                           //         popularList.location,
//                           //         style: TextStyle(
//                           //           fontWeight: FontWeight.w600,
//                           //           fontSize: 24,
//                           //           color:
//                           //               AppTheme.getTheme().backgroundColor,
//                           //         ),
//                           //       ),
//                           //     ),
//                           //   ),
//                           // ),
//                         ),
//                         Positioned(
//                           top: 80,
//                           //left: 110,
//                           right: 10,
//                           child: Container(
//                             // width: 170,
//                             color: Colors.black.withOpacity(0.5),
//
//                             child: Column(
//                               //crossAxisAlignment: CrossAxisAlignment.center,
//                               // mainAxisAlignment: MainAxisAlignment.start,
//
//                               children: [
//                                 Padding(
//                                   padding: const EdgeInsets.all(4),
//                                   child: Text(
//                                     "Average Price "
//                                     "BDT ${popularList.avgPrice ?? "nan"}",
//                                     style: TextStyle(
//                                         fontSize: 13,
//                                         fontWeight: FontWeight.normal,
//                                         color: Colors.white),
//                                   ),
//                                 ),
//                                 Padding(
//                                   padding: const EdgeInsets.only(
//                                       left: 32, bottom: 4, top: 0, right: 0),
//                                   // child: Text(
//                                   //   "BDT ${popularList.avgPrice??"nan"}",
//                                   //   style: TextStyle(
//                                   //     fontSize: 16,
//                                   //     fontWeight: FontWeight.bold,
//                                   //     color:  Colors.orange,
//                                   //
//                                   //   ),
//                                   // ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:new_motel/models/home/home.dart';
import 'package:new_motel/modules/hotelBooking/hotelListHomeScreen.dart';
import 'package:new_motel/utils/constants.dart';

import '../../appTheme.dart';

class PopularListView extends StatefulWidget {
  final Function(int) callBack;
  final AnimationController animationController;
  final List<FrontLocation> frontlocation;
  const PopularListView(
      {Key key, this.callBack, this.animationController, this.frontlocation})
      : super(key: key);

  @override
  _PopularListViewState createState() => _PopularListViewState();
}

class _PopularListViewState extends State<PopularListView>
    with TickerProviderStateMixin {
  AnimationController animationController;
  List<FrontLocation> frontlocation;

  @override
  void initState() {
    animationController = AnimationController(
        duration: Duration(milliseconds: 1000), vsync: this);

    super.initState();
  }

  Future<bool> getData() async {
    await Future.delayed(const Duration(milliseconds: 50));
    return true;
  }

  @override
  Widget build(BuildContext context) {
    frontlocation = widget.frontlocation;
    return AnimatedBuilder(
      animation: widget.animationController,
      builder: (BuildContext context, Widget child) {
        return FadeTransition(
          opacity: widget.animationController,
          child: new Transform(
            transform: new Matrix4.translationValues(
                0.0, 40 * (1.0 - widget.animationController.value), 0.0),
            child: Container(
              height: MediaQuery.of(context).size.height / 5.4,
              width: double.infinity,
              child: FutureBuilder(
                future: getData(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return SizedBox();
                  } else {
                    return frontlocation == null
                        ? Center(child: CircularProgressIndicator())
                        : ListView.builder(
                            shrinkWrap: true,
                            primary: false,
                            physics: BouncingScrollPhysics(),
                            padding: const EdgeInsets.all(0),
                            itemCount: frontlocation.length,
                            scrollDirection: Axis.horizontal,
                            itemBuilder: (context, index) {
                              var count = frontlocation.length > 10
                                  ? 10
                                  : frontlocation.length;
                              var animation = Tween(begin: 0.0, end: 1.0)
                                  .animate(CurvedAnimation(
                                      parent: animationController,
                                      curve: Interval((1 / count) * index, 1.0,
                                          curve: Curves.fastOutSlowIn)));
                              animationController.forward();
                              return CategoryView(
                                popularList: frontlocation[index],
                                animation: animation,
                                animationController: animationController,
                                callback: () {
                                  widget.callBack(index);
                                },
                              );
                            },
                          );
                  }
                },
              ),
            ),
          ),
        );
      },
    );
  }
}

class CategoryView extends StatelessWidget {
  final VoidCallback callback;
  final FrontLocation popularList;
  final AnimationController animationController;
  final Animation animation;

  const CategoryView(
      {Key key,
      this.popularList,
      this.animationController,
      this.animation,
      this.callback})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 20.0, right: 5),
      child: AnimatedBuilder(
        animation: animationController,
        builder: (BuildContext context, Widget child) {
          return FadeTransition(
            opacity: animation,
            child: new Transform(
              transform: new Matrix4.translationValues(
                  100 * (1.0 - animation.value), 0.0, 0.0),
              child: InkWell(
                splashColor: Colors.transparent,
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => HotelListHomeScreen(
                          from: POPULAR_SEARCH,
                          isSearch: 1,
                          locationId: int.parse(popularList.id),
                        ),
                      ));
                },

                // Maing Box Fields

                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(14.0)),
                    boxShadow: <BoxShadow>[
                      BoxShadow(
                        color: AppTheme.getTheme().dividerColor,
                        offset: Offset(4, 4),
                        blurRadius: 16,
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(16)), //5.0
                    child: Stack(
                      children: <Widget>[
                        Center(
                          child: Container(
                            child: AspectRatio(
                              aspectRatio: 2,
                              child: Image.network(
                                IMAGE_URL + popularList.thumbnail,
                                fit: BoxFit.cover,
                                loadingBuilder: (BuildContext context,
                                    Widget child,
                                    ImageChunkEvent loadingProgress) {
                                  if (loadingProgress == null) return child;
                                  return Center(
                                    child: CircularProgressIndicator(
                                      value: loadingProgress
                                                  .expectedTotalBytes !=
                                              null
                                          ? loadingProgress
                                                  .cumulativeBytesLoaded /
                                              loadingProgress.expectedTotalBytes
                                          : null,
                                    ),
                                  );
                                },
                                // IMAGE_URL+popularList.thumbnail,
                                // fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),

                        // Location Field
                        Positioned(
                          top: 0,
                          left: 0,
                          right: 0,

                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.only(
                                    left: 8, bottom: 0, top: 8),
                                child: Text(
                                  popularList.location,
                                  textAlign: TextAlign.right,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 22,
                                    color: AppTheme.getTheme().backgroundColor,
                                  ),
                                ),
                              ),

                              // Property Field
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 8, bottom: 0, top: 0),
                                    child: Text(
                                      popularList.property + PROPERTY,
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w100,
                                        color:
                                            AppTheme.getTheme().backgroundColor,
                                      ),
                                    ),
                                  ),

                                  // SizedBox(
                                  //   width: 4,
                                  // ),
                                  // Icon(
                                  //   FontAwesomeIcons.mapMarkerAlt,
                                  //   size: 12,
                                  //   color: AppTheme.getTheme().primaryColor,
                                  // ),
                                ],
                              ),
                            ],
                          ),
                          // Expanded(
                          //   child: Container(
                          //
                          //     decoration: BoxDecoration(
                          //       gradient: LinearGradient(
                          //         colors: [
                          //           AppTheme.getTheme()
                          //               .dividerColor
                          //               .withOpacity(0.4),
                          //           AppTheme.getTheme()
                          //               .dividerColor
                          //               .withOpacity(0.0),
                          //         ],
                          //         begin: Alignment.topCenter,
                          //         end: Alignment.bottomCenter,
                          //       ),
                          //     ),
                          //     child: Padding(
                          //       padding: const EdgeInsets.only(
                          //           left: 8, bottom: 32, top: 8),
                          //       child: Text(
                          //         popularList.location,
                          //         style: TextStyle(
                          //           fontWeight: FontWeight.w600,
                          //           fontSize: 24,
                          //           color:
                          //               AppTheme.getTheme().backgroundColor,
                          //         ),
                          //       ),
                          //     ),
                          //   ),
                          // ),
                        ),

                        // Average Field
                        Positioned(
                          top: 100,
                          //left: 110,
                          right: 10,
                          child: Container(
                            // width: 170,
                            color: Colors.black.withOpacity(0.5),

                            child: Column(
                              //crossAxisAlignment: CrossAxisAlignment.center,
                              // mainAxisAlignment: MainAxisAlignment.start,

                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(4),
                                  child: Text(
                                    "$AVERAGE_PRICE BDT ${popularList.avgPrice ?? "nan"}",
                                    style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.normal,
                                        color: Colors.white),
                                  ),
                                ),
                                // Padding(
                                //   padding: const EdgeInsets.only(
                                //       left: 32, bottom: 4, top: 0, right: 0),
                                //   // child: Text(
                                //   //   "BDT ${popularList.avgPrice??"nan"}",
                                //   //   style: TextStyle(
                                //   //     fontSize: 16,
                                //   //     fontWeight: FontWeight.bold,
                                //   //     color:  Colors.orange,
                                //   //
                                //   //   ),
                                //   // ),
                                // ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
