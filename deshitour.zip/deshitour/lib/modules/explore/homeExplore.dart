import 'package:autocomplete_textfield/autocomplete_textfield.dart';
import 'package:date_range_picker/date_range_picker.dart' as DateRagePicker;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:new_motel/authenticating/login.dart';
import 'package:new_motel/models/home/home.dart';
import 'package:new_motel/modules/explore/frontHome.dart';
import 'package:new_motel/modules/explore/popularListView.dart';
import 'package:new_motel/modules/explore/titleView.dart';
import 'package:new_motel/modules/hotelBooking/hotelListHomeScreen.dart';
import 'package:new_motel/modules/hotelBooking/roomPopupView.dart';
import 'package:new_motel/modules/profile/profile_page.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:new_motel/widget/customDrawer.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../appTheme.dart';
import '../../models/hotelListData.dart';
import '../hotelDetailes/searchScreen.dart';
import 'deshitour_prferences.dart';
import 'frontTour.dart';

class HomeExploreScreen extends StatefulWidget {
  final AnimationController animationController;
  final HomeData homeData;

  const HomeExploreScreen({Key key, this.animationController, this.homeData})
      : super(key: key);

  @override
  _HomeExploreScreenState createState() => _HomeExploreScreenState();
}

class _HomeExploreScreenState extends State<HomeExploreScreen>
    with TickerProviderStateMixin {
  AutoCompleteTextField searchTextField;
  GlobalKey<AutoCompleteTextFieldState<AllLocation>> key = new GlobalKey();

  var hotelList = HotelListData.hotelList;
  ScrollController controller;
  AnimationController _animationController;
  int room = 0;
  int ad = 0;
  int children = 0;
  String _currentWeather = "";
  bool apiCall = false;
  var checkInDate;
  var checkoutDate;

  // DateTime startDate = DateTime.now();
  // DateTime endDate = DateTime.now().add(Duration(days: 7));
  var sliderImageHieght = 0.0;
  List<FrontLocation> fron_location;
  List<AllLocation> all_location;
  List<FrontHotel> front_hotel;
  List<FrontTour> front_tour;
  bool loading = false;
  HomeData homeData;

  String location_id;
  String location_name;
  SharedPreferences sharedPreferences;
  TextEditingController _controller = TextEditingController();
  // my custom DatePicker.......

  DateTime _startDate = DateTime.now();
  DateTime _endDate = DateTime.now().add(Duration(days: 1));

  Future displayDateRangePicker(BuildContext context) async {
    final List<DateTime> picked = await DateRagePicker.showDatePicker(
        context: context,
        initialFirstDate: _startDate,
        initialLastDate: _endDate,
        firstDate: new DateTime(DateTime.now().year - 50),
        lastDate: new DateTime(DateTime.now().year + 50));
    if (picked != null && picked.length == 2) {
      setState(() {
        _startDate = picked[0];
        _endDate = picked[1];
      });
    }
  }

  // Future<String> getJSONData() async {
  //   loading = true;
  //   var response = await http.get(ApiService.home_all_data);
  //   setState(() {
  //     loading = false;
  //     HomeData  homeData = HomeData.fromJson(json.decode(response.body)[0]);
  //     fron_location = homeData.frontLocation;
  //     all_location = homeData.allLocation;
  //     front_hotel = homeData.frontHotel;
  //     front_tour = homeData.frontTour;
  //     // Get the JSON data
  //     print("fornt Location :${fron_location.length}");
  //     print("all Location :${all_location.length}");
  //     print("front hotel :${front_hotel.length}");
  //     print("front tour :${front_tour.length}");
  //   });
  //   //print(data);
  //   return "data";
  // }
  String token;
  String image;

  Future<String> getToken() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    token = sharedPreferences.getString("token");
    image = sharedPreferences.getString("photo");
    setState(() {});
  }

  @override
  void initState() {
    getToken();

    //  getJSONData();
    _animationController =
        AnimationController(duration: Duration(milliseconds: 0), vsync: this);
    widget.animationController.forward();
    controller = ScrollController(initialScrollOffset: 0.0);

    controller.addListener(() {
      if (context != null) {
        if (controller.offset < 0) {
          // we static set the just below half scrolling values
          _animationController.animateTo(0.0);
        } else if (controller.offset > 0.0 &&
            controller.offset < sliderImageHieght) {
          // we need around half scrolling values
          if (controller.offset < ((sliderImageHieght / 0))) {
            _animationController
                .animateTo((controller.offset / sliderImageHieght));
          } else {
            // we static set the just above half scrolling values "around == 0.64"
            _animationController
                .animateTo((sliderImageHieght / 0) / sliderImageHieght);
          }
        }
      }
    });
    _startDate.toLocal();
    super.initState();

    setState(() {
      setText();
    });
  }

  @override
  Widget build(BuildContext context) {
    sliderImageHieght = MediaQuery.of(context).size.width * 0.8;
    homeData = widget.homeData;
    if (homeData == null) {
    } else {
      fron_location = homeData.frontLocation;
      front_hotel = homeData.frontHotel;
      front_tour = homeData.frontTour;
      all_location = homeData.allLocation;
      print("All Location ${homeData.allLocation.length}");
    }
    return AnimatedBuilder(
      animation: widget.animationController,
      builder: (BuildContext context, Widget child) {
        return FadeTransition(
          opacity: widget.animationController,
          // FadeTransition and Transform : just for screen loading animation on fistTime
          child: new Transform(
            transform: new Matrix4.translationValues(
                0.0, 60 * (1.0 - widget.animationController.value), 0.0),
            child: SafeArea(
              child: Scaffold(
                appBar: AppBar(
                  actions: [
                    InkWell(
                      onTap: () async {
                        SharedPreferences sharedPreferences =
                            await SharedPreferences.getInstance();
                        String token = sharedPreferences.getString("token");

                        if (token == null) {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => LoginWidget()));
                        } else {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ProfilePage(),
                              fullscreenDialog: true,
                            ),
                          );
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(right: 20),
                        child: CircleAvatar(
                          backgroundColor: Colors.grey[600],
                          radius: 20.0,
                          child: Center(
                            child: CircleAvatar(
                              backgroundColor: Colors.white,
                              radius: 17.0,
                              backgroundImage: image == null
                                  ? AssetImage("assets/images/person.png")
                                  : NetworkImage(
                                      "https://deshitour.com/" + image),
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                  centerTitle: true,
                  title: RichText(
                    text: TextSpan(
                        text: DESHI,
                        style: TextStyle(
                          fontSize: 30,
                          fontFamily: 'Impact',
                          color: HexColor("#26408A"),
                        ),
                        children: <TextSpan>[
                          TextSpan(
                              text: TOUR,
                              style: TextStyle(
                                fontSize: 30,
                                fontFamily: 'Impact',
                                color: HexColor("#118ACB"),
                              )),
                        ]),
                  ),
                  iconTheme: IconThemeData(color: Colors.black),
                  backgroundColor: Colors.white,
                  elevation: 1,
                ),
                drawer: CustomDrawer(
                  title: DESHITOUR,
                ),
                backgroundColor: AppTheme.getTheme().backgroundColor,
                body: ListView(
                  shrinkWrap: true,
                  primary: false,
                  children: [
                    Container(
                        decoration: BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage("assets/images/bg.jpg"),
                                fit: BoxFit.cover)
                            //color: popUpBackgroundColor,
                            ),
                        child: searchBox(_animationController)),
                    Container(
                      child: ListView.builder(
                        shrinkWrap: true,
                        primary: false,
                        controller: controller,
                        itemCount: 6,
                        // physics: NeverScrollableScrollPhysics(),
                        // padding on top is only for we need spec for sider

                        scrollDirection: Axis.vertical,
                        itemBuilder: (context, index) {
                          // some list UI
                          var count = 6;
                          var animation = Tween(begin: 0.0, end: 1.0).animate(
                            CurvedAnimation(
                              parent: widget.animationController,
                              curve: Interval((1 / count) * index, 1.0,
                                  curve: Curves.fastOutSlowIn),
                            ),
                          );
                          if (index == 0) {
                            return TitleView(
                              titleTxt: LOCATION,
                              subTxt: '',
                              animation: animation,
                              animationController: widget.animationController,
                            );
                          } else if (index == 1) {
                            return Padding(
                              padding: const EdgeInsets.only(top: 0),
                              child: PopularListView(
                                frontlocation: fron_location,
                                animationController: widget.animationController,
                                callBack: (index) {
                                  // LoaderPage().showInSnackBar(context, "null");
                                },
                              ),
                            );
                          } else if (index == 2) {
                            return TitleView(
                              titleTxt: TODAYS_TOP_HOTEL,
                              subTxt: '',
                              animation: animation,
                              animationController: widget.animationController,
                            );
                          } else if (index == 3) {
                            return Padding(
                              padding: const EdgeInsets.only(top: 0, left: 12),
                              child: Container(
                                height: 250,
                                child: FrontHome(
                                  frontlocation: front_hotel,
                                  animationController:
                                      widget.animationController,
                                  callBack: (index) {},
                                ),
                              ),
                            );
                          } else if (index == 4) {
                            return Padding(
                              padding: const EdgeInsets.only(top: 0),
                              child: TitleView(
                                titleTxt: EXPLORE_TOUR,
                                subTxt: '',
                                animation: animation,
                                animationController: widget.animationController,
                              ),
                            );
                          } else {
                            return Padding(
                              padding: const EdgeInsets.only(top: 0),
                              child: FrontTourView(
                                frontTour: front_tour,
                                animationController: widget.animationController,
                                callBack: (index) {},
                              ),
                            );
                          }
                          // else {
                          //   return Null;
                          // }
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget getDealListView(int index) {
    // var hotelList = HotelListData.hotelList;
    List<Widget> list = List<Widget>();
    hotelList.forEach((f) {
      var animation = Tween(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(
          parent: widget.animationController,
          curve: Interval(0, 1.0, curve: Curves.fastOutSlowIn),
        ),
      );
    });
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: list,
      ),
    );
  }

  Widget serachUI() {
    return Center(
      // padding: const EdgeInsets.only(left: 24, right: 24, top: 24),
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.getTheme().backgroundColor.withOpacity(.5),
          borderRadius: BorderRadius.all(Radius.circular(38)),
          // border: Border.all(
          //   color: HexColor("#757575").withOpacity(0.6),
          // ),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: AppTheme.getTheme().dividerColor,
              blurRadius: 8,
              offset: Offset(4, 4),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.only(left: 16, right: 16),
          child: Container(
            // height: 48,
            child: Center(
              child: InkWell(
                borderRadius: BorderRadius.all(Radius.circular(38)),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => SearchScreen(),
                        fullscreenDialog: true),
                  );
                },
                child: Row(
                  children: <Widget>[
                    Icon(
                      FontAwesomeIcons.search,
                      size: 18,
                      color: AppTheme.getTheme().primaryColor,
                    ),
                    SizedBox(
                      width: 8,
                    ),
                    TextField(
                      maxLines: 1,
                      // onTap: () {
                      //   Navigator.push(
                      //     context,
                      //     MaterialPageRoute(builder: (context) => SearchScreen(), fullscreenDialog: true),
                      //   );
                      // },
                      // enabled: false,
                      onChanged: (String txt) {},
                      style: TextStyle(
                        fontSize: 16,
                        // color: AppTheme.dark_grey,
                      ),
                      cursorColor: AppTheme.getTheme().primaryColor,
                      decoration: new InputDecoration(
                        errorText: null,
                        border: InputBorder.none,
                        hintText: WHERE_ARE_YOU_GOING,
                        hintStyle:
                            TextStyle(color: AppTheme.getTheme().disabledColor),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Search Box Method
  Widget searchBox(AnimationController animationController) {
    return Container(
      //width: MediaQuery.of(context).size.height / 2,
      color: Colors.transparent,
      padding: EdgeInsets.only(left: 26, top: 10.0, right: 24, bottom: 10),
      child: Container(
        child: Card(
          shape: RoundedRectangleBorder(
            borderRadius: new BorderRadius.circular(0.0),
            side: BorderSide(color: HexColor("#fff201"), width: 3),
          ),
          color: Colors.white,
          elevation: 10,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              getDropDown(),
              new Divider(
                thickness: 2,
                color: HexColor("#fff201"),
              ),
              getTimeDateUI(),
              new Divider(
                thickness: 2,
                color: HexColor("#fff201"),
              ),
              getTimeUI(),
              new Divider(
                thickness: 2,
                color: HexColor("#fff201"),
              ),
              ButtonTheme(
                buttonColor: HexColor("#26408A"),
                height: 50,
                child: RaisedButton(
                  onPressed: () {
                    if (location_id != 0) {
                      // Navigator.pushNamed(
                      //   context,
                      //   Routes.HoteList,
                      //   arguments: RouteSettings(arguments: {
                      //     'location_id': location_id,
                      //     'checkin': checkInDate,
                      //     'checkout': checkoutDate,
                      //   }),
                      // );
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => HotelListHomeScreen(
                                  from: HOME_SEARCH,
                                  locaton_id: location_id,
                                  locaton_name: location_name,
                                  checkIn: checkInDate,
                                  checkOut: checkoutDate,
                                  isSearch: HOME_SEARCH,
                                  allLocation: all_location,
                                  location_property: null,
                                  starCount: null,
                                  locationId: 1,
                                  room: room,
                                  adults: ad,
                                  child: children,
                                )),
                      );
                    } else {
                      print(
                          "Location_id $location_id $checkInDate $checkoutDate");
                      final snackBar = SnackBar(
                          content: Text("Please select your location "));
                      Scaffold.of(context).showSnackBar(snackBar);
                    }
                  },
                  // child: new Text("Get Weather"),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        SEARCH,
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 20),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget getTimeDateUI() {
    final f = new DateFormat('dd/MM/yyyy');
    checkInDate = f.format(_startDate);
    checkoutDate = f.format(_endDate);
    print("date ${checkInDate} ${checkoutDate}");
    return Container(
      child: Row(
        children: <Widget>[
          Column(
            children: <Widget>[
              Material(
                color: Colors.transparent,
                child: InkWell(
                  focusColor: Colors.transparent,
                  highlightColor: Colors.transparent,
                  hoverColor: Colors.transparent,
                  splashColor: Colors.black.withOpacity(0.2),
                  borderRadius: BorderRadius.all(
                    Radius.circular(4.0),
                  ),
                  onTap: () {
                    FocusScope.of(context).requestFocus(FocusNode());
                    // setState(() {
                    //   isDatePopupOpen = true;
                    // });
                    // showDemoDialog(context: context);
                  },
                  child: Container(
                    alignment: Alignment.topLeft,
                    padding: const EdgeInsets.only(
                        left: 16, right: 0, top: 4, bottom: 4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Icon(
                          Icons.calendar_today_outlined,
                          color: Colors.black,
                        ),
                        SizedBox(
                          width: 16,
                        ),
                        GestureDetector(
                          onTap: () async {
                            await displayDateRangePicker(context);
                          },
                          child: Text(
                            "${DateFormat("dd, MMM").format(_startDate)} - ${DateFormat("dd, MMM").format(_endDate)}",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: Colors.black),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),

          // Padding(
          //   padding: EdgeInsets.only(right: 8),
          //   child: Container(
          //     width: 1,
          //     height: 42,
          //     color: Colors.white,
          //   ),
          // ),
        ],
      ),
    );
  }

  Widget getTimeUI() {
    return Container(
      padding: const EdgeInsets.only(left: 0, bottom: 0),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Column(
              children: <Widget>[
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    focusColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    hoverColor: Colors.transparent,
                    splashColor: Colors.black,
                    borderRadius: BorderRadius.all(
                      Radius.circular(4.0),
                    ),
                    onTap: () {
                      FocusScope.of(context).requestFocus(FocusNode());
                      showDialog(
                        context: context,
                        builder: (BuildContext context) => RoomPopupView(
                          ad: ad,
                          room: room,
                          ch: children,
                          barrierDismissible: true,
                          onChnage: (ro, a, c) {
                            setState(() {
                              room = ro;
                              ad = a;
                              children = c;
                            });
                          },
                        ),
                      );
                    },
                    child: Container(
                      alignment: Alignment.topLeft,
                      padding: const EdgeInsets.only(
                          left: 15, top: 4.0, right: 0.0, bottom: 4.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Icon(
                            Icons.person_rounded,
                            color: Colors.black,
                          ),
                          SizedBox(
                            width: 16,
                          ),
                          Text(
                            " $ad $ADULTS -$children $CHILDREN",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: Colors.black),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Padding(
          //   padding: EdgeInsets.only(right: 8),
          //   child: Container(
          //     width: 1,
          //     height: 42,
          //     color: Colors.white,
          //   ),
          // ),
        ],
      ),
    );
  }

  Widget getDropDown() {
    print("Location Id: $location_id");
    print("Location Name: $location_name");

    // print("object");
    return Container(
      alignment: Alignment.center,
      width: MediaQuery.of(context).size.width,
      color: Colors.transparent,
      padding: EdgeInsets.all(4.0),
      // child: DropdownButtonHideUnderline(
      //   child: DropdownButton<String>(
      //       items: hoteslData.map((String val) {
      //         return DropdownMenuItem<String>(
      //           value: _dropDownValue,
      //           child: Container(
      //               margin: EdgeInsets.only(left: 10.0, right: 10.0),
      //               child: Text(val)),
      //         );
      //       }).toList(),
      //       hint: Text(
      //         "Where are you going?",
      //         style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),
      //       ),
      //       onChanged: (String val) {
      //         _dropDownValue = val;
      //         setState(() {
      //           _dropDownValue = val;
      //           // _dropDownValue = hoteslData[val];
      //           print("onChanged Value : " + _dropDownValue);
      //         });
      //       }),
      // ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          all_location == null
              ? CircularProgressIndicator()
              : searchTextField = AutoCompleteTextField<AllLocation>(
                  controller: _controller,
                  key: key,
                  clearOnSubmit: false,
                  suggestions: all_location,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 16.0,
                      fontWeight: FontWeight.bold),
                  // decoration: InputDecoration(
                  //   // border: new OutlineInputBorder(
                  //   //   borderRadius: const BorderRadius.all(
                  //   //     const Radius.circular(10.0),
                  //   //   ),
                  //   // ),
                  //   border: OutlineInputBorder(
                  //     borderRadius: BorderRadius.circular(8),
                  //     borderSide: BorderSide(
                  //       width: 0,
                  //       style: BorderStyle.none,
                  //     ),
                  //   ),
                  //   filled: true,
                  //   contentPadding: EdgeInsets.all(16),
                  //   fillColor: Colors.grey,
                  //  // contentPadding: EdgeInsets.fromLTRB(30.0, 30.0, 30.0, 20.0),
                  //   hintText: "Search Name",
                  //   hintStyle: new TextStyle(color: Colors.white),
                  // ),
                  decoration: new InputDecoration(
                    prefixIcon: Icon(
                      Icons.search,
                      color: Colors.black,
                      size: 20,
                    ),
                    hintText: WHERE_ARE_YOU_GOING,
                    hintStyle: new TextStyle(color: Colors.black),

                    enabledBorder: InputBorder.none,
                    disabledBorder: InputBorder.none,
                    // focusedBorder: OutlineInputBorder(
                    //   borderRadius: BorderRadius.all(Radius.circular(4.0)),
                    //   borderSide: BorderSide(color: Colors.blue),
                    // ),
                  ),
                  itemFilter: (item, query) {
                    return item.location
                        .toLowerCase()
                        .startsWith(query.toLowerCase());
                  },
                  itemSorter: (a, b) {
                    return a.location.compareTo(b.location);
                  },
                  itemSubmitted: (item) {
                    setState(() async {
                      searchTextField.textField.controller.text = item.location;
                      location_id = item.id;
                      location_name = item.location;
                      // Location().locationId=location_id;
                      // Location().locaton_name =location_name;
                      SharedPreferences sharedPreferences =
                          await SharedPreferences.getInstance();
                      sharedPreferences.setString(
                          DeshiTourPreference.LOCATION_ID, location_id);
                      sharedPreferences.setString(
                          DeshiTourPreference.LOCATION_NAME, location_name);

                      print("Location  Id -> ${item.id}");
                    });
                  },
                  itemBuilder: (context, item) {
                    // ui for the autocompelete row
                    return row(item);
                  },
                ),
        ],
      ),
    );
  }

  Widget row(AllLocation item) {
    return Container(
      height: 40,
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
              item != null ? item.location : LOCATION_NOT_FOUND,
              style: TextStyle(fontSize: 18.0, color: Colors.black),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(item != null ? item.country : " ",
                style: TextStyle(
                  fontSize: 18.0,
                  color: Colors.black,
                )),
          )
        ],
      ),
    );
  }

  Widget dataNOtAvailable(String item) {
    return Container(
      height: 40,
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
              item,
              style: TextStyle(fontSize: 18.0, color: Colors.black),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Icon(
              Icons.error,
              color: Colors.red,
            ),
          ),
        ],
      ),
    );
  }

  Widget getProperWidget() {
    if (apiCall)
      return new CircularProgressIndicator();
    else
      return new Text(
        '$_currentWeather',
        style: Theme.of(context).textTheme.display1,
      );
  }

  Future<void> setText() async {
    sharedPreferences = await SharedPreferences.getInstance();
    location_id = sharedPreferences.getString(DeshiTourPreference.LOCATION_ID);
    location_name =
        sharedPreferences.getString(DeshiTourPreference.LOCATION_NAME);

    setState(() {});
  }
}
