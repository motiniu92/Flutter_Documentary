import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:new_motel/models/hotelList/hotelDetails.dart';
import 'package:new_motel/models/tour/toursDetails.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';

class RelatedHotel extends StatefulWidget {
  final Function(int) callBack;
  final AnimationController animationController;
  final List<HotelDetailsRelatedItems> relatedHotel;
  final List<TourDetailsRelatedItems> relatedTourHotel;

  const RelatedHotel(
      {Key key,
      this.callBack,
      this.animationController,
      @required this.relatedHotel,
      @required this.relatedTourHotel})
      : super(key: key);

  @override
  _RelatedHotelState createState() => _RelatedHotelState();
}

class _RelatedHotelState extends State<RelatedHotel>
    with TickerProviderStateMixin {
  AnimationController animationController;

  // List<HotelDetailsRelatedItems> homeFront;
  // List<TourDetailsRelatedItems> tourFront;

  var homeFront;

  @override
  void initState() {
    animationController = AnimationController(
        duration: Duration(milliseconds: 1000), vsync: this);
    super.initState();
  }

  Future<bool> getData() async {
    await Future.delayed(const Duration(milliseconds: 50));
    return true;
  }

  @override
  Widget build(BuildContext context) {
    if (widget.relatedHotel != null) {
      homeFront = widget.relatedHotel;
    } else {
      homeFront = widget.relatedTourHotel;
    }

    return AnimatedBuilder(
      animation: widget.animationController,
      builder: (BuildContext context, Widget child) {
        return FadeTransition(
          opacity: widget.animationController,
          child: new Transform(
            transform: new Matrix4.translationValues(
                0.0, 40 * (1.0 - widget.animationController.value), 0.0),
            child: Container(
              height: MediaQuery.of(context).size.height / 4.4,
              width: double.infinity,
              child: FutureBuilder(
                future: getData(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return SizedBox();
                  } else {
                    return homeFront == null
                        ? Center(child: CircularProgressIndicator())
                        : ListView.builder(
                            padding: const EdgeInsets.only(
                                top: 8, bottom: 0, right: 24, left: 8),
                            itemCount: homeFront.length,
                            scrollDirection: Axis.horizontal,
                            itemBuilder: (context, index) {
                              var count =
                                  homeFront.length > 10 ? 10 : homeFront.length;
                              var animation = Tween(begin: 0.0, end: 1.0)
                                  .animate(CurvedAnimation(
                                      parent: animationController,
                                      curve: Interval((1 / count) * index, 1.0,
                                          curve: Curves.fastOutSlowIn)));
                              animationController.forward();
                              return ReviewHotelListView(
                                popularList: homeFront[index],
                                animation: animation,
                                animationController: animationController,
                                callback: () {
                                  widget.callBack(index);
                                },
                              );
                            },
                          );
                  }
                },
              ),
            ),
          ),
        );
      },
    );
  }
}

class ReviewHotelListView extends StatelessWidget {
  final VoidCallback callback;
  final dynamic popularList;
  final AnimationController animationController;
  final Animation animation;
  final _LOADING_IMAGE = 'assets/images/bp_loading.gif';
  final _BOOKMARK_ICON = 'assets/icons/bp_bookmark_icon.svg';
  final _LOCATION_ICON = 'assets/icons/bp_location_icon.svg';
  final _STAR_ICON = 'assets/icons/price_tag.svg';

  const ReviewHotelListView(
      {Key key,
      this.popularList,
      this.animationController,
      this.animation,
      this.callback})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final _bodBody1TextStyle = Theme.of(context).textTheme.bodyText1;
    return Container(
        width: 300,
        height: 268,
        decoration:
            BoxDecoration(borderRadius: BorderRadius.circular(12), boxShadow: [
          BoxShadow(offset: Offset(0, 10), blurRadius: 30, color: kShadowColor)
        ]),
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.all(4),
              child: Stack(
                children: [
                  AspectRatio(
                    aspectRatio: 2.8,
                    child: Image.network(
                      popularList.thumbnail,
                      fit: BoxFit.cover,
                      color: Colors.blueAccent.withOpacity(1.0),
                      colorBlendMode: BlendMode.softLight,
                      loadingBuilder: (BuildContext context, Widget child,
                          ImageChunkEvent loadingProgress) {
                        if (loadingProgress == null) return child;
                        return Center(
                          child: CircularProgressIndicator(
                            value: loadingProgress.expectedTotalBytes != null
                                ? loadingProgress.cumulativeBytesLoaded /
                                    loadingProgress.expectedTotalBytes
                                : null,
                          ),
                        );
                      },
                      // IMAGE_URL+popularList.thumbnail,
                      // fit: BoxFit.cover,
                    ),
                  ),
                  Positioned(
                    left: 10,
                    bottom: 20,
                    child: Container(
                      width: 108,
                      height: 20,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.4),
                          borderRadius: BorderRadius.circular(2)),
                      child: Text(popularList.title,
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 16)),
                    ),
                  ),
                  Positioned(
                    left: 10,
                    bottom: 0,
                    child: Container(
                      width: 108,
                      height: 20,
                      decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.4),
                          borderRadius: BorderRadius.circular(2)),
                      child: Row(
                        children: <Widget>[
                          SIZED_BOX_W04,
                          SvgPicture.asset(
                            _LOCATION_ICON,
                            color: Colors.white,
                          ),
                          SIZED_BOX_W10,
                          Text(popularList.location ?? "",
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.normal,
                                  fontSize: 12)),
                          Divider(color: Colors.black),
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
            Positioned(
                child: Container(
                    color: kPrimaryColor,
                    margin: new EdgeInsets.symmetric(horizontal: 4.0),
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 0),
                    child: Row(
                      children: [
                        SmoothStarRating(
                          allowHalfRating: true,
                          starCount: 5,
                          rating: double.parse(popularList.starsCount),
                          size: 14,
                          isReadOnly: true,
                          color: kBackgroundColor,
                          borderColor: kBackgroundColor,
                        ),
                        SIZED_BOX_W04,
                        Text("(${popularList.starsCount})",
                            style: _bodBody1TextStyle.copyWith(
                                color: kBackgroundColor)),
                        SIZED_BOX_W60,
                       // SizedBox(width: 10,),
                        SvgPicture.asset(
                          _STAR_ICON,
                          color: kBackgroundColor,
                        ),
                        SIZED_BOX_W04,
                        //SizedBox(width: 3,),
                        Text("${popularList.currCode} ${popularList.price}",
                            style: _bodBody1TextStyle.copyWith(
                                color: kBackgroundColor))
                      ],
                    )))
          ],
        ));
  }
}
