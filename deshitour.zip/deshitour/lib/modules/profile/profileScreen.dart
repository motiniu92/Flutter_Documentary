// import 'dart:async';
//
// import 'package:flutter/material.dart';
// import 'package:new_motel/authenticating/login.dart';
// import 'package:new_motel/modules/profile/userProfile.dart';
// import 'package:new_motel/utils/constants.dart';
// import 'package:new_motel/widget/customDrawer.dart';
// import 'package:new_motel/widget/custom_drawer2.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// import '../../appTheme.dart';
// import '../../models/settingListData.dart';
// import '../../splashScreen.dart';
// import 'Bookings.dart';
//
// class ProfileScreen extends StatefulWidget {
//   final AnimationController animationController;
//
//   const ProfileScreen({Key key, this.animationController}) : super(key: key);
//
//   @override
//   _ProfileScreenState createState() => _ProfileScreenState();
// }
//
// class _ProfileScreenState extends State<ProfileScreen> {
//   List<SettingsListData> userSettingsList = SettingsListData.userSettingsList;
//   String firstName;
//   String lastName;
//   String email;
//   int id = 0;
//   String singInText = "Please Sign In for continue";
//
//   Future<String> getUserData() async {
//     print("Get usewr daTA");
//     // set User Data....>>>>
//     SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
//
//     firstName = sharedPreferences.getString('firstName');
//     lastName = sharedPreferences.getString('lastName');
//     email = sharedPreferences.getString('email');
//     print("SharedData>>>>${sharedPreferences.getString('firstName')}");
//
//     setState(() {});
//   }
//
//   String token;
//
//   Future<String> getToken() async {
//     SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
//
//     token = sharedPreferences.getString("token");
//     return token;
//   }
//
//   Future<String> logOut() async {
//     SharedPreferences sharedPreferces = await SharedPreferences.getInstance();
//     String token = sharedPreferces.getString('token');
//     if (token != null) {
//       await sharedPreferces.clear();
//       Navigator.of(context).popUntil((route) => route.isFirst);
//       Navigator.pop(context);
//       Navigator.push(
//           context, MaterialPageRoute(builder: (context) => SplashScreen()));
//     } else {
//       Navigator.push(
//           context, MaterialPageRoute(builder: (context) => SplashScreen()));
//       return token;
//     }
//   }
//
//   @override
//   void initState() {
//     widget.animationController.forward();
//     super.initState();
//     getUserData();
//     getToken();
//     // logOut();
//   }
//
//   @override
//   void didUpdateWidget(covariant ProfileScreen oldWidget) {
//     // TODO: implement didUpdateWidget
//
//     super.didUpdateWidget(oldWidget);
//   }
//
//   FutureOr onGoBack(dynamic value) {
//     getToken();
//     getUserData();
//     reloadProfileScreen();
//     setState(() {});
//   }
//
//   void navigateSecondPage(String from) {
//     Route route =
//         MaterialPageRoute(builder: (context) => LoginWidget(type: from));
//     Navigator.push(context, route).then(onGoBack);
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return AnimatedBuilder(
//       animation: widget.animationController,
//       builder: (BuildContext context, Widget child) {
//         return FadeTransition(
//           opacity: widget.animationController,
//           child: new Transform(
//             transform: new Matrix4.translationValues(
//                 0.0, 40 * (1.0 - widget.animationController.value), 0.0),
//             child: SafeArea(
//               child: Scaffold(
//                 appBar: AppBar(
//                   iconTheme: IconThemeData(color: Colors.black),
//                   title: RichText(
//                     text: TextSpan(
//                         text: DESHI,
//                         style: TextStyle(
//                           fontSize: 30,
//                           fontFamily: 'Impact',
//                           color: HexColor("#26408A"),
//                         ),
//                         children: <TextSpan>[
//                           TextSpan(
//                               text: TOUR,
//                               style: TextStyle(
//                                 fontSize: 30,
//                                 fontFamily: 'Impact',
//                                 color: HexColor("#118ACB"),
//                               )),
//                         ]),
//                   ),
//                   backgroundColor: Colors.white,
//                   elevation: 1,
//                 ),
//                 drawer: token == null
//                     ? CustomDrawerTwo()
//                     : CustomDrawer(
//                         title: DESHITOUR,
//                       ),
//                 backgroundColor: AppTheme.getTheme().backgroundColor,
//                 body: reloadProfileScreen(),
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }
//
//   reloadProfileScreen() {
//     return token == null
//         ? Center(
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 Text(
//                   singInText,
//                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//                 ),
//                 SizedBox(height: 10),
//                 ElevatedButton(
//                     onPressed: () {
//                       navigateSecondPage("2");
//                       //_navigateAndDisplaySelection(context, "2");
//                     },
//                     child: Text("Sign In"))
//               ],
//             ),
//           )
//         : Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: <Widget>[
//               Padding(
//                 padding:
//                     EdgeInsets.only(top: MediaQuery.of(context).padding.top),
//                 child: Container(child: appBar()),
//               ),
//               Expanded(
//                 child: ListView.builder(
//                   physics: BouncingScrollPhysics(),
//                   padding: EdgeInsets.all(0.0),
//                   itemCount: userSettingsList.length,
//                   itemBuilder: (context, index) {
//                     return InkWell(
//                       onTap: () async {
//                         // if (index == 6) {
//                         //   await Navigator.push(
//                         //       context,
//                         //       MaterialPageRoute(
//                         //         builder: (context) => SettingsScreen(),
//                         //         fullscreenDialog: true,
//                         //       ));
//                         //
//                         //   setState(() {});
//                         // }
//
//                         // if (index == 5) {
//                         //   Navigator.push(
//                         //     context,
//                         //     MaterialPageRoute(
//                         //       builder: (context) => UserAddress(),
//                         //       fullscreenDialog: true,
//                         //     ),
//                         //   );
//                         // }
//
//                         // if (index == 3) {
//                         //   Navigator.push(
//                         //     context,
//                         //     MaterialPageRoute(
//                         //       builder: (context) => HeplCenterScreen(),
//                         //       fullscreenDialog: true,
//                         //     ),
//                         //   );
//                         // }
//
//                         // if (index == 4) {
//                         //   Navigator.push(
//                         //     context,
//                         //     MaterialPageRoute(
//                         //       builder: (context) => MyDocuments(),
//                         //       fullscreenDialog: true,
//                         //     ),
//                         //   );
//                         // }
//
//                         if (index == 3) {
//                           Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                               builder: (context) => Bookings(),
//                               fullscreenDialog: true,
//                             ),
//                           );
//                         }
//
//                         // if (index == 2) {
//                         //   Navigator.push(
//                         //     context,
//                         //     MaterialPageRoute(
//                         //       builder: (context) => WishList(),
//                         //       fullscreenDialog: true,
//                         //     ),
//                         //   );
//                         // }
//
//                         if (index == 1) {
//                           SharedPreferences sharedPreferences =
//                               await SharedPreferences.getInstance();
//                           String token = sharedPreferences.getString("token");
//
//                           if (token == null) {
//                             // A method that launches the SelectionScreen and awaits the result from
//                             // Navigator.pop.
//                             _navigateAndDisplaySelection(context);
//
//                             // Navigator.push(
//                             //   context,
//                             //   MaterialPageRoute(
//                             //     builder: (context) =>
//                             //         LoginWidget(type: "profile"),
//                             //     fullscreenDialog: true,
//                             //   ),
//                             // );
//                           } else {
//                             Navigator.push(
//                               context,
//                               MaterialPageRoute(
//                                 builder: (context) =>
//                                     ProfileScreenPage(type: 'profile'),
//                                 fullscreenDialog: true,
//                               ),
//                             );
//                           }
//                         }
//                         // if (index == 0) {
//                         //   Navigator.push(
//                         //     context,
//                         //     MaterialPageRoute(
//                         //       builder: (context) => ChangepasswordScreen(),
//                         //       fullscreenDialog: true,
//                         //     ),
//                         //   );
//                         // }
//                       },
//                       child: Column(
//                         children: <Widget>[
//                           Padding(
//                             padding: const EdgeInsets.only(left: 8, right: 16),
//                             child: Row(
//                               children: <Widget>[
//                                 Expanded(
//                                   child: Padding(
//                                     padding: const EdgeInsets.all(16.0),
//                                     child: Text(
//                                       userSettingsList[index].titleTxt,
//                                       style: TextStyle(
//                                           fontWeight: FontWeight.w500,
//                                           fontSize: 16),
//                                     ),
//                                   ),
//                                 ),
//                                 Padding(
//                                   padding: const EdgeInsets.all(16),
//                                   child: Container(
//                                     child: Icon(
//                                         userSettingsList[index].iconData,
//                                         color: AppTheme.getTheme()
//                                             .disabledColor
//                                             .withOpacity(0.3)),
//                                   ),
//                                 )
//                               ],
//                             ),
//                           ),
//                           Padding(
//                             padding: const EdgeInsets.only(left: 16, right: 16),
//                             child: Divider(
//                               height: 1,
//                             ),
//                           )
//                         ],
//                       ),
//                     );
//                   },
//                 ),
//               )
//             ],
//           );
//   }
//
//   Widget appBar() {
//     return InkWell(
//       onTap: () {
//         // Navigator.push(
//         //   context,
//         //   MaterialPageRoute(
//         //     builder: (context) => EditProfile(),
//         //     fullscreenDialog: true,
//         //   ),
//         // );
//       },
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.center,
//         crossAxisAlignment: CrossAxisAlignment.center,
//         children: <Widget>[
//           Expanded(
//             child: Padding(
//               padding: const EdgeInsets.only(left: 24),
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: <Widget>[
//                   Text(
//                     "$firstName $lastName",
//                     style: new TextStyle(
//                       fontSize: 20,
//                       fontWeight: FontWeight.w700,
//                     ),
//                   ),
//                   SizedBox(
//                     height: 3,
//                   ),
//                   Text(
//                     '$email',
//                     style: new TextStyle(
//                       fontSize: 20,
//                       fontWeight: FontWeight.bold,
//                       color: AppTheme.getTheme().disabledColor,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//           Padding(
//             padding: const EdgeInsets.only(right: 24, top: 16, bottom: 16),
//             child: Container(
//               width: 70,
//               height: 70,
//               child: ClipRRect(
//                 borderRadius: BorderRadius.all(Radius.circular(40.0)),
//                 child: Image.asset("assets/images/usersImage.png"),
//               ),
//             ),
//           )
//         ],
//       ),
//     );
//   }
//
//   _navigateAndDisplaySelection(BuildContext context) async {
//     // Navigator.push returns a Future that completes after calling
//     // Navigator.pop on the Selection Screen.
//     final result = await Navigator.push(
//       context,
//       MaterialPageRoute(builder: (context) => LoginWidget(type: "profile")),
//     );
//
//     print(Text("$result"));
//     // ignore: unrelated_type_equality_checks
//     if ("$result" == "1") {
//       //   setState(() {
//       getUserData();
//       //  });
//     }
//
//     // // After the Selection Screen returns a result, hide any previous snackbars
//     // // and show the new result.
//     // Scaffold.of(context)
//     //   ..removeCurrentSnackBar()
//     //   ..showSnackBar(SnackBar(content: Text("$result")));
//   }
// }
