import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';
import '../../appTheme.dart';

class WishList extends StatefulWidget {
  //final FrontHotel popularList;
  //const WishList({Key key, this.popularList}) : super(key: key);

  @override
  _WishListState createState() => _WishListState();
}

class _WishListState extends State<WishList> {
  ScrollController scrollController = ScrollController(initialScrollOffset: 0);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Scaffold(
        // backgroundColor: AppTheme.getTheme().backgroundColor,
        body: InkWell(
          splashColor: Colors.transparent,
          highlightColor: Colors.transparent,
          focusColor: Colors.transparent,
          onTap: () {
            FocusScope.of(context).requestFocus(FocusNode());
          },
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Padding(

                padding:
                    EdgeInsets.only(top: MediaQuery.of(context).padding.top),
                child: appBar(),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: ClipRRect(

                    borderRadius: BorderRadius.circular(24.0),
                    child: Card(

                      child: Container(
                        width: double.infinity,
                        //height: MediaQuery.of(context).size.height,

                        decoration: BoxDecoration(boxShadow: [
                          BoxShadow(
                              offset: Offset(0, 10),
                              blurRadius: 30,
                              color: kShadowColor)
                        ]),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            SizedBox(
                              height: 12,
                            ),

                            Row(

                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 12.0, right: 0.0),
                                  child: Container(
                                      width: 150.0,
                                      height: 100.0,
                                      decoration: new BoxDecoration(
                                          shape: BoxShape.rectangle,
                                          image: new DecorationImage(
                                            fit: BoxFit.cover,
                                            // image: NetworkImage("path to your image")
                                            image: AssetImage(
                                                "assets/images/bg.jpg"),
                                          ))),
                                ),
                                Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              left: 8.0, top: 7),
                                          child: Text(
                                            'Title',
                                            //popularList.title,
                                            style: TextStyle(fontSize: 26),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(left: 8.0),
                                          child: SmoothStarRating(
                                            allowHalfRating: true,
                                            starCount: 5,
                                            // rating: double.parse(
                                            //popularList.starsCount
                                            // ),
                                            //size: 16,
                                            // isReadOnly: true,
                                            // color: Colors.amberAccent,
                                          ),
                                        ),
                                        // SvgPicture.asset(
                                        //   _STAR_ICON,
                                        //   color: kBackgroundColor,
                                        // ),
                                        Text(
                                          // "(${popularList.starsCount})",
                                          '(5)',
                                        ),
                                      ],
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(
                                        '20/02/2021',
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),



                            // Apply Button Fields
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 12.0,
                                      right: 8.0,
                                      bottom: 8,
                                      top: 16),
                                  child: Container(
                                    width: 150,
                                    height: 48,
                                    decoration: BoxDecoration(
                                      color: HexColor("#1d8bcb"),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(5.0)),
                                      boxShadow: <BoxShadow>[
                                        BoxShadow(
                                          color:
                                              AppTheme.getTheme().dividerColor,
                                          blurRadius: 8,
                                          offset: Offset(4, 4),
                                        ),
                                      ],
                                    ),
                                    child: Material(
                                      color: Colors.transparent,
                                      child: InkWell(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(24.0)),
                                        highlightColor: Colors.transparent,
                                        onTap: () {
                                          Navigator.pop(context);
                                        },
                                        child: Center(
                                          child: Text(
                                            REMOVE,
                                            style: TextStyle(
                                                fontWeight: FontWeight.w500,
                                                fontSize: 16,
                                                color: Colors.white),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 16.0,
                                      right: 0.0,
                                      bottom: 8,
                                      top: 16),
                                  child: Container(
                                    width: 150,
                                    height: 48,
                                    decoration: BoxDecoration(
                                      color: AppTheme.getTheme().primaryColor,
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(5.0)),
                                      boxShadow: <BoxShadow>[
                                        BoxShadow(
                                          color:
                                              AppTheme.getTheme().dividerColor,
                                          blurRadius: 8,
                                          offset: Offset(4, 4),
                                        ),
                                      ],
                                    ),
                                    child: Material(
                                      color: Colors.transparent,
                                      child: InkWell(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(24.0)),
                                        highlightColor: Colors.transparent,
                                        onTap: () {
                                          Navigator.pop(context);
                                        },
                                        child: Center(
                                          child: Text(
                                            PREVIEW,
                                            style: TextStyle(
                                                fontWeight: FontWeight.w500,
                                                fontSize: 16,
                                                color: Colors.white),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget appBar() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: [
            SizedBox(
              height: AppBar().preferredSize.height,
              child: Padding(
                padding: EdgeInsets.only(top: 8, left: 8),
                child: Container(
                    width: AppBar().preferredSize.height - 8,
                    height: AppBar().preferredSize.height - 8,
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.all(
                          Radius.circular(32.0),
                        ),
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Icon(Icons.arrow_back),
                        ),
                      ),
                    )),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8.0, left: 90),
              child: Center(
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    WISHLIST,
                    style: new TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
