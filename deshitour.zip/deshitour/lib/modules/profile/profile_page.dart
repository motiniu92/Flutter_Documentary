import 'dart:async';

import 'package:flutter/material.dart';
import 'package:new_motel/modules/login/changepassword.dart';
import 'package:new_motel/modules/profile/Bookings.dart';
import 'package:new_motel/modules/profile/myDocuments.dart';
import 'package:new_motel/modules/profile/userProfile.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../appTheme.dart';
import '../../splashScreen.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  String firstName;
  String lastName;
  String email;
  String profileImage;
  int id = 0;
  String singInText = "Please Sign In for continue";

  Future<String> getUserData() async {
    print("Get usewr daTA");
    // set User Data....>>>>
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    firstName = sharedPreferences.getString('firstName');
    lastName = sharedPreferences.getString('lastName');
    email = sharedPreferences.getString('email');
    profileImage = sharedPreferences.getString("photo");

    print("SharedData>>>>${sharedPreferences.getString('firstName')}");

    setState(() {});
  }

  String token;

  Future<String> getToken() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    profileImage = sharedPreferences.getString("photo");
    // token = sharedPreferences.getString("token");
  }

  Future<String> logOut() async {
    SharedPreferences sharedPreferces = await SharedPreferences.getInstance();
    String token = sharedPreferces.getString('token');
    if (token != null) {
      await sharedPreferces.clear();
      Navigator.of(context).popUntil((route) => route.isFirst);
      Navigator.pop(context);
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => SplashScreen()));
    } else {
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => SplashScreen()));
      return token;
    }
  }

  @override
  void initState() {
    super.initState();
    getUserData();
    getToken();
    // logOut();
  }

  // FutureOr onGoBack(dynamic value) {
  //   getToken();
  //   getUserData();
  //   reloadProfileScreen();
  //   setState(() {});
  // }

  // void navigateSecondPage(String from) {
  //   Route route =
  //       MaterialPageRoute(builder: (context) => LoginWidget(type: from));
  //   Navigator.push(context, route).then(onGoBack);
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        iconTheme: IconThemeData(color: Colors.black),
        title: RichText(
          text: TextSpan(
              text: DESHI,
              style: TextStyle(
                fontSize: 30,
                fontFamily: 'Impact',
                color: HexColor("#26408A"),
              ),
              children: <TextSpan>[
                TextSpan(
                    text: TOUR,
                    style: TextStyle(
                      fontSize: 30,
                      fontFamily: 'Impact',
                      color: HexColor("#118ACB"),
                    )),
              ]),
        ),

        //title:
        // RichText(
        //   text: TextSpan(
        //       text: Vromon,
        //       style: TextStyle(
        //         fontSize: 30,
        //         fontFamily: 'Impact',
        //         color: HexColor("#26408A"),
        //       ),
        //       children: <TextSpan>[
        //         TextSpan(
        //             text: TOUR,
        //             style: TextStyle(
        //               fontSize: 30,
        //               fontFamily: 'Impact',
        //               color: HexColor("#118ACB"),
        //             )),
        //       ]),
        // ),
        backgroundColor: Colors.white,
        elevation: 1,
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 18.0),
                      child: Text(
                        "$firstName $lastName",
                        style: TextStyle(
                            fontSize: 22, fontWeight: FontWeight.bold),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 18.0, top: 4),
                      child: Text(
                        "$email",
                        style: TextStyle(fontSize: 20),
                      ),
                    ),
                    //Spacer(),
                  ],
                ),
                Spacer(),
                Padding(
                  padding: const EdgeInsets.only(right: 18.0, top: 10),
                  child: CircleAvatar(
                    backgroundColor: Colors.black,
                    radius: 40.0,
                    child: Center(
                      child: CircleAvatar(
                        backgroundColor: Colors.white,
                        radius: 37.0,
                        backgroundImage: profileImage == null
                            ? AssetImage("assets/images/person.png")
                            : NetworkImage(
                                "https://deshitour.com/" + "$profileImage",
                              ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Card(
              elevation: 0,
              child: ListTile(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => ChangepasswordScreen()));
                },
                title: Text(
                  "Change password",
                  style: TextStyle(fontSize: 18),
                ),
                trailing: Icon(Icons.lock_outlined),
              ),
            ),
            Divider(
              thickness: 1,
              indent: 17,
              endIndent: 17,
            ),
            Card(
              elevation: 0,
              child: ListTile(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => ProfileScreenPage(
                                type: 'profile',
                              )));
                },
                title: Text(
                  "My Profile",
                  style: TextStyle(fontSize: 18),
                ),
                trailing: Icon(Icons.person_outline),
              ),
            ),
            Divider(
              thickness: 1,
              indent: 17,
              endIndent: 17,
            ),
            Card(
              elevation: 0,
              child: ListTile(
                onTap: () {
                  // Navigator.push(context,
                  //     MaterialPageRoute(builder: (context) => WishList()));
                },
                title: Text(
                  "WishList",
                  style: TextStyle(fontSize: 18),
                ),
                trailing: Icon(Icons.list),
              ),
            ),
            Divider(
              thickness: 1,
              indent: 17,
              endIndent: 17,
            ),
            Card(
              elevation: 0,
              child: ListTile(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Bookings()));
                },
                title: Text(
                  "Bookings",
                  style: TextStyle(fontSize: 18),
                ),
                trailing: Icon(Icons.bookmark_outline_sharp),
              ),
            ),
            Card(
              elevation: 0,
              child: ListTile(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => MyDocuments()));
                },
                title: Text(
                  "My Document",
                  style: TextStyle(fontSize: 18),
                ),
                trailing: Icon(Icons.description_sharp),
              ),
            ),
            Divider(
              thickness: 1,
              indent: 17,
              endIndent: 17,
            ),
            Card(
              elevation: 0,
              child: ListTile(
                onTap: () {
                  _dialogLogOut();
                },
                title: Text(
                  "Log Out",
                  style: TextStyle(fontSize: 18),
                ),
                trailing: Icon(Icons.logout),
              ),
            ),
            Divider(
              thickness: 1,
              indent: 17,
              endIndent: 17,
            ),
          ],
        ),
      ),
    );
  }

  _dialogLogOut() async {
    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(('Logout!')),
          content: Text(('Do you want to logout?')),
          actions: <Widget>[
            FlatButton(
              child: Text(
                ('No'),
                style: TextStyle(color: Colors.red),
              ),
              onPressed: () {
                Navigator.of(context).pop(false); //Will not exit the App
              },
            ),
            FlatButton(
              child: Text(
                ('Yes'),
                style: TextStyle(color: Colors.indigo[800]),
              ),
              onPressed: () {
                logOut();
              },
            )
          ],
        );
      },
    );
  }

  Widget appBar() {
    return InkWell(
      onTap: () {
        // Navigator.push(
        //   context,
        //   MaterialPageRoute(
        //     builder: (context) => EditProfile(),
        //     fullscreenDialog: true,
        //   ),
        // );
      },
    );
  }
}
