// <<<<<<< HEAD
// =======
// import 'dart:convert';
// import 'dart:io';
// import 'dart:ui';
//
// import 'package:flutter/material.dart';
// import 'package:VromonBuzz/model/profile.dart';
// import 'package:VromonBuzz/provider/authenticate.dart';
// import 'package:VromonBuzz/provider/profile_provider.dart';
// import 'package:VromonBuzz/service/apiService.dart';
// import 'package:VromonBuzz/widget/login_widget.dart';
// import 'package:provider/provider.dart';
//
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
// class ProfilePage extends StatefulWidget {
//   @override
//   _ProfilePageState createState() => _ProfilePageState();
// }
//
// class _ProfilePageState extends State<ProfilePage> {
// //   Future<String> getToken() async {
// //     SharedPreferences _sharedPreferences =
// //     await SharedPreferences.getInstance();
// //     return _sharedPreferences.getString("token");
// //
// // }
// //   @override
// //   void initState() {
// //     super.initState();
// //     // print('Token.....>>>> ${getToken()}');
// //     // getToken();
// //   }
//   ProfileResponse profile;
//
//   List<ProfileResponse> p;
//
//   Future<String> _startLoadScreen() async {
//     SharedPreferences _sharedPreferences =
//         await SharedPreferences.getInstance();
//     String token = _sharedPreferences.getString("access_token");
//
//
//     var response = await http.get(
//         'https://vromonbuzz.com/api/login/profile?appKey=VromonBuzz',
//         headers: {
//           "Authorization": token,
//         });
//     setState(() {
//       if (response.statusCode == 200) {
//         profile = Profile.fromJson(json.decode(response.body)).response;
//         print("profile=======>>>${profile.aiFirstName}");
//         print(response.body);
//       } else {
//         print("failed");
//         print("$token");
//       }
//     });
//   }
//
//   @override
//   void initState() async {
//     super.initState();
//     SharedPreferences _sharedPreferences =await
//     SharedPreferences.getInstance();
//     String token = _sharedPreferences.getString("token");
//
//     print("gdgfusgfuysgfusgfugsuf$token");
//     //getToken();
//     _startLoadScreen();
//   }
//
//   @override
//   Widget build(BuildContext context)  {
//     //print("Token=====>> $token");
//
//     //ProfileProvider profile = Provider.of<ProfileProvider>(context);'
//
//
//
//     return Scaffold(
//       appBar: AppBar(),
//       body: Container(
//         child: ListView.builder(
//           itemCount: p == null ? 0 : p.length,
//           itemBuilder: (context, index) {
//             return Text(profile.aiFirstName);
//           },
//         ),
//       ),
//     );
//   }
//
//   _getToken(String token) async {
//     SharedPreferences localStorage = await SharedPreferences.getInstance();
//     var token = localStorage.getString('token');
//     return '?token=$token';
//   }
// }
// //
// >>>>>>> 1850955794eb86f2d1a44c32b604748b8266b596
// import 'dart:convert';
// import 'dart:io';
// import 'dart:ui';
//
// import 'package:flutter/material.dart';
// import 'package:VromonBuzz/model/profile.dart';
// import 'package:VromonBuzz/provider/authenticate.dart';
// import 'package:VromonBuzz/provider/profile_provider.dart';
// import 'package:VromonBuzz/service/apiService.dart';
// import 'package:VromonBuzz/widget/login_widget.dart';
// import 'package:provider/provider.dart';
//
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
// class ProfilePage extends StatefulWidget {
//   @override
//   _ProfilePageState createState() => _ProfilePageState();
// }
//
// class _ProfilePageState extends State<ProfilePage> {
// //   Future<String> getToken() async {
// //     SharedPreferences _sharedPreferences =
// //     await SharedPreferences.getInstance();
// //     return _sharedPreferences.getString("token");
// //
// // }
// //   @override
// //   void initState() {
// //     super.initState();
// //     // print('Token.....>>>> ${getToken()}');
// //     // getToken();
// //   }
//
//
//   Future<String> _startLoadScreen() async {
//     SharedPreferences _sharedPreferences =
//         await SharedPreferences.getInstance();
//     String token = _sharedPreferences.getString("token");
//     var response = await http.get(
//         'https://vromonbuzz.com/api/login/profile?appKey=VromonBuzz',
//         headers: {
//           "Authorization": _getToken(token),
//         });
//     setState(() {
//       if (response.statusCode == 200) {
//         profile = Profile.fromJson(json.decode(response.body)).response;
//         _sharedPreferences.getString('token');
//         print(response.body);
//       } else {
//         print("failed");
//         print("$token");
//       }
//     });
//   }
//
//   @override
//   void initState() {
//     super.initState();
//     //getToken();
//     _startLoadScreen();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     //print("Token=====>> $token");
//
//     //ProfileProvider profile = Provider.of<ProfileProvider>(context);
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Profile"),
//       ),
//       body: Container(
//         child: ListView.builder(
//           itemCount: p == null ? 0 : p.length,
//           itemBuilder: (context, index) {
//             return Text(profile.aiFirstName);
//           },
//         ),
//       ),
//     );
//   }
//
//   _getToken(String token) async {
//     SharedPreferences localStorage = await SharedPreferences.getInstance();
//     var token = localStorage.getString('token');
//     return '?token=$token';
//   }
// }
// //
// // import 'dart:convert';
// //
// // import 'package:flutter/material.dart';
// // import 'package:http/http.dart' as http;
// // import 'package:VromonBuzz/model/logonResponse.dart';
// // import 'package:shared_preferences/shared_preferences.dart';
// //
// // class LoginPage extends StatefulWidget {
// //   @override
// //   _LoginPageState createState() => _LoginPageState();
// // }
// //
// // class _LoginPageState extends State<LoginPage> {
// //   String token;
// //
// //   Future<void> login(String email, String password) async {
// //     final response = await http.post(
// //       "https://vromonbuzz.com/api/login/profile?appKey=VromonBuzz",
// //       body: {
// //         "email": email,
// //         "password": password,
// //       },
// //     );
// //
// //     savePref(token);
// //     print(response.body);
// //     final data = json.decode(response.body);
// //     print(data);
// //
// //     bool success = data["response"];
// //     String pMessage = data["message"];
// //
// //     if (success) {
// //       Map user = json.decode(response.body);
// //       if (user['data']['access_token'] != null) {
// //         print(user['data']['access_token']);
// //
// //         print(pMessage);
// //       }
// //     }
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: Text("Login"),
// //       ),
// //       body: Container(
// //         child: Column(
// //           children: [
// //             TextFormField(),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// //
// //   savePref(String token) async {
// //     SharedPreferences preferences = await SharedPreferences.getInstance();
// //
// //     return preferences.setString("token", token);
// //   }
// // }
// //

import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:new_motel/model/profile.dart';
import 'package:new_motel/modules/profile/update_profile.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../appTheme.dart';

class ProfileScreenPage extends StatefulWidget {
  final String token;
  final String type;

  const ProfileScreenPage({Key key, this.token, this.type}) : super(key: key);

  @override
  ProfileScreenPageState createState() => ProfileScreenPageState();
}

class ProfileScreenPageState extends State<ProfileScreenPage> {
  // Future<List<DataList>> fetchProfile() async {
  //
  //
  //
  // // }  //<---------------------------Load Token

  Uint8List _byteImage;

  Future loadToken() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    prefs.getString('apiToken');
    return prefs.getString('apiToken');
  }

  Future<ProfileInfo> getProfile() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String token = prefs.getString('apiToken');
    String id = prefs.getString('id');
    String url = "https://deshitour.com/api/login/profile?appKey=DeshiTour";
    print("Profile..>>>>$url");

    Map<String, String> requestHeaders = {
      'Content-type': 'application/json',
      'Accept': 'application/json',
      'authorization': token
    };
    // String _token = await loadToken();
    print("PRofileTOken.. $token");
    print("Profile..>>>>$id");
    var response = await http.get(url, headers: requestHeaders);
    print('API ${response.statusCode}\n API${json.decode(response.body)}');
    if (response.statusCode == 200) {
      profile =
          ProfileResponse.fromJson(json.decode(response.body)).profileInfo;
      return ProfileResponse.fromJson(json.decode(response.body)).profileInfo;
    } else {
      throw Exception(FAILED_MASSAGE);
    }
  }

  ProfileInfo profile;

  Future<ProfileInfo> futureProfileData;

  @override
  void initState() {
    super.initState();
    getProfile();
    //  loadToken();
    // FIRSTNAME_G = profile.ai_last_name;
    // FIRSTNAME = ;
    // EMAIL = user["email"];
    // LASTNAME = user["phone"];
    futureProfileData = getProfile();

    setState(() {});
  }

  // List<ProfileData> prfileGetUser;
  // bool loading = true;
  //
  // getAllUser() async {
  //   await ProfileService().getUser();
  //   setState(() {
  //     loading = false;
  //   });
  // }
  //
  // @override
  // void initState() {
  //   super.initState();
  //   getAllUser();
  // }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.black,
            ),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
          elevation: 1,
          title: RichText(
            text: TextSpan(
                text: DESHI,
                style: TextStyle(
                  fontSize: 30,
                  fontFamily: 'Impact',
                  color: HexColor("#26408A"),
                ),
                children: <TextSpan>[
                  TextSpan(
                      text: TOUR,
                      style: TextStyle(
                        fontSize: 30,
                        fontFamily: 'Impact',
                        color: HexColor("#118ACB"),
                      )),
                ]),
          ),

          // title: RichText(
          //   text: TextSpan(
          //       text: Vromon,
          //       style: TextStyle(
          //         fontSize: 30,
          //         fontFamily: 'Impact',
          //         color: HexColor("#26408A"),
          //       ),
          //       children: <TextSpan>[
          //         TextSpan(
          //             text: TOUR,
          //             style: TextStyle(
          //               fontSize: 30,
          //               fontFamily: 'Impact',
          //               color: HexColor("#118ACB"),
          //             )),
          //       ]),
          // ),
          actions: [
            // OutlinedButton(
            //   onPressed: () {
            //     print(" First Name: ${profile.aiFirstName}");
            //     Navigator.push(
            //         context,
            //         MaterialPageRoute(
            //             builder: (context) => ProfileUpdateScreen(
            //                   id: profile.accountsId,
            //                   firstName: profile.aiFirstName,
            //                   lastName: profile.aiLastName,
            //                   city: profile.aiCity,
            //                   state: profile.aiState,
            //                   country: profile.aiCountry,
            //                   address1: profile.aiAddress1,
            //                   address2: profile.aiAddress2,
            //                   phone: profile.aiMobile,
            //                   fax: profile.aiFax,
            //                   zip: profile.aiPostalCode,
            //                   photo: profile.photo,
            //                   email: profile.accountsEmail,
            //                   password: profile.accountsVerified,
            //                 )));
            //   },
            //   child: Text(
            //     "Update",
            //     style: TextStyle(fontSize: 20, color: Colors.black),
            //   ),
            // )
          ],
        ),
        body: userProfile(),
      ),
    );
  }

  userProfile() {
    return SingleChildScrollView(
      child: InkWell(
        splashColor: Colors.white,
        highlightColor: Colors.white,
        focusColor: Colors.white,
        onTap: () {
          FocusScope.of(context).requestFocus(FocusNode());
        },
        child: FutureBuilder<ProfileInfo>(
          future: futureProfileData,
          builder: (BuildContext context, AsyncSnapshot<ProfileInfo> snapshot) {
            if (snapshot.hasData) {
              //   String thumbnail= snapshot.data.photo;
              //
              //   print("Base 64 data $thumbnail");
              //
              //
              //
              // //  String placeholder = "iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DHxgljNBAAO9TXL0Y4OHwAAAABJRU5ErkJggg==";
              //   // if (thumbnail?.isEmpty ?? true)
              //   //   thumbnail = placeholder;
              //   // else {
              //   //   switch (thumbnail.length % 4) {
              //   //     case 1:  break; // this case can't be handled well, because 3 padding chars is illeagal.
              //   //     case 2:  thumbnail = thumbnail + "=="; break;
              //   //     case 3:  thumbnail = thumbnail + "="; break;
              //   //   }
              //   // }
              //
              //   if (thumbnail!= null) {
              //     if(thumbnail.contains(",")){
              //       var parts = thumbnail.split(',');
              //       var prefix = parts[1].trim();
              //
              //  //     _bytesImage = Base64Decoder().convert(prefix);
              //        _byteImage = Base64Decoder().convert(prefix);
              //     }else {
              //       // _bytesImage = Base64Decoder().convert(thumbnail);
              //        _byteImage = Base64Decoder().convert(thumbnail);
              //     }
              //   }
              //
              //   print("Base 64 data 2:  $thumbnail");
              //   //String img = "iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAABmJLR0QA/wD/AP+gvaeTAAASKUlEQVR4nO3dfZBfVX3H8feGZDeYBBIZhUoCJCQkYKgoTotWQ0USiIBVitjyoFZx6IwtUloeWotkxoIII53UTltRHgoZwKIVRjutToAGkIdAHVGUJAtNIAQrGhLysHna7PaP7y+TZLNLfufec+73nvv7vGa+s8vyy+73nt8953fvuecBRERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERETqoss7AUlmLDALmAkc0/p+GjCuFZNaXwE2A+taXzcBK4FlwHJgRev7rRXmLhVRA9Aco4F3AKe24n1YIxBDP/AMsLgVjwDbIv1uESnoAGAucCf2yT1YUWwE7sAamlHJj1JE9nIk8BXgZaqr9CPFauB64IikRywiTAMWYvfj3hV/aGzHrgpmJTt6kQ51NHAPsBP/ir6/6AfuwhorESmhG7gS2IJ/xQ6NPmAB8ToiRTrK6UAv/hW5bKwA5kUuG5HGGo11qg3gX3ljxQDWd9EdsZxEGucI4HH8K2yqeBrrzxCRIc4A1uNfSVPHOuBDkcpMpBEuxB6jeVfOqqIfuChKyUkpGgrs7wrsnj/Ve7EceBIbz78C61jcxO6x/7B7bsAEYAY2d2AmcFLr+xQGsSccNyb6/SK1dz3xP137gLuBC4C3RcjxcOwK5VukeRx5XYQcRbJzBXEr0pPAZ4CDE+Z8MHbpvjRy7pcnzFmkdi4g3mO+R4Gzqk0fsNmG3yuQ73AxAHy62vRFfJwJ7KB8pXkOOKXi3IczF+tfKHs824H5FecuUqlpWOdbmYrSB1xFvQbV9ABfoHwfwWvAURXnLlKJMZQf5LMMW/Sjro4DnqXcMS6lXo2bSBQLKVcxFgHjK8863ARs5mKZY72p8qxFEjqdcp1+15HXmI0ubMGSosc7gPUtiGRvLMVn9Q0Al1afcjSXUbzhW471LYhkbQHFPwkvc8g3ts9R/Pi/4JCvSDRHU7xn/O8c8k3lBoqVQR9aWUgyVrQzbBF53fPvTxc2lLhoWYhkZzo26y30hF+B9aQ3zXhs8FJoefRjE5REsnIb4Sf7FuAEj2Qrcjx2WR9aLt/wSFakqCnYzjmhJ/pVHslW7GrCy2U7theCSBaKPAP/BZ0xAq4He8QXWj5f9khWJNQBFNuxpw4Te6oyj/DyeQltQyYZKHJyP+CSqa8lqJGUBroTndjtKNJQ3uaSqUibugnfpfdJl0zr4SnCymoDNqtSItE9VVwnYQtshrg5RSKZCH28NwH4nRSJdCo1AHGFXspvBb6TIpFM7FpoNEQn3i4lowYgrg8Evv4+bDOQTvU68P3AfxNaxiKVOBD7RA+5pz3fJdN6+QRhZbYF7TgsNXQC4b3ah7tkWi9TCC+3410ybSDdAsQzM/D1y4A1KRLJzGrg+cB/E1rWMgI1APGEnpRLk2SRpycCXz8rSRYdSA1APEWuAMQsD3x9qv0KO44agHhC17NfkSSLPIU2AFOTZNGB1ADEc1Dg619IkkWeQvsAQstaRqAGIJ7QVXzWJckiT6FjIZq4YpILNQDxhJ6UG5NkkafQslADILUTugJQJyz+0a4ewspuq0+azaMrAJEOpgYgnk2Br89hn7+q6PbJiRqAeHQfW5waACdqAOLZEPj6SUmyyFNoWagBiEQNQDyhDcDRSbLIU2hZhJa1jEANQDwvBr5eE1p2Cx3bvzJJFh1IDUA8oWP71QDsFjq2P3TosIxADUA8oWP7fzdJFnk6KfD1agCkdoosCDLZJdN60YIgjnQFEM8ybDRgCK1vV2whVc2kjEQNQDxbCV/Y4swUiWTmrMDXP054QysjUAMQ10OBr/8wMDFFIpmYRHgj+GCKRDqVGoC4Qk/OscA5KRLJxLnYRKAQagCktrqxUWohHVqdvDbg04SV1etoazCpuTsI79U+1SVTX6cTXk63umQqEmAu4Sd2aN9BEzxMeDnpqYnU3ihsrfvQk3uuR7JO5hNePi+iPivJxPWEn+DLCO8Qy9FYoJfw8rnOI1mRIqYQvkTYIPA3HslW7BrCy2U7cKRHsiJF3UL4ib4VeKdHshX5bWxzz9By+bpHsiJlHA3sIPxk76WZ695PwG5zQsujH5jhkK9IaXcRfsIPAvcAXQ75ptIFfJtiZXGHQ74iURwJbKbYif8Vh3xT+SrFyqAPbQMmmfsixU7+QeAvHfKN7QqKH/9fO+QrElUPNn21SAUYAC6rPuVoLseOocixL0Obp0hDzKN4RRgEbiCvPoEuil/272r4Plh51iIJ3UTxCjEIfIs89hI4mOIdfrvixsqzFklsDPAY5SrGSuq9luC7KDbKb894El36S0NNxbYFL1NBtgBXU69hw2OxEX5bKXdsa9GIP2m4D1FsgNDQWI71LXibT/lP/UFsuO9pFecu4uJ8ynUK7hmPYuvqVd1J+D5gccncd8UA8Klq0xfxdTlxKs+ueAr4LGnXGJwEXEz4Sj77iyaMdxAJdh1xK9Ig1kdwL/AJ4uw7MAX4JNazX/Yef7i4NkKOUlBOz5ab6nJs2G+q96IX61lfhg1IegFY34pNrdeMx64cJmKTmGa24iRgeqK8BrFj/2qi3y+SjQuwTrDYn651jR3AZ6KUnEhDzAdew79ypo61qLdfZFhHAD/Cv5KmiqeAadFKS6SBRgMLgJ34V9hYMQAsRCP8RNo2Fxvs4115y8YyNLFHpJAxwOcJ322oDtGHXcnUaciySJamAouw9fG8K/b+YgdwJxrTLxLdVOxeusjKuqljO7Z+3zHJjl5EABuddx3wEv4V/yVsNN+UpEcsIvsYBZwC3A5soLpK/zpwG7ZXn7brypiGAjfHAcAJ2E7Dp2Kz9cZG+t39wDPY7L/FwCPYzkeSOTUAzdUDzMLuyY9pfT8VG/c/ARv3P7712k3Y3ICNre//F3sEuRybP7AcVXgRERERERERERERERERERERERERERERERERERERERERkUpoQZDm6AKOwnYXmgwctsfXw4E3Ydt7M8zXrdhCo2CLgqxrxWvAr4E1wIvAy62vq7CNSyRzagDydCi2/NfxwHHAbOBYdq/wk9o2bMOP5cCzwP+04lcV/X2JRA1AHqYC798jZvqmM6KXsa3Il7TiWWxbMBEJcCDwYeCbwGr8l/4uGmuBb2Nbgb8tagmJNMxbgE8D9wGb8a+8sWMA+DFwDXbbItLxuoGzge+Tx7ZfMeNZ4ItYwyfSUWYDNwGv4l8RvWMDcG654hSpv1HAR4BH8a90dYudwJnFi1akvnqAz2KPzbwrWp1jNfF2MhJxNw64Cvgl/pUrlzi7UEnXRzfW4GdjtHcCDTQauAjr7T7MOZfcnAj8u3cSb+Aw4L3YOIwZ2JZrk4GDsO3WdtWnnVjfxkZsFOUKoLf19bHWz6RhuoA/xEbHeX+S5ho3BZd6WgdiHZQ3E/cWrhe4FTiP6kZvDktXAHG8G/gacJJzHoPASuxkXQO8skf8ChuYAzbOf8+v3dgtSxe2aeikVhyKDeCZDExh96ded6L8VyX6vSFGYbsrnw98FPtkj216K/4E6APuB+4CfgDsSPD3JJEJwEJ8nuFvw54o3Ah8CmuExqU9XMC2IZ+OVY5rgf8CfhPheAawxsVLD3br5nkFtwq4hGreRynpo1Q7THcL9gnxt8Ac7PK0LrqwiUmXYPfw6wk/vvsrz9qMAS7F5jF4Vfyh8WvsfX5TwuOWgn4LG65bxYnwG+Bfsb6FnD4VurHL6H/Apg/v7zhfwMq1aqcAP28jP69YRf5PRhrlTNKP3tuATQL6fexyO3ejgJOxjrR17H2sW1s/r3o48FuAu0n7PsaMH2IzQsXJWOzTbIA0b/AA8DB2L5/TJ32oMcDvARdiVwge8wDmUK/L/XZjPfCxBOUh+3Ec8Axp3tQtwL9Q3/n9TTIKu6/egX9lLhP/TL36fxrt46SZmrsW+BLw1uoOpaP1APfiX3ljxRPAIVFLSPbShVXQ2Jf8a4G/otmX+XUzAViMf6WNHc8BR0YsJ2kZjz3Kivlm9QHXY4NspDqHAEvxr6yp4mXg7dFKSziKuPf7O7Ehn5OrPAgBrCF/Ev9KmjpeQU8IojiWuAN7fgq8p9IjkF3GAP+Jf+WsKp7Hhm1LQe/GRl/FeDM2A1diJ6FUrwtYhH+lrDqWor6lQuYArxPnTViMLse8XYp/ZfSK2yOUX0eZj3XQlS34HcAC7Fmz+DkRG13oXRE948LSpdghPkick2UltkiE+BqPll0bxBYh0cCy/XgPsInyhb2INPPFJdw/4l/56hKPoF2/RnQ8NiCnTAEPYJf8Ug+zyX+Ib+w4v1SJNtQMyi/S+TpwRtWJy4i6sIlUXhXtFWx05zHYkOOJ2DTjO7BxIF55rUFXp3t5K3a/XqZQe9G2VnXzMfwq2QO88ejOU4n3hKlIXNt2KTZcN3ZfVKYwf4IGW9TRj/GpXMtp7xP2I075DWJTiA9uI8fGu5lyBfkYtkim1Ms8/CrXxwPyfNAxzysC8mykz1GuABfjvHSzjMhrll8fYXPyL3bKcxDro8hqs5KYPgBsp3jh/QcdXHg1NwO/SrUsMNeTHXMd5A02X23yyLVDgXsoPiZ/CXAOtvy21M95jn97U+LXx/ZHzn+/cl3A9yjeYv4Ezd2vO89Rf08H5nqiY66D2IjXYc/npl4B/BnFt5t+Dnt8sz5eOhLZO9Fw1xA9wB8M9z+a2ADMBm4o+G9/CZyGrccv9TXXO4EMDVtmTWsAerDx+UX2md+OPdpZHTUjSWGOdwIZOtk7gSp8ieL3SRc55CvhRrHvBiPqA2gvGr1WxUyKT+/9e4d8pZjZ+FekXBuAC4Ym1qRbgH+i2DP7JcDlkXORdNT5V1xjy+48irWIr2H73ks+riLNp+PQWX1Vq2IW4T2VHU2FJlJ8iq/2WsvPLcSvGPub1Ve1VLMIQ29dsvBlihXGrR7JSmk/JG6laHdWX9VSzCJ8tdIjqEAXxbbrfgFN8MnV48StFCGz+qoWexbh1mrTT28KxQriNI9kJYqfEa9ChM7qq1qKWYR7zY3J/SlAkYk+/wb8IHYiUpmYV24vYVu011XorMN27HW7k3sDsJqwy5oNwF8kykWqkfs5623UiP+RoR3YnP12XY097pF8xZxaewT1vgU4NsHv3Jjgd7qaTXuLfjwCHOCUo8QTe8ffOs+Vf4i4x7q92vSr88fYwh0jHXgv1tpL/h4gbqXoBQ6q9AjaczbxOwDXVnoEFXsXcB/Qz+4DfhW4kXq+wVJMip1/H6Rei77Ow/qrYh/nz6o8CC/jsLX7J5N/H4fs6xriV4xB4P+wFXRnUWw6eVlvxvarXES6ocDfrexoRBI5nzSVIyRynQ24z0I5+oSU3KzwTiBjvUN/oAZAcvNTGjiktSJPDP2BGgDJzTbsUaCEeQ34+dAfqgGQHC3xTiBDD2Pb2u9FDYDk6CHvBDI0bJmpAZAcPQys8U4iIwPAd4b7H2oAJEcDwL3eSWRkCSM0mGoAJFd3O/7t0CnJ3isONXItQOlsXcAz+AyoCV1I5E+d8hzEhhSPOMxZVwCSq0FsnoeHAxlhr70ReC479g1sIxWRxhkDrMLnk7XdWYQpZvW1G9uwOTEijfXn+FWw/c0iTDWrr924pe1SFMlUN7Z2nlclGzqLsIpZfe3ERuDwEuUqko25+FW0usaVpUpUJDP341/p6hK9+GxvJuJmCrbklXfl845+YE7JshTJ0hnYKEHvSugZ15QuRZGMfQ3/SugVS9DK19LhxgKP4V8Zq47VqNdfBIBDgF/gXymrivXAO6KUnEhDTAZexL9ypo4twPsjlZlIo7wd2wrOu5KmrPxnRSstkQY6Ct+RgqliHXrcJ9KWNwM/wr/SxopX0D2/SJBxwO34V96y8d+ot1+ksHOwy2fvihwa/cAC9JxfpLQZ2Hbx3pW63ViO7vdFojuLej8q3Ix96mtij0giE4BrscE03hV+V2zDFvPQvb5IRSYAn8eG1HpV/I3AQmxmo4g46AHOBb6LbUKautLvxHbtuRiYWMHxiUibDgY+CdxJ3CuDtcB9wCU4X+Z3ef5xkcxMA96Lrf83vRVHYrcPQzvq+rFL+jXYCj3Pt+JxbJfefTbq9KAGQCSO0ezeAagP68gTERERERGpk/8HhcH2sU3qffYAAAAASUVORK5CYII=";

              // print(
              //     "Get Photo${"https://deshitour.com/uploads\/images\/user\/650_45697c35-5049-411c-b8d4-b7b08bfe5dd67769382983594217900.jpg"}");

              return Expanded(
                child: Column(
                  children: [
                    SizedBox(
                      height: 30,
                    ),
                    CircleAvatar(
                      backgroundColor: Colors.black,
                      radius: 60.0,
                      child: Center(
                        child: CircleAvatar(
                          backgroundColor: Colors.white,
                          radius: 57.0,
                          backgroundImage: snapshot.data.photo == null
                              ? AssetImage("assets/images/person.png")
                              : NetworkImage(
                                  "https://deshitour.com/" +
                                      snapshot.data.photo,
                                ),
                        ),
                      ),
                    ),

                    // FirstName Fields
                    Padding(
                      padding: const EdgeInsets.only(left: 8, right: 16),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 16.0, bottom: 16, top: 16),
                              child: Text(
                                "First Name",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                  color: AppTheme.getTheme()
                                      .disabledColor
                                      .withOpacity(0.3),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                right: 16.0, bottom: 16, top: 16),
                            child: Container(
                              child: Text(
                                snapshot.data.aiFirstName,
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),

                    // LastName Fields
                    Padding(
                      padding: const EdgeInsets.only(left: 8, right: 16),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 16.0, bottom: 16, top: 16),
                              child: Text(
                                "Last Name",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                  color: AppTheme.getTheme()
                                      .disabledColor
                                      .withOpacity(0.3),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                right: 16.0, bottom: 16, top: 16),
                            child: Container(
                              child: Text(
                                snapshot.data == null
                                    ? 0
                                    : snapshot.data.aiLastName,
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),

                    // // Email Fields
                    Padding(
                      padding: const EdgeInsets.only(left: 8, right: 16),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 16.0, bottom: 16, top: 16),
                              child: Text(
                                "Email",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                  color: AppTheme.getTheme()
                                      .disabledColor
                                      .withOpacity(0.3),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                right: 16.0, bottom: 16, top: 16),
                            child: Container(
                              child: Text(
                                snapshot.data == null
                                    ? 0
                                    : snapshot.data.accountsEmail,
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    //
                    // // Phone Number Fields
                    Padding(
                      padding: const EdgeInsets.only(left: 8, right: 16),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 16.0, bottom: 16, top: 16),
                              child: Text(
                                "Phone Number",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                  color: AppTheme.getTheme()
                                      .disabledColor
                                      .withOpacity(0.3),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                right: 16.0, bottom: 16, top: 16),
                            child: Container(
                              child: Text(
                                snapshot.data == null
                                    ? 0
                                    : snapshot.data.aiMobile,
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),

                    // City Fields
                    Padding(
                      padding: const EdgeInsets.only(left: 8, right: 16),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 16.0, bottom: 16, top: 16),
                              child: Text(
                                "City",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                  color: AppTheme.getTheme()
                                      .disabledColor
                                      .withOpacity(0.3),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                right: 16.0, bottom: 16, top: 16),
                            child: Container(
                              child: Text(
                                snapshot.data.aiCity ?? "",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),

                    // // State Fields
                    Padding(
                      padding: const EdgeInsets.only(left: 8, right: 16),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 16.0, bottom: 16, top: 16),
                              child: Text(
                                "State",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                  color: AppTheme.getTheme()
                                      .disabledColor
                                      .withOpacity(0.3),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                right: 16.0, bottom: 16, top: 16),
                            child: Container(
                              child: Text(
                                snapshot.data.aiState ?? "",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    //
                    // // Country Fields
                    Padding(
                      padding: const EdgeInsets.only(left: 8, right: 16),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 16.0, bottom: 16, top: 16),
                              child: Text(
                                "Country",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                  color: AppTheme.getTheme()
                                      .disabledColor
                                      .withOpacity(0.3),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                right: 16.0, bottom: 16, top: 16),
                            child: Container(
                              child: Text(
                                snapshot.data.aiCountry ?? "",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    //
                    // // Address1 Fields
                    Padding(
                      padding: const EdgeInsets.only(left: 8, right: 16),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 16.0, bottom: 16, top: 16),
                              child: Text(
                                "Address1",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                  color: AppTheme.getTheme()
                                      .disabledColor
                                      .withOpacity(0.3),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                right: 16.0, bottom: 16, top: 16),
                            child: Container(
                              child: Text(
                                snapshot.data.aiAddress1 ?? "",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),

                    // // Address2 Fields
                    Padding(
                      padding: const EdgeInsets.only(left: 8, right: 16),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 16.0, bottom: 16, top: 16),
                              child: Text(
                                "Address2",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                  color: AppTheme.getTheme()
                                      .disabledColor
                                      .withOpacity(0.3),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                right: 16.0, bottom: 16, top: 16),
                            child: Container(
                              child: Text(
                                snapshot.data.aiAddress2 ?? "",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),

                    // // Zip Fields
                    Padding(
                      padding: const EdgeInsets.only(left: 8, right: 16),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 16.0, bottom: 16, top: 16),
                              child: Text(
                                "Zip",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                  color: AppTheme.getTheme()
                                      .disabledColor
                                      .withOpacity(0.3),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                right: 16.0, bottom: 16, top: 16),
                            child: Container(
                              child: Text(
                                snapshot.data.aiPostalCode ?? "",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),

                    // // Fax Fields
                    Padding(
                      padding: const EdgeInsets.only(left: 8, right: 16),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 16.0, bottom: 16, top: 16),
                              child: Text(
                                "Fax",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                  color: AppTheme.getTheme()
                                      .disabledColor
                                      .withOpacity(0.3),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                right: 16.0, bottom: 16, top: 16),
                            child: Container(
                              child: Text(
                                snapshot.data.aiFax ?? "",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),

                    // Password Fields
                    Padding(
                      padding: const EdgeInsets.only(left: 8, right: 16),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 16.0, bottom: 16, top: 16),
                              child: Text(
                                "accounts_verified",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                  color: AppTheme.getTheme()
                                      .disabledColor
                                      .withOpacity(0.3),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                right: 16.0, bottom: 16, top: 16),
                            child: Container(
                              child: Text(
                                snapshot.data.accountsVerified ?? "",
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 24, right: 24, bottom: 8, top: 16),
                      child: Container(
                        height: 48,
                        decoration: BoxDecoration(
                          color: HexColor("#6fbe44"),
                          //  color: AppTheme.getTheme().primaryColor,
                          borderRadius: BorderRadius.all(Radius.circular(24.0)),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: AppTheme.getTheme().dividerColor,
                              blurRadius: 8,
                              offset: Offset(4, 4),
                            ),
                          ],
                        ),
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            borderRadius:
                                BorderRadius.all(Radius.circular(24.0)),
                            highlightColor: Colors.transparent,
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => ProfileUpdateScreen(
                                            id: profile.accountsId,
                                            firstName: profile.aiFirstName,
                                            lastName: profile.aiLastName,
                                            city: profile.aiCity,
                                            state: profile.aiState,
                                            country: profile.aiCountry,
                                            address1: profile.aiAddress1,
                                            address2: profile.aiAddress2,
                                            phone: profile.aiMobile,
                                            fax: profile.aiFax,
                                            zip: profile.aiPostalCode,
                                            photo: profile.photo,
                                            email: profile.accountsEmail,
                                            password: profile.accountsVerified,
                                          )));
                            },
                            child: Center(
                              child: Text(
                                "Update Profile",
                                style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16,
                                    color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            } else {
              return Center(
                child: CircularProgressIndicator(),
              );
            }
          },
        ),

        // ListView.builder(
        //   itemCount: prfileGetUser == null ? 0 : prfileGetUser.length,
        //   itemBuilder: (_, index) {
        //     ProfileData profileData = prfileGetUser[index];
        //     return Container(
        //       child: Column(
        //         children: [
        //           Text(profileData.ai_first_name.toString()),
        //         ],
        //       ),
        //     );
        //   },
        // ),
      ),
    );
  }

  Widget getProfileUI() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Container(
            width: 120,
            height: 130,
            child: Stack(
              alignment: Alignment.center,
              children: <Widget>[
                Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    color: AppTheme.getTheme().primaryColor,
                    shape: BoxShape.circle,
                    boxShadow: <BoxShadow>[
                      BoxShadow(
                        color: AppTheme.getTheme().dividerColor,
                        blurRadius: 8,
                        offset: Offset(4, 4),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(150.0)),
                    child: Container(
                      child: Image.network(
                          "https://cdn2.vectorstock.com/i/1000x1000/17/61/male-avatar-profile-picture-vector-10211761.jpg"),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 6,
                  right: 6,
                  child: Container(
                    decoration: BoxDecoration(
                      color: AppTheme.getTheme().primaryColor,
                      shape: BoxShape.circle,
                      boxShadow: <BoxShadow>[
                        BoxShadow(
                          color: AppTheme.getTheme().dividerColor,
                          blurRadius: 8,
                          offset: Offset(4, 4),
                        ),
                      ],
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.all(Radius.circular(24.0)),
                        onTap: () {},
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Icon(
                            Icons.camera_alt,
                            color: AppTheme.getTheme().backgroundColor,
                            size: 18,
                          ),
                        ),
                      ),
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget appBar() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SizedBox(
          height: AppBar().preferredSize.height,
          child: Padding(
            padding: EdgeInsets.only(top: 8, left: 8),
            child: Container(
              width: AppBar().preferredSize.height - 8,
              height: AppBar().preferredSize.height - 8,
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.all(
                    Radius.circular(32.0),
                  ),
                  onTap: () {
                    // Navigator.push(
                    //     context,
                    //     MaterialPageRoute(
                    //         builder: (context) => ProfileScreen()));
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Icon(Icons.arrow_back),
                  ),
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 4, left: 24),
          child: Text(
            "Edit Profile",
            style: new TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    );
  }
}
