// import 'dart:convert';
// import 'dart:io';
//
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:http/http.dart' as http;
// import 'package:new_motel/loaderPage.dart';
// import 'package:new_motel/model/myBookingResponse.dart';
// import 'package:new_motel/service/apiService.dart';
// import 'package:new_motel/utils/constants.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:smooth_star_rating/smooth_star_rating.dart';
//
// import '../../appTheme.dart';
//
// class Bookings extends StatefulWidget {
//   @override
//   _BookingsState createState() => _BookingsState();
// }
//
// class _BookingsState extends State<Bookings> {
//   ScrollController scrollController = ScrollController(initialScrollOffset: 0);
//   var loading;
//   // ...>>>>>>>>>>>>
//   // DateTimeRange dateRange;
//   // String checkIn(startDate) {
//   //   if (dateRange == null) {
//   //     return 'Check in';
//   //   } else {
//   //     return DateFormat('MM/dd/yyyy').format(dateRange.start);
//   //   }
//   // }
//   //
//   // String checkOut(endDate) {
//   //   if (dateRange == null) {
//   //     return 'Check out';
//   //   } else {
//   //     return DateFormat('MM/dd/yyyy').format(dateRange.end);
//   //   }
//   // }
//
//   String message;
//   bool status;
//
//   ///Date Time........>>>>
//
//   MyBookingResponse myBookingResponse;
//   List<Response> response1;
//   getMyBookingJSONData() async {
//     try {
//       SharedPreferences sharedPreferences =
//           await SharedPreferences.getInstance();
//       String userId = sharedPreferences.getString('id');
//       loading = true;
//       var response = await http.get(ApiService.mybooking + "&id=$userId");
//       bool isSuccess = response.statusCode == 200;
//       status = json.decode(response.body)['error']['status'];
//       message = json.decode(response.body)['error']['msg'];
//
//       if (!status) {
//         if (isSuccess) {
//           setState(() {
//             loading = false;
//             myBookingResponse =
//                 MyBookingResponse.fromJson(json.decode(response.body));
//             print(response.body);
//             print("Bokkkkkingggg$message");
//
//             response1 = myBookingResponse.response;
//             print("${response1.length}");
//           });
//         }
//       } else {
//         Fluttertoast.showToast(
//             msg: message,
//             toastLength: Toast.LENGTH_SHORT,
//             gravity: ToastGravity.BOTTOM,
//             timeInSecForIosWeb: 3,
//             backgroundColor: Colors.indigo[800],
//             textColor: Colors.white,
//             fontSize: 20.0);
//       }
//
//       // else {
//       //
//       // }
//       // Fluttertoast.showToast(
//       //     msg: message,
//       //     toastLength: Toast.LENGTH_SHORT,
//       //     gravity: ToastGravity.BOTTOM,
//       //     timeInSecForIosWeb: 4,
//       //     backgroundColor: Colors.indigo[800],
//       //     textColor: Colors.white,
//       //     fontSize: 16.0);
//
//       return "response";
//     } catch (e) {}
//   }
//
//   Future<bool> getData() async {
//     await Future.delayed(const Duration(milliseconds: 50));
//     return true;
//   }
//
//   Future<void> cancelBooking(
//     String id,
//   ) async {
//     final body = {
//       "id": id,
//     };
//
//     final jsonString = json.encode(body);
//     print("JSonEncoded.....>>>>$jsonString");
//     final headers = {HttpHeaders.contentTypeHeader: 'application/json'};
//
//     final response = await http.post(ApiService.cancelbooking,
//         headers: headers, body: jsonString);
//     try {
//       var data = json.decode(response.body);
//       print(data);
//       print("response==>>  ${data['response']['msg']}");
//       // Check if User's Creds is valid,
//       // var isSuccess = data['response'] == true; // Write you own condition;
//       //  getMyBookingJSONData();
//       Fluttertoast.showToast(
//           msg: (data['response']['msg']),
//           toastLength: Toast.LENGTH_SHORT,
//           gravity: ToastGravity.BOTTOM,
//           timeInSecForIosWeb: 2,
//           backgroundColor: Colors.indigo[800],
//           textColor: Colors.white,
//           fontSize: 16.0);
//       // setState(() {
//       //   setButton();
//       // });
//
//     } catch (e) {
//       print(e);
//     }
//   }
//
//   //
//
//   Future<void> changeBookingDate(
//       String id, String start_date, String end_date) async {
//     final body = {
//       "id": id,
//       "start_date": start_date,
//       "end_date": end_date,
//     };
//
//     final jsonString = json.encode(body);
//     print("JSonEncoded.....>>>>$jsonString");
//     final headers = {HttpHeaders.contentTypeHeader: 'application/json'};
//
//     final response = await http.post(ApiService.changeBookingDate,
//         headers: headers, body: jsonString);
//     var error = json.decode(response.body)['msg'];
//     print("error  $error");
//     try {
//       var data = json.decode(response.body)['status'];
//       print("Date Picker Data...$data");
//       print("response==>>  ${data['status']}");
//       if (data == 1) {
//         Fluttertoast.showToast(
//             msg: 'Succesfully date changed',
//             toastLength: Toast.LENGTH_SHORT,
//             gravity: ToastGravity.BOTTOM,
//             timeInSecForIosWeb: 2,
//             backgroundColor: Colors.indigo[800],
//             textColor: Colors.white,
//             fontSize: 16.0);
//         Navigator.pop(context);
//         Navigator.of(context).pop();
//       } else {
//         print("error  $error");
//         Fluttertoast.showToast(
//             msg: error,
//             toastLength: Toast.LENGTH_SHORT,
//             gravity: ToastGravity.BOTTOM,
//             timeInSecForIosWeb: 2,
//             backgroundColor: Colors.indigo[800],
//             textColor: Colors.white,
//             fontSize: 16.0);
//       }
//       // Check if User's Creds is valid,
//       // var isSuccess = data['response'] == true; // Write you own condition;
//
//     } catch (e) {
//       print(e);
//     }
//   }
//
//   // Future _selectDate() async {
//   //   DateTime picked = await showDatePicker(
//   //       context: context,
//   //       initialDate: new DateTime.now(),
//   //       firstDate: new DateTime(2020),
//   //       lastDate: new DateTime(2030));
//   //   if (picked != null)
//   //     setState(() => {
//   //           data.registrationdate = picked.toString(),
//   //           intialdateval.text = picked.toString()
//   //         });
//   // }
//   // final format = new DateFormat.yMMMEd('en-US');
//   // DateTime _startDate = DateTime.now();
//   // DateTime _endDate = DateTime.now()
//   //     .add(Duration(days: 1));
//
//   // DateTime _startDate = DateTime.now();
//   // DateTime _endDate = DateTime.now().add(Duration(days: 1));
//   // Future displayDateRangePicker(BuildContext context) async {
//   //   final List<DateTime> picked = await DateRagePicker.showDatePicker(
//   //       context: context,
//   //       initialFirstDate: _startDate,
//   //       initialLastDate: _endDate,
//   //       firstDate: new DateTime(DateTime.now().year - 50),
//   //       lastDate: new DateTime(DateTime.now().year + 50));
//   //   if (picked != null && picked.length == 2) {
//   //     setState(() {
//   //       _startDate = picked[0];
//   //       _endDate = picked[1];
//   //     });
//   //   }
//   // }
//
//   // DateTime selectedDate = DateTime.now();
//   //
//   // Future<DateTime> _selecteDate(BuildContext context) async {
//   //   final DateTime picked = await showDatePicker(
//   //     context: context,
//   //     initialDate: selectedDate,
//   //     firstDate: DateTime(2000),
//   //     lastDate: DateTime(2050),
//   //     helpText: "Select Change Date",
//   //     confirmText: "OK",
//   //   );
//   //   if (picked != null && picked != selectedDate) {
//   //     setState(() {
//   //       selectedDate = picked;
//   //     });
//   //   }
//   //   setState(() {
//   //
//   //   });
//   //   return selectedDate;
//   // }
//
//   DateTime selectedDate = DateTime.now();
//   final controller = TextEditingController();
//   // String presentText;
//
//   void _selectDate() async {
//     final DateTime picked = await showDatePicker(
//         context: context,
//         initialDate: DateTime.now(),
//         firstDate: DateTime(2015, 8),
//         lastDate: DateTime(2101));
//     if (picked != null && picked != selectedDate)
//       setState(() {
//         selectedDate = picked;
//         controller.text = picked.toString();
//       });
//   }
//
//   @override
//   void initState() {
//     super.initState();
//     // _selecteDate(context);
//     getMyBookingJSONData();
//     // setState(() {
//     //   _selecteDate(context);
//     // });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     MediaQueryData queryData;
//     queryData = MediaQuery.of(context);
//     return SafeArea(
//       child: Scaffold(
//         backgroundColor: Colors.white,
//         appBar: AppBar(
//           leading: IconButton(
//             icon: Icon(
//               Icons.arrow_back,
//               color: Colors.black,
//             ),
//             onPressed: () {
//               Navigator.pop(context);
//             },
//           ),
//           backgroundColor: Colors.white,
//           elevation: 1,
//           title: RichText(
//             text: TextSpan(
//                 text: DESHI,
//                 style: TextStyle(
//                   fontSize: 30,
//                   fontFamily: 'Impact',
//                   color: HexColor("#26408A"),
//                 ),
//                 children: <TextSpan>[
//                   TextSpan(
//                       text: TOUR,
//                       style: TextStyle(
//                         fontSize: 30,
//                         fontFamily: 'Impact',
//                         color: HexColor("#118ACB"),
//                       )),
//                 ]),
//           ),
//         ),
//         body: response1 == null
//             ? Center(
//                 child: LoaderPage(
//                   msg: "",
//                 ),
//               )
//             : ListView.builder(
//                 itemCount: response1.length,
//                 itemBuilder: (_, index) {
//                   print("index = $index");
//                   final item = response1[index];
//                   String checkin = item.checkin;
//                   String checkout = item.checkout;
//
//                   String changedCheckin = item.checkin;
//                   String changedCheckout = item.checkout;
//
//                   return ClipRRect(
//                     borderRadius: BorderRadius.circular(24.0),
//                     child: Card(
//                       elevation: 5,
//                       margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
//                       child: Container(
//                         width: double.infinity,
//                         height: 320,
//                         decoration: BoxDecoration(boxShadow: [
//                           BoxShadow(
//                               offset: Offset(0, 10),
//                               blurRadius: 30,
//                               color: kShadowColor)
//                         ]),
//                         child: Column(
//                           mainAxisAlignment: MainAxisAlignment.start,
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: <Widget>[
//                             SizedBox(
//                               height: 12,
//                             ),
//
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.start,
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 Padding(
//                                   padding: const EdgeInsets.only(
//                                       left: 8.0,
//                                       top: 4.0,
//                                       right: 4.0,
//                                       bottom: 4.0),
//                                   child: Container(
//                                     width: 150,
//                                     height: 65,
//                                     decoration: new BoxDecoration(),
//                                     child: Expanded(
//                                       flex: 2,
//                                       child: Column(
//                                         mainAxisAlignment:
//                                             MainAxisAlignment.start,
//                                         crossAxisAlignment:
//                                             CrossAxisAlignment.start,
//                                         children: [
//                                           Container(
//                                             child: Padding(
//                                               padding: const EdgeInsets.only(
//                                                   left: 8.0,
//                                                   top: 2.0,
//                                                   right: 0.0,
//                                                   bottom: 4.0),
//                                               child: Text(
//                                                 RESERVATION_NUMBER,
//                                                 style: TextStyle(fontSize: 13),
//                                               ),
//                                             ),
//                                           ),
//                                           Padding(
//                                             padding: const EdgeInsets.only(
//                                                 left: 8.0,
//                                                 top: 2.0,
//                                                 right: 0.0,
//                                                 bottom: 2.0),
//                                             child: Text(
//                                               FREE_CANCELATION,
//                                               style: TextStyle(fontSize: 13),
//                                             ),
//                                           ),
//                                         ],
//                                       ),
//                                     ),
//                                   ),
//                                 ),
//                                 Expanded(
//                                   flex: 1,
//                                   child: Column(
//                                     mainAxisAlignment: MainAxisAlignment.center,
//                                     crossAxisAlignment:
//                                         CrossAxisAlignment.center,
//                                     children: [
//                                       Container(
//                                         child: Padding(
//                                           padding: const EdgeInsets.only(
//                                               left: 8.0,
//                                               top: 2.0,
//                                               right: 0.0,
//                                               bottom: 4.0),
//                                           child: Text(
//                                             "$CHECK_IN : $checkin",
//                                           ),
//                                         ),
//                                       ),
//                                       Padding(
//                                         padding: const EdgeInsets.only(
//                                             left: 8.0,
//                                             top: 2.0,
//                                             right: 0.0,
//                                             bottom: 2.0),
//                                         child: Text(
//                                           "$CHECK_OUT :$checkout",
//                                         ),
//                                       ),
//                                     ],
//                                   ),
//                                 ),
//                               ],
//                             ),
//
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.start,
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 Padding(
//                                   padding: const EdgeInsets.only(
//                                       left: 12.0, right: 0.0),
//                                   child: Container(
//                                       width: 130.0,
//                                       height: 130.0,
//                                       decoration: new BoxDecoration(
//                                           borderRadius: new BorderRadius.only(
//                                             topLeft:
//                                                 const Radius.circular(16.0),
//                                             topRight:
//                                                 const Radius.circular(16.0),
//                                             bottomLeft:
//                                                 const Radius.circular(20.0),
//                                             bottomRight:
//                                                 const Radius.circular(20.0),
//                                           ),
//                                           shape: BoxShape.rectangle,
//                                           image: new DecorationImage(
//                                             fit: BoxFit.cover,
//                                             // image: NetworkImage("path to your image")
//                                             image: NetworkImage(
//                                                 response1[index].thumbnail),
//                                           ))),
//                                 ),
//                                 Column(
//                                   children: [
//                                     Row(
//                                       mainAxisAlignment:
//                                           MainAxisAlignment.start,
//                                       crossAxisAlignment:
//                                           CrossAxisAlignment.start,
//                                       children: [
//                                         Padding(
//                                           padding: const EdgeInsets.only(
//                                               left: 8.0, top: 7),
//                                           child: Text(
//                                             response1[index].title,
//                                             maxLines: 2,
//                                             //popularList.title,
//                                             style: TextStyle(fontSize: 19),
//                                           ),
//                                         ),
//                                       ],
//                                     ),
//                                     Row(
//                                       mainAxisAlignment:
//                                           MainAxisAlignment.start,
//                                       children: [
//                                         Padding(
//                                           padding:
//                                               const EdgeInsets.only(left: 8.0),
//                                           child: SmoothStarRating(
//                                             allowHalfRating: true,
//                                             starCount: 5,
//                                             // rating: double.parse(
//                                             //popularList.starsCount
//                                             // ),
//                                             //size: 16,
//                                             // isReadOnly: true,
//                                             // color: Colors.amberAccent,
//                                           ),
//                                         ),
//                                         // SvgPicture.asset(
//                                         //   _STAR_ICON,
//                                         //   color: kBackgroundColor,
//                                         // ),
//                                         Text(
//                                           // "(${popularList.starsCount})",
//                                           '(5)',
//                                         ),
//                                       ],
//                                     ),
//                                     Padding(
//                                       padding: const EdgeInsets.only(
//                                           left: 8.0, top: 7),
//                                       child: Text(
//                                         "Location : ${response1[index].location}",
//                                       ),
//                                     ),
//                                     Padding(
//                                       padding: const EdgeInsets.all(8.0),
//                                       child: Text(
//                                         "Total Amount : ${response1[index].checkoutTotal}",
//                                       ),
//                                     ),
//                                     Padding(
//                                       padding: const EdgeInsets.only(
//                                           left: 8.0, top: 7),
//                                       child: Text(
//                                         'Contact :${response1[index].phone}',
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ],
//                             ),
//
//                             // Apply Button Fields
//
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.start,
//                               crossAxisAlignment: CrossAxisAlignment.center,
//                               children: [
//                                 Padding(
//                                   padding: const EdgeInsets.only(
//                                       left: 10.0,
//                                       right: 4.0,
//                                       bottom: 4.0,
//                                       top: 16),
//                                   child: Container(
//                                     width: 105,
//                                     height: 48,
//                                     decoration: BoxDecoration(
//                                       color: HexColor("#1d8bcb"),
//                                       borderRadius: BorderRadius.all(
//                                           Radius.circular(5.0)),
//                                       boxShadow: <BoxShadow>[
//                                         BoxShadow(
//                                           color:
//                                               AppTheme.getTheme().dividerColor,
//                                           blurRadius: 8,
//                                           offset: Offset(4, 4),
//                                         ),
//                                       ],
//                                     ),
//                                     child: Material(
//                                       color: Colors.transparent,
//                                       child: InkWell(
//                                         borderRadius: BorderRadius.all(
//                                             Radius.circular(24.0)),
//                                         highlightColor: Colors.transparent,
//                                         onTap: () {},
//                                         child: Center(
//                                           child: Text(
//                                             VIEW_CONFIRMATION,
//                                             textAlign: TextAlign.center,
//                                             style: TextStyle(
//                                                 fontWeight: FontWeight.w500,
//                                                 fontSize: 16,
//                                                 color: Colors.white),
//                                           ),
//                                         ),
//                                       ),
//                                     ),
//                                   ),
//                                 ),
//                                 Padding(
//                                   padding: const EdgeInsets.only(
//                                       left: 4.0,
//                                       right: 4.0,
//                                       bottom: 8,
//                                       top: 16),
//                                   child: Container(
//                                     child: Container(
//                                         width: 105,
//                                         height: 48,
//                                         decoration: BoxDecoration(
//                                           color:
//                                               AppTheme.getTheme().primaryColor,
//                                           borderRadius: BorderRadius.all(
//                                               Radius.circular(5.0)),
//                                           boxShadow: <BoxShadow>[
//                                             BoxShadow(
//                                               color: AppTheme.getTheme()
//                                                   .dividerColor,
//                                               blurRadius: 8,
//                                               offset: Offset(4, 4),
//                                             ),
//                                           ],
//                                         ),
//                                         child: response1[index].status ==
//                                                 'cancelled'
//                                             ? getCanceledStatus()
//                                             : getUnpaidStatus(
//                                                 response1[index].id)),
//                                   ),
//                                 ),
//                                 Padding(
//                                   padding: const EdgeInsets.only(
//                                       left: 4.0,
//                                       right: 0.0,
//                                       bottom: 8,
//                                       top: 16),
//                                   child: Container(
//                                     width: 105,
//                                     height: 48,
//                                     decoration: BoxDecoration(
//                                       color: HexColor("#FF7802"),
//                                       borderRadius: BorderRadius.all(
//                                           Radius.circular(5.0)),
//                                       boxShadow: <BoxShadow>[
//                                         BoxShadow(
//                                           color:
//                                               AppTheme.getTheme().dividerColor,
//                                           blurRadius: 8,
//                                           offset: Offset(4, 4),
//                                         ),
//                                       ],
//                                     ),
//                                     child: Material(
//                                       elevation: 1,
//                                       color: Colors.transparent,
//                                       child: InkWell(
//                                         borderRadius: BorderRadius.all(
//                                             Radius.circular(24.0)),
//                                         highlightColor: Colors.transparent,
//                                         onTap: () {
//                                           return showDialog(
//                                             context: context,
//                                             barrierDismissible: false,
//                                             builder: (context) {
//                                               return AlertDialog(
//                                                 title: Text(
//                                                     ('Set your desired dates below')),
//                                                 content: Column(
//                                                   mainAxisSize:
//                                                       MainAxisSize.min,
//                                                   children: [
//                                                     Row(
//                                                       mainAxisAlignment:
//                                                           MainAxisAlignment
//                                                               .spaceAround,
//                                                       children: [
//                                                         Text(
//                                                           "Check in :",
//                                                           style: TextStyle(
//                                                               fontSize: 19),
//                                                         ),
//                                                         GestureDetector(
//                                                             onTap: () =>
//                                                                 _selectDate(),
//                                                             child: AbsorbPointer(
//                                                                 child: Container(
//                                                               // height: 35,
//                                                               width: 140,
//                                                               child:
//                                                                   TextFormField(
//                                                                 controller:
//                                                                     controller,
//                                                                 // initialValue:
//                                                                 //     "$changedCheckin",r,
//
//                                                                 onChanged:
//                                                                     (value) {
//                                                                   selectedDate =
//                                                                       value
//                                                                           as DateTime;
//                                                                 },
//                                                               ),
//                                                             ))),
//                                                         SizedBox(
//                                                           height: 15,
//                                                         ),
//                                                         // Row(
//                                                         //   mainAxisAlignment:
//                                                         //       MainAxisAlignment
//                                                         //           .spaceAround,
//                                                         //   children: [
//                                                         //     Text(
//                                                         //       "Check out :",
//                                                         //       style: TextStyle(
//                                                         //           fontSize:
//                                                         //               19),
//                                                         //     ),
//                                                         //     InkWell(
//                                                         //       onTap: () {
//                                                         //         // setState(() {
//                                                         //         //   _selecteDate(
//                                                         //         //       context);
//                                                         //         // });
//                                                         //       },
//                                                         //       child:
//                                                         //           Container(
//                                                         //         decoration:
//                                                         //             BoxDecoration(),
//                                                         //         child: Text(
//                                                         //           changedCheckout,
//                                                         //           style: TextStyle(
//                                                         //               fontSize:
//                                                         //                   19),
//                                                         //         ),
//                                                         //       ),
//                                                         //     ),
//                                                         //   ],
//                                                         // ),
//                                                         SizedBox(
//                                                           height: 15,
//                                                         ),
//                                                         // ElevatedButton(
//                                                         //     onPressed: () {
//                                                         //       print(
//                                                         //           "checkin final date : $changedCheckin");
//                                                         //
//                                                         //       changeBookingDate(
//                                                         //           response1[
//                                                         //                   index]
//                                                         //               .id,
//                                                         //           "${DateFormat("dd, MMM").format(selectedDate)} ",
//                                                         //           "${DateFormat("dd, MMM").format(selectedDate)}");
//                                                         //     },
//                                                         //     child: Text(
//                                                         //         "Updates Notes"))
//                                                       ],
//                                                     ),
//                                                     Row(
//                                                       mainAxisAlignment:
//                                                           MainAxisAlignment
//                                                               .spaceAround,
//                                                       children: [
//                                                         Text(
//                                                           "Check in :",
//                                                           style: TextStyle(
//                                                               fontSize: 19),
//                                                         ),
//                                                         GestureDetector(
//                                                             onTap: () =>
//                                                                 _selectDate(),
//                                                             child: AbsorbPointer(
//                                                                 child: Container(
//                                                               // height: 35,
//                                                               width: 140,
//                                                               child:
//                                                                   TextFormField(
//                                                                 controller:
//                                                                     controller,
//                                                                 // initialValue:
//                                                                 //     "$changedCheckin",r,
//
//                                                                 onChanged:
//                                                                     (value) {
//                                                                   selectedDate =
//                                                                       value
//                                                                           as DateTime;
//                                                                 },
//                                                               ),
//                                                             ))),
//                                                         SizedBox(
//                                                           height: 15,
//                                                         ),
//                                                         // Row(
//                                                         //   mainAxisAlignment:
//                                                         //       MainAxisAlignment
//                                                         //           .spaceAround,
//                                                         //   children: [
//                                                         //     Text(
//                                                         //       "Check out :",
//                                                         //       style: TextStyle(
//                                                         //           fontSize:
//                                                         //               19),
//                                                         //     ),
//                                                         //     InkWell(
//                                                         //       onTap: () {
//                                                         //         // setState(() {
//                                                         //         //   _selecteDate(
//                                                         //         //       context);
//                                                         //         // });
//                                                         //       },
//                                                         //       child:
//                                                         //           Container(
//                                                         //         decoration:
//                                                         //             BoxDecoration(),
//                                                         //         child: Text(
//                                                         //           changedCheckout,
//                                                         //           style: TextStyle(
//                                                         //               fontSize:
//                                                         //                   19),
//                                                         //         ),
//                                                         //       ),
//                                                         //     ),
//                                                         //   ],
//                                                         // ),
//                                                         SizedBox(
//                                                           height: 15,
//                                                         ),
//                                                       ],
//                                                     ),
//                                                     ElevatedButton(
//                                                         onPressed: () {
//                                                           print(
//                                                               "checkin final date : $changedCheckin");
//
//                                                           changeBookingDate(
//                                                               response1[index]
//                                                                   .id,
//                                                               "$changedCheckin ",
//                                                               "$changedCheckout");
//                                                         },
//                                                         child: Text(
//                                                             "Updates Notes")),
//                                                   ],
//                                                 ),
//                                               );
//                                             },
//                                           );
//                                           //displayDateRangePicker(context);
//                                           // getTimeDateUI();
//                                           // getTimeDateUI();
//                                           // changeBookingDate(
//                                           //     response1[index].id,
//                                           //     response1[index].checkin,
//                                           //     response1[index].checkout);
//                                         },
//                                         child: Center(
//                                           child: Text(
//                                             CHANGE_DATE,
//                                             textAlign: TextAlign.center,
//                                             style: TextStyle(
//                                                 fontWeight: FontWeight.w500,
//                                                 fontSize: 16,
//                                                 color: Colors.white),
//                                           ),
//                                         ),
//                                       ),
//                                     ),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ],
//                         ),
//                       ),
//                     ),
//                   );
//                 },
//               ),
//       ),
//     );
//   }
//
//   // Future pickDateRange(BuildContext context) async {
//   //   final initialDateRange = DateTimeRange(
//   //     start: DateTime.now(),
//   //     end: DateTime.now().add(Duration(hours: 24 * 3)),
//   //   );
//   //   final newDateRange = await showDateRangePicker(
//   //     context: context,
//   //     firstDate: DateTime(DateTime.now().year - 5),
//   //     lastDate: DateTime(DateTime.now().year + 5),
//   //     initialDateRange: dateRange ?? initialDateRange,
//   //   );
//   //
//   //   if (newDateRange == null) return;
//   //
//   //   setState(() => dateRange = newDateRange);
//   // }
//
//   // Widget getTimeDateUI() {
//   //   final f = new DateFormat('dd/MM/yyyy');
//   //   checkIn = f.format(_startDate);
//   //   checkOut = f.format(_endDate);
//   //   print("date ${checkIn} ${checkOut}");
//   //   return Container(
//   //     child: Row(
//   //       children: <Widget>[
//   //         Column(
//   //           children: <Widget>[
//   //             Material(
//   //               color: Colors.transparent,
//   //               child: InkWell(
//   //                 focusColor: Colors.transparent,
//   //                 highlightColor: Colors.transparent,
//   //                 hoverColor: Colors.transparent,
//   //                 splashColor: Colors.black.withOpacity(0.2),
//   //                 borderRadius: BorderRadius.all(
//   //                   Radius.circular(4.0),
//   //                 ),
//   //                 onTap: () {
//   //
//   //                //   FocusScope.of(context).requestFocus(FocusNode());
//   //                   // changeBookingDate(response1[i], start_date, end_date)
//   //                 },
//   //                 child: Container(
//   //                   alignment: Alignment.topLeft,
//   //                   padding: const EdgeInsets.only(
//   //                       left: 16, right: 0, top: 4, bottom: 4),
//   //                   child: Row(
//   //                     crossAxisAlignment: CrossAxisAlignment.start,
//   //                     children: <Widget>[
//   //                       Icon(
//   //                         Icons.calendar_today_outlined,
//   //                         color: Colors.black,
//   //                       ),
//   //                       SizedBox(
//   //                         width: 16,
//   //                       ),
//   //                       GestureDetector(
//   //                         onTap: () async {
//   //                           await displayDateRangePicker(context);
//   //                         },
//   //                         child: Text(
//   //                           "${DateFormat("dd, MMM").format(_startDate)} - ${DateFormat("dd, MMM").format(_endDate)}",
//   //                           style: TextStyle(
//   //                               fontWeight: FontWeight.bold,
//   //                               fontSize: 16,
//   //                               color: Colors.black),
//   //                         ),
//   //                       ),
//   //                     ],
//   //                   ),
//   //                 ),
//   //               ),
//   //             ),
//   //           ],
//   //         ),
//   //
//   //         // Padding(
//   //         //   padding: EdgeInsets.only(right: 8),
//   //         //   child: Container(
//   //         //     width: 1,
//   //         //     height: 42,
//   //         //     color: Colors.white,
//   //         //   ),
//   //         // ),
//   //       ],
//   //     ),
//   //   );
//   // }
// //  Widget changeDatePicker(){
// //     return
// //
// // }
//   Widget getUnpaidStatus(String id) {
//     return Material(
//       color: Colors.transparent,
//       child: InkWell(
//         borderRadius: BorderRadius.all(Radius.circular(24.0)),
//         highlightColor: Colors.transparent,
//         onTap: () {
//           cancelBooking(id);
//         },
//         child: Center(
//           child: Text(
//             CANCEL_BOOKING,
//             textAlign: TextAlign.center,
//             style: TextStyle(
//                 fontWeight: FontWeight.w500, fontSize: 16, color: Colors.white),
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget getCanceledStatus() {
//     return Material(
//       color: Colors.transparent,
//       child: InkWell(
//         borderRadius: BorderRadius.all(Radius.circular(24.0)),
//         highlightColor: Colors.grey,
//         onTap: () {
//           Fluttertoast.showToast(
//               msg: ("Already Cancel your booking?"),
//               toastLength: Toast.LENGTH_SHORT,
//               gravity: ToastGravity.BOTTOM,
//               timeInSecForIosWeb: 2,
//               backgroundColor: Colors.grey[800],
//               textColor: Colors.white,
//               fontSize: 16.0);
//         },
//         child: Center(
//           child: Text(
//             CANCEL_BOOKING,
//             textAlign: TextAlign.center,
//             style: TextStyle(
//                 fontWeight: FontWeight.w500, fontSize: 16, color: Colors.white),
//           ),
//         ),
//       ),
//     );
//   }
// }
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:new_motel/model/myBookingResponse.dart';
import 'package:new_motel/service/apiService.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';

import '../../appTheme.dart';
import '../../loaderPage.dart';

class Bookings extends StatefulWidget {
  @override
  _BookingsState createState() => _BookingsState();
}

class _BookingsState extends State<Bookings> {
  ScrollController scrollController = ScrollController(initialScrollOffset: 0);
  var loading;
  // ...>>>>>>>>>>>>
  // DateTimeRange dateRange;
  // String checkIn(startDate) {
  //   if (dateRange == null) {
  //     return 'Check in';
  //   } else {
  //     return DateFormat('MM/dd/yyyy').format(dateRange.start);
  //   }
  // }
  //
  // String checkOut(endDate) {
  //   if (dateRange == null) {
  //     return 'Check out';
  //   } else {
  //     return DateFormat('MM/dd/yyyy').format(dateRange.end);
  //   }
  // }

  String message;
  bool status;

  ///Date Time........>>>>

  MyBookingResponse myBookingResponse;
  List<Response> response1;
  getMyBookingJSONData() async {
    try {
      SharedPreferences sharedPreferences =
          await SharedPreferences.getInstance();
      String userId = sharedPreferences.getString('id');
      loading = true;
      var response = await http.get(ApiService.mybooking + "&id=$userId");
      bool isSuccess = response.statusCode == 200;
      status = json.decode(response.body)['error']['status'];
      message = json.decode(response.body)['error']['msg'];

      if (!status) {
        if (isSuccess) {
          setState(() {
            loading = false;
            myBookingResponse =
                MyBookingResponse.fromJson(json.decode(response.body));
            print(response.body);
            print("Bokkkkkingggg$message");

            response1 = myBookingResponse.response;
            print("${response1.length}");
          });
        }
      } else {
        Fluttertoast.showToast(
            msg: message,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 3,
            backgroundColor: Colors.indigo[800],
            textColor: Colors.white,
            fontSize: 20.0);
      }

      // else {
      //
      // }
      // Fluttertoast.showToast(
      //     msg: message,
      //     toastLength: Toast.LENGTH_SHORT,
      //     gravity: ToastGravity.BOTTOM,
      //     timeInSecForIosWeb: 4,
      //     backgroundColor: Colors.indigo[800],
      //     textColor: Colors.white,
      //     fontSize: 16.0);

      return "response";
    } catch (e) {}
  }

  Future<bool> getData() async {
    await Future.delayed(const Duration(milliseconds: 50));
    return true;
  }

  Future<void> cancelBooking(
    String id,
  ) async {
    final body = {
      "id": id,
    };

    final jsonString = json.encode(body);
    print("JSonEncoded.....>>>>$jsonString");
    final headers = {HttpHeaders.contentTypeHeader: 'application/json'};

    final response = await http.post(ApiService.cancelbooking,
        headers: headers, body: jsonString);
    try {
      var data = json.decode(response.body);
      print(data);
      print("response==>>  ${data['response']['msg']}");
      // Check if User's Creds is valid,
      // var isSuccess = data['response'] == true; // Write you own condition;
      //  getMyBookingJSONData();
      Fluttertoast.showToast(
          msg: (data['response']['msg']),
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 2,
          backgroundColor: Colors.indigo[800],
          textColor: Colors.white,
          fontSize: 16.0);
      // setState(() {
      //   setButton();
      // });

    } catch (e) {
      print(e);
    }
  }

  bool isLoading = false;
  //

  Future<void> changeBookingDate(
      String id, String start_date, String end_date) async {
    final body = {
      "id": id,
      "start_date": start_date,
      "end_date": end_date,
    };

    final jsonString = json.encode(body);
    print("JSonEncoded.....>>>>$jsonString");
    final headers = {HttpHeaders.contentTypeHeader: 'application/json'};

    final response = await http.post(ApiService.changeBookingDate,
        headers: headers, body: jsonString);
    var error = json.decode(response.body)['error'];
    print("error  $error");
    try {
      if (response.statusCode == 200) {
        setState(() {
          isLoading = true;
        });
        Map data = json.decode(response.body);
        print(data);
        print("response==>>  ${data['response']['msg']}");
        // Check if User's Creds is valid,
        // var isSuccess = data['response'] == true; // Write you own condition;

        //  getMyBookingJSONData();
        Fluttertoast.showToast(
            msg: (data['response']['msg']),
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 2,
            backgroundColor: Colors.indigo[800],
            textColor: Colors.white,
            fontSize: 16.0);
      } else {
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      print(e);
    }
    // try {
    //   var data = json.decode(response.body)['response'];
    //   print("Date Picker Data...$data");
    //   print("response==>>  ${data['response']}");
    //   if (data == 1) {
    //     Fluttertoast.showToast(
    //         msg: 'Sucessfully date changed',
    //         toastLength: Toast.LENGTH_SHORT,
    //         gravity: ToastGravity.BOTTOM,
    //         timeInSecForIosWeb: 2,
    //         backgroundColor: Colors.indigo[800],
    //         textColor: Colors.white,
    //         fontSize: 16.0);
    //     Navigator.pop(context);
    //     Navigator.of(context).pop();
    //   } else {
    //     print("error  $error");
    //     Fluttertoast.showToast(
    //         msg: error,
    //         toastLength: Toast.LENGTH_SHORT,
    //         gravity: ToastGravity.BOTTOM,
    //         timeInSecForIosWeb: 2,
    //         backgroundColor: Colors.indigo[800],
    //         textColor: Colors.white,
    //         fontSize: 16.0);
    //   }
    //   // Check if User's Creds is valid,
    //   // var isSuccess = data['response'] == true; // Write you own condition;
    //
    // } catch (e) {
    //   print(e);
    // }
  }

  // Future _selectDate() async {
  //   DateTime picked = await showDatePicker(
  //       context: context,
  //       initialDate: new DateTime.now(),
  //       firstDate: new DateTime(2020),
  //       lastDate: new DateTime(2030));
  //   if (picked != null)
  //     setState(() => {
  //           data.registrationdate = picked.toString(),
  //           intialdateval.text = picked.toString()
  //         });
  // }
  // final format = new DateFormat.yMMMEd('en-US');
  // DateTime _startDate = DateTime.now();
  // DateTime _endDate = DateTime.now()
  //     .add(Duration(days: 1));

  // DateTime _startDate = DateTime.now();
  // DateTime _endDate = DateTime.now().add(Duration(days: 1));
  // Future displayDateRangePicker(BuildContext context) async {
  //   final List<DateTime> picked = await DateRagePicker.showDatePicker(
  //       context: context,
  //       initialFirstDate: _startDate,
  //       initialLastDate: _endDate,
  //       firstDate: new DateTime(DateTime.now().year - 50),
  //       lastDate: new DateTime(DateTime.now().year + 50));
  //   if (picked != null && picked.length == 2) {
  //     setState(() {
  //       _startDate = picked[0];
  //       _endDate = picked[1];
  //     });
  //   }
  // }

  // DateTime selectedDate = DateTime.now();
  //
  // Future<DateTime> _selecteDate(BuildContext context) async {
  //   final DateTime picked = await showDatePicker(
  //     context: context,
  //     initialDate: selectedDate,
  //     firstDate: DateTime(2000),
  //     lastDate: DateTime(2050),
  //     helpText: "Select Change Date",
  //     confirmText: "OK",
  //   );
  //   if (picked != null && picked != selectedDate) {
  //     setState(() {
  //       selectedDate = picked;
  //     });
  //   }
  //   setState(() {
  //
  //   });
  //   return selectedDate;
  // }
  // final _key = GlobalKey<FormState>();
  // DateTime selectedDate = DateTime.parse("12.05.2020");
  // DateTime selectedDate2 = DateTime.parse("12.05.2020");
  // formatDate(DateTime(1989, 2, 21), [yyyy, '-', mm, '-', dd]);

  DateTime selectedDate;
  DateTime selectedDate2;
  // final controller = TextEditingController();
  // final controller2 = TextEditingController();
  // String presentText;

  // void _selectDate() async {
  //   final DateTime picked = await showDatePicker(
  //       context: context,
  //       initialDate: selectedDate ?? DateTime.now(),
  //       firstDate: DateTime(2015, 8),
  //       lastDate: DateTime(2101));
  //   if (picked != null && picked != selectedDate)
  //     setState(() {
  //       selectedDate = picked;
  //       //   controller.text = picked.toString();
  //     });
  // }

  var checkData;

  @override
  void initState() {
    super.initState();
    checkData = selectedDate;
    // _selecteDate(context);
    getMyBookingJSONData();
    getCanceledStatus();
    //changeBookingDate(, start_date, end_date)
  }

  @override
  Widget build(BuildContext context) {
    MediaQueryData queryData;
    queryData = MediaQuery.of(context);
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.black,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          backgroundColor: Colors.white,
          elevation: 1,
          title: RichText(
            text: TextSpan(
                text: DESHI,
                style: TextStyle(
                  fontSize: 30,
                  fontFamily: 'Impact',
                  color: HexColor("#26408A"),
                ),
                children: <TextSpan>[
                  TextSpan(
                      text: TOUR,
                      style: TextStyle(
                        fontSize: 30,
                        fontFamily: 'Impact',
                        color: HexColor("#118ACB"),
                      )),
                ]),
          ),
        ),
        body: response1 == null
            ? Center(
                child: LoaderPage(
                  msg: "",
                ),
              )
            : ListView.builder(
                itemCount: response1.length,
                itemBuilder: (_, index) {
                  print("index = $index");
                  checkData = response1[index];
                  String checkin = checkData.checkin;
                  String checkout = checkData.checkout;

                  // String changedCheckin = item.checkin;
                  // String changedCheckout = item.checkout;

                  return ClipRRect(
                    borderRadius: BorderRadius.circular(24.0),
                    child: Card(
                      elevation: 5,
                      margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      child: Container(
                        width: double.infinity,
                        height: 320,
                        decoration: BoxDecoration(boxShadow: [
                          BoxShadow(
                              offset: Offset(0, 10),
                              blurRadius: 30,
                              color: kShadowColor)
                        ]),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            SizedBox(
                              height: 12,
                            ),

                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 8.0,
                                      top: 4.0,
                                      right: 4.0,
                                      bottom: 4.0),
                                  child: Container(
                                    width: 150,
                                    height: 65,
                                    decoration: new BoxDecoration(),
                                    child: Expanded(
                                      flex: 2,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            child: Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 8.0,
                                                  top: 2.0,
                                                  right: 0.0,
                                                  bottom: 4.0),
                                              child: Text(
                                                RESERVATION_NUMBER,
                                                style: TextStyle(fontSize: 13),
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                left: 8.0,
                                                top: 2.0,
                                                right: 0.0,
                                                bottom: 2.0),
                                            child: Text(
                                              FREE_CANCELATION,
                                              style: TextStyle(fontSize: 13),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  flex: 1,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                              left: 8.0,
                                              top: 2.0,
                                              right: 0.0,
                                              bottom: 4.0),
                                          child: Text(
                                            "$CHECK_IN : $checkin",
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 8.0,
                                            top: 2.0,
                                            right: 0.0,
                                            bottom: 2.0),
                                        child: Text(
                                          "$CHECK_OUT :$checkout",
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),

                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 12.0, right: 0.0),
                                  child: Container(
                                      width: 130.0,
                                      height: 130.0,
                                      decoration: new BoxDecoration(
                                          borderRadius: new BorderRadius.only(
                                            topLeft:
                                                const Radius.circular(16.0),
                                            topRight:
                                                const Radius.circular(16.0),
                                            bottomLeft:
                                                const Radius.circular(20.0),
                                            bottomRight:
                                                const Radius.circular(20.0),
                                          ),
                                          shape: BoxShape.rectangle,
                                          image: new DecorationImage(
                                            fit: BoxFit.cover,
                                            // image: NetworkImage("path to your image")
                                            image: NetworkImage(
                                                response1[index].thumbnail),
                                          ))),
                                ),
                                Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              left: 8.0, top: 7),
                                          child: Text(
                                            response1[index].title,
                                            maxLines: 2,
                                            //popularList.title,
                                            style: TextStyle(fontSize: 19),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(left: 8.0),
                                          child: SmoothStarRating(
                                            allowHalfRating: true,
                                            starCount: 5,
                                            // rating: double.parse(
                                            //popularList.starsCount
                                            // ),
                                            //size: 16,
                                            // isReadOnly: true,
                                            // color: Colors.amberAccent,
                                          ),
                                        ),
                                        // SvgPicture.asset(
                                        //   _STAR_ICON,
                                        //   color: kBackgroundColor,
                                        // ),
                                        Text(
                                          // "(${popularList.starsCount})",
                                          '(5)',
                                        ),
                                      ],
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          left: 8.0, top: 7),
                                      child: Text(
                                        "Location : ${response1[index].location}",
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(
                                        "Total Amount : ${response1[index].checkoutTotal}",
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          left: 8.0, top: 7),
                                      child: Text(
                                        'Contact :${response1[index].phone}',
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),

                            // Apply Button Fields

                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 10.0,
                                      right: 4.0,
                                      bottom: 4.0,
                                      top: 16),
                                  child: Container(
                                    width: 105,
                                    height: 48,
                                    decoration: BoxDecoration(
                                      color: HexColor("#1d8bcb"),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(5.0)),
                                      boxShadow: <BoxShadow>[
                                        BoxShadow(
                                          color:
                                              AppTheme.getTheme().dividerColor,
                                          blurRadius: 8,
                                          offset: Offset(4, 4),
                                        ),
                                      ],
                                    ),
                                    child: Material(
                                      color: Colors.transparent,
                                      child: InkWell(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(24.0)),
                                        highlightColor: Colors.transparent,
                                        onTap: () {},
                                        child: Center(
                                          child: Text(
                                            VIEW_CONFIRMATION,
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                fontWeight: FontWeight.w500,
                                                fontSize: 16,
                                                color: Colors.white),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 4.0,
                                      right: 4.0,
                                      bottom: 8,
                                      top: 16),
                                  child: Container(
                                    child: Container(
                                        width: 105,
                                        height: 48,
                                        decoration: BoxDecoration(
                                          color:
                                              AppTheme.getTheme().primaryColor,
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(5.0)),
                                          boxShadow: <BoxShadow>[
                                            BoxShadow(
                                              color: AppTheme.getTheme()
                                                  .dividerColor,
                                              blurRadius: 8,
                                              offset: Offset(4, 4),
                                            ),
                                          ],
                                        ),
                                        child: response1[index].status ==
                                                'cancelled'
                                            ? getCanceledStatus()
                                            : getUnpaidStatus(
                                                response1[index].id)),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 4.0,
                                      right: 0.0,
                                      bottom: 8,
                                      top: 16),
                                  child: Container(
                                    width: 105,
                                    height: 48,
                                    decoration: BoxDecoration(
                                      color: HexColor("#FF7802"),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(5.0)),
                                      boxShadow: <BoxShadow>[
                                        BoxShadow(
                                          color:
                                              AppTheme.getTheme().dividerColor,
                                          blurRadius: 8,
                                          offset: Offset(4, 4),
                                        ),
                                      ],
                                    ),
                                    child: Material(
                                      elevation: 1,
                                      color: Colors.transparent,
                                      child: InkWell(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(24.0)),
                                        highlightColor: Colors.transparent,
                                        onTap: () {
                                          return showDialog(
                                            context: context,
                                            barrierDismissible: false,
                                            builder: (context) {
                                              return StatefulBuilder(builder:
                                                  (context, setStateee) {
                                                return AlertDialog(
                                                    title: Text(
                                                        ('Set your desired dates below')),
                                                    content: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        children: [
                                                          Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceAround,
                                                            children: [
                                                              Text(
                                                                "Check in :",
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        19),
                                                              ),
                                                              InkWell(
                                                                onTap:
                                                                    () async {
                                                                  print(
                                                                      selectedDate);

                                                                  final DateTime picked1 = await showDatePicker(
                                                                      context:
                                                                          context,
                                                                      initialDate:
                                                                          DateTime.now() ??
                                                                              selectedDate,
                                                                      firstDate:
                                                                          DateTime(
                                                                              2015,
                                                                              8),
                                                                      lastDate:
                                                                          DateTime(
                                                                              2101));
                                                                  if (picked1 !=
                                                                          null &&
                                                                      picked1 !=
                                                                          selectedDate)
                                                                    setStateee(
                                                                        () {
                                                                      selectedDate =
                                                                          picked1;
                                                                      //   controller.text = picked.toString();
                                                                    });
                                                                },
                                                                child:
                                                                    Container(
                                                                  child: Text(selectedDate.toString() ==
                                                                              null ||
                                                                          selectedDate.toString() ==
                                                                              "null"
                                                                      ? checkin
                                                                      : DateFormat(
                                                                              "dd, MMM")
                                                                          .format(
                                                                              selectedDate)
                                                                          .toString()),
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                height: 15,
                                                              ),
                                                              // Row(
                                                              //   mainAxisAlignment:
                                                              //       MainAxisAlignment
                                                              //           .spaceAround,
                                                              //   children: [
                                                              //     Text(
                                                              //       "Check out :",
                                                              //       style: TextStyle(
                                                              //           fontSize:
                                                              //               19),
                                                              //     ),
                                                              //     InkWell(
                                                              //       onTap: () {
                                                              //         // setState(() {
                                                              //         //   _selecteDate(
                                                              //         //       context);
                                                              //         // });
                                                              //       },
                                                              //       child:
                                                              //           Container(
                                                              //         decoration:
                                                              //             BoxDecoration(),
                                                              //         child: Text(
                                                              //           changedCheckout,
                                                              //           style: TextStyle(
                                                              //               fontSize:
                                                              //                   19),
                                                              //         ),
                                                              //       ),
                                                              //     ),
                                                              //   ],
                                                              // ),
                                                              SizedBox(
                                                                height: 15,
                                                              ),
                                                              // ElevatedButton(
                                                              //     onPressed: () {
                                                              //       print(
                                                              //           "checkin final date : $changedCheckin");
                                                              //
                                                              //       changeBookingDate(
                                                              //           response1[
                                                              //                   index]
                                                              //               .id,
                                                              //           "${DateFormat("dd, MMM").format(selectedDate)} ",
                                                              //           "${DateFormat("dd, MMM").format(selectedDate)}");
                                                              //     },
                                                              //     child: Text(
                                                              //         "Updates Notes"))
                                                            ],
                                                          ),
                                                          Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceAround,
                                                            children: [
                                                              Text(
                                                                "Check Out:",
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        19),
                                                              ),
                                                              InkWell(
                                                                onTap:
                                                                    () async {
                                                                  print(
                                                                      selectedDate2);
                                                                  final DateTime picked = await showDatePicker(
                                                                      context:
                                                                          context,
                                                                      initialDate: selectedDate2 ??
                                                                          DateTime
                                                                              .now(),
                                                                      firstDate:
                                                                          DateTime(
                                                                              2015,
                                                                              8),
                                                                      lastDate:
                                                                          DateTime(
                                                                              2101));
                                                                  if (picked !=
                                                                          null &&
                                                                      picked !=
                                                                          selectedDate2)
                                                                    setStateee(
                                                                        () {
                                                                      selectedDate2 =
                                                                          picked;
                                                                      //   controller.text = picked.toString();
                                                                    });
                                                                },
                                                                child:
                                                                    Container(
                                                                  child: Text(selectedDate2.toString() ==
                                                                              null ||
                                                                          selectedDate2.toString() ==
                                                                              "null"
                                                                      ? checkout
                                                                      : DateFormat(
                                                                              "dd/MM/yyyy")
                                                                          .format(
                                                                              selectedDate2)
                                                                          .toString()),
                                                                ),
                                                              ),
                                                              // GestureDetector(
                                                              //     onTap: () {
                                                              //       setState(
                                                              //           () {
                                                              //         _selectDate2();
                                                              //       });
                                                              //     },
                                                              //     child:
                                                              //         AbsorbPointer(
                                                              //             child:
                                                              //                 Container(
                                                              //       // height: 35,
                                                              //       width: 140,
                                                              //       child:
                                                              //           TextFormField(
                                                              //         initialValue:
                                                              //             checkout,
                                                              //         // initialValue:
                                                              //         //     "$changedCheckout",
                                                              //         // onChanged:
                                                              //         //     (value) {
                                                              //         //   setState(
                                                              //         //       () {
                                                              //         //     changedCheckout =
                                                              //         //         value;
                                                              //         //   });
                                                              //         // },
                                                              //       ),
                                                              //     ))),
                                                              SizedBox(
                                                                height: 15,
                                                              ),
                                                              // Row(
                                                              //   mainAxisAlignment:
                                                              //       MainAxisAlignment
                                                              //           .spaceAround,
                                                              //   children: [
                                                              //     Text(
                                                              //       "Check out :",
                                                              //       style: TextStyle(
                                                              //           fontSize:
                                                              //               19),
                                                              //     ),
                                                              //     InkWell(
                                                              //       onTap: () {
                                                              //         // setState(() {
                                                              //         //   _selecteDate(
                                                              //         //       context);
                                                              //         // });
                                                              //       },
                                                              //       child:
                                                              //           Container(
                                                              //         decoration:
                                                              //             BoxDecoration(),
                                                              //         child: Text(
                                                              //           changedCheckout,
                                                              //           style: TextStyle(
                                                              //               fontSize:
                                                              //                   19),
                                                              //         ),
                                                              //       ),
                                                              //     ),
                                                              //   ],
                                                              // ),
                                                              SizedBox(
                                                                height: 15,
                                                              ),
                                                            ],
                                                          ),
                                                          SizedBox(
                                                            height: 15,
                                                          ),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    left: 38.0),
                                                            child:
                                                                ElevatedButton(
                                                                    onPressed:
                                                                        () {
                                                                      print(
                                                                          "selectedDate $selectedDate");
                                                                      print(
                                                                          "selectedDate2 $selectedDate2");
                                                                      changeBookingDate(
                                                                          response1[index]
                                                                              .id,
                                                                          "${DateFormat("dd, MMM").format(selectedDate)} ",
                                                                          "${DateFormat("dd, MMM").format(selectedDate2)}");
                                                                      Navigator.pop(
                                                                          context);
                                                                    },
                                                                    child: Text(
                                                                        "Updates Notes")),
                                                          ),
                                                        ]));
                                              });
                                            },
                                          );
                                        },
                                        child: Center(
                                          child: Text(
                                            CHANGE_DATE,
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                fontWeight: FontWeight.w500,
                                                fontSize: 16,
                                                color: Colors.white),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }

  // Future pickDateRange(BuildContext context) async {
  //   final initialDateRange = DateTimeRange(
  //     start: DateTime.now(),
  //     end: DateTime.now().add(Duration(hours: 24 * 3)),
  //   );
  //   final newDateRange = await showDateRangePicker(
  //     context: context,
  //     firstDate: DateTime(DateTime.now().year - 5),
  //     lastDate: DateTime(DateTime.now().year + 5),
  //     initialDateRange: dateRange ?? initialDateRange,
  //   );
  //
  //   if (newDateRange == null) return;
  //
  //   setState(() => dateRange = newDateRange);
  // }

  // Widget getTimeDateUI() {
  //   final f = new DateFormat('dd/MM/yyyy');
  //   checkIn = f.format(_startDate);
  //   checkOut = f.format(_endDate);
  //   print("date ${checkIn} ${checkOut}");
  //   return Container(
  //     child: Row(
  //       children: <Widget>[
  //         Column(
  //           children: <Widget>[
  //             Material(
  //               color: Colors.transparent,
  //               child: InkWell(
  //                 focusColor: Colors.transparent,
  //                 highlightColor: Colors.transparent,
  //                 hoverColor: Colors.transparent,
  //                 splashColor: Colors.black.withOpacity(0.2),
  //                 borderRadius: BorderRadius.all(
  //                   Radius.circular(4.0),
  //                 ),
  //                 onTap: () {
  //
  //                //   FocusScope.of(context).requestFocus(FocusNode());
  //                   // changeBookingDate(response1[i], start_date, end_date)
  //                 },
  //                 child: Container(
  //                   alignment: Alignment.topLeft,
  //                   padding: const EdgeInsets.only(
  //                       left: 16, right: 0, top: 4, bottom: 4),
  //                   child: Row(
  //                     crossAxisAlignment: CrossAxisAlignment.start,
  //                     children: <Widget>[
  //                       Icon(
  //                         Icons.calendar_today_outlined,
  //                         color: Colors.black,
  //                       ),
  //                       SizedBox(
  //                         width: 16,
  //                       ),
  //                       GestureDetector(
  //                         onTap: () async {
  //                           await displayDateRangePicker(context);
  //                         },
  //                         child: Text(
  //                           "${DateFormat("dd, MMM").format(_startDate)} - ${DateFormat("dd, MMM").format(_endDate)}",
  //                           style: TextStyle(
  //                               fontWeight: FontWeight.bold,
  //                               fontSize: 16,
  //                               color: Colors.black),
  //                         ),
  //                       ),
  //                     ],
  //                   ),
  //                 ),
  //               ),
  //             ),
  //           ],
  //         ),
  //
  //         // Padding(
  //         //   padding: EdgeInsets.only(right: 8),
  //         //   child: Container(
  //         //     width: 1,
  //         //     height: 42,
  //         //     color: Colors.white,
  //         //   ),
  //         // ),
  //       ],
  //     ),
  //   );
  // }
//  Widget changeDatePicker(){
//     return
//
// }
  Widget getUnpaidStatus(String id) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.all(Radius.circular(24.0)),
        highlightColor: Colors.transparent,
        onTap: () {
          cancelBooking(id);
        },
        child: Center(
          child: Text(
            CANCEL_BOOKING,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontWeight: FontWeight.w500, fontSize: 16, color: Colors.white),
          ),
        ),
      ),
    );
  }

  Widget getCanceledStatus() {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.all(Radius.circular(24.0)),
        highlightColor: Colors.grey,
        onTap: () {
          Fluttertoast.showToast(
              msg: ("Already Cancel your booking?"),
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
              timeInSecForIosWeb: 2,
              backgroundColor: Colors.grey[800],
              textColor: Colors.white,
              fontSize: 16.0);
        },
        child: Center(
          child: Text(
            CANCEL_BOOKING,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontWeight: FontWeight.w500, fontSize: 16, color: Colors.white),
          ),
        ),
      ),
    );
  }
}
