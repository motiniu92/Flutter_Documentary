// import 'dart:convert';
// import 'dart:io';
// import 'dart:math';
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:http/http.dart' as http;
// import 'package:image_picker/image_picker.dart';
// import 'package:intl/intl.dart';
// import 'package:new_motel/global/global_data.dart';
// import 'package:new_motel/model/profile_model.dart';
// import 'package:new_motel/utils/constants.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// import '../../appTheme.dart';
//
// class ProfileUpdatePage extends StatefulWidget {
//   // final ProfileData profileData;
//   final String firstName;
//   final String id;
//   final String lastName;
//   final String city;
//   final String state;
//   final String country;
//   final String address1;
//   final String address2;
//   final String phone;
//   final String fax;
//   final String zip;
//   final String photo;
//   final String email;
//   final String password;
//
//   const ProfileUpdatePage(
//       {Key key,
//       this.id,
//       this.firstName,
//       this.lastName,
//       this.city,
//       this.state,
//       this.country,
//       this.address1,
//       this.address2,
//       this.phone,
//       this.fax,
//       this.zip,
//       this.photo,
//       this.email,
//       this.password})
//       : super(key: key);
//
//   // final int index;
//
//   @override
//   _ProfileUpdatePageState createState() => _ProfileUpdatePageState();
// }
//
// class _ProfileUpdatePageState extends State<ProfileUpdatePage> {
//   final _key = GlobalKey<FormState>();
//   final firstController = TextEditingController();
//   final lastController = TextEditingController();
//   final cityController = TextEditingController();
//   final stateController = TextEditingController();
//   final countryController = TextEditingController();
//   final address1Controller = TextEditingController();
//   final address2Controller = TextEditingController();
//   final phoneController = TextEditingController();
//   final faxController = TextEditingController();
//   final zipController = TextEditingController();
//   final emailController = TextEditingController();
//   final passwordController = TextEditingController();
//
//   DateTime date = DateTime.now();
//   Map<String, dynamic> data;
//   final ImagePicker _picker = ImagePicker();
//   // image Upload.....
//   PickedFile _imageFile;
//   void takePhoto(ImageSource source) async {
//     final pickedFile = await _picker.getImage(
//       source: source,
//     );
//     setState(() {
//       _imageFile = pickedFile;
//     });
//   }
//
//   final _scaffoldKey = GlobalKey<ScaffoldState>();
//
//   _showMsg(msg) {
//     final snackBar = SnackBar(content: Text(msg));
//     _scaffoldKey.currentState.showSnackBar(snackBar);
//   }
//
//   // gallery() async {
//   //   // ignore: deprecated_member_use
//   //   var _image = await ImagePicker.pickImage(source: ImageSource.gallery);
//   //   setState(() {
//   //     image = _image;
//   //   });
//   // }
//
//   bool isLoading = false;
//
//   // updateProfile() async {
//   //   final form = _key.currentState;
//   //   if (form.validate()) {
//   //     setState(() {
//   //       isLoading = true;
//   //     });
//   //     form.save();
//   //     await update();
//   //   } else {
//   //     setState(() {
//   //       isLoading = false;
//   //     });
//   //   }
//   // }
//
//   update() async {
//     // SharedPreferences _preference = await SharedPreferences.getInstance();
//     // String id = _preference.getString('id');
//
//     var body = {
//       'id': '',
//       "firstname": firstController.text,
//       "lastname": lastController.text,
//       "city": cityController.text,
//       "state": stateController.text,
//       "country": countryController.text,
//       "address1": address1Controller.text,
//       "address2": address2Controller.text,
//       "phone": phoneController.text,
//       "fax": faxController.text,
//       "zip": zipController.text,
//       "photo": _imageFile,
//       "email": emailController.text,
//       "password": passwordController.text,
//     };
//     final jsonString = json.encode(body);
//     print("JSonEncoded.....>>>>$jsonString");
//     // final headers = {HttpHeaders.contentTypeHeader: 'application/json'};
//
//     var response = await http.post(
//       "https://vromonbuzz.com/api/login/updateprofile?appKey=VromonBuzz",
//       body: body,
//     );
//     if (response.statusCode == 200) {
//       var data = json.decode(response.body);
//       print("AAAA${response.body}");
//       print("BBB${data}");
//       if (data != null) {
//         setState(() {
//           firstController.text = widget.firstName;
//           lastController.text = widget.lastName;
//           cityController.text = widget.city;
//           stateController.text = widget.state;
//           countryController.text = widget.country;
//           address1Controller.text = widget.address1;
//           address2Controller.text = widget.address2;
//           phoneController.text = widget.phone;
//           faxController.text = widget.fax;
//           zipController.text = widget.zip;
//           // "Photo" = PHOTO_G;
//           emailController.text = widget.email;
//           passwordController.text = widget.password;
//         });
//         Fluttertoast.showToast(
//             msg: ('  Profile Update Successfully'),
//             toastLength: Toast.LENGTH_SHORT,
//             gravity: ToastGravity.BOTTOM,
//             timeInSecForIosWeb: 2,
//             backgroundColor: Colors.indigo[800],
//             textColor: Colors.white,
//             fontSize: 16.0);
//         Navigator.of(context).pop();
//       } else {}
//     }
//
//     //  print(jsonString);
//     //
//     // if (data != null) {
//     //   setState(() {
//     //     Fluttertoast.showToast(
//     //         msg: "Profile Update SuccessFully",
//     //         toastLength: Toast.LENGTH_SHORT,
//     //         gravity: ToastGravity.BOTTOM,
//     //         timeInSecForIosWeb: 2,
//     //         backgroundColor: Colors.purple,
//     //         textColor: Colors.white,
//     //         fontSize: 16.0);
//     //     Navigator.pop(context, true);
//     //   });
//     // } else {
//     //   setState(() {
//     //     isLoading = false;
//     //   });
//     //
//     //   _showMsg(data["errors"]["msg"]).toString();
//     // }
//   }
//
//   @override
//   void initState() {
//     print("Update Name: ${widget.firstName}");
//     firstController.text = widget.firstName;
//     lastController.text = widget.lastName;
//     cityController.text = widget.city;
//     stateController.text = widget.state;
//     countryController.text = widget.country;
//     address1Controller.text = widget.address1;
//     address2Controller.text = widget.address2;
//     phoneController.text = widget.phone;
//     faxController.text = widget.fax;
//     zipController.text = widget.zip;
//     // "Photo" = PHOTO_G;
//     emailController.text = widget.email;
//     passwordController.text = widget.password;
//     // dobController.text = DOB;
//
//     super.initState();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     Widget bottomSheet() {
//       return ClipRRect(
//         borderRadius: BorderRadius.circular(25),
//         child: Container(
//           height: 100.0,
//           width: MediaQuery.of(context).size.width,
//           margin: EdgeInsets.symmetric(
//             horizontal: 20,
//             vertical: 20,
//           ),
//           child: Column(
//             children: <Widget>[
//               Text(
//                 ('choose_profile_photo'),
//                 style: TextStyle(
//                   fontSize: 20.0,
//                 ),
//               ),
//               SizedBox(
//                 height: 20,
//               ),
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: <Widget>[
//                   FlatButton.icon(
//                     icon: Icon(Icons.camera),
//                     onPressed: () {
//                       takePhoto(ImageSource.camera);
//                       Navigator.pop(context);
//                     },
//                     label: Text("Camera"),
//                   ),
//                   FlatButton.icon(
//                     icon: Icon(Icons.image),
//                     onPressed: () {
//                       Navigator.pop(context);
//                       takePhoto(ImageSource.gallery);
//                     },
//                     label: Text("Gallery"),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       );
//     }
//
//     return Scaffold(
//       appBar: AppBar(
//         leading: IconButton(
//           icon: Icon(
//             Icons.arrow_back,
//             color: Colors.black,
//           ),
//           onPressed: () {
//             Navigator.pop(context);
//           },
//         ),
//         backgroundColor: Colors.white,
//         elevation: 1,
//         title: Text(
//           "Update Profile",
//           style: TextStyle(fontSize: 20, color: Colors.black),
//         ),
//       ),
//       backgroundColor: Colors.transparent,
//       body: SafeArea(
//         child: Form(
//           child: SingleChildScrollView(
//             child: Column(
//               children: [
//                 SizedBox(
//                   height: 40,
//                 ),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Center(
//                       child: Stack(children: <Widget>[
//                         CircleAvatar(
//                           backgroundColor: Colors.indigo,
//                           radius: 80.0,
//                           backgroundImage: _imageFile == null
//                               ? (widget.photo == null
//                                   ? AssetImage("assets/images/vromonbuzz.png")
//                                   : NetworkImage(widget.photo))
//                               : FileImage(File(_imageFile.path)),
//                         ),
//                         Positioned(
//                           bottom: 20.0,
//                           right: 20.0,
//                           child: InkWell(
//                             onTap: () {
//                               showModalBottomSheet(
//                                 context: context,
//                                 builder: ((builder) => bottomSheet()),
//                               );
//                             },
//                             child: Icon(
//                               Icons.add_a_photo,
//                               size: 31.0,
//                             ),
//                           ),
//                         ),
//                       ]),
//                     ),
//                   ],
//                 ),
//
//                 // FirstName Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: firstController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter FirstName";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'First Name',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // LastName Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: lastController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter LastName";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Last Name',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // City Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: cityController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter City";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'City',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // State Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: stateController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter City";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'State',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Country Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: countryController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter Country";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Country',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Address1 Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: address1Controller,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter Address1";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Address1',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Address2 Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: address2Controller,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter  Address2";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'City',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Phone Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: phoneController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter Phone";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Phone',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Fax Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: faxController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter Fax";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Fax',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Zip Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: zipController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter Zip";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Zip',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Email Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: emailController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter Email";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Email',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Password Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: passwordController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter Password";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Password',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 SizedBox(
//                   height: 30,
//                 ),
//
//                 // Update Button
//                 Padding(
//                   padding: const EdgeInsets.only(
//                       left: 24, right: 24, bottom: 8, top: 16),
//                   child: Container(
//                     height: 45,
//                     width: 230,
//                     child: RaisedButton(
//                       onPressed: () {
//                         update();
//                       },
//                       color: AppTheme.getTheme().primaryColor,
//                       child: Text(
//                         "Update",
//                         style: TextStyle(fontSize: 15, color: Colors.white),
//                       ),
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(20),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Padding(
//                 //   padding: const EdgeInsets.only(
//                 //       left: 24, right: 24, bottom: 8, top: 16),
//                 //   child: Container(
//                 //     height: 48,
//                 //     decoration: BoxDecoration(
//                 //       color: AppTheme.getTheme().primaryColor,
//                 //       borderRadius:
//                 //       BorderRadius.all(Radius.circular(24.0)),
//                 //       boxShadow: <BoxShadow>[
//                 //         BoxShadow(
//                 //           color: AppTheme.getTheme().dividerColor,
//                 //           blurRadius: 8,
//                 //           offset: Offset(4, 4),
//                 //         ),
//                 //       ],
//                 //     ),
//                 //     child: Material(
//                 //       color: Colors.transparent,
//                 //       child: InkWell(
//                 //         borderRadius:
//                 //         BorderRadius.all(Radius.circular(24.0)),
//                 //         highlightColor: Colors.transparent,
//                 //         onTap: () {
//                 //           Navigator.pop(context);
//                 //         },
//                 //         child: Center(
//                 //           child: Text(
//                 //             APPLY,
//                 //             style: TextStyle(
//                 //                 fontWeight: FontWeight.w500,
//                 //                 fontSize: 16,
//                 //                 color: Colors.white),
//                 //           ),
//                 //         ),
//                 //       ),
//                 //     ),
//                 //   ),
//                 // ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
//
//
//
//
//
//
// // 2nd importn part
// import 'dart:convert';
// import 'dart:io';
//
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:http/http.dart' as http;
// import 'package:image_picker/image_picker.dart';
// import 'package:new_motel/appTheme.dart';
// import 'package:new_motel/utils/constants.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// class ProfileUpdateScreen extends StatefulWidget {
//   final String id;
//   final String firstName;
//   final String lastName;
//   final String city;
//   final String state;
//   final String country;
//   final String address1;
//   final String address2;
//   final String phone;
//   final String fax;
//   final String zip;
//   final String photo;
//   final String email;
//   final String password;
//   final String confirmPassword;
//
//   const ProfileUpdateScreen({
//     Key key,
//     this.id,
//     this.firstName,
//     this.lastName,
//     this.city,
//     this.state,
//     this.country,
//     this.address1,
//     this.address2,
//     this.phone,
//     this.fax,
//     this.zip,
//     this.photo,
//     this.email,
//     this.password,
//     this.confirmPassword,
//   }) : super(key: key);
//   @override
//   _ProfileUpdateScreenState createState() => _ProfileUpdateScreenState();
// }
//
// class _ProfileUpdateScreenState extends State<ProfileUpdateScreen> {
//   final _key = GlobalKey<FormState>();
//   // final nameController = TextEditingController();
//   // final emailController = TextEditingController();
//   // final phoneController = TextEditingController();
//   // final upazilaController = TextEditingController();
//   // final dobController = TextEditingController();
//   // final occuptionController = TextEditingController();
//   // final imageController = TextEditingController();
//   // final educationController = TextEditingController();
//   // final addressController = TextEditingController();
//   // Map<String, dynamic> data;
//   String pMessage = '';
//   bool success = false;
//   final ImagePicker _picker = ImagePicker();
//   // image Upload.....
//   PickedFile _imageFile;
//   void takePhoto(ImageSource source) async {
//     final pickedFile = await _picker.getImage(
//       source: source,
//     );
//     setState(() {
//       _imageFile = pickedFile;
//     });
//   }
//
//   File image;
//   final firstController = TextEditingController();
//   final lastController = TextEditingController();
//   final cityController = TextEditingController();
//   final stateController = TextEditingController();
//   final countryController = TextEditingController();
//   final address1Controller = TextEditingController();
//   final address2Controller = TextEditingController();
//   final phoneController = TextEditingController();
//   final faxController = TextEditingController();
//   final zipController = TextEditingController();
//   final emailController = TextEditingController();
//   final passwordController = TextEditingController();
//   final confirmPasswordController = TextEditingController();
//
//   final _scaffoldKey = GlobalKey<ScaffoldState>();
//   _showMsg(msg) {
//     final snackBar = SnackBar(content: Text(msg));
//     _scaffoldKey.currentState.showSnackBar(snackBar);
//   }
//
//   bool isLoading = false;
//   bool _autoValidate = false;
//
//   File file;
// //
// //   void _choose() async {
// //     file = await ImagePicker.pickImage(source: ImageSource.camera);
// // // file = await ImagePicker.pickImage(source: ImageSource.gallery);
// //   }
//
//   void _upload() {
//     if (file == null) return;
//     String base64Image = base64Encode(file.readAsBytesSync());
//     String id;
//
//     http.post("https://vromonbuzz.com//api/login/updatephoto?appKey=VromonBuzz",
//         body: {
//           "id": id,
//           "user_photo": base64Image,
//         }).then((res) {
//       print(res.statusCode);
//       if (res.statusCode == 200) {
//         return base64.decode(base64Image);
//       }
//     }).catchError((err) {
//       print(err);
//     });
//   }
//
//   // gallery() async {
//   //   // ignore: deprecated_member_use
//   //   var image2 = await ImagePicker.pickImage(source: ImageSource.gallery);
//   //   setState(() {
//   //     image = image2;
//   //   });
//   // }
//
//   updateProfile() async {
//     final form = _key.currentState;
//     if (form.validate()) {
//       setState(() {
//         isLoading = true;
//       });
//       form.save();
//       update();
//     } else {
//       setState(() {
//         isLoading = false;
//       });
//     }
//   }
//
//   update() async {
//     SharedPreferences _preference = await SharedPreferences.getInstance();
//     String id = _preference.getString('id');
//
//     /*   var uri = Uri.parse("http://uat.gagro.com.bd/api/profile");
//     var request = http.MultipartRequest('POST', uri)
//       ..fields['name'] = nameController.text
//       ..fields['email'] = emailController.text
//       ..fields['phone'] = phoneController.text
//       ..fields['dob'] = dobController.text
//       ..fields['upazila_id'] = upazilaController.text
//       ..fields['address'] = addressController.text
//       ..fields['occupation'] = occuptionController.text
//       ..fields['education'] = educationController.text;
//       /*
//       ..files.add(await http.MultipartFile.fromPath(
//           'package', 'build/package.tar.gz',
//           contentType: MediaType('application', 'x-tar')));*/
//     var response = await request.send()
//    if (response.statusCode == 200) print('Uploaded!');*/
//     var response = await http.post(
//       "https://vromonbuzz.com/api/login/updateprofile?appKey=VromonBuzz",
//       body: {
//         'id': id,
//         "firstname": firstController.text,
//         "lastname": lastController.text,
//         "city": cityController.text,
//         "state": stateController.text,
//         "country": countryController.text,
//         "address1": address1Controller.text,
//         "address2": address2Controller.text,
//         "phone": phoneController.text,
//         "fax": faxController.text,
//         "zip": zipController.text,
//         "photo": '',
//         "email": emailController.text,
//         "password": passwordController.text,
//         "confirm_password": confirmPasswordController.text,
//       },
//       headers: {
//         "Accept": "application/json",
//       },
//     );
//     var errorMsg = json.decode(response.body)['msg'];
//     print(errorMsg);
//     if (response.statusCode == 200) {
//       var data = json.decode(response.body)['status'];
//       if (data == 1) {
//         setState(() {
//           isLoading = true;
//         });
//         Fluttertoast.showToast(
//             msg: "Successfully Done",
//             toastLength: Toast.LENGTH_SHORT,
//             gravity: ToastGravity.BOTTOM,
//             timeInSecForIosWeb: 2,
//             backgroundColor: Colors.indigo,
//             textColor: Colors.white,
//             fontSize: 16.0);
//         setState(() {});
//         Navigator.pop(context);
//       } else {
//         setState(() {
//           isLoading = false;
//         });
//         Fluttertoast.showToast(
//             msg: errorMsg,
//             toastLength: Toast.LENGTH_SHORT,
//             gravity: ToastGravity.BOTTOM,
//             timeInSecForIosWeb: 2,
//             backgroundColor: Colors.indigo,
//             textColor: Colors.white,
//             fontSize: 16.0);
//         // setState(() {});
//       }
//     }
//
//     // if (data != null) {
//     //   setState(() {
//     //     Fluttertoast.showToast(
//     //         msg: pMessage,
//     //         toastLength: Toast.LENGTH_SHORT,
//     //         gravity: ToastGravity.BOTTOM,
//     //         timeInSecForIosWeb: 2,
//     //         backgroundColor: Colors.indigo[800],
//     //         textColor: Colors.white,
//     //         fontSize: 16.0);
//     //     Navigator.push(context,
//     //         MaterialPageRoute(builder: (context) => ProfileScreenPage()));
//     //     print(pMessage);
//     //   });
//     // } else {
//     //   setState(() {
//     //     isLoading = false;
//     //   });
//     //
//     //   //  _showMsg(data["errors"]["msg"]).toString();
//     // }
//   }
//
//   @override
//   void initState() {
//     updateProfile();
//     firstController.text = widget.firstName;
//     lastController.text = widget.lastName;
//     cityController.text = widget.city;
//     stateController.text = widget.state;
//     countryController.text = widget.country;
//     address1Controller.text = widget.address1;
//     address2Controller.text = widget.address2;
//     phoneController.text = widget.phone;
//     faxController.text = widget.fax;
//     zipController.text = widget.zip;
//     //file = image.path;
//     emailController.text = widget.email;
//     //  passwordController.text = widget.password;
//     super.initState();
//     setState(() {});
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     Widget bottomSheet() {
//       return ClipRRect(
//         borderRadius: BorderRadius.circular(25),
//         child: Container(
//           height: 100.0,
//           width: MediaQuery.of(context).size.width,
//           margin: EdgeInsets.symmetric(
//             horizontal: 20,
//             vertical: 20,
//           ),
//           child: Column(
//             children: <Widget>[
//               Text(
//                 ('choose_profile_photo'),
//                 style: TextStyle(
//                   fontSize: 20.0,
//                 ),
//               ),
//               SizedBox(
//                 height: 20,
//               ),
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: <Widget>[
//                   FlatButton.icon(
//                     icon: Icon(Icons.camera),
//                     onPressed: () {
//                       takePhoto(ImageSource.camera);
//                       Navigator.pop(context);
//                     },
//                     label: Text("Camera"),
//                   ),
//                   FlatButton.icon(
//                     icon: Icon(Icons.image),
//                     onPressed: () {
//                       Navigator.pop(context);
//                       takePhoto(ImageSource.gallery);
//                     },
//                     label: Text("Gallery"),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       );
//     }
//
//     return SafeArea(
//       child: Scaffold(
//         appBar: AppBar(
//           leading: IconButton(
//             icon: Icon(
//               Icons.arrow_back,
//               color: Colors.black,
//             ),
//             onPressed: () {
//               Navigator.of(context).pop();
//             },
//           ),
//           backgroundColor: Colors.white,
//           elevation: 1,
//           title: RichText(
//             text: TextSpan(
//                 text: Vromon,
//                 style: TextStyle(
//                   fontSize: 30,
//                   fontFamily: 'Impact',
//                   color: HexColor("#26408A"),
//                 ),
//                 children: <TextSpan>[
//                   TextSpan(
//                       text: TOUR,
//                       style: TextStyle(
//                         fontSize: 30,
//                         fontFamily: 'Impact',
//                         color: HexColor("#118ACB"),
//                       )),
//                 ]),
//           ),
//         ),
//         backgroundColor: Colors.white,
//         key: _scaffoldKey,
//         body: SafeArea(
//           child: Form(
//             autovalidate: _autoValidate,
//             key: _key,
//             child: ListView(
//               children: <Widget>[
//                 SizedBox(
//                   height: 20,
//                 ),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Center(
//                       child: Stack(children: <Widget>[
//                         CircleAvatar(
//                           // backgroundColor: Colors.indigo,
//                           radius: 80.0,
//                           backgroundImage: _imageFile == null
//                               ? (widget.photo == null
//                                   ? AssetImage("assets/images/person.png")
//                                   : NetworkImage(widget.photo))
//                               : FileImage(File(_imageFile.path)),
//                         ),
//                         Positioned(
//                           bottom: 20.0,
//                           right: 20.0,
//                           child: InkWell(
//                             onTap: () {
//                               showModalBottomSheet(
//                                 context: context,
//                                 builder: ((builder) => bottomSheet()),
//                               );
//                             },
//                             child: Icon(
//                               Icons.add_a_photo,
//                               size: 31.0,
//                             ),
//                           ),
//                         ),
//                       ]),
//                     ),
//                   ],
//                 ),
//                 SizedBox(
//                   height: 20,
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: firstController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter FirstName";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'First Name',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: lastController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter Last Name";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Last Name',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: phoneController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter Phone Number";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Phone Number',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: emailController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter Email";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Email',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: cityController,
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'City',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: stateController,
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'State',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//                 //country 1..
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: countryController,
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Country',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//                 // address 1
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: address1Controller,
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Address1',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: address2Controller,
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Address2',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//                 //FAX
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: faxController,
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'FAX',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//                 //Zippp
//
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: zipController,
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Postal Code',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 //Passowrd
//
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: passwordController,
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Password',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 //  Confirm  //Passowrd
//
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: confirmPasswordController,
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Confirm Password',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//                 SizedBox(
//                   height: 30,
//                 ),
//                 Padding(
//                   padding:
//                       const EdgeInsets.only(left: 50, right: 50, bottom: 30),
//                   child: Container(
//                     height: 45,
//                     width: 230,
//                     child: isLoading
//                         ? Center(
//                             child: CircularProgressIndicator(
//                               valueColor:
//                                   AlwaysStoppedAnimation(Colors.indigo[800]),
//                             ),
//                           )
//                         : RaisedButton(
//                             onPressed: () {
//                               if (_key.currentState.validate()) {
//                                 setState(() {
//                                   updateProfile();
//                                 });
//                               } else {
//                                 setState(() {
//                                   _autoValidate = true;
//                                 });
//                               }
//                             },
//                             color: Colors.indigo[800],
//                             child: Text(
//                               "Update",
//                               style:
//                                   TextStyle(fontSize: 15, color: Colors.white),
//                             ),
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(20),
//                             ),
//                           ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
// import 'dart:convert';
// import 'dart:io';
// import 'dart:math';
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:http/http.dart' as http;
// import 'package:image_picker/image_picker.dart';
// import 'package:intl/intl.dart';
// import 'package:new_motel/global/global_data.dart';
// import 'package:new_motel/model/profile_model.dart';
// import 'package:new_motel/utils/constants.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// import '../../appTheme.dart';
//
// class ProfileUpdatePage extends StatefulWidget {
//   // final ProfileData profileData;
//   final String firstName;
//   final String id;
//   final String lastName;
//   final String city;
//   final String state;
//   final String country;
//   final String address1;
//   final String address2;
//   final String phone;
//   final String fax;
//   final String zip;
//   final String photo;
//   final String email;
//   final String password;
//
//   const ProfileUpdatePage(
//       {Key key,
//       this.id,
//       this.firstName,
//       this.lastName,
//       this.city,
//       this.state,
//       this.country,
//       this.address1,
//       this.address2,
//       this.phone,
//       this.fax,
//       this.zip,
//       this.photo,
//       this.email,
//       this.password})
//       : super(key: key);
//
//   // final int index;
//
//   @override
//   _ProfileUpdatePageState createState() => _ProfileUpdatePageState();
// }
//
// class _ProfileUpdatePageState extends State<ProfileUpdatePage> {
//   final _key = GlobalKey<FormState>();
//   final firstController = TextEditingController();
//   final lastController = TextEditingController();
//   final cityController = TextEditingController();
//   final stateController = TextEditingController();
//   final countryController = TextEditingController();
//   final address1Controller = TextEditingController();
//   final address2Controller = TextEditingController();
//   final phoneController = TextEditingController();
//   final faxController = TextEditingController();
//   final zipController = TextEditingController();
//   final emailController = TextEditingController();
//   final passwordController = TextEditingController();
//
//   DateTime date = DateTime.now();
//   Map<String, dynamic> data;
//   final ImagePicker _picker = ImagePicker();
//   // image Upload.....
//   PickedFile _imageFile;
//   void takePhoto(ImageSource source) async {
//     final pickedFile = await _picker.getImage(
//       source: source,
//     );
//     setState(() {
//       _imageFile = pickedFile;
//     });
//   }
//
//   final _scaffoldKey = GlobalKey<ScaffoldState>();
//
//   _showMsg(msg) {
//     final snackBar = SnackBar(content: Text(msg));
//     _scaffoldKey.currentState.showSnackBar(snackBar);
//   }
//
//   // gallery() async {
//   //   // ignore: deprecated_member_use
//   //   var _image = await ImagePicker.pickImage(source: ImageSource.gallery);
//   //   setState(() {
//   //     image = _image;
//   //   });
//   // }
//
//   bool isLoading = false;
//
//   // updateProfile() async {
//   //   final form = _key.currentState;
//   //   if (form.validate()) {
//   //     setState(() {
//   //       isLoading = true;
//   //     });
//   //     form.save();
//   //     await update();
//   //   } else {
//   //     setState(() {
//   //       isLoading = false;
//   //     });
//   //   }
//   // }
//
//   update() async {
//     // SharedPreferences _preference = await SharedPreferences.getInstance();
//     // String id = _preference.getString('id');
//
//     var body = {
//       'id': '',
//       "firstname": firstController.text,
//       "lastname": lastController.text,
//       "city": cityController.text,
//       "state": stateController.text,
//       "country": countryController.text,
//       "address1": address1Controller.text,
//       "address2": address2Controller.text,
//       "phone": phoneController.text,
//       "fax": faxController.text,
//       "zip": zipController.text,
//       "photo": _imageFile,
//       "email": emailController.text,
//       "password": passwordController.text,
//     };
//     final jsonString = json.encode(body);
//     print("JSonEncoded.....>>>>$jsonString");
//     // final headers = {HttpHeaders.contentTypeHeader: 'application/json'};
//
//     var response = await http.post(
//       "https://vromonbuzz.com/api/login/updateprofile?appKey=VromonBuzz",
//       body: body,
//     );
//     if (response.statusCode == 200) {
//       var data = json.decode(response.body);
//       print("AAAA${response.body}");
//       print("BBB${data}");
//       if (data != null) {
//         setState(() {
//           firstController.text = widget.firstName;
//           lastController.text = widget.lastName;
//           cityController.text = widget.city;
//           stateController.text = widget.state;
//           countryController.text = widget.country;
//           address1Controller.text = widget.address1;
//           address2Controller.text = widget.address2;
//           phoneController.text = widget.phone;
//           faxController.text = widget.fax;
//           zipController.text = widget.zip;
//           // "Photo" = PHOTO_G;
//           emailController.text = widget.email;
//           passwordController.text = widget.password;
//         });
//         Fluttertoast.showToast(
//             msg: ('  Profile Update Successfully'),
//             toastLength: Toast.LENGTH_SHORT,
//             gravity: ToastGravity.BOTTOM,
//             timeInSecForIosWeb: 2,
//             backgroundColor: Colors.indigo[800],
//             textColor: Colors.white,
//             fontSize: 16.0);
//         Navigator.of(context).pop();
//       } else {}
//     }
//
//     //  print(jsonString);
//     //
//     // if (data != null) {
//     //   setState(() {
//     //     Fluttertoast.showToast(
//     //         msg: "Profile Update SuccessFully",
//     //         toastLength: Toast.LENGTH_SHORT,
//     //         gravity: ToastGravity.BOTTOM,
//     //         timeInSecForIosWeb: 2,
//     //         backgroundColor: Colors.purple,
//     //         textColor: Colors.white,
//     //         fontSize: 16.0);
//     //     Navigator.pop(context, true);
//     //   });
//     // } else {
//     //   setState(() {
//     //     isLoading = false;
//     //   });
//     //
//     //   _showMsg(data["errors"]["msg"]).toString();
//     // }
//   }
//
//   @override
//   void initState() {
//     print("Update Name: ${widget.firstName}");
//     firstController.text = widget.firstName;
//     lastController.text = widget.lastName;
//     cityController.text = widget.city;
//     stateController.text = widget.state;
//     countryController.text = widget.country;
//     address1Controller.text = widget.address1;
//     address2Controller.text = widget.address2;
//     phoneController.text = widget.phone;
//     faxController.text = widget.fax;
//     zipController.text = widget.zip;
//     // "Photo" = PHOTO_G;
//     emailController.text = widget.email;
//     passwordController.text = widget.password;
//     // dobController.text = DOB;
//
//     super.initState();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     Widget bottomSheet() {
//       return ClipRRect(
//         borderRadius: BorderRadius.circular(25),
//         child: Container(
//           height: 100.0,
//           width: MediaQuery.of(context).size.width,
//           margin: EdgeInsets.symmetric(
//             horizontal: 20,
//             vertical: 20,
//           ),
//           child: Column(
//             children: <Widget>[
//               Text(
//                 ('choose_profile_photo'),
//                 style: TextStyle(
//                   fontSize: 20.0,
//                 ),
//               ),
//               SizedBox(
//                 height: 20,
//               ),
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: <Widget>[
//                   FlatButton.icon(
//                     icon: Icon(Icons.camera),
//                     onPressed: () {
//                       takePhoto(ImageSource.camera);
//                       Navigator.pop(context);
//                     },
//                     label: Text("Camera"),
//                   ),
//                   FlatButton.icon(
//                     icon: Icon(Icons.image),
//                     onPressed: () {
//                       Navigator.pop(context);
//                       takePhoto(ImageSource.gallery);
//                     },
//                     label: Text("Gallery"),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       );
//     }
//
//     return Scaffold(
//       appBar: AppBar(
//         leading: IconButton(
//           icon: Icon(
//             Icons.arrow_back,
//             color: Colors.black,
//           ),
//           onPressed: () {
//             Navigator.pop(context);
//           },
//         ),
//         backgroundColor: Colors.white,
//         elevation: 1,
//         title: Text(
//           "Update Profile",
//           style: TextStyle(fontSize: 20, color: Colors.black),
//         ),
//       ),
//       backgroundColor: Colors.transparent,
//       body: SafeArea(
//         child: Form(
//           child: SingleChildScrollView(
//             child: Column(
//               children: [
//                 SizedBox(
//                   height: 40,
//                 ),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Center(
//                       child: Stack(children: <Widget>[
//                         CircleAvatar(
//                           backgroundColor: Colors.indigo,
//                           radius: 80.0,
//                           backgroundImage: _imageFile == null
//                               ? (widget.photo == null
//                                   ? AssetImage("assets/images/vromonbuzz.png")
//                                   : NetworkImage(widget.photo))
//                               : FileImage(File(_imageFile.path)),
//                         ),
//                         Positioned(
//                           bottom: 20.0,
//                           right: 20.0,
//                           child: InkWell(
//                             onTap: () {
//                               showModalBottomSheet(
//                                 context: context,
//                                 builder: ((builder) => bottomSheet()),
//                               );
//                             },
//                             child: Icon(
//                               Icons.add_a_photo,
//                               size: 31.0,
//                             ),
//                           ),
//                         ),
//                       ]),
//                     ),
//                   ],
//                 ),
//
//                 // FirstName Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: firstController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter FirstName";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'First Name',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // LastName Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: lastController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter LastName";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Last Name',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // City Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: cityController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter City";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'City',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // State Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: stateController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter City";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'State',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Country Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: countryController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter Country";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Country',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Address1 Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: address1Controller,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter Address1";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Address1',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Address2 Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: address2Controller,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter  Address2";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'City',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Phone Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: phoneController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter Phone";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Phone',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Fax Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: faxController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter Fax";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Fax',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Zip Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: zipController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter Zip";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Zip',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Email Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: emailController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter Email";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Email',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Password Fields
//                 Padding(
//                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//                   child: Container(
//                     decoration: BoxDecoration(
//                       color: AppTheme.getTheme().backgroundColor,
//                       borderRadius: BorderRadius.all(Radius.circular(38)),
//                       // border: Border.all(
//                       //   color: HexColor("#757575").withOpacity(0.6),
//                       // ),
//                       boxShadow: <BoxShadow>[
//                         BoxShadow(
//                           color: AppTheme.getTheme().dividerColor,
//                           blurRadius: 8,
//                           offset: Offset(4, 4),
//                         ),
//                       ],
//                     ),
//                     child: Padding(
//                       padding: const EdgeInsets.only(left: 16, right: 16),
//                       child: Container(
//                         height: 48,
//                         child: Center(
//                           child: TextFormField(
//                             controller: passwordController,
//                             validator: (value) {
//                               if (value.isEmpty) {
//                                 return "Please Enter Password";
//                               }
//                               return null;
//                             },
//                             maxLines: 1,
//                             onChanged: (String txt) {},
//                             style: TextStyle(
//                               fontSize: 16,
//                             ),
//                             cursorColor: AppTheme.getTheme().primaryColor,
//                             decoration: new InputDecoration(
//                               errorText: null,
//                               border: InputBorder.none,
//                               hintText: 'Password',
//                               hintStyle: TextStyle(
//                                   color: AppTheme.getTheme().disabledColor),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 SizedBox(
//                   height: 30,
//                 ),
//
//                 // Update Button
//                 Padding(
//                   padding: const EdgeInsets.only(
//                       left: 24, right: 24, bottom: 8, top: 16),
//                   child: Container(
//                     height: 45,
//                     width: 230,
//                     child: RaisedButton(
//                       onPressed: () {
//                         update();
//                       },
//                       color: AppTheme.getTheme().primaryColor,
//                       child: Text(
//                         "Update",
//                         style: TextStyle(fontSize: 15, color: Colors.white),
//                       ),
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(20),
//                       ),
//                     ),
//                   ),
//                 ),
//
//                 // Padding(
//                 //   padding: const EdgeInsets.only(
//                 //       left: 24, right: 24, bottom: 8, top: 16),
//                 //   child: Container(
//                 //     height: 48,
//                 //     decoration: BoxDecoration(
//                 //       color: AppTheme.getTheme().primaryColor,
//                 //       borderRadius:
//                 //       BorderRadius.all(Radius.circular(24.0)),
//                 //       boxShadow: <BoxShadow>[
//                 //         BoxShadow(
//                 //           color: AppTheme.getTheme().dividerColor,
//                 //           blurRadius: 8,
//                 //           offset: Offset(4, 4),
//                 //         ),
//                 //       ],
//                 //     ),
//                 //     child: Material(
//                 //       color: Colors.transparent,
//                 //       child: InkWell(
//                 //         borderRadius:
//                 //         BorderRadius.all(Radius.circular(24.0)),
//                 //         highlightColor: Colors.transparent,
//                 //         onTap: () {
//                 //           Navigator.pop(context);
//                 //         },
//                 //         child: Center(
//                 //           child: Text(
//                 //             APPLY,
//                 //             style: TextStyle(
//                 //                 fontWeight: FontWeight.w500,
//                 //                 fontSize: 16,
//                 //                 color: Colors.white),
//                 //           ),
//                 //         ),
//                 //       ),
//                 //     ),
//                 //   ),
//                 // ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
//
//
//
//
//

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:new_motel/modules/profile/userProfile.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../appTheme.dart';

class ProfileUpdateScreen extends StatefulWidget {
  final String id;
  final ProfileScreenPageState profileGetState;
  final String firstName;
  final String lastName;
  final String city;
  final String state;
  final String country;
  final String address1;
  final String address2;
  final String phone;
  final String fax;
  final String zip;
  final String photo;
  final String email;
  final String password;
  final String confirmPassword;

  const ProfileUpdateScreen({
    Key key,
    this.id,
    this.profileGetState,
    this.firstName,
    this.lastName,
    this.city,
    this.state,
    this.country,
    this.address1,
    this.address2,
    this.phone,
    this.fax,
    this.zip,
    this.photo,
    this.email,
    this.password,
    this.confirmPassword,
  }) : super(key: key);
  @override
  _ProfileUpdateScreenState createState() => _ProfileUpdateScreenState();
}

class _ProfileUpdateScreenState extends State<ProfileUpdateScreen> {
  final _key = GlobalKey<FormState>();
  // final nameController = TextEditingController();
  // final emailController = TextEditingController();
  // final phoneController = TextEditingController();
  // final upazilaController = TextEditingController();
  // final dobController = TextEditingController();
  // final occuptionController = TextEditingController();
  // final imageController = TextEditingController();
  // final educationController = TextEditingController();
  // final addressController = TextEditingController();
  // Map<String, dynamic> data;
  String pMessage = '';
  bool success = false;
  // final ImagePicker _picker = ImagePicker();
  // // image Upload.....
  // PickedFile _imageFile;
  // Uint8List _bytesImage;
  // String base64Image;

  // void takePhoto(ImageSource source) async {
  //   final pickedFile = await _picker.getImage(
  //     source: source,
  //   );
  //   setState(() {
  //     _imageFile = pickedFile;
  //   });
  // }

  // File image;

  final firstController = TextEditingController();
  final lastController = TextEditingController();
  final cityController = TextEditingController();
  final stateController = TextEditingController();
  final countryController = TextEditingController();
  final address1Controller = TextEditingController();
  final address2Controller = TextEditingController();
  final phoneController = TextEditingController();
  final faxController = TextEditingController();
  final zipController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();

  final _scaffoldKey = GlobalKey<ScaffoldState>();
  _showMsg(msg) {
    final snackBar = SnackBar(content: Text(msg));
    _scaffoldKey.currentState.showSnackBar(snackBar);
  }

  bool isLoading = false;
  bool _autoValidate = false;

//
//   void _choose() async {
//     file = await ImagePicker.pickImage(source: ImageSource.camera);
// // file = await ImagePicker.pickImage(source: ImageSource.gallery);
//   }
  final ImagePicker _picker = ImagePicker();
  // image Upload.....
  // PickedFile _imageFile;
  // Uint8List _bytesImage;
  // String base64Image;
  // File file;

  // _uploadPhoto(PickedFile pickedFile) async {
  //   SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  //   String id = sharedPreferences.getString("id");
  //   if (pickedFile == null) return;
  //   File file = File(pickedFile.path);
  //   final _imageFile = ImageProcess.decodeImage(
  //     file.readAsBytesSync(),
  //   );
  //   base64Image = base64Encode(ImageProcess.encodeJpg(_imageFile));

  //   //  _bytesImage = Base64Decoder().convert(widget.photo);
  //   // print("==> image $base64Image");
  //   // String id;

  //   final response = await http.post(
  //       "https://vromonbuzz.com//api/login/updatephoto?appKey=VromonBuzz",
  //       body: {
  //         "id": id,
  //         "user_photo": base64Image,
  //       });
  //   if (response.statusCode == 200) {
  //     return base64Image;
  //   }

  //   print("==> ${response.statusCode}");
  // }

  // _uploadPhoto() async {
  //   SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  //   String id = sharedPreferences.getString("id");
  //
  //   if(file==null){
  //     String based = base64Encode(file.readAsBytesSync());
  //     print("Abir Based $based ");
  //     //String imageName = file.path.split(',').last;
  //     var url = "https://vromonbuzz.com//api/login/updatephoto?appKey=VromonBuzz";
  //     var response = await http.post(url,body: {
  //       "id" : id,
  //       "user_photo" : base64Decode(File(based).path),
  //
  //
  //     });
  //     return response;
  //   }
  //  //  if (pickedFile == null) return;
  //  //  print("path: ${pickedFile.path}");
  //  //
  //  //  File file = File(pickedFile.path);
  //  //  Uint8List bytes = file.readAsBytesSync();
  //  // // String base64Image = base64Encode(bytes);
  //  //
  //  //  final bytes1 = await Io.File(pickedFile.path).readAsBytes();
  //  //  String base64Encode = base64.encode(bytes1);
  //   // final _imageFile = ImageProcess.decodeImage(
  //   //   file.readAsBytesSync(),
  //   // );
  //  // base64Image = base64Encode(ImageProcess.encodeJpg(_imageFile));
  //
  //  // String img = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAABmJLR0QA/wD/AP+gvaeTAAASKUlEQVR4nO3dfZBfVX3H8feGZDeYBBIZhUoCJCQkYKgoTotWQ0USiIBVitjyoFZx6IwtUloeWotkxoIII53UTltRHgoZwKIVRjutToAGkIdAHVGUJAtNIAQrGhLysHna7PaP7y+TZLNLfufec+73nvv7vGa+s8vyy+73nt8953fvuecBRERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERETqoss7AUlmLDALmAkc0/p+GjCuFZNaXwE2A+taXzcBK4FlwHJgRev7rRXmLhVRA9Aco4F3AKe24n1YIxBDP/AMsLgVjwDbIv1uESnoAGAucCf2yT1YUWwE7sAamlHJj1JE9nIk8BXgZaqr9CPFauB64IikRywiTAMWYvfj3hV/aGzHrgpmJTt6kQ51NHAPsBP/ir6/6AfuwhorESmhG7gS2IJ/xQ6NPmAB8ToiRTrK6UAv/hW5bKwA5kUuG5HGGo11qg3gX3ljxQDWd9EdsZxEGucI4HH8K2yqeBrrzxCRIc4A1uNfSVPHOuBDkcpMpBEuxB6jeVfOqqIfuChKyUkpGgrs7wrsnj/Ve7EceBIbz78C61jcxO6x/7B7bsAEYAY2d2AmcFLr+xQGsSccNyb6/SK1dz3xP137gLuBC4C3RcjxcOwK5VukeRx5XYQcRbJzBXEr0pPAZ4CDE+Z8MHbpvjRy7pcnzFmkdi4g3mO+R4Gzqk0fsNmG3yuQ73AxAHy62vRFfJwJ7KB8pXkOOKXi3IczF+tfKHs824H5FecuUqlpWOdbmYrSB1xFvQbV9ABfoHwfwWvAURXnLlKJMZQf5LMMW/Sjro4DnqXcMS6lXo2bSBQLKVcxFgHjK8863ARs5mKZY72p8qxFEjqdcp1+15HXmI0ubMGSosc7gPUtiGRvLMVn9Q0Al1afcjSXUbzhW471LYhkbQHFPwkvc8g3ts9R/Pi/4JCvSDRHU7xn/O8c8k3lBoqVQR9aWUgyVrQzbBF53fPvTxc2lLhoWYhkZzo26y30hF+B9aQ3zXhs8FJoefRjE5REsnIb4Sf7FuAEj2Qrcjx2WR9aLt/wSFakqCnYzjmhJ/pVHslW7GrCy2U7theCSBaKPAP/BZ0xAq4He8QXWj5f9khWJNQBFNuxpw4Te6oyj/DyeQltQyYZKHJyP+CSqa8lqJGUBroTndjtKNJQ3uaSqUibugnfpfdJl0zr4SnCymoDNqtSItE9VVwnYQtshrg5RSKZCH28NwH4nRSJdCo1AHGFXspvBb6TIpFM7FpoNEQn3i4lowYgrg8Evv4+bDOQTvU68P3AfxNaxiKVOBD7RA+5pz3fJdN6+QRhZbYF7TgsNXQC4b3ah7tkWi9TCC+3410ybSDdAsQzM/D1y4A1KRLJzGrg+cB/E1rWMgI1APGEnpRLk2SRpycCXz8rSRYdSA1APEWuAMQsD3x9qv0KO44agHhC17NfkSSLPIU2AFOTZNGB1ADEc1Dg619IkkWeQvsAQstaRqAGIJ7QVXzWJckiT6FjIZq4YpILNQDxhJ6UG5NkkafQslADILUTugJQJyz+0a4ewspuq0+azaMrAJEOpgYgnk2Br89hn7+q6PbJiRqAeHQfW5waACdqAOLZEPj6SUmyyFNoWagBiEQNQDyhDcDRSbLIU2hZhJa1jEANQDwvBr5eE1p2Cx3bvzJJFh1IDUA8oWP71QDsFjq2P3TosIxADUA8oWP7fzdJFnk6KfD1agCkdoosCDLZJdN60YIgjnQFEM8ybDRgCK1vV2whVc2kjEQNQDxbCV/Y4swUiWTmrMDXP054QysjUAMQ10OBr/8wMDFFIpmYRHgj+GCKRDqVGoC4Qk/OscA5KRLJxLnYRKAQagCktrqxUWohHVqdvDbg04SV1etoazCpuTsI79U+1SVTX6cTXk63umQqEmAu4Sd2aN9BEzxMeDnpqYnU3ihsrfvQk3uuR7JO5hNePi+iPivJxPWEn+DLCO8Qy9FYoJfw8rnOI1mRIqYQvkTYIPA3HslW7BrCy2U7cKRHsiJF3UL4ib4VeKdHshX5bWxzz9By+bpHsiJlHA3sIPxk76WZ695PwG5zQsujH5jhkK9IaXcRfsIPAvcAXQ75ptIFfJtiZXGHQ74iURwJbKbYif8Vh3xT+SrFyqAPbQMmmfsixU7+QeAvHfKN7QqKH/9fO+QrElUPNn21SAUYAC6rPuVoLseOocixL0Obp0hDzKN4RRgEbiCvPoEuil/272r4Plh51iIJ3UTxCjEIfIs89hI4mOIdfrvixsqzFklsDPAY5SrGSuq9luC7KDbKb894El36S0NNxbYFL1NBtgBXU69hw2OxEX5bKXdsa9GIP2m4D1FsgNDQWI71LXibT/lP/UFsuO9pFecu4uJ8ynUK7hmPYuvqVd1J+D5gccncd8UA8Klq0xfxdTlxKs+ueAr4LGnXGJwEXEz4Sj77iyaMdxAJdh1xK9Ig1kdwL/AJ4uw7MAX4JNazX/Yef7i4NkKOUlBOz5ab6nJs2G+q96IX61lfhg1IegFY34pNrdeMx64cJmKTmGa24iRgeqK8BrFj/2qi3y+SjQuwTrDYn651jR3AZ6KUnEhDzAdew79ypo61qLdfZFhHAD/Cv5KmiqeAadFKS6SBRgMLgJ34V9hYMQAsRCP8RNo2Fxvs4115y8YyNLFHpJAxwOcJ322oDtGHXcnUaciySJamAouw9fG8K/b+YgdwJxrTLxLdVOxeusjKuqljO7Z+3zHJjl5EABuddx3wEv4V/yVsNN+UpEcsIvsYBZwC3A5soLpK/zpwG7ZXn7brypiGAjfHAcAJ2E7Dp2Kz9cZG+t39wDPY7L/FwCPYzkeSOTUAzdUDzMLuyY9pfT8VG/c/ARv3P7712k3Y3ICNre//F3sEuRybP7AcVXgRERERERERERERERERERERERERERERERERERERERERkUpoQZDm6AKOwnYXmgwctsfXw4E3Ydt7M8zXrdhCo2CLgqxrxWvAr4E1wIvAy62vq7CNSyRzagDydCi2/NfxwHHAbOBYdq/wk9o2bMOP5cCzwP+04lcV/X2JRA1AHqYC798jZvqmM6KXsa3Il7TiWWxbMBEJcCDwYeCbwGr8l/4uGmuBb2Nbgb8tagmJNMxbgE8D9wGb8a+8sWMA+DFwDXbbItLxuoGzge+Tx7ZfMeNZ4ItYwyfSUWYDNwGv4l8RvWMDcG654hSpv1HAR4BH8a90dYudwJnFi1akvnqAz2KPzbwrWp1jNfF2MhJxNw64Cvgl/pUrlzi7UEnXRzfW4GdjtHcCDTQauAjr7T7MOZfcnAj8u3cSb+Aw4L3YOIwZ2JZrk4GDsO3WdtWnnVjfxkZsFOUKoLf19bHWz6RhuoA/xEbHeX+S5ho3BZd6WgdiHZQ3E/cWrhe4FTiP6kZvDktXAHG8G/gacJJzHoPASuxkXQO8skf8ChuYAzbOf8+v3dgtSxe2aeikVhyKDeCZDExh96ded6L8VyX6vSFGYbsrnw98FPtkj216K/4E6APuB+4CfgDsSPD3JJEJwEJ8nuFvw54o3Ah8CmuExqU9XMC2IZ+OVY5rgf8CfhPheAawxsVLD3br5nkFtwq4hGreRynpo1Q7THcL9gnxt8Ac7PK0LrqwiUmXYPfw6wk/vvsrz9qMAS7F5jF4Vfyh8WvsfX5TwuOWgn4LG65bxYnwG+Bfsb6FnD4VurHL6H/Apg/v7zhfwMq1aqcAP28jP69YRf5PRhrlTNKP3tuATQL6fexyO3ejgJOxjrR17H2sW1s/r3o48FuAu0n7PsaMH2IzQsXJWOzTbIA0b/AA8DB2L5/TJ32oMcDvARdiVwge8wDmUK/L/XZjPfCxBOUh+3Ec8Axp3tQtwL9Q3/n9TTIKu6/egX9lLhP/TL36fxrt46SZmrsW+BLw1uoOpaP1APfiX3ljxRPAIVFLSPbShVXQ2Jf8a4G/otmX+XUzAViMf6WNHc8BR0YsJ2kZjz3Kivlm9QHXY4NspDqHAEvxr6yp4mXg7dFKSziKuPf7O7Ehn5OrPAgBrCF/Ev9KmjpeQU8IojiWuAN7fgq8p9IjkF3GAP+Jf+WsKp7Hhm1LQe/GRl/FeDM2A1diJ6FUrwtYhH+lrDqWor6lQuYArxPnTViMLse8XYp/ZfSK2yOUX0eZj3XQlS34HcAC7Fmz+DkRG13oXRE948LSpdghPkick2UltkiE+BqPll0bxBYh0cCy/XgPsInyhb2INPPFJdw/4l/56hKPoF2/RnQ8NiCnTAEPYJf8Ug+zyX+Ib+w4v1SJNtQMyi/S+TpwRtWJy4i6sIlUXhXtFWx05zHYkOOJ2DTjO7BxIF55rUFXp3t5K3a/XqZQe9G2VnXzMfwq2QO88ejOU4n3hKlIXNt2KTZcN3ZfVKYwf4IGW9TRj/GpXMtp7xP2I075DWJTiA9uI8fGu5lyBfkYtkim1Ms8/CrXxwPyfNAxzysC8mykz1GuABfjvHSzjMhrll8fYXPyL3bKcxDro8hqs5KYPgBsp3jh/QcdXHg1NwO/SrUsMNeTHXMd5A02X23yyLVDgXsoPiZ/CXAOtvy21M95jn97U+LXx/ZHzn+/cl3A9yjeYv4Ezd2vO89Rf08H5nqiY66D2IjXYc/npl4B/BnFt5t+Dnt8sz5eOhLZO9Fw1xA9wB8M9z+a2ADMBm4o+G9/CZyGrccv9TXXO4EMDVtmTWsAerDx+UX2md+OPdpZHTUjSWGOdwIZOtk7gSp8ieL3SRc55CvhRrHvBiPqA2gvGr1WxUyKT+/9e4d8pZjZ+FekXBuAC4Ym1qRbgH+i2DP7JcDlkXORdNT5V1xjy+48irWIr2H73ks+riLNp+PQWX1Vq2IW4T2VHU2FJlJ8iq/2WsvPLcSvGPub1Ve1VLMIQ29dsvBlihXGrR7JSmk/JG6laHdWX9VSzCJ8tdIjqEAXxbbrfgFN8MnV48StFCGz+qoWexbh1mrTT28KxQriNI9kJYqfEa9ChM7qq1qKWYR7zY3J/SlAkYk+/wb8IHYiUpmYV24vYVu011XorMN27HW7k3sDsJqwy5oNwF8kykWqkfs5623UiP+RoR3YnP12XY097pF8xZxaewT1vgU4NsHv3Jjgd7qaTXuLfjwCHOCUo8QTe8ffOs+Vf4i4x7q92vSr88fYwh0jHXgv1tpL/h4gbqXoBQ6q9AjaczbxOwDXVnoEFXsXcB/Qz+4DfhW4kXq+wVJMip1/H6Rei77Ow/qrYh/nz6o8CC/jsLX7J5N/H4fs6xriV4xB4P+wFXRnUWw6eVlvxvarXES6ocDfrexoRBI5nzSVIyRynQ24z0I5+oSU3KzwTiBjvUN/oAZAcvNTGjiktSJPDP2BGgDJzTbsUaCEeQ34+dAfqgGQHC3xTiBDD2Pb2u9FDYDk6CHvBDI0bJmpAZAcPQys8U4iIwPAd4b7H2oAJEcDwL3eSWRkCSM0mGoAJFd3O/7t0CnJ3isONXItQOlsXcAz+AyoCV1I5E+d8hzEhhSPOMxZVwCSq0FsnoeHAxlhr70ReC479g1sIxWRxhkDrMLnk7XdWYQpZvW1G9uwOTEijfXn+FWw/c0iTDWrr924pe1SFMlUN7Z2nlclGzqLsIpZfe3ERuDwEuUqko25+FW0usaVpUpUJDP341/p6hK9+GxvJuJmCrbklXfl845+YE7JshTJ0hnYKEHvSugZ15QuRZGMfQ3/SugVS9DK19LhxgKP4V8Zq47VqNdfBIBDgF/gXymrivXAO6KUnEhDTAZexL9ypo4twPsjlZlIo7wd2wrOu5KmrPxnRSstkQY6Ct+RgqliHXrcJ9KWNwM/wr/SxopX0D2/SJBxwO34V96y8d+ot1+ksHOwy2fvihwa/cAC9JxfpLQZ2Hbx3pW63ViO7vdFojuLej8q3Ix96mtij0giE4BrscE03hV+V2zDFvPQvb5IRSYAn8eG1HpV/I3AQmxmo4g46AHOBb6LbUKautLvxHbtuRiYWMHxiUibDgY+CdxJ3CuDtcB9wCU4X+Z3ef5xkcxMA96Lrf83vRVHYrcPQzvq+rFL+jXYCj3Pt+JxbJfefTbq9KAGQCSO0ezeAagP68gTERERERGpk/8HhcH2sU3qffYAAAAASUVORK5CYII=";
  //
  // //  print("Base64 bijoy: $base64Encode");
  //   //  _bytesImage = Base64Decoder().convert(widget.photo);
  //   // print("==> image $base64Image");
  //   // String id;
  //
  //   // final response = await http.post(
  //   //     "https://vromonbuzz.com//api/login/updatephoto?appKey=VromonBuzz",
  //   //     body: {
  //   //       "id": id,
  //   //       "user_photo":base64,
  //   //     });
  //   // if (response.statusCode == 200) {
  //   //   return base64;
  //   // }
  //   //
  //   // print("==> ${response.body}");
  // }

  // gallery() async {
  //   // ignore: deprecated_member_use
  //   var image2 = await ImagePicker.pickImage(source: ImageSource.gallery);
  //   setState(() {
  //     image = image2;
  //   });
  // }
  File fileImage;
  asyncFileUpload() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var id = sharedPreferences.getString("id");
    //create multipart request for POST or PATCH method
    var request = http.MultipartRequest(
        "POST",
        Uri.parse(
            "https://deshitour.com//api/login/updatephoto?appKey=DeshiTour"));
    //add text fields
    request.fields["id"] = id;
    //create multipart using filepath, string or bytes
    var pic = await http.MultipartFile.fromPath("user_photo", fileImage.path);
    //add multipart to request
    request.files.add(pic);
    var response = await request.send();
    //Get the response from the server
    var responseData = await response.stream.toBytes();
    var responseString = String.fromCharCodes(responseData);
    print(responseString);
  }

  void takePhoto(ImageSource source) async {
    final pickedFile = await _picker.getImage(
      source: source,
    );
    setState(() {
      fileImage = File(pickedFile.path);
    });
  }

  updateProfile() async {
    final form = _key.currentState;
    if (form.validate()) {
      setState(() {
        isLoading = true;
      });
      form.save();
      update();
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  update() async {
    SharedPreferences _preference = await SharedPreferences.getInstance();
    String id = _preference.getString('id');

    var response = await http.post(
      "https://deshitour.com/api/login/updateprofile?appKey=DeshiTour",
      body: {
        'id': id,
        "firstname": firstController.text,
        "lastname": lastController.text,
        "city": cityController.text,
        "state": stateController.text,
        "country": countryController.text,
        "address1": address1Controller.text,
        "address2": address2Controller.text,
        "phone": phoneController.text,
        "fax": faxController.text,
        "zip": zipController.text,
        "photo": widget.photo ?? "",
        "email": emailController.text,
        "password": passwordController.text,
        "confirm_password": confirmPasswordController.text,
      },
      headers: {
        "Accept": "application/json",
      },
    );
    var errorMsg = json.decode(response.body)['msg'];
    print(errorMsg);
    if (response.statusCode == 200) {
      var data = json.decode(response.body)['status'];
      if (data == 1) {
        setState(() {
          isLoading = true;
        });

        Fluttertoast.showToast(
            msg: "Successfully Done",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 2,
            backgroundColor: Colors.indigo,
            textColor: Colors.white,
            fontSize: 16.0);
        //setState(() {});
        navigateSecondPage("3");
      } else {
        setState(() {
          isLoading = false;
        });
        Fluttertoast.showToast(
            msg: errorMsg,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 2,
            backgroundColor: Colors.indigo,
            textColor: Colors.white,
            fontSize: 16.0);
        // setState(() {});
      }
    }

    // if (data != null) {
    //   setState(() {
    //     Fluttertoast.showToast(
    //         msg: pMessage,
    //         toastLength: Toast.LENGTH_SHORT,
    //         gravity: ToastGravity.BOTTOM,
    //         timeInSecForIosWeb: 2,
    //         backgroundColor: Colors.indigo[800],
    //         textColor: Colors.white,
    //         fontSize: 16.0);
    //     Navigator.push(context,
    //         MaterialPageRoute(builder: (context) => ProfileScreenPage()));
    //     print(pMessage);
    //   });
    // } else {
    //   setState(() {
    //     isLoading = false;
    //   });
    //
    //   //  _showMsg(data["errors"]["msg"]).toString();
    // }
  }

  FutureOr onGoBack(dynamic value) {
    updateProfileScreen();
    setState(() {});
  }

  //
  // String _imageBase64;
  // Uint8List bytes;
  //
  // Widget getImagenBase64(String imagen) {
  //   _imageBase64 = imagen;
  //   const Base64Codec base64 = Base64Codec();
  //   if (_imageBase64 == null) return new Container();
  //   bytes = base64.decode(_imageBase64);
  //   return Image.memory(
  //     bytes,
  //     width: 200,
  //     fit: BoxFit.fitWidth,
  //
  //   );
  // }
  void navigateSecondPage(String from) {
    Route route =
        MaterialPageRoute(builder: (context) => ProfileScreenPage(type: from));
    Navigator.push(context, route).then(onGoBack);
  }

  //  File file;
  //  Future pickedCamra() async {
  //    final myFile = await ImagePicker().getImage(source: ImageSource.camera);
  //
  //    setState(() {
  //      file = File(myFile.path);
  //    });
  //  }
  //
  //  Future upload() async {
  //    if (file == null) return;
  //    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  //    var id = sharedPreferences.getString("id");
  // List<int> test = file.readAsBytesSync();
  // String test2 = base64Encode(test);
  // Uint8List test3 = base64Decode(test2);
  //    var response = await http.post(
  //      "https://vromonbuzz.com//api/login/updatephoto?appKey=VromonBuzz",
  //      body: {
  //        "id": id,
  //        "user_photo": test3,
  //      },
  //    );
  //    print("Upload Image....${response.body}");
  //    print("BAse64... $test3");
  //    print("Url...$test3");
  //    print("Id...$id");
  //
  //    return response;
  //  }

  @override
  void initState() {
    firstController.text = widget.firstName;
    lastController.text = widget.lastName;
    cityController.text = widget.city;
    stateController.text = widget.state;
    countryController.text = widget.country;
    address1Controller.text = widget.address1;
    address2Controller.text = widget.address2;
    phoneController.text = widget.phone;
    faxController.text = widget.fax;
    zipController.text = widget.zip;
    // _imageFile = widget.photo;
    emailController.text = widget.email;
    //  passwordController.text = widget.password;
    super.initState();
    // _uploadPhoto(_imageFile);
    // _uploadPhoto();
    // String img = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAABmJLR0QA/wD/AP+gvaeTAAASKUlEQVR4nO3dfZBfVX3H8feGZDeYBBIZhUoCJCQkYKgoTotWQ0USiIBVitjyoFZx6IwtUloeWotkxoIII53UTltRHgoZwKIVRjutToAGkIdAHVGUJAtNIAQrGhLysHna7PaP7y+TZLNLfufec+73nvv7vGa+s8vyy+73nt8953fvuecBRERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERETqoss7AUlmLDALmAkc0/p+GjCuFZNaXwE2A+taXzcBK4FlwHJgRev7rRXmLhVRA9Aco4F3AKe24n1YIxBDP/AMsLgVjwDbIv1uESnoAGAucCf2yT1YUWwE7sAamlHJj1JE9nIk8BXgZaqr9CPFauB64IikRywiTAMWYvfj3hV/aGzHrgpmJTt6kQ51NHAPsBP/ir6/6AfuwhorESmhG7gS2IJ/xQ6NPmAB8ToiRTrK6UAv/hW5bKwA5kUuG5HGGo11qg3gX3ljxQDWd9EdsZxEGucI4HH8K2yqeBrrzxCRIc4A1uNfSVPHOuBDkcpMpBEuxB6jeVfOqqIfuChKyUkpGgrs7wrsnj/Ve7EceBIbz78C61jcxO6x/7B7bsAEYAY2d2AmcFLr+xQGsSccNyb6/SK1dz3xP137gLuBC4C3RcjxcOwK5VukeRx5XYQcRbJzBXEr0pPAZ4CDE+Z8MHbpvjRy7pcnzFmkdi4g3mO+R4Gzqk0fsNmG3yuQ73AxAHy62vRFfJwJ7KB8pXkOOKXi3IczF+tfKHs824H5FecuUqlpWOdbmYrSB1xFvQbV9ABfoHwfwWvAURXnLlKJMZQf5LMMW/Sjro4DnqXcMS6lXo2bSBQLKVcxFgHjK8863ARs5mKZY72p8qxFEjqdcp1+15HXmI0ubMGSosc7gPUtiGRvLMVn9Q0Al1afcjSXUbzhW471LYhkbQHFPwkvc8g3ts9R/Pi/4JCvSDRHU7xn/O8c8k3lBoqVQR9aWUgyVrQzbBF53fPvTxc2lLhoWYhkZzo26y30hF+B9aQ3zXhs8FJoefRjE5REsnIb4Sf7FuAEj2Qrcjx2WR9aLt/wSFakqCnYzjmhJ/pVHslW7GrCy2U7theCSBaKPAP/BZ0xAq4He8QXWj5f9khWJNQBFNuxpw4Te6oyj/DyeQltQyYZKHJyP+CSqa8lqJGUBroTndjtKNJQ3uaSqUibugnfpfdJl0zr4SnCymoDNqtSItE9VVwnYQtshrg5RSKZCH28NwH4nRSJdCo1AHGFXspvBb6TIpFM7FpoNEQn3i4lowYgrg8Evv4+bDOQTvU68P3AfxNaxiKVOBD7RA+5pz3fJdN6+QRhZbYF7TgsNXQC4b3ah7tkWi9TCC+3410ybSDdAsQzM/D1y4A1KRLJzGrg+cB/E1rWMgI1APGEnpRLk2SRpycCXz8rSRYdSA1APEWuAMQsD3x9qv0KO44agHhC17NfkSSLPIU2AFOTZNGB1ADEc1Dg619IkkWeQvsAQstaRqAGIJ7QVXzWJckiT6FjIZq4YpILNQDxhJ6UG5NkkafQslADILUTugJQJyz+0a4ewspuq0+azaMrAJEOpgYgnk2Br89hn7+q6PbJiRqAeHQfW5waACdqAOLZEPj6SUmyyFNoWagBiEQNQDyhDcDRSbLIU2hZhJa1jEANQDwvBr5eE1p2Cx3bvzJJFh1IDUA8oWP71QDsFjq2P3TosIxADUA8oWP7fzdJFnk6KfD1agCkdoosCDLZJdN60YIgjnQFEM8ybDRgCK1vV2whVc2kjEQNQDxbCV/Y4swUiWTmrMDXP054QysjUAMQ10OBr/8wMDFFIpmYRHgj+GCKRDqVGoC4Qk/OscA5KRLJxLnYRKAQagCktrqxUWohHVqdvDbg04SV1etoazCpuTsI79U+1SVTX6cTXk63umQqEmAu4Sd2aN9BEzxMeDnpqYnU3ihsrfvQk3uuR7JO5hNePi+iPivJxPWEn+DLCO8Qy9FYoJfw8rnOI1mRIqYQvkTYIPA3HslW7BrCy2U7cKRHsiJF3UL4ib4VeKdHshX5bWxzz9By+bpHsiJlHA3sIPxk76WZ695PwG5zQsujH5jhkK9IaXcRfsIPAvcAXQ75ptIFfJtiZXGHQ74iURwJbKbYif8Vh3xT+SrFyqAPbQMmmfsixU7+QeAvHfKN7QqKH/9fO+QrElUPNn21SAUYAC6rPuVoLseOocixL0Obp0hDzKN4RRgEbiCvPoEuil/272r4Plh51iIJ3UTxCjEIfIs89hI4mOIdfrvixsqzFklsDPAY5SrGSuq9luC7KDbKb894El36S0NNxbYFL1NBtgBXU69hw2OxEX5bKXdsa9GIP2m4D1FsgNDQWI71LXibT/lP/UFsuO9pFecu4uJ8ynUK7hmPYuvqVd1J+D5gccncd8UA8Klq0xfxdTlxKs+ueAr4LGnXGJwEXEz4Sj77iyaMdxAJdh1xK9Ig1kdwL/AJ4uw7MAX4JNazX/Yef7i4NkKOUlBOz5ab6nJs2G+q96IX61lfhg1IegFY34pNrdeMx64cJmKTmGa24iRgeqK8BrFj/2qi3y+SjQuwTrDYn651jR3AZ6KUnEhDzAdew79ypo61qLdfZFhHAD/Cv5KmiqeAadFKS6SBRgMLgJ34V9hYMQAsRCP8RNo2Fxvs4115y8YyNLFHpJAxwOcJ322oDtGHXcnUaciySJamAouw9fG8K/b+YgdwJxrTLxLdVOxeusjKuqljO7Z+3zHJjl5EABuddx3wEv4V/yVsNN+UpEcsIvsYBZwC3A5soLpK/zpwG7ZXn7brypiGAjfHAcAJ2E7Dp2Kz9cZG+t39wDPY7L/FwCPYzkeSOTUAzdUDzMLuyY9pfT8VG/c/ARv3P7712k3Y3ICNre//F3sEuRybP7AcVXgRERERERERERERERERERERERERERERERERERERERERkUpoQZDm6AKOwnYXmgwctsfXw4E3Ydt7M8zXrdhCo2CLgqxrxWvAr4E1wIvAy62vq7CNSyRzagDydCi2/NfxwHHAbOBYdq/wk9o2bMOP5cCzwP+04lcV/X2JRA1AHqYC798jZvqmM6KXsa3Il7TiWWxbMBEJcCDwYeCbwGr8l/4uGmuBb2Nbgb8tagmJNMxbgE8D9wGb8a+8sWMA+DFwDXbbItLxuoGzge+Tx7ZfMeNZ4ItYwyfSUWYDNwGv4l8RvWMDcG654hSpv1HAR4BH8a90dYudwJnFi1akvnqAz2KPzbwrWp1jNfF2MhJxNw64Cvgl/pUrlzi7UEnXRzfW4GdjtHcCDTQauAjr7T7MOZfcnAj8u3cSb+Aw4L3YOIwZ2JZrk4GDsO3WdtWnnVjfxkZsFOUKoLf19bHWz6RhuoA/xEbHeX+S5ho3BZd6WgdiHZQ3E/cWrhe4FTiP6kZvDktXAHG8G/gacJJzHoPASuxkXQO8skf8ChuYAzbOf8+v3dgtSxe2aeikVhyKDeCZDExh96ded6L8VyX6vSFGYbsrnw98FPtkj216K/4E6APuB+4CfgDsSPD3JJEJwEJ8nuFvw54o3Ah8CmuExqU9XMC2IZ+OVY5rgf8CfhPheAawxsVLD3br5nkFtwq4hGreRynpo1Q7THcL9gnxt8Ac7PK0LrqwiUmXYPfw6wk/vvsrz9qMAS7F5jF4Vfyh8WvsfX5TwuOWgn4LG65bxYnwG+Bfsb6FnD4VurHL6H/Apg/v7zhfwMq1aqcAP28jP69YRf5PRhrlTNKP3tuATQL6fexyO3ejgJOxjrR17H2sW1s/r3o48FuAu0n7PsaMH2IzQsXJWOzTbIA0b/AA8DB2L5/TJ32oMcDvARdiVwge8wDmUK/L/XZjPfCxBOUh+3Ec8Axp3tQtwL9Q3/n9TTIKu6/egX9lLhP/TL36fxrt46SZmrsW+BLw1uoOpaP1APfiX3ljxRPAIVFLSPbShVXQ2Jf8a4G/otmX+XUzAViMf6WNHc8BR0YsJ2kZjz3Kivlm9QHXY4NspDqHAEvxr6yp4mXg7dFKSziKuPf7O7Ehn5OrPAgBrCF/Ev9KmjpeQU8IojiWuAN7fgq8p9IjkF3GAP+Jf+WsKp7Hhm1LQe/GRl/FeDM2A1diJ6FUrwtYhH+lrDqWor6lQuYArxPnTViMLse8XYp/ZfSK2yOUX0eZj3XQlS34HcAC7Fmz+DkRG13oXRE948LSpdghPkick2UltkiE+BqPll0bxBYh0cCy/XgPsInyhb2INPPFJdw/4l/56hKPoF2/RnQ8NiCnTAEPYJf8Ug+zyX+Ib+w4v1SJNtQMyi/S+TpwRtWJy4i6sIlUXhXtFWx05zHYkOOJ2DTjO7BxIF55rUFXp3t5K3a/XqZQe9G2VnXzMfwq2QO88ejOU4n3hKlIXNt2KTZcN3ZfVKYwf4IGW9TRj/GpXMtp7xP2I075DWJTiA9uI8fGu5lyBfkYtkim1Ms8/CrXxwPyfNAxzysC8mykz1GuABfjvHSzjMhrll8fYXPyL3bKcxDro8hqs5KYPgBsp3jh/QcdXHg1NwO/SrUsMNeTHXMd5A02X23yyLVDgXsoPiZ/CXAOtvy21M95jn97U+LXx/ZHzn+/cl3A9yjeYv4Ezd2vO89Rf08H5nqiY66D2IjXYc/npl4B/BnFt5t+Dnt8sz5eOhLZO9Fw1xA9wB8M9z+a2ADMBm4o+G9/CZyGrccv9TXXO4EMDVtmTWsAerDx+UX2md+OPdpZHTUjSWGOdwIZOtk7gSp8ieL3SRc55CvhRrHvBiPqA2gvGr1WxUyKT+/9e4d8pZjZ+FekXBuAC4Ym1qRbgH+i2DP7JcDlkXORdNT5V1xjy+48irWIr2H73ks+riLNp+PQWX1Vq2IW4T2VHU2FJlJ8iq/2WsvPLcSvGPub1Ve1VLMIQ29dsvBlihXGrR7JSmk/JG6laHdWX9VSzCJ8tdIjqEAXxbbrfgFN8MnV48StFCGz+qoWexbh1mrTT28KxQriNI9kJYqfEa9ChM7qq1qKWYR7zY3J/SlAkYk+/wb8IHYiUpmYV24vYVu011XorMN27HW7k3sDsJqwy5oNwF8kykWqkfs5623UiP+RoR3YnP12XY097pF8xZxaewT1vgU4NsHv3Jjgd7qaTXuLfjwCHOCUo8QTe8ffOs+Vf4i4x7q92vSr88fYwh0jHXgv1tpL/h4gbqXoBQ6q9AjaczbxOwDXVnoEFXsXcB/Qz+4DfhW4kXq+wVJMip1/H6Rei77Ow/qrYh/nz6o8CC/jsLX7J5N/H4fs6xriV4xB4P+wFXRnUWw6eVlvxvarXES6ocDfrexoRBI5nzSVIyRynQ24z0I5+oSU3KzwTiBjvUN/oAZAcvNTGjiktSJPDP2BGgDJzTbsUaCEeQ34+dAfqgGQHC3xTiBDD2Pb2u9FDYDk6CHvBDI0bJmpAZAcPQys8U4iIwPAd4b7H2oAJEcDwL3eSWRkCSM0mGoAJFd3O/7t0CnJ3isONXItQOlsXcAz+AyoCV1I5E+d8hzEhhSPOMxZVwCSq0FsnoeHAxlhr70ReC479g1sIxWRxhkDrMLnk7XdWYQpZvW1G9uwOTEijfXn+FWw/c0iTDWrr924pe1SFMlUN7Z2nlclGzqLsIpZfe3ERuDwEuUqko25+FW0usaVpUpUJDP341/p6hK9+GxvJuJmCrbklXfl845+YE7JshTJ0hnYKEHvSugZ15QuRZGMfQ3/SugVS9DK19LhxgKP4V8Zq47VqNdfBIBDgF/gXymrivXAO6KUnEhDTAZexL9ypo4twPsjlZlIo7wd2wrOu5KmrPxnRSstkQY6Ct+RgqliHXrcJ9KWNwM/wr/SxopX0D2/SJBxwO34V96y8d+ot1+ksHOwy2fvihwa/cAC9JxfpLQZ2Hbx3pW63ViO7vdFojuLej8q3Ix96mtij0giE4BrscE03hV+V2zDFvPQvb5IRSYAn8eG1HpV/I3AQmxmo4g46AHOBb6LbUKautLvxHbtuRiYWMHxiUibDgY+CdxJ3CuDtcB9wCU4X+Z3ef5xkcxMA96Lrf83vRVHYrcPQzvq+rFL+jXYCj3Pt+JxbJfefTbq9KAGQCSO0ezeAagP68gTERERERGpk/8HhcH2sU3qffYAAAAASUVORK5CYII=";
    updateProfileScreen();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.black,
            ),
            onPressed: () {
              Navigator.of(context).pop();

              //   Navigator.push(context, MaterialPageRoute(builder: (context)=> ProfileScreenPage()));
            },
          ),
          backgroundColor: Colors.white,
          elevation: 1,
          title: RichText(
            text: TextSpan(
                text: DESHI,
                style: TextStyle(
                  fontSize: 30,
                  fontFamily: 'Impact',
                  color: HexColor("#26408A"),
                ),
                children: <TextSpan>[
                  TextSpan(
                      text: TOUR,
                      style: TextStyle(
                        fontSize: 30,
                        fontFamily: 'Impact',
                        color: HexColor("#118ACB"),
                      )),
                ]),
          ),
        ),
        backgroundColor: Colors.white,
        key: _scaffoldKey,
        body: updateProfileScreen(),
      ),
    );
  }

  //
  // FileImage getFileImage(PickedFile imageFile) {
  //   _uploadPhoto(file.pat);
  //   return FileImage(File(imageFile.path));
  // }

  // Widget bottomSheet() {
  //   return ClipRRect(
  //     borderRadius: BorderRadius.circular(25),
  //     child: Container(
  //       height: 100.0,
  //       width: MediaQuery.of(context).size.width,
  //       margin: EdgeInsets.symmetric(
  //         horizontal: 20,
  //         vertical: 20,
  //       ),
  //       child: Column(
  //         children: <Widget>[
  //           Text(
  //             ('choose_profile_photo'),
  //             style: TextStyle(
  //               fontSize: 20.0,
  //             ),
  //           ),
  //           SizedBox(
  //             height: 20,
  //           ),
  //           Row(
  //             mainAxisAlignment: MainAxisAlignment.center,
  //             children: <Widget>[
  //               FlatButton.icon(
  //                 icon: Icon(Icons.camera),
  //                 onPressed: () {
  //                   takePhoto(ImageSource.camera);
  //                   Navigator.pop(context);
  //                 },
  //                 label: Text("Camera"),
  //               ),
  //               FlatButton.icon(
  //                 icon: Icon(Icons.image),
  //                 onPressed: () {
  //                   Navigator.pop(context);
  //                   takePhoto(ImageSource.gallery);
  //                 },
  //                 label: Text("Gallery"),
  //               ),
  //             ],
  //           ),
  //         ],
  //       ),
  //     ),
  //   );
  // }

  Widget updateProfileScreen() {
    return SafeArea(
      child: Form(
        autovalidate: _autoValidate,
        key: _key,
        child: ListView(
          children: <Widget>[
            SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Center(
                  child: Stack(children: <Widget>[
                    // Positioned(
                    //   bottom: 20.0,
                    //   right: 20.0,
                    //   child: InkWell(
                    //     onTap: () {
                    //       showModalBottomSheet(
                    //         context: context,
                    //         builder: ((builder) => bottomSheet()),
                    //       );
                    //     },
                    //     child: Icon(
                    //       Icons.add_a_photo,
                    //       size: 31.0,
                    //     ),
                    //   ),
                    // ),

                    CircleAvatar(
                      radius: 60.0,
                      backgroundColor: Colors.black,
                      child: CircleAvatar(
                        // backgroundColor: Colors.indigo,
                        radius: 57.0,
                        backgroundImage: fileImage == null
                            ? AssetImage("assets/images/person.png")
                            : FileImage(File(fileImage.path)),

                        backgroundColor: Colors.white,
                      ),
                    ),
                    Positioned(
                      bottom: 20.0,
                      right: 5.0,
                      child: InkWell(
                        onTap: () {
                          showModalBottomSheet(
                            context: context,
                            builder: ((builder) => bottomSheet()),
                          );
                        },
                        child: Icon(
                          Icons.add_a_photo,
                          size: 31.0,
                        ),
                      ),
                    ),
                  ]),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
              child: Container(
                decoration: BoxDecoration(
                  color: AppTheme.getTheme().backgroundColor,
                  borderRadius: BorderRadius.all(Radius.circular(38)),
                  // border: Border.all(
                  //   color: HexColor("#757575").withOpacity(0.6),
                  // ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: AppTheme.getTheme().dividerColor,
                      blurRadius: 8,
                      offset: Offset(4, 4),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Container(
                    height: 48,
                    child: Center(
                      child: TextFormField(
                        controller: firstController,
                        validator: (value) {
                          if (value.isEmpty) {
                            return "Please Enter FirstName";
                          }
                          return null;
                        },
                        maxLines: 1,
                        onChanged: (String txt) {},
                        style: TextStyle(
                          fontSize: 16,
                        ),
                        cursorColor: AppTheme.getTheme().primaryColor,
                        decoration: new InputDecoration(
                          errorText: null,
                          border: InputBorder.none,
                          hintText: 'First Name',
                          hintStyle: TextStyle(
                              color: AppTheme.getTheme().disabledColor),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
              child: Container(
                decoration: BoxDecoration(
                  color: AppTheme.getTheme().backgroundColor,
                  borderRadius: BorderRadius.all(Radius.circular(38)),
                  // border: Border.all(
                  //   color: HexColor("#757575").withOpacity(0.6),
                  // ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: AppTheme.getTheme().dividerColor,
                      blurRadius: 8,
                      offset: Offset(4, 4),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Container(
                    height: 48,
                    child: Center(
                      child: TextFormField(
                        controller: lastController,
                        validator: (value) {
                          if (value.isEmpty) {
                            return "Please Enter Last Name";
                          }
                          return null;
                        },
                        maxLines: 1,
                        onChanged: (String txt) {},
                        style: TextStyle(
                          fontSize: 16,
                        ),
                        cursorColor: AppTheme.getTheme().primaryColor,
                        decoration: new InputDecoration(
                          errorText: null,
                          border: InputBorder.none,
                          hintText: 'Last Name',
                          hintStyle: TextStyle(
                              color: AppTheme.getTheme().disabledColor),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
              child: Container(
                decoration: BoxDecoration(
                  color: AppTheme.getTheme().backgroundColor,
                  borderRadius: BorderRadius.all(Radius.circular(38)),
                  // border: Border.all(
                  //   color: HexColor("#757575").withOpacity(0.6),
                  // ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: AppTheme.getTheme().dividerColor,
                      blurRadius: 8,
                      offset: Offset(4, 4),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Container(
                    height: 48,
                    child: Center(
                      child: TextFormField(
                        controller: phoneController,
                        validator: (value) {
                          if (value.isEmpty) {
                            return "Please Enter Phone Number";
                          }
                          return null;
                        },
                        maxLines: 1,
                        onChanged: (String txt) {},
                        style: TextStyle(
                          fontSize: 16,
                        ),
                        cursorColor: AppTheme.getTheme().primaryColor,
                        decoration: new InputDecoration(
                          errorText: null,
                          border: InputBorder.none,
                          hintText: 'Phone Number',
                          hintStyle: TextStyle(
                              color: AppTheme.getTheme().disabledColor),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
              child: Container(
                decoration: BoxDecoration(
                  color: AppTheme.getTheme().backgroundColor,
                  borderRadius: BorderRadius.all(Radius.circular(38)),
                  // border: Border.all(
                  //   color: HexColor("#757575").withOpacity(0.6),
                  // ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: AppTheme.getTheme().dividerColor,
                      blurRadius: 8,
                      offset: Offset(4, 4),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Container(
                    height: 48,
                    child: Center(
                      child: TextFormField(
                        controller: emailController,
                        validator: (value) {
                          if (value.isEmpty) {
                            return "Please Enter Email";
                          }
                          return null;
                        },
                        maxLines: 1,
                        onChanged: (String txt) {},
                        style: TextStyle(
                          fontSize: 16,
                        ),
                        cursorColor: AppTheme.getTheme().primaryColor,
                        decoration: new InputDecoration(
                          errorText: null,
                          border: InputBorder.none,
                          hintText: 'Email',
                          hintStyle: TextStyle(
                              color: AppTheme.getTheme().disabledColor),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
              child: Container(
                decoration: BoxDecoration(
                  color: AppTheme.getTheme().backgroundColor,
                  borderRadius: BorderRadius.all(Radius.circular(38)),
                  // border: Border.all(
                  //   color: HexColor("#757575").withOpacity(0.6),
                  // ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: AppTheme.getTheme().dividerColor,
                      blurRadius: 8,
                      offset: Offset(4, 4),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Container(
                    height: 48,
                    child: Center(
                      child: TextFormField(
                        controller: cityController,
                        maxLines: 1,
                        onChanged: (String txt) {},
                        style: TextStyle(
                          fontSize: 16,
                        ),
                        cursorColor: AppTheme.getTheme().primaryColor,
                        decoration: new InputDecoration(
                          errorText: null,
                          border: InputBorder.none,
                          hintText: 'City',
                          hintStyle: TextStyle(
                              color: AppTheme.getTheme().disabledColor),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
              child: Container(
                decoration: BoxDecoration(
                  color: AppTheme.getTheme().backgroundColor,
                  borderRadius: BorderRadius.all(Radius.circular(38)),
                  // border: Border.all(
                  //   color: HexColor("#757575").withOpacity(0.6),
                  // ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: AppTheme.getTheme().dividerColor,
                      blurRadius: 8,
                      offset: Offset(4, 4),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Container(
                    height: 48,
                    child: Center(
                      child: TextFormField(
                        controller: stateController,
                        maxLines: 1,
                        onChanged: (String txt) {},
                        style: TextStyle(
                          fontSize: 16,
                        ),
                        cursorColor: AppTheme.getTheme().primaryColor,
                        decoration: new InputDecoration(
                          errorText: null,
                          border: InputBorder.none,
                          hintText: 'State',
                          hintStyle: TextStyle(
                              color: AppTheme.getTheme().disabledColor),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            //country 1..
            Padding(
              padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
              child: Container(
                decoration: BoxDecoration(
                  color: AppTheme.getTheme().backgroundColor,
                  borderRadius: BorderRadius.all(Radius.circular(38)),
                  // border: Border.all(
                  //   color: HexColor("#757575").withOpacity(0.6),
                  // ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: AppTheme.getTheme().dividerColor,
                      blurRadius: 8,
                      offset: Offset(4, 4),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Container(
                    height: 48,
                    child: Center(
                      child: TextFormField(
                        controller: countryController,
                        maxLines: 1,
                        onChanged: (String txt) {},
                        style: TextStyle(
                          fontSize: 16,
                        ),
                        cursorColor: AppTheme.getTheme().primaryColor,
                        decoration: new InputDecoration(
                          errorText: null,
                          border: InputBorder.none,
                          hintText: 'Country',
                          hintStyle: TextStyle(
                              color: AppTheme.getTheme().disabledColor),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            // address 1
            Padding(
              padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
              child: Container(
                decoration: BoxDecoration(
                  color: AppTheme.getTheme().backgroundColor,
                  borderRadius: BorderRadius.all(Radius.circular(38)),
                  // border: Border.all(
                  //   color: HexColor("#757575").withOpacity(0.6),
                  // ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: AppTheme.getTheme().dividerColor,
                      blurRadius: 8,
                      offset: Offset(4, 4),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Container(
                    height: 48,
                    child: Center(
                      child: TextFormField(
                        controller: address1Controller,
                        maxLines: 1,
                        onChanged: (String txt) {},
                        style: TextStyle(
                          fontSize: 16,
                        ),
                        cursorColor: AppTheme.getTheme().primaryColor,
                        decoration: new InputDecoration(
                          errorText: null,
                          border: InputBorder.none,
                          hintText: 'Address1',
                          hintStyle: TextStyle(
                              color: AppTheme.getTheme().disabledColor),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
              child: Container(
                decoration: BoxDecoration(
                  color: AppTheme.getTheme().backgroundColor,
                  borderRadius: BorderRadius.all(Radius.circular(38)),
                  // border: Border.all(
                  //   color: HexColor("#757575").withOpacity(0.6),
                  // ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: AppTheme.getTheme().dividerColor,
                      blurRadius: 8,
                      offset: Offset(4, 4),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Container(
                    height: 48,
                    child: Center(
                      child: TextFormField(
                        controller: address2Controller,
                        maxLines: 1,
                        onChanged: (String txt) {},
                        style: TextStyle(
                          fontSize: 16,
                        ),
                        cursorColor: AppTheme.getTheme().primaryColor,
                        decoration: new InputDecoration(
                          errorText: null,
                          border: InputBorder.none,
                          hintText: 'Address2',
                          hintStyle: TextStyle(
                              color: AppTheme.getTheme().disabledColor),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            //FAX
            Padding(
              padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
              child: Container(
                decoration: BoxDecoration(
                  color: AppTheme.getTheme().backgroundColor,
                  borderRadius: BorderRadius.all(Radius.circular(38)),
                  // border: Border.all(
                  //   color: HexColor("#757575").withOpacity(0.6),
                  // ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: AppTheme.getTheme().dividerColor,
                      blurRadius: 8,
                      offset: Offset(4, 4),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Container(
                    height: 48,
                    child: Center(
                      child: TextFormField(
                        controller: faxController,
                        maxLines: 1,
                        onChanged: (String txt) {},
                        style: TextStyle(
                          fontSize: 16,
                        ),
                        cursorColor: AppTheme.getTheme().primaryColor,
                        decoration: new InputDecoration(
                          errorText: null,
                          border: InputBorder.none,
                          hintText: 'FAX',
                          hintStyle: TextStyle(
                              color: AppTheme.getTheme().disabledColor),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            //Zippp

            Padding(
              padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
              child: Container(
                decoration: BoxDecoration(
                  color: AppTheme.getTheme().backgroundColor,
                  borderRadius: BorderRadius.all(Radius.circular(38)),
                  // border: Border.all(
                  //   color: HexColor("#757575").withOpacity(0.6),
                  // ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: AppTheme.getTheme().dividerColor,
                      blurRadius: 8,
                      offset: Offset(4, 4),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Container(
                    height: 48,
                    child: Center(
                      child: TextFormField(
                        controller: zipController,
                        maxLines: 1,
                        onChanged: (String txt) {},
                        style: TextStyle(
                          fontSize: 16,
                        ),
                        cursorColor: AppTheme.getTheme().primaryColor,
                        decoration: new InputDecoration(
                          errorText: null,
                          border: InputBorder.none,
                          hintText: 'Postal Code',
                          hintStyle: TextStyle(
                              color: AppTheme.getTheme().disabledColor),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),

            //Passowrd

            Padding(
              padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
              child: Container(
                decoration: BoxDecoration(
                  color: AppTheme.getTheme().backgroundColor,
                  borderRadius: BorderRadius.all(Radius.circular(38)),
                  // border: Border.all(
                  //   color: HexColor("#757575").withOpacity(0.6),
                  // ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: AppTheme.getTheme().dividerColor,
                      blurRadius: 8,
                      offset: Offset(4, 4),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Container(
                    height: 48,
                    child: Center(
                      child: TextFormField(
                        controller: passwordController,
                        maxLines: 1,
                        onChanged: (String txt) {},
                        style: TextStyle(
                          fontSize: 16,
                        ),
                        cursorColor: AppTheme.getTheme().primaryColor,
                        decoration: new InputDecoration(
                          errorText: null,
                          border: InputBorder.none,
                          hintText: 'Password',
                          hintStyle: TextStyle(
                              color: AppTheme.getTheme().disabledColor),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),

            //  Confirm  //Passowrd

            Padding(
              padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
              child: Container(
                decoration: BoxDecoration(
                  color: AppTheme.getTheme().backgroundColor,
                  borderRadius: BorderRadius.all(Radius.circular(38)),
                  // border: Border.all(
                  //   color: HexColor("#757575").withOpacity(0.6),
                  // ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                      color: AppTheme.getTheme().dividerColor,
                      blurRadius: 8,
                      offset: Offset(4, 4),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Container(
                    height: 48,
                    child: Center(
                      child: TextFormField(
                        controller: confirmPasswordController,
                        maxLines: 1,
                        onChanged: (String txt) {},
                        style: TextStyle(
                          fontSize: 16,
                        ),
                        cursorColor: AppTheme.getTheme().primaryColor,
                        decoration: new InputDecoration(
                          errorText: null,
                          border: InputBorder.none,
                          hintText: 'Confirm Password',
                          hintStyle: TextStyle(
                              color: AppTheme.getTheme().disabledColor),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 50, right: 50, bottom: 30),
              child: Container(
                height: 45,
                width: 230,
                child: isLoading
                    ? Center(
                        child: CircularProgressIndicator(
                          valueColor:
                              AlwaysStoppedAnimation(Colors.indigo[800]),
                        ),
                      )
                    : RaisedButton(
                        onPressed: () {
                          asyncFileUpload();
                          if (_key.currentState.validate()) {
                            updateProfile();
                          } else {
                            setState(() {
                              _autoValidate = true;
                            });
                          }
                        },
                        color: HexColor("#6fbe44"),
                        child: Text(
                          "Update",
                          style: TextStyle(fontSize: 15, color: Colors.white),
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget bottomSheet() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(25),
      child: Container(
        height: 100.0,
        width: MediaQuery.of(context).size.width,
        margin: EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 20,
        ),
        child: Column(
          children: <Widget>[
            Text(
              ('Choose Profile Photo'),
              style: TextStyle(
                fontSize: 20.0,
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                FlatButton.icon(
                  icon: Icon(Icons.camera),
                  onPressed: () {
                    takePhoto(ImageSource.camera);
                    Navigator.pop(context);
                  },
                  label: Text("Camera"),
                ),
                FlatButton.icon(
                  icon: Icon(Icons.image),
                  onPressed: () {
                    Navigator.pop(context);
                    takePhoto(ImageSource.gallery);
                  },
                  label: Text("Gallery"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

//
//
// // import 'dart:convert';
// // import 'dart:io';
// // import 'dart:math';
// // import 'package:flutter/material.dart';
// // import 'package:fluttertoast/fluttertoast.dart';
// // import 'package:http/http.dart' as http;
// // import 'package:image_picker/image_picker.dart';
// // import 'package:intl/intl.dart';
// // import 'package:new_motel/global/global_data.dart';
// // import 'package:new_motel/model/profile_model.dart';
// // import 'package:new_motel/utils/constants.dart';
// // import 'package:shared_preferences/shared_preferences.dart';
// //
// // import '../../appTheme.dart';
// //
// // class ProfileUpdatePage extends StatefulWidget {
// //   // final ProfileData profileData;
// //   final String firstName;
// //   final String id;
// //   final String lastName;
// //   final String city;
// //   final String state;
// //   final String country;
// //   final String address1;
// //   final String address2;
// //   final String phone;
// //   final String fax;
// //   final String zip;
// //   final String photo;
// //   final String email;
// //   final String password;
// //
// //   const ProfileUpdatePage(
// //       {Key key,
// //       this.id,
// //       this.firstName,
// //       this.lastName,
// //       this.city,
// //       this.state,
// //       this.country,
// //       this.address1,
// //       this.address2,
// //       this.phone,
// //       this.fax,
// //       this.zip,
// //       this.photo,
// //       this.email,
// //       this.password})
// //       : super(key: key);
// //
// //   // final int index;
// //
// //   @override
// //   _ProfileUpdatePageState createState() => _ProfileUpdatePageState();
// // }
// //
// // class _ProfileUpdatePageState extends State<ProfileUpdatePage> {
// //   final _key = GlobalKey<FormState>();
// //   final firstController = TextEditingController();
// //   final lastController = TextEditingController();
// //   final cityController = TextEditingController();
// //   final stateController = TextEditingController();
// //   final countryController = TextEditingController();
// //   final address1Controller = TextEditingController();
// //   final address2Controller = TextEditingController();
// //   final phoneController = TextEditingController();
// //   final faxController = TextEditingController();
// //   final zipController = TextEditingController();
// //   final emailController = TextEditingController();
// //   final passwordController = TextEditingController();
// //
// //   DateTime date = DateTime.now();
// //   Map<String, dynamic> data;
// //   final ImagePicker _picker = ImagePicker();
// //   // image Upload.....
// //   PickedFile _imageFile;
// //   void takePhoto(ImageSource source) async {
// //     final pickedFile = await _picker.getImage(
// //       source: source,
// //     );
// //     setState(() {
// //       _imageFile = pickedFile;
// //     });
// //   }
// //
// //   final _scaffoldKey = GlobalKey<ScaffoldState>();
// //
// //   _showMsg(msg) {
// //     final snackBar = SnackBar(content: Text(msg));
// //     _scaffoldKey.currentState.showSnackBar(snackBar);
// //   }
// //
// //   // gallery() async {
// //   //   // ignore: deprecated_member_use
// //   //   var _image = await ImagePicker.pickImage(source: ImageSource.gallery);
// //   //   setState(() {
// //   //     image = _image;
// //   //   });
// //   // }
// //
// //   bool isLoading = false;
// //
// //   // updateProfile() async {
// //   //   final form = _key.currentState;
// //   //   if (form.validate()) {
// //   //     setState(() {
// //   //       isLoading = true;
// //   //     });
// //   //     form.save();
// //   //     await update();
// //   //   } else {
// //   //     setState(() {
// //   //       isLoading = false;
// //   //     });
// //   //   }
// //   // }
// //
// //   update() async {
// //     // SharedPreferences _preference = await SharedPreferences.getInstance();
// //     // String id = _preference.getString('id');
// //
// //     var body = {
// //       'id': '',
// //       "firstname": firstController.text,
// //       "lastname": lastController.text,
// //       "city": cityController.text,
// //       "state": stateController.text,
// //       "country": countryController.text,
// //       "address1": address1Controller.text,
// //       "address2": address2Controller.text,
// //       "phone": phoneController.text,
// //       "fax": faxController.text,
// //       "zip": zipController.text,
// //       "photo": _imageFile,
// //       "email": emailController.text,
// //       "password": passwordController.text,
// //     };
// //     final jsonString = json.encode(body);
// //     print("JSonEncoded.....>>>>$jsonString");
// //     // final headers = {HttpHeaders.contentTypeHeader: 'application/json'};
// //
// //     var response = await http.post(
// //       "https://deshitour.com/api/login/updateprofile?appKey=DeshiTour",
// //       body: body,
// //     );
// //     if (response.statusCode == 200) {
// //       var data = json.decode(response.body);
// //       print("AAAA${response.body}");
// //       print("BBB${data}");
// //       if (data != null) {
// //         setState(() {
// //           firstController.text = widget.firstName;
// //           lastController.text = widget.lastName;
// //           cityController.text = widget.city;
// //           stateController.text = widget.state;
// //           countryController.text = widget.country;
// //           address1Controller.text = widget.address1;
// //           address2Controller.text = widget.address2;
// //           phoneController.text = widget.phone;
// //           faxController.text = widget.fax;
// //           zipController.text = widget.zip;
// //           // "Photo" = PHOTO_G;
// //           emailController.text = widget.email;
// //           passwordController.text = widget.password;
// //         });
// //         Fluttertoast.showToast(
// //             msg: ('  Profile Update Successfully'),
// //             toastLength: Toast.LENGTH_SHORT,
// //             gravity: ToastGravity.BOTTOM,
// //             timeInSecForIosWeb: 2,
// //             backgroundColor: Colors.indigo[800],
// //             textColor: Colors.white,
// //             fontSize: 16.0);
// //         Navigator.of(context).pop();
// //       } else {}
// //     }
// //
// //     //  print(jsonString);
// //     //
// //     // if (data != null) {
// //     //   setState(() {
// //     //     Fluttertoast.showToast(
// //     //         msg: "Profile Update SuccessFully",
// //     //         toastLength: Toast.LENGTH_SHORT,
// //     //         gravity: ToastGravity.BOTTOM,
// //     //         timeInSecForIosWeb: 2,
// //     //         backgroundColor: Colors.purple,
// //     //         textColor: Colors.white,
// //     //         fontSize: 16.0);
// //     //     Navigator.pop(context, true);
// //     //   });
// //     // } else {
// //     //   setState(() {
// //     //     isLoading = false;
// //     //   });
// //     //
// //     //   _showMsg(data["errors"]["msg"]).toString();
// //     // }
// //   }
// //
// //   @override
// //   void initState() {
// //     print("Update Name: ${widget.firstName}");
// //     firstController.text = widget.firstName;
// //     lastController.text = widget.lastName;
// //     cityController.text = widget.city;
// //     stateController.text = widget.state;
// //     countryController.text = widget.country;
// //     address1Controller.text = widget.address1;
// //     address2Controller.text = widget.address2;
// //     phoneController.text = widget.phone;
// //     faxController.text = widget.fax;
// //     zipController.text = widget.zip;
// //     // "Photo" = PHOTO_G;
// //     emailController.text = widget.email;
// //     passwordController.text = widget.password;
// //     // dobController.text = DOB;
// //
// //     super.initState();
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     Widget bottomSheet() {
// //       return ClipRRect(
// //         borderRadius: BorderRadius.circular(25),
// //         child: Container(
// //           height: 100.0,
// //           width: MediaQuery.of(context).size.width,
// //           margin: EdgeInsets.symmetric(
// //             horizontal: 20,
// //             vertical: 20,
// //           ),
// //           child: Column(
// //             children: <Widget>[
// //               Text(
// //                 ('choose_profile_photo'),
// //                 style: TextStyle(
// //                   fontSize: 20.0,
// //                 ),
// //               ),
// //               SizedBox(
// //                 height: 20,
// //               ),
// //               Row(
// //                 mainAxisAlignment: MainAxisAlignment.center,
// //                 children: <Widget>[
// //                   FlatButton.icon(
// //                     icon: Icon(Icons.camera),
// //                     onPressed: () {
// //                       takePhoto(ImageSource.camera);
// //                       Navigator.pop(context);
// //                     },
// //                     label: Text("Camera"),
// //                   ),
// //                   FlatButton.icon(
// //                     icon: Icon(Icons.image),
// //                     onPressed: () {
// //                       Navigator.pop(context);
// //                       takePhoto(ImageSource.gallery);
// //                     },
// //                     label: Text("Gallery"),
// //                   ),
// //                 ],
// //               ),
// //             ],
// //           ),
// //         ),
// //       );
// //     }
// //
// //     return Scaffold(
// //       appBar: AppBar(
// //         leading: IconButton(
// //           icon: Icon(
// //             Icons.arrow_back,
// //             color: Colors.black,
// //           ),
// //           onPressed: () {
// //             Navigator.pop(context);
// //           },
// //         ),
// //         backgroundColor: Colors.white,
// //         elevation: 1,
// //         title: Text(
// //           "Update Profile",
// //           style: TextStyle(fontSize: 20, color: Colors.black),
// //         ),
// //       ),
// //       backgroundColor: Colors.transparent,
// //       body: SafeArea(
// //         child: Form(
// //           child: SingleChildScrollView(
// //             child: Column(
// //               children: [
// //                 SizedBox(
// //                   height: 40,
// //                 ),
// //                 Row(
// //                   mainAxisAlignment: MainAxisAlignment.center,
// //                   children: [
// //                     Center(
// //                       child: Stack(children: <Widget>[
// //                         CircleAvatar(
// //                           backgroundColor: Colors.indigo,
// //                           radius: 80.0,
// //                           backgroundImage: _imageFile == null
// //                               ? (widget.photo == null
// //                                   ? AssetImage("assets/images/deshiTour.png")
// //                                   : NetworkImage(widget.photo))
// //                               : FileImage(File(_imageFile.path)),
// //                         ),
// //                         Positioned(
// //                           bottom: 20.0,
// //                           right: 20.0,
// //                           child: InkWell(
// //                             onTap: () {
// //                               showModalBottomSheet(
// //                                 context: context,
// //                                 builder: ((builder) => bottomSheet()),
// //                               );
// //                             },
// //                             child: Icon(
// //                               Icons.add_a_photo,
// //                               size: 31.0,
// //                             ),
// //                           ),
// //                         ),
// //                       ]),
// //                     ),
// //                   ],
// //                 ),
// //
// //                 // FirstName Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: firstController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter FirstName";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'First Name',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // LastName Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: lastController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter LastName";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Last Name',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // City Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: cityController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter City";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'City',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // State Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: stateController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter City";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'State',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Country Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: countryController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter Country";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Country',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Address1 Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: address1Controller,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter Address1";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Address1',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Address2 Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: address2Controller,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter  Address2";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'City',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Phone Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: phoneController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter Phone";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Phone',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Fax Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: faxController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter Fax";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Fax',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Zip Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: zipController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter Zip";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Zip',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Email Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: emailController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter Email";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Email',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Password Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: passwordController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter Password";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Password',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 SizedBox(
// //                   height: 30,
// //                 ),
// //
// //                 // Update Button
// //                 Padding(
// //                   padding: const EdgeInsets.only(
// //                       left: 24, right: 24, bottom: 8, top: 16),
// //                   child: Container(
// //                     height: 45,
// //                     width: 230,
// //                     child: RaisedButton(
// //                       onPressed: () {
// //                         update();
// //                       },
// //                       color: AppTheme.getTheme().primaryColor,
// //                       child: Text(
// //                         "Update",
// //                         style: TextStyle(fontSize: 15, color: Colors.white),
// //                       ),
// //                       shape: RoundedRectangleBorder(
// //                         borderRadius: BorderRadius.circular(20),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Padding(
// //                 //   padding: const EdgeInsets.only(
// //                 //       left: 24, right: 24, bottom: 8, top: 16),
// //                 //   child: Container(
// //                 //     height: 48,
// //                 //     decoration: BoxDecoration(
// //                 //       color: AppTheme.getTheme().primaryColor,
// //                 //       borderRadius:
// //                 //       BorderRadius.all(Radius.circular(24.0)),
// //                 //       boxShadow: <BoxShadow>[
// //                 //         BoxShadow(
// //                 //           color: AppTheme.getTheme().dividerColor,
// //                 //           blurRadius: 8,
// //                 //           offset: Offset(4, 4),
// //                 //         ),
// //                 //       ],
// //                 //     ),
// //                 //     child: Material(
// //                 //       color: Colors.transparent,
// //                 //       child: InkWell(
// //                 //         borderRadius:
// //                 //         BorderRadius.all(Radius.circular(24.0)),
// //                 //         highlightColor: Colors.transparent,
// //                 //         onTap: () {
// //                 //           Navigator.pop(context);
// //                 //         },
// //                 //         child: Center(
// //                 //           child: Text(
// //                 //             APPLY,
// //                 //             style: TextStyle(
// //                 //                 fontWeight: FontWeight.w500,
// //                 //                 fontSize: 16,
// //                 //                 color: Colors.white),
// //                 //           ),
// //                 //         ),
// //                 //       ),
// //                 //     ),
// //                 //   ),
// //                 // ),
// //               ],
// //             ),
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// // }
// //
// //
// //
// //
// //
// //
// // // 2nd importn part
// // import 'dart:convert';
// // import 'dart:io';
// //
// // import 'package:flutter/material.dart';
// // import 'package:fluttertoast/fluttertoast.dart';
// // import 'package:http/http.dart' as http;
// // import 'package:image_picker/image_picker.dart';
// // import 'package:new_motel/appTheme.dart';
// // import 'package:new_motel/utils/constants.dart';
// // import 'package:shared_preferences/shared_preferences.dart';
// //
// // class ProfileUpdateScreen extends StatefulWidget {
// //   final String id;
// //   final String firstName;
// //   final String lastName;
// //   final String city;
// //   final String state;
// //   final String country;
// //   final String address1;
// //   final String address2;
// //   final String phone;
// //   final String fax;
// //   final String zip;
// //   final String photo;
// //   final String email;
// //   final String password;
// //   final String confirmPassword;
// //
// //   const ProfileUpdateScreen({
// //     Key key,
// //     this.id,
// //     this.firstName,
// //     this.lastName,
// //     this.city,
// //     this.state,
// //     this.country,
// //     this.address1,
// //     this.address2,
// //     this.phone,
// //     this.fax,
// //     this.zip,
// //     this.photo,
// //     this.email,
// //     this.password,
// //     this.confirmPassword,
// //   }) : super(key: key);
// //   @override
// //   _ProfileUpdateScreenState createState() => _ProfileUpdateScreenState();
// // }
// //
// // class _ProfileUpdateScreenState extends State<ProfileUpdateScreen> {
// //   final _key = GlobalKey<FormState>();
// //   // final nameController = TextEditingController();
// //   // final emailController = TextEditingController();
// //   // final phoneController = TextEditingController();
// //   // final upazilaController = TextEditingController();
// //   // final dobController = TextEditingController();
// //   // final occuptionController = TextEditingController();
// //   // final imageController = TextEditingController();
// //   // final educationController = TextEditingController();
// //   // final addressController = TextEditingController();
// //   // Map<String, dynamic> data;
// //   String pMessage = '';
// //   bool success = false;
// //   final ImagePicker _picker = ImagePicker();
// //   // image Upload.....
// //   PickedFile _imageFile;
// //   void takePhoto(ImageSource source) async {
// //     final pickedFile = await _picker.getImage(
// //       source: source,
// //     );
// //     setState(() {
// //       _imageFile = pickedFile;
// //     });
// //   }
// //
// //   File image;
// //   final firstController = TextEditingController();
// //   final lastController = TextEditingController();
// //   final cityController = TextEditingController();
// //   final stateController = TextEditingController();
// //   final countryController = TextEditingController();
// //   final address1Controller = TextEditingController();
// //   final address2Controller = TextEditingController();
// //   final phoneController = TextEditingController();
// //   final faxController = TextEditingController();
// //   final zipController = TextEditingController();
// //   final emailController = TextEditingController();
// //   final passwordController = TextEditingController();
// //   final confirmPasswordController = TextEditingController();
// //
// //   final _scaffoldKey = GlobalKey<ScaffoldState>();
// //   _showMsg(msg) {
// //     final snackBar = SnackBar(content: Text(msg));
// //     _scaffoldKey.currentState.showSnackBar(snackBar);
// //   }
// //
// //   bool isLoading = false;
// //   bool _autoValidate = false;
// //
// //   File file;
// // //
// // //   void _choose() async {
// // //     file = await ImagePicker.pickImage(source: ImageSource.camera);
// // // // file = await ImagePicker.pickImage(source: ImageSource.gallery);
// // //   }
// //
// //   void _upload() {
// //     if (file == null) return;
// //     String base64Image = base64Encode(file.readAsBytesSync());
// //     String id;
// //
// //     http.post("https://deshitour.com//api/login/updatephoto?appKey=DeshiTour",
// //         body: {
// //           "id": id,
// //           "user_photo": base64Image,
// //         }).then((res) {
// //       print(res.statusCode);
// //       if (res.statusCode == 200) {
// //         return base64.decode(base64Image);
// //       }
// //     }).catchError((err) {
// //       print(err);
// //     });
// //   }
// //
// //   // gallery() async {
// //   //   // ignore: deprecated_member_use
// //   //   var image2 = await ImagePicker.pickImage(source: ImageSource.gallery);
// //   //   setState(() {
// //   //     image = image2;
// //   //   });
// //   // }
// //
// //   updateProfile() async {
// //     final form = _key.currentState;
// //     if (form.validate()) {
// //       setState(() {
// //         isLoading = true;
// //       });
// //       form.save();
// //       update();
// //     } else {
// //       setState(() {
// //         isLoading = false;
// //       });
// //     }
// //   }
// //
// //   update() async {
// //     SharedPreferences _preference = await SharedPreferences.getInstance();
// //     String id = _preference.getString('id');
// //
// //     /*   var uri = Uri.parse("http://uat.gagro.com.bd/api/profile");
// //     var request = http.MultipartRequest('POST', uri)
// //       ..fields['name'] = nameController.text
// //       ..fields['email'] = emailController.text
// //       ..fields['phone'] = phoneController.text
// //       ..fields['dob'] = dobController.text
// //       ..fields['upazila_id'] = upazilaController.text
// //       ..fields['address'] = addressController.text
// //       ..fields['occupation'] = occuptionController.text
// //       ..fields['education'] = educationController.text;
// //       /*
// //       ..files.add(await http.MultipartFile.fromPath(
// //           'package', 'build/package.tar.gz',
// //           contentType: MediaType('application', 'x-tar')));*/
// //     var response = await request.send()
// //    if (response.statusCode == 200) print('Uploaded!');*/
// //     var response = await http.post(
// //       "https://deshitour.com/api/login/updateprofile?appKey=DeshiTour",
// //       body: {
// //         'id': id,
// //         "firstname": firstController.text,
// //         "lastname": lastController.text,
// //         "city": cityController.text,
// //         "state": stateController.text,
// //         "country": countryController.text,
// //         "address1": address1Controller.text,
// //         "address2": address2Controller.text,
// //         "phone": phoneController.text,
// //         "fax": faxController.text,
// //         "zip": zipController.text,
// //         "photo": '',
// //         "email": emailController.text,
// //         "password": passwordController.text,
// //         "confirm_password": confirmPasswordController.text,
// //       },
// //       headers: {
// //         "Accept": "application/json",
// //       },
// //     );
// //     var errorMsg = json.decode(response.body)['msg'];
// //     print(errorMsg);
// //     if (response.statusCode == 200) {
// //       var data = json.decode(response.body)['status'];
// //       if (data == 1) {
// //         setState(() {
// //           isLoading = true;
// //         });
// //         Fluttertoast.showToast(
// //             msg: "Successfully Done",
// //             toastLength: Toast.LENGTH_SHORT,
// //             gravity: ToastGravity.BOTTOM,
// //             timeInSecForIosWeb: 2,
// //             backgroundColor: Colors.indigo,
// //             textColor: Colors.white,
// //             fontSize: 16.0);
// //         setState(() {});
// //         Navigator.pop(context);
// //       } else {
// //         setState(() {
// //           isLoading = false;
// //         });
// //         Fluttertoast.showToast(
// //             msg: errorMsg,
// //             toastLength: Toast.LENGTH_SHORT,
// //             gravity: ToastGravity.BOTTOM,
// //             timeInSecForIosWeb: 2,
// //             backgroundColor: Colors.indigo,
// //             textColor: Colors.white,
// //             fontSize: 16.0);
// //         // setState(() {});
// //       }
// //     }
// //
// //     // if (data != null) {
// //     //   setState(() {
// //     //     Fluttertoast.showToast(
// //     //         msg: pMessage,
// //     //         toastLength: Toast.LENGTH_SHORT,
// //     //         gravity: ToastGravity.BOTTOM,
// //     //         timeInSecForIosWeb: 2,
// //     //         backgroundColor: Colors.indigo[800],
// //     //         textColor: Colors.white,
// //     //         fontSize: 16.0);
// //     //     Navigator.push(context,
// //     //         MaterialPageRoute(builder: (context) => ProfileScreenPage()));
// //     //     print(pMessage);
// //     //   });
// //     // } else {
// //     //   setState(() {
// //     //     isLoading = false;
// //     //   });
// //     //
// //     //   //  _showMsg(data["errors"]["msg"]).toString();
// //     // }
// //   }
// //
// //   @override
// //   void initState() {
// //     updateProfile();
// //     firstController.text = widget.firstName;
// //     lastController.text = widget.lastName;
// //     cityController.text = widget.city;
// //     stateController.text = widget.state;
// //     countryController.text = widget.country;
// //     address1Controller.text = widget.address1;
// //     address2Controller.text = widget.address2;
// //     phoneController.text = widget.phone;
// //     faxController.text = widget.fax;
// //     zipController.text = widget.zip;
// //     //file = image.path;
// //     emailController.text = widget.email;
// //     //  passwordController.text = widget.password;
// //     super.initState();
// //     setState(() {});
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     Widget bottomSheet() {
// //       return ClipRRect(
// //         borderRadius: BorderRadius.circular(25),
// //         child: Container(
// //           height: 100.0,
// //           width: MediaQuery.of(context).size.width,
// //           margin: EdgeInsets.symmetric(
// //             horizontal: 20,
// //             vertical: 20,
// //           ),
// //           child: Column(
// //             children: <Widget>[
// //               Text(
// //                 ('choose_profile_photo'),
// //                 style: TextStyle(
// //                   fontSize: 20.0,
// //                 ),
// //               ),
// //               SizedBox(
// //                 height: 20,
// //               ),
// //               Row(
// //                 mainAxisAlignment: MainAxisAlignment.center,
// //                 children: <Widget>[
// //                   FlatButton.icon(
// //                     icon: Icon(Icons.camera),
// //                     onPressed: () {
// //                       takePhoto(ImageSource.camera);
// //                       Navigator.pop(context);
// //                     },
// //                     label: Text("Camera"),
// //                   ),
// //                   FlatButton.icon(
// //                     icon: Icon(Icons.image),
// //                     onPressed: () {
// //                       Navigator.pop(context);
// //                       takePhoto(ImageSource.gallery);
// //                     },
// //                     label: Text("Gallery"),
// //                   ),
// //                 ],
// //               ),
// //             ],
// //           ),
// //         ),
// //       );
// //     }
// //
// //     return SafeArea(
// //       child: Scaffold(
// //         appBar: AppBar(
// //           leading: IconButton(
// //             icon: Icon(
// //               Icons.arrow_back,
// //               color: Colors.black,
// //             ),
// //             onPressed: () {
// //               Navigator.of(context).pop();
// //             },
// //           ),
// //           backgroundColor: Colors.white,
// //           elevation: 1,
// //           title: RichText(
// //             text: TextSpan(
// //                 text: DESHI,
// //                 style: TextStyle(
// //                   fontSize: 30,
// //                   fontFamily: 'Impact',
// //                   color: HexColor("#26408A"),
// //                 ),
// //                 children: <TextSpan>[
// //                   TextSpan(
// //                       text: TOUR,
// //                       style: TextStyle(
// //                         fontSize: 30,
// //                         fontFamily: 'Impact',
// //                         color: HexColor("#118ACB"),
// //                       )),
// //                 ]),
// //           ),
// //         ),
// //         backgroundColor: Colors.white,
// //         key: _scaffoldKey,
// //         body: SafeArea(
// //           child: Form(
// //             autovalidate: _autoValidate,
// //             key: _key,
// //             child: ListView(
// //               children: <Widget>[
// //                 SizedBox(
// //                   height: 20,
// //                 ),
// //                 Row(
// //                   mainAxisAlignment: MainAxisAlignment.center,
// //                   children: [
// //                     Center(
// //                       child: Stack(children: <Widget>[
// //                         CircleAvatar(
// //                           // backgroundColor: Colors.indigo,
// //                           radius: 80.0,
// //                           backgroundImage: _imageFile == null
// //                               ? (widget.photo == null
// //                                   ? AssetImage("assets/images/person.png")
// //                                   : NetworkImage(widget.photo))
// //                               : FileImage(File(_imageFile.path)),
// //                         ),
// //                         Positioned(
// //                           bottom: 20.0,
// //                           right: 20.0,
// //                           child: InkWell(
// //                             onTap: () {
// //                               showModalBottomSheet(
// //                                 context: context,
// //                                 builder: ((builder) => bottomSheet()),
// //                               );
// //                             },
// //                             child: Icon(
// //                               Icons.add_a_photo,
// //                               size: 31.0,
// //                             ),
// //                           ),
// //                         ),
// //                       ]),
// //                     ),
// //                   ],
// //                 ),
// //                 SizedBox(
// //                   height: 20,
// //                 ),
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: firstController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter FirstName";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'First Name',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: lastController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter Last Name";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Last Name',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: phoneController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter Phone Number";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Phone Number',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: emailController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter Email";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Email',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: cityController,
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'City',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: stateController,
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'State',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //                 //country 1..
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: countryController,
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Country',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //                 // address 1
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: address1Controller,
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Address1',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: address2Controller,
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Address2',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //                 //FAX
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: faxController,
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'FAX',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //                 //Zippp
// //
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: zipController,
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Postal Code',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 //Passowrd
// //
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: passwordController,
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Password',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 //  Confirm  //Passowrd
// //
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: confirmPasswordController,
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Confirm Password',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //                 SizedBox(
// //                   height: 30,
// //                 ),
// //                 Padding(
// //                   padding:
// //                       const EdgeInsets.only(left: 50, right: 50, bottom: 30),
// //                   child: Container(
// //                     height: 45,
// //                     width: 230,
// //                     child: isLoading
// //                         ? Center(
// //                             child: CircularProgressIndicator(
// //                               valueColor:
// //                                   AlwaysStoppedAnimation(Colors.indigo[800]),
// //                             ),
// //                           )
// //                         : RaisedButton(
// //                             onPressed: () {
// //                               if (_key.currentState.validate()) {
// //                                 setState(() {
// //                                   updateProfile();
// //                                 });
// //                               } else {
// //                                 setState(() {
// //                                   _autoValidate = true;
// //                                 });
// //                               }
// //                             },
// //                             color: Colors.indigo[800],
// //                             child: Text(
// //                               "Update",
// //                               style:
// //                                   TextStyle(fontSize: 15, color: Colors.white),
// //                             ),
// //                             shape: RoundedRectangleBorder(
// //                               borderRadius: BorderRadius.circular(20),
// //                             ),
// //                           ),
// //                   ),
// //                 ),
// //               ],
// //             ),
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// // }
// // import 'dart:convert';
// // import 'dart:io';
// // import 'dart:math';
// // import 'package:flutter/material.dart';
// // import 'package:fluttertoast/fluttertoast.dart';
// // import 'package:http/http.dart' as http;
// // import 'package:image_picker/image_picker.dart';
// // import 'package:intl/intl.dart';
// // import 'package:new_motel/global/global_data.dart';
// // import 'package:new_motel/model/profile_model.dart';
// // import 'package:new_motel/utils/constants.dart';
// // import 'package:shared_preferences/shared_preferences.dart';
// //
// // import '../../appTheme.dart';
// //
// // class ProfileUpdatePage extends StatefulWidget {
// //   // final ProfileData profileData;
// //   final String firstName;
// //   final String id;
// //   final String lastName;
// //   final String city;
// //   final String state;
// //   final String country;
// //   final String address1;
// //   final String address2;
// //   final String phone;
// //   final String fax;
// //   final String zip;
// //   final String photo;
// //   final String email;
// //   final String password;
// //
// //   const ProfileUpdatePage(
// //       {Key key,
// //       this.id,
// //       this.firstName,
// //       this.lastName,
// //       this.city,
// //       this.state,
// //       this.country,
// //       this.address1,
// //       this.address2,
// //       this.phone,
// //       this.fax,
// //       this.zip,
// //       this.photo,
// //       this.email,
// //       this.password})
// //       : super(key: key);
// //
// //   // final int index;
// //
// //   @override
// //   _ProfileUpdatePageState createState() => _ProfileUpdatePageState();
// // }
// //
// // class _ProfileUpdatePageState extends State<ProfileUpdatePage> {
// //   final _key = GlobalKey<FormState>();
// //   final firstController = TextEditingController();
// //   final lastController = TextEditingController();
// //   final cityController = TextEditingController();
// //   final stateController = TextEditingController();
// //   final countryController = TextEditingController();
// //   final address1Controller = TextEditingController();
// //   final address2Controller = TextEditingController();
// //   final phoneController = TextEditingController();
// //   final faxController = TextEditingController();
// //   final zipController = TextEditingController();
// //   final emailController = TextEditingController();
// //   final passwordController = TextEditingController();
// //
// //   DateTime date = DateTime.now();
// //   Map<String, dynamic> data;
// //   final ImagePicker _picker = ImagePicker();
// //   // image Upload.....
// //   PickedFile _imageFile;
// //   void takePhoto(ImageSource source) async {
// //     final pickedFile = await _picker.getImage(
// //       source: source,
// //     );
// //     setState(() {
// //       _imageFile = pickedFile;
// //     });
// //   }
// //
// //   final _scaffoldKey = GlobalKey<ScaffoldState>();
// //
// //   _showMsg(msg) {
// //     final snackBar = SnackBar(content: Text(msg));
// //     _scaffoldKey.currentState.showSnackBar(snackBar);
// //   }
// //
// //   // gallery() async {
// //   //   // ignore: deprecated_member_use
// //   //   var _image = await ImagePicker.pickImage(source: ImageSource.gallery);
// //   //   setState(() {
// //   //     image = _image;
// //   //   });
// //   // }
// //
// //   bool isLoading = false;
// //
// //   // updateProfile() async {
// //   //   final form = _key.currentState;
// //   //   if (form.validate()) {
// //   //     setState(() {
// //   //       isLoading = true;
// //   //     });
// //   //     form.save();
// //   //     await update();
// //   //   } else {
// //   //     setState(() {
// //   //       isLoading = false;
// //   //     });
// //   //   }
// //   // }
// //
// //   update() async {
// //     // SharedPreferences _preference = await SharedPreferences.getInstance();
// //     // String id = _preference.getString('id');
// //
// //     var body = {
// //       'id': '',
// //       "firstname": firstController.text,
// //       "lastname": lastController.text,
// //       "city": cityController.text,
// //       "state": stateController.text,
// //       "country": countryController.text,
// //       "address1": address1Controller.text,
// //       "address2": address2Controller.text,
// //       "phone": phoneController.text,
// //       "fax": faxController.text,
// //       "zip": zipController.text,
// //       "photo": _imageFile,
// //       "email": emailController.text,
// //       "password": passwordController.text,
// //     };
// //     final jsonString = json.encode(body);
// //     print("JSonEncoded.....>>>>$jsonString");
// //     // final headers = {HttpHeaders.contentTypeHeader: 'application/json'};
// //
// //     var response = await http.post(
// //       "https://deshitour.com/api/login/updateprofile?appKey=DeshiTour",
// //       body: body,
// //     );
// //     if (response.statusCode == 200) {
// //       var data = json.decode(response.body);
// //       print("AAAA${response.body}");
// //       print("BBB${data}");
// //       if (data != null) {
// //         setState(() {
// //           firstController.text = widget.firstName;
// //           lastController.text = widget.lastName;
// //           cityController.text = widget.city;
// //           stateController.text = widget.state;
// //           countryController.text = widget.country;
// //           address1Controller.text = widget.address1;
// //           address2Controller.text = widget.address2;
// //           phoneController.text = widget.phone;
// //           faxController.text = widget.fax;
// //           zipController.text = widget.zip;
// //           // "Photo" = PHOTO_G;
// //           emailController.text = widget.email;
// //           passwordController.text = widget.password;
// //         });
// //         Fluttertoast.showToast(
// //             msg: ('  Profile Update Successfully'),
// //             toastLength: Toast.LENGTH_SHORT,
// //             gravity: ToastGravity.BOTTOM,
// //             timeInSecForIosWeb: 2,
// //             backgroundColor: Colors.indigo[800],
// //             textColor: Colors.white,
// //             fontSize: 16.0);
// //         Navigator.of(context).pop();
// //       } else {}
// //     }
// //
// //     //  print(jsonString);
// //     //
// //     // if (data != null) {
// //     //   setState(() {
// //     //     Fluttertoast.showToast(
// //     //         msg: "Profile Update SuccessFully",
// //     //         toastLength: Toast.LENGTH_SHORT,
// //     //         gravity: ToastGravity.BOTTOM,
// //     //         timeInSecForIosWeb: 2,
// //     //         backgroundColor: Colors.purple,
// //     //         textColor: Colors.white,
// //     //         fontSize: 16.0);
// //     //     Navigator.pop(context, true);
// //     //   });
// //     // } else {
// //     //   setState(() {
// //     //     isLoading = false;
// //     //   });
// //     //
// //     //   _showMsg(data["errors"]["msg"]).toString();
// //     // }
// //   }
// //
// //   @override
// //   void initState() {
// //     print("Update Name: ${widget.firstName}");
// //     firstController.text = widget.firstName;
// //     lastController.text = widget.lastName;
// //     cityController.text = widget.city;
// //     stateController.text = widget.state;
// //     countryController.text = widget.country;
// //     address1Controller.text = widget.address1;
// //     address2Controller.text = widget.address2;
// //     phoneController.text = widget.phone;
// //     faxController.text = widget.fax;
// //     zipController.text = widget.zip;
// //     // "Photo" = PHOTO_G;
// //     emailController.text = widget.email;
// //     passwordController.text = widget.password;
// //     // dobController.text = DOB;
// //
// //     super.initState();
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     Widget bottomSheet() {
// //       return ClipRRect(
// //         borderRadius: BorderRadius.circular(25),
// //         child: Container(
// //           height: 100.0,
// //           width: MediaQuery.of(context).size.width,
// //           margin: EdgeInsets.symmetric(
// //             horizontal: 20,
// //             vertical: 20,
// //           ),
// //           child: Column(
// //             children: <Widget>[
// //               Text(
// //                 ('choose_profile_photo'),
// //                 style: TextStyle(
// //                   fontSize: 20.0,
// //                 ),
// //               ),
// //               SizedBox(
// //                 height: 20,
// //               ),
// //               Row(
// //                 mainAxisAlignment: MainAxisAlignment.center,
// //                 children: <Widget>[
// //                   FlatButton.icon(
// //                     icon: Icon(Icons.camera),
// //                     onPressed: () {
// //                       takePhoto(ImageSource.camera);
// //                       Navigator.pop(context);
// //                     },
// //                     label: Text("Camera"),
// //                   ),
// //                   FlatButton.icon(
// //                     icon: Icon(Icons.image),
// //                     onPressed: () {
// //                       Navigator.pop(context);
// //                       takePhoto(ImageSource.gallery);
// //                     },
// //                     label: Text("Gallery"),
// //                   ),
// //                 ],
// //               ),
// //             ],
// //           ),
// //         ),
// //       );
// //     }
// //
// //     return Scaffold(
// //       appBar: AppBar(
// //         leading: IconButton(
// //           icon: Icon(
// //             Icons.arrow_back,
// //             color: Colors.black,
// //           ),
// //           onPressed: () {
// //             Navigator.pop(context);
// //           },
// //         ),
// //         backgroundColor: Colors.white,
// //         elevation: 1,
// //         title: Text(
// //           "Update Profile",
// //           style: TextStyle(fontSize: 20, color: Colors.black),
// //         ),
// //       ),
// //       backgroundColor: Colors.transparent,
// //       body: SafeArea(
// //         child: Form(
// //           child: SingleChildScrollView(
// //             child: Column(
// //               children: [
// //                 SizedBox(
// //                   height: 40,
// //                 ),
// //                 Row(
// //                   mainAxisAlignment: MainAxisAlignment.center,
// //                   children: [
// //                     Center(
// //                       child: Stack(children: <Widget>[
// //                         CircleAvatar(
// //                           backgroundColor: Colors.indigo,
// //                           radius: 80.0,
// //                           backgroundImage: _imageFile == null
// //                               ? (widget.photo == null
// //                                   ? AssetImage("assets/images/deshiTour.png")
// //                                   : NetworkImage(widget.photo))
// //                               : FileImage(File(_imageFile.path)),
// //                         ),
// //                         Positioned(
// //                           bottom: 20.0,
// //                           right: 20.0,
// //                           child: InkWell(
// //                             onTap: () {
// //                               showModalBottomSheet(
// //                                 context: context,
// //                                 builder: ((builder) => bottomSheet()),
// //                               );
// //                             },
// //                             child: Icon(
// //                               Icons.add_a_photo,
// //                               size: 31.0,
// //                             ),
// //                           ),
// //                         ),
// //                       ]),
// //                     ),
// //                   ],
// //                 ),
// //
// //                 // FirstName Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: firstController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter FirstName";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'First Name',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // LastName Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: lastController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter LastName";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Last Name',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // City Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: cityController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter City";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'City',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // State Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: stateController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter City";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'State',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Country Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: countryController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter Country";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Country',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Address1 Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: address1Controller,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter Address1";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Address1',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Address2 Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: address2Controller,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter  Address2";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'City',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Phone Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: phoneController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter Phone";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Phone',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Fax Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: faxController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter Fax";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Fax',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Zip Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: zipController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter Zip";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Zip',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Email Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: emailController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter Email";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Email',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Password Fields
// //                 Padding(
// //                   padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
// //                   child: Container(
// //                     decoration: BoxDecoration(
// //                       color: AppTheme.getTheme().backgroundColor,
// //                       borderRadius: BorderRadius.all(Radius.circular(38)),
// //                       // border: Border.all(
// //                       //   color: HexColor("#757575").withOpacity(0.6),
// //                       // ),
// //                       boxShadow: <BoxShadow>[
// //                         BoxShadow(
// //                           color: AppTheme.getTheme().dividerColor,
// //                           blurRadius: 8,
// //                           offset: Offset(4, 4),
// //                         ),
// //                       ],
// //                     ),
// //                     child: Padding(
// //                       padding: const EdgeInsets.only(left: 16, right: 16),
// //                       child: Container(
// //                         height: 48,
// //                         child: Center(
// //                           child: TextFormField(
// //                             controller: passwordController,
// //                             validator: (value) {
// //                               if (value.isEmpty) {
// //                                 return "Please Enter Password";
// //                               }
// //                               return null;
// //                             },
// //                             maxLines: 1,
// //                             onChanged: (String txt) {},
// //                             style: TextStyle(
// //                               fontSize: 16,
// //                             ),
// //                             cursorColor: AppTheme.getTheme().primaryColor,
// //                             decoration: new InputDecoration(
// //                               errorText: null,
// //                               border: InputBorder.none,
// //                               hintText: 'Password',
// //                               hintStyle: TextStyle(
// //                                   color: AppTheme.getTheme().disabledColor),
// //                             ),
// //                           ),
// //                         ),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 SizedBox(
// //                   height: 30,
// //                 ),
// //
// //                 // Update Button
// //                 Padding(
// //                   padding: const EdgeInsets.only(
// //                       left: 24, right: 24, bottom: 8, top: 16),
// //                   child: Container(
// //                     height: 45,
// //                     width: 230,
// //                     child: RaisedButton(
// //                       onPressed: () {
// //                         update();
// //                       },
// //                       color: AppTheme.getTheme().primaryColor,
// //                       child: Text(
// //                         "Update",
// //                         style: TextStyle(fontSize: 15, color: Colors.white),
// //                       ),
// //                       shape: RoundedRectangleBorder(
// //                         borderRadius: BorderRadius.circular(20),
// //                       ),
// //                     ),
// //                   ),
// //                 ),
// //
// //                 // Padding(
// //                 //   padding: const EdgeInsets.only(
// //                 //       left: 24, right: 24, bottom: 8, top: 16),
// //                 //   child: Container(
// //                 //     height: 48,
// //                 //     decoration: BoxDecoration(
// //                 //       color: AppTheme.getTheme().primaryColor,
// //                 //       borderRadius:
// //                 //       BorderRadius.all(Radius.circular(24.0)),
// //                 //       boxShadow: <BoxShadow>[
// //                 //         BoxShadow(
// //                 //           color: AppTheme.getTheme().dividerColor,
// //                 //           blurRadius: 8,
// //                 //           offset: Offset(4, 4),
// //                 //         ),
// //                 //       ],
// //                 //     ),
// //                 //     child: Material(
// //                 //       color: Colors.transparent,
// //                 //       child: InkWell(
// //                 //         borderRadius:
// //                 //         BorderRadius.all(Radius.circular(24.0)),
// //                 //         highlightColor: Colors.transparent,
// //                 //         onTap: () {
// //                 //           Navigator.pop(context);
// //                 //         },
// //                 //         child: Center(
// //                 //           child: Text(
// //                 //             APPLY,
// //                 //             style: TextStyle(
// //                 //                 fontWeight: FontWeight.w500,
// //                 //                 fontSize: 16,
// //                 //                 color: Colors.white),
// //                 //           ),
// //                 //         ),
// //                 //       ),
// //                 //     ),
// //                 //   ),
// //                 // ),
// //               ],
// //             ),
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// // }
// //
// //
// //
// //
// //
//
// import 'dart:async';
// import 'dart:convert';
// import 'dart:io';
//
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:http/http.dart' as http;
// import 'package:image_picker/image_picker.dart';
// import 'package:new_motel/appTheme.dart';
// import 'package:new_motel/modules/profile/userProfile.dart';
// import 'package:new_motel/utils/constants.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// class ProfileUpdateScreen extends StatefulWidget {
//   final String id;
//   final ProfileScreenPageState profileGetState;
//   final String firstName;
//   final String lastName;
//   final String city;
//   final String state;
//   final String country;
//   final String address1;
//   final String address2;
//   final String phone;
//   final String fax;
//   final String zip;
//   final String photo;
//   final String email;
//   final String password;
//   final String confirmPassword;
//
//   const ProfileUpdateScreen({
//     Key key,
//     this.id,
//     this.profileGetState,
//     this.firstName,
//     this.lastName,
//     this.city,
//     this.state,
//     this.country,
//     this.address1,
//     this.address2,
//     this.phone,
//     this.fax,
//     this.zip,
//     this.photo,
//     this.email,
//     this.password,
//     this.confirmPassword,
//   }) : super(key: key);
//   @override
//   _ProfileUpdateScreenState createState() => _ProfileUpdateScreenState();
// }
//
// class _ProfileUpdateScreenState extends State<ProfileUpdateScreen> {
//   final _key = GlobalKey<FormState>();
//   // final nameController = TextEditingController();
//   // final emailController = TextEditingController();
//   // final phoneController = TextEditingController();
//   // final upazilaController = TextEditingController();
//   // final dobController = TextEditingController();
//   // final occuptionController = TextEditingController();
//   // final imageController = TextEditingController();
//   // final educationController = TextEditingController();
//   // final addressController = TextEditingController();
//   // Map<String, dynamic> data;
//   String pMessage = '';
//   bool success = false;
//   // final ImagePicker _picker = ImagePicker();
//   // // image Upload.....
//   // PickedFile _imageFile;
//   // Uint8List _bytesImage;
//   // String base64Image;
//
//   void takePhoto(ImageSource source) async {
//     final pickedFile = await _picker.getImage(
//       source: source,
//     );
//     setState(() {
//       _imageFile = pickedFile;
//     });
//   }
//
//   // File image;
//   // File _photo;
//   // String photoBase64;
//   //
//   // Future getImage(ImageSource source) async {
//   //   var photo = await ImagePicker.pickImage(source: source);
//   //
//   //   _photo = await FlutterNativeImage.compressImage(photo.path,
//   //       quality: 100, targetWidth: 120, targetHeight: 120);
//   //
//   //   setState(() {
//   //     _photo = photo;
//   //
//   //     List<int> imageBytes = _photo.readAsBytesSync();
//   //     photoBase64 = base64Encode(imageBytes);
//   //     print("AAAAAAAAAAA$photoBase64");
//   //   });
//   // }
//
//   // File imageResized;
//   // File _photo;
//   // String photoBase64;
//   // Future getImage(ImageSource source) async {
//   //   var photo = await ImagePicker.pickImage(source: source);
//   //
//   //   // imageResized = await FlutterNativeImage.compressImage(photo.path,
//   //   //     quality: 100, targetWidth: 120, targetHeight: 120);
//   //
//   //   setState(() {
//   //     _photo = photo;
//   //
//   //     List<int> imageBytes = imageResized.readAsBytesSync();
//   //     photoBase64 = base64Encode(imageBytes);
//   //     print(photoBase64);
//   //   });
//   // }
//
//   final firstController = TextEditingController();
//   final lastController = TextEditingController();
//   final cityController = TextEditingController();
//   final stateController = TextEditingController();
//   final countryController = TextEditingController();
//   final address1Controller = TextEditingController();
//   final address2Controller = TextEditingController();
//   final phoneController = TextEditingController();
//   final faxController = TextEditingController();
//   final zipController = TextEditingController();
//   final emailController = TextEditingController();
//   final passwordController = TextEditingController();
//   final confirmPasswordController = TextEditingController();
//
//   final _scaffoldKey = GlobalKey<ScaffoldState>();
//   _showMsg(msg) {
//     final snackBar = SnackBar(content: Text(msg));
//     _scaffoldKey.currentState.showSnackBar(snackBar);
//   }
//
//   bool isLoading = false;
//   bool _autoValidate = false;
//
//   // File _image;
//   // imageSelectorGallery() async {
//   //   _image = await ImagePicker.pickImage(
//   //     source: ImageSource.gallery,
//   //     // maxHeight: 50.0,
//   //     // maxWidth: 50.0,
//   //   );
//   //   List<int> imageBytes = _image.readAsBytesSync();
//   //   print(imageBytes);
//   //   String base64Image = base64UrlEncode(imageBytes);
//   //   print('string is');
//   //   print("Abir Uploaded $base64Image");
//   //   print("You selected gallery image : " + _image.path);
//   //   //  setState(() {});
//   //
//   //   photo() async {
//   //     SharedPreferences sharedPreferences =
//   //         await SharedPreferences.getInstance();
//   //     var id = sharedPreferences.getString("id");
//   //     var response = await http.post(
//   //         "https://deshitour.com//api/login/updatephoto?appKey=DeshiTour",
//   //         body: {
//   //           "id": id,
//   //           "user_photo": base64Image,
//   //         });
//   //     print("Response...${response.body}");
//   //     return response;
//   //   }
//   // }
//
//   updateProfile() async {
//     final form = _key.currentState;
//     if (form.validate()) {
//       setState(() {
//         isLoading = true;
//       });
//       form.save();
//       update();
//     } else {
//       setState(() {
//         isLoading = false;
//       });
//     }
//   }
//
//   update() async {
//     SharedPreferences _preference = await SharedPreferences.getInstance();
//     String id = _preference.getString('id');
//
//     var response = await http.post(
//       "https://deshitour.com/api/login/updateprofile?appKey=DeshiTour",
//       body: {
//         'id': id,
//         "firstname": firstController.text,
//         "lastname": lastController.text,
//         "city": cityController.text,
//         "state": stateController.text,
//         "country": countryController.text,
//         "address1": address1Controller.text,
//         "address2": address2Controller.text,
//         "phone": phoneController.text,
//         "fax": faxController.text,
//         "zip": zipController.text,
//         "photo": widget.photo ?? "",
//         "email": emailController.text,
//         "password": passwordController.text,
//         "confirm_password": confirmPasswordController.text,
//       },
//       headers: {
//         "Accept": "application/json",
//       },
//     );
//     var errorMsg = json.decode(response.body)['msg'];
//     print(errorMsg);
//     if (response.statusCode == 200) {
//       var data = json.decode(response.body)['status'];
//       if (data == 1) {
//         setState(() {
//           isLoading = true;
//         });
//
//         Fluttertoast.showToast(
//             msg: "Successfully Done",
//             toastLength: Toast.LENGTH_SHORT,
//             gravity: ToastGravity.BOTTOM,
//             timeInSecForIosWeb: 2,
//             backgroundColor: Colors.indigo,
//             textColor: Colors.white,
//             fontSize: 16.0);
//         //setState(() {});
//         navigateSecondPage("3");
//       } else {
//         setState(() {
//           isLoading = false;
//         });
//         Fluttertoast.showToast(
//             msg: errorMsg,
//             toastLength: Toast.LENGTH_SHORT,
//             gravity: ToastGravity.BOTTOM,
//             timeInSecForIosWeb: 2,
//             backgroundColor: Colors.indigo,
//             textColor: Colors.white,
//             fontSize: 16.0);
//         // setState(() {});
//       }
//     }
//   }
//
//   FutureOr onGoBack(dynamic value) {
//     ppppp();
//     setState(() {});
//   }
//
//   void navigateSecondPage(String from) {
//     Route route =
//     MaterialPageRoute(builder: (context) => ProfileScreenPage(type: from));
//     Navigator.push(context, route).then(onGoBack);
//   }
//
//   File imageFile;
//   String imagenConvertida;
//   void _openPhoto(BuildContext context, ImageSource source) async {
//     var picture = await ImagePicker().getImage(source: source);
//     this.setState(() {
//       imageFile = File(picture.path);
//       var bytes = imageFile.readAsBytesSync();
//
//       imagenConvertida = base64.encode(bytes);
//       print(bytes);
//       print(imagenConvertida);
//     });
//   }
//
//   _uploadPhoto() async {
//     SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
//     var id = sharedPreferences.getString("id");
//     var response = await http.post(
//         "https://deshitour.com//api/login/updatephoto?appKey=DeshiTour",
//         body: {
//           "id": id,
//           "user_photo": imagenConvertida,
//         });
//     print("Response...${response.body}");
//     return response;
//   }
//
//   @override
//   void initState() {
//     firstController.text = widget.firstName;
//     lastController.text = widget.lastName;
//     cityController.text = widget.city;
//     stateController.text = widget.state;
//     countryController.text = widget.country;
//     address1Controller.text = widget.address1;
//     address2Controller.text = widget.address2;
//     phoneController.text = widget.phone;
//     faxController.text = widget.fax;
//     zipController.text = widget.zip;
//     // _imageFile = widget.photo;
//     emailController.text = widget.email;
//     //  passwordController.text = widget.password;
//     super.initState();
//     // _uploadPhoto(_imageFile);
//     // _uploadPhoto();
//     // String img = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAABmJLR0QA/wD/AP+gvaeTAAASKUlEQVR4nO3dfZBfVX3H8feGZDeYBBIZhUoCJCQkYKgoTotWQ0USiIBVitjyoFZx6IwtUloeWotkxoIII53UTltRHgoZwKIVRjutToAGkIdAHVGUJAtNIAQrGhLysHna7PaP7y+TZLNLfufec+73nvv7vGa+s8vyy+73nt8953fvuecBRERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERERETqoss7AUlmLDALmAkc0/p+GjCuFZNaXwE2A+taXzcBK4FlwHJgRev7rRXmLhVRA9Aco4F3AKe24n1YIxBDP/AMsLgVjwDbIv1uESnoAGAucCf2yT1YUWwE7sAamlHJj1JE9nIk8BXgZaqr9CPFauB64IikRywiTAMWYvfj3hV/aGzHrgpmJTt6kQ51NHAPsBP/ir6/6AfuwhorESmhG7gS2IJ/xQ6NPmAB8ToiRTrK6UAv/hW5bKwA5kUuG5HGGo11qg3gX3ljxQDWd9EdsZxEGucI4HH8K2yqeBrrzxCRIc4A1uNfSVPHOuBDkcpMpBEuxB6jeVfOqqIfuChKyUkpGgrs7wrsnj/Ve7EceBIbz78C61jcxO6x/7B7bsAEYAY2d2AmcFLr+xQGsSccNyb6/SK1dz3xP137gLuBC4C3RcjxcOwK5VukeRx5XYQcRbJzBXEr0pPAZ4CDE+Z8MHbpvjRy7pcnzFmkdi4g3mO+R4Gzqk0fsNmG3yuQ73AxAHy62vRFfJwJ7KB8pXkOOKXi3IczF+tfKHs824H5FecuUqlpWOdbmYrSB1xFvQbV9ABfoHwfwWvAURXnLlKJMZQf5LMMW/Sjro4DnqXcMS6lXo2bSBQLKVcxFgHjK8863ARs5mKZY72p8qxFEjqdcp1+15HXmI0ubMGSosc7gPUtiGRvLMVn9Q0Al1afcjSXUbzhW471LYhkbQHFPwkvc8g3ts9R/Pi/4JCvSDRHU7xn/O8c8k3lBoqVQR9aWUgyVrQzbBF53fPvTxc2lLhoWYhkZzo26y30hF+B9aQ3zXhs8FJoefRjE5REsnIb4Sf7FuAEj2Qrcjx2WR9aLt/wSFakqCnYzjmhJ/pVHslW7GrCy2U7theCSBaKPAP/BZ0xAq4He8QXWj5f9khWJNQBFNuxpw4Te6oyj/DyeQltQyYZKHJyP+CSqa8lqJGUBroTndjtKNJQ3uaSqUibugnfpfdJl0zr4SnCymoDNqtSItE9VVwnYQtshrg5RSKZCH28NwH4nRSJdCo1AHGFXspvBb6TIpFM7FpoNEQn3i4lowYgrg8Evv4+bDOQTvU68P3AfxNaxiKVOBD7RA+5pz3fJdN6+QRhZbYF7TgsNXQC4b3ah7tkWi9TCC+3410ybSDdAsQzM/D1y4A1KRLJzGrg+cB/E1rWMgI1APGEnpRLk2SRpycCXz8rSRYdSA1APEWuAMQsD3x9qv0KO44agHhC17NfkSSLPIU2AFOTZNGB1ADEc1Dg619IkkWeQvsAQstaRqAGIJ7QVXzWJckiT6FjIZq4YpILNQDxhJ6UG5NkkafQslADILUTugJQJyz+0a4ewspuq0+azaMrAJEOpgYgnk2Br89hn7+q6PbJiRqAeHQfW5waACdqAOLZEPj6SUmyyFNoWagBiEQNQDyhDcDRSbLIU2hZhJa1jEANQDwvBr5eE1p2Cx3bvzJJFh1IDUA8oWP71QDsFjq2P3TosIxADUA8oWP7fzdJFnk6KfD1agCkdoosCDLZJdN60YIgjnQFEM8ybDRgCK1vV2whVc2kjEQNQDxbCV/Y4swUiWTmrMDXP054QysjUAMQ10OBr/8wMDFFIpmYRHgj+GCKRDqVGoC4Qk/OscA5KRLJxLnYRKAQagCktrqxUWohHVqdvDbg04SV1etoazCpuTsI79U+1SVTX6cTXk63umQqEmAu4Sd2aN9BEzxMeDnpqYnU3ihsrfvQk3uuR7JO5hNePi+iPivJxPWEn+DLCO8Qy9FYoJfw8rnOI1mRIqYQvkTYIPA3HslW7BrCy2U7cKRHsiJF3UL4ib4VeKdHshX5bWxzz9By+bpHsiJlHA3sIPxk76WZ695PwG5zQsujH5jhkK9IaXcRfsIPAvcAXQ75ptIFfJtiZXGHQ74iURwJbKbYif8Vh3xT+SrFyqAPbQMmmfsixU7+QeAvHfKN7QqKH/9fO+QrElUPNn21SAUYAC6rPuVoLseOocixL0Obp0hDzKN4RRgEbiCvPoEuil/272r4Plh51iIJ3UTxCjEIfIs89hI4mOIdfrvixsqzFklsDPAY5SrGSuq9luC7KDbKb894El36S0NNxbYFL1NBtgBXU69hw2OxEX5bKXdsa9GIP2m4D1FsgNDQWI71LXibT/lP/UFsuO9pFecu4uJ8ynUK7hmPYuvqVd1J+D5gccncd8UA8Klq0xfxdTlxKs+ueAr4LGnXGJwEXEz4Sj77iyaMdxAJdh1xK9Ig1kdwL/AJ4uw7MAX4JNazX/Yef7i4NkKOUlBOz5ab6nJs2G+q96IX61lfhg1IegFY34pNrdeMx64cJmKTmGa24iRgeqK8BrFj/2qi3y+SjQuwTrDYn651jR3AZ6KUnEhDzAdew79ypo61qLdfZFhHAD/Cv5KmiqeAadFKS6SBRgMLgJ34V9hYMQAsRCP8RNo2Fxvs4115y8YyNLFHpJAxwOcJ322oDtGHXcnUaciySJamAouw9fG8K/b+YgdwJxrTLxLdVOxeusjKuqljO7Z+3zHJjl5EABuddx3wEv4V/yVsNN+UpEcsIvsYBZwC3A5soLpK/zpwG7ZXn7brypiGAjfHAcAJ2E7Dp2Kz9cZG+t39wDPY7L/FwCPYzkeSOTUAzdUDzMLuyY9pfT8VG/c/ARv3P7712k3Y3ICNre//F3sEuRybP7AcVXgRERERERERERERERERERERERERERERERERERERERERkUpoQZDm6AKOwnYXmgwctsfXw4E3Ydt7M8zXrdhCo2CLgqxrxWvAr4E1wIvAy62vq7CNSyRzagDydCi2/NfxwHHAbOBYdq/wk9o2bMOP5cCzwP+04lcV/X2JRA1AHqYC798jZvqmM6KXsa3Il7TiWWxbMBEJcCDwYeCbwGr8l/4uGmuBb2Nbgb8tagmJNMxbgE8D9wGb8a+8sWMA+DFwDXbbItLxuoGzge+Tx7ZfMeNZ4ItYwyfSUWYDNwGv4l8RvWMDcG654hSpv1HAR4BH8a90dYudwJnFi1akvnqAz2KPzbwrWp1jNfF2MhJxNw64Cvgl/pUrlzi7UEnXRzfW4GdjtHcCDTQauAjr7T7MOZfcnAj8u3cSb+Aw4L3YOIwZ2JZrk4GDsO3WdtWnnVjfxkZsFOUKoLf19bHWz6RhuoA/xEbHeX+S5ho3BZd6WgdiHZQ3E/cWrhe4FTiP6kZvDktXAHG8G/gacJJzHoPASuxkXQO8skf8ChuYAzbOf8+v3dgtSxe2aeikVhyKDeCZDExh96ded6L8VyX6vSFGYbsrnw98FPtkj216K/4E6APuB+4CfgDsSPD3JJEJwEJ8nuFvw54o3Ah8CmuExqU9XMC2IZ+OVY5rgf8CfhPheAawxsVLD3br5nkFtwq4hGreRynpo1Q7THcL9gnxt8Ac7PK0LrqwiUmXYPfw6wk/vvsrz9qMAS7F5jF4Vfyh8WvsfX5TwuOWgn4LG65bxYnwG+Bfsb6FnD4VurHL6H/Apg/v7zhfwMq1aqcAP28jP69YRf5PRhrlTNKP3tuATQL6fexyO3ejgJOxjrR17H2sW1s/r3o48FuAu0n7PsaMH2IzQsXJWOzTbIA0b/AA8DB2L5/TJ32oMcDvARdiVwge8wDmUK/L/XZjPfCxBOUh+3Ec8Axp3tQtwL9Q3/n9TTIKu6/egX9lLhP/TL36fxrt46SZmrsW+BLw1uoOpaP1APfiX3ljxRPAIVFLSPbShVXQ2Jf8a4G/otmX+XUzAViMf6WNHc8BR0YsJ2kZjz3Kivlm9QHXY4NspDqHAEvxr6yp4mXg7dFKSziKuPf7O7Ehn5OrPAgBrCF/Ev9KmjpeQU8IojiWuAN7fgq8p9IjkF3GAP+Jf+WsKp7Hhm1LQe/GRl/FeDM2A1diJ6FUrwtYhH+lrDqWor6lQuYArxPnTViMLse8XYp/ZfSK2yOUX0eZj3XQlS34HcAC7Fmz+DkRG13oXRE948LSpdghPkick2UltkiE+BqPll0bxBYh0cCy/XgPsInyhb2INPPFJdw/4l/56hKPoF2/RnQ8NiCnTAEPYJf8Ug+zyX+Ib+w4v1SJNtQMyi/S+TpwRtWJy4i6sIlUXhXtFWx05zHYkOOJ2DTjO7BxIF55rUFXp3t5K3a/XqZQe9G2VnXzMfwq2QO88ejOU4n3hKlIXNt2KTZcN3ZfVKYwf4IGW9TRj/GpXMtp7xP2I075DWJTiA9uI8fGu5lyBfkYtkim1Ms8/CrXxwPyfNAxzysC8mykz1GuABfjvHSzjMhrll8fYXPyL3bKcxDro8hqs5KYPgBsp3jh/QcdXHg1NwO/SrUsMNeTHXMd5A02X23yyLVDgXsoPiZ/CXAOtvy21M95jn97U+LXx/ZHzn+/cl3A9yjeYv4Ezd2vO89Rf08H5nqiY66D2IjXYc/npl4B/BnFt5t+Dnt8sz5eOhLZO9Fw1xA9wB8M9z+a2ADMBm4o+G9/CZyGrccv9TXXO4EMDVtmTWsAerDx+UX2md+OPdpZHTUjSWGOdwIZOtk7gSp8ieL3SRc55CvhRrHvBiPqA2gvGr1WxUyKT+/9e4d8pZjZ+FekXBuAC4Ym1qRbgH+i2DP7JcDlkXORdNT5V1xjy+48irWIr2H73ks+riLNp+PQWX1Vq2IW4T2VHU2FJlJ8iq/2WsvPLcSvGPub1Ve1VLMIQ29dsvBlihXGrR7JSmk/JG6laHdWX9VSzCJ8tdIjqEAXxbbrfgFN8MnV48StFCGz+qoWexbh1mrTT28KxQriNI9kJYqfEa9ChM7qq1qKWYR7zY3J/SlAkYk+/wb8IHYiUpmYV24vYVu011XorMN27HW7k3sDsJqwy5oNwF8kykWqkfs5623UiP+RoR3YnP12XY097pF8xZxaewT1vgU4NsHv3Jjgd7qaTXuLfjwCHOCUo8QTe8ffOs+Vf4i4x7q92vSr88fYwh0jHXgv1tpL/h4gbqXoBQ6q9AjaczbxOwDXVnoEFXsXcB/Qz+4DfhW4kXq+wVJMip1/H6Rei77Ow/qrYh/nz6o8CC/jsLX7J5N/H4fs6xriV4xB4P+wFXRnUWw6eVlvxvarXES6ocDfrexoRBI5nzSVIyRynQ24z0I5+oSU3KzwTiBjvUN/oAZAcvNTGjiktSJPDP2BGgDJzTbsUaCEeQ34+dAfqgGQHC3xTiBDD2Pb2u9FDYDk6CHvBDI0bJmpAZAcPQys8U4iIwPAd4b7H2oAJEcDwL3eSWRkCSM0mGoAJFd3O/7t0CnJ3isONXItQOlsXcAz+AyoCV1I5E+d8hzEhhSPOMxZVwCSq0FsnoeHAxlhr70ReC479g1sIxWRxhkDrMLnk7XdWYQpZvW1G9uwOTEijfXn+FWw/c0iTDWrr924pe1SFMlUN7Z2nlclGzqLsIpZfe3ERuDwEuUqko25+FW0usaVpUpUJDP341/p6hK9+GxvJuJmCrbklXfl845+YE7JshTJ0hnYKEHvSugZ15QuRZGMfQ3/SugVS9DK19LhxgKP4V8Zq47VqNdfBIBDgF/gXymrivXAO6KUnEhDTAZexL9ypo4twPsjlZlIo7wd2wrOu5KmrPxnRSstkQY6Ct+RgqliHXrcJ9KWNwM/wr/SxopX0D2/SJBxwO34V96y8d+ot1+ksHOwy2fvihwa/cAC9JxfpLQZ2Hbx3pW63ViO7vdFojuLej8q3Ix96mtij0giE4BrscE03hV+V2zDFvPQvb5IRSYAn8eG1HpV/I3AQmxmo4g46AHOBb6LbUKautLvxHbtuRiYWMHxiUibDgY+CdxJ3CuDtcB9wCU4X+Z3ef5xkcxMA96Lrf83vRVHYrcPQzvq+rFL+jXYCj3Pt+JxbJfefTbq9KAGQCSO0ezeAagP68gTERERERGpk/8HhcH2sU3qffYAAAAASUVORK5CYII=";
//     ppppp();
//     setState(() {});
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       child: Scaffold(
//         appBar: AppBar(
//           leading: IconButton(
//             icon: Icon(
//               Icons.arrow_back,
//               color: Colors.black,
//             ),
//             onPressed: () {
//               Navigator.of(context).pop();
//             },
//           ),
//           backgroundColor: Colors.white,
//           elevation: 1,
//           title: RichText(
//             text: TextSpan(
//                 text: DESHI,
//                 style: TextStyle(
//                   fontSize: 30,
//                   fontFamily: 'Impact',
//                   color: HexColor("#26408A"),
//                 ),
//                 children: <TextSpan>[
//                   TextSpan(
//                       text: TOUR,
//                       style: TextStyle(
//                         fontSize: 30,
//                         fontFamily: 'Impact',
//                         color: HexColor("#118ACB"),
//                       )),
//                 ]),
//           ),
//         ),
//         backgroundColor: Colors.white,
//         key: _scaffoldKey,
//         body: ppppp(),
//       ),
//     );
//   }
//
//   ppppp() {
//     return SafeArea(
//       child: Form(
//         autovalidate: _autoValidate,
//         key: _key,
//         child: ListView(
//           children: <Widget>[
//             SizedBox(
//               height: 20,
//             ),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 Center(
//                   child: Stack(
//                     children: <Widget>[
//                       // Positioned(
//                       //   bottom: 20.0,
//                       //   right: 20.0,
//                       //   child: InkWell(
//                       //     onTap: () {
//                       //       showModalBottomSheet(
//                       //         context: context,
//                       //         builder: ((builder) => bottomSheet()),
//                       //       );
//                       //     },
//                       //     child: Icon(
//                       //       Icons.add_a_photo,
//                       //       size: 31.0,
//                       //     ),
//                       //   ),
//                       // ),
//
//                       CircleAvatar(
//                         radius: 60.0,
//                         backgroundColor: Colors.black,
//                         child: CircleAvatar(
//                           // backgroundColor: Colors.indigo,
//                           radius: 57.0,
//                           backgroundImage: imageFile == null
//                               ? AssetImage("assets/images/person.png")
//                               : FileImage(imageFile),
//                           backgroundColor: Colors.white,
//                         ),
//                       ),
//
//                       Positioned(
//                         bottom: 20.0,
//                         right: 5.0,
//                         child: InkWell(
//                           onTap: () {
//                             showModalBottomSheet(
//                               context: context,
//                               builder: ((builder) => bottomSheet()),
//                             );
//                           },
//                           child: Icon(
//                             Icons.add_a_photo,
//                             size: 31.0,
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//             SizedBox(
//               height: 20,
//             ),
//             Padding(
//               padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//               child: Container(
//                 decoration: BoxDecoration(
//                   color: AppTheme.getTheme().backgroundColor,
//                   borderRadius: BorderRadius.all(Radius.circular(38)),
//                   // border: Border.all(
//                   //   color: HexColor("#757575").withOpacity(0.6),
//                   // ),
//                   boxShadow: <BoxShadow>[
//                     BoxShadow(
//                       color: AppTheme.getTheme().dividerColor,
//                       blurRadius: 8,
//                       offset: Offset(4, 4),
//                     ),
//                   ],
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.only(left: 16, right: 16),
//                   child: Container(
//                     height: 48,
//                     child: Center(
//                       child: TextFormField(
//                         controller: firstController,
//                         validator: (value) {
//                           if (value.isEmpty) {
//                             return "Please Enter FirstName";
//                           }
//                           return null;
//                         },
//                         maxLines: 1,
//                         onChanged: (String txt) {},
//                         style: TextStyle(
//                           fontSize: 16,
//                         ),
//                         cursorColor: AppTheme.getTheme().primaryColor,
//                         decoration: new InputDecoration(
//                           errorText: null,
//                           border: InputBorder.none,
//                           hintText: 'First Name',
//                           hintStyle: TextStyle(
//                               color: AppTheme.getTheme().disabledColor),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             Padding(
//               padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//               child: Container(
//                 decoration: BoxDecoration(
//                   color: AppTheme.getTheme().backgroundColor,
//                   borderRadius: BorderRadius.all(Radius.circular(38)),
//                   // border: Border.all(
//                   //   color: HexColor("#757575").withOpacity(0.6),
//                   // ),
//                   boxShadow: <BoxShadow>[
//                     BoxShadow(
//                       color: AppTheme.getTheme().dividerColor,
//                       blurRadius: 8,
//                       offset: Offset(4, 4),
//                     ),
//                   ],
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.only(left: 16, right: 16),
//                   child: Container(
//                     height: 48,
//                     child: Center(
//                       child: TextFormField(
//                         controller: lastController,
//                         validator: (value) {
//                           if (value.isEmpty) {
//                             return "Please Enter Last Name";
//                           }
//                           return null;
//                         },
//                         maxLines: 1,
//                         onChanged: (String txt) {},
//                         style: TextStyle(
//                           fontSize: 16,
//                         ),
//                         cursorColor: AppTheme.getTheme().primaryColor,
//                         decoration: new InputDecoration(
//                           errorText: null,
//                           border: InputBorder.none,
//                           hintText: 'Last Name',
//                           hintStyle: TextStyle(
//                               color: AppTheme.getTheme().disabledColor),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             Padding(
//               padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//               child: Container(
//                 decoration: BoxDecoration(
//                   color: AppTheme.getTheme().backgroundColor,
//                   borderRadius: BorderRadius.all(Radius.circular(38)),
//                   // border: Border.all(
//                   //   color: HexColor("#757575").withOpacity(0.6),
//                   // ),
//                   boxShadow: <BoxShadow>[
//                     BoxShadow(
//                       color: AppTheme.getTheme().dividerColor,
//                       blurRadius: 8,
//                       offset: Offset(4, 4),
//                     ),
//                   ],
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.only(left: 16, right: 16),
//                   child: Container(
//                     height: 48,
//                     child: Center(
//                       child: TextFormField(
//                         controller: phoneController,
//                         validator: (value) {
//                           if (value.isEmpty) {
//                             return "Please Enter Phone Number";
//                           }
//                           return null;
//                         },
//                         maxLines: 1,
//                         onChanged: (String txt) {},
//                         style: TextStyle(
//                           fontSize: 16,
//                         ),
//                         cursorColor: AppTheme.getTheme().primaryColor,
//                         decoration: new InputDecoration(
//                           errorText: null,
//                           border: InputBorder.none,
//                           hintText: 'Phone Number',
//                           hintStyle: TextStyle(
//                               color: AppTheme.getTheme().disabledColor),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             Padding(
//               padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//               child: Container(
//                 decoration: BoxDecoration(
//                   color: AppTheme.getTheme().backgroundColor,
//                   borderRadius: BorderRadius.all(Radius.circular(38)),
//                   // border: Border.all(
//                   //   color: HexColor("#757575").withOpacity(0.6),
//                   // ),
//                   boxShadow: <BoxShadow>[
//                     BoxShadow(
//                       color: AppTheme.getTheme().dividerColor,
//                       blurRadius: 8,
//                       offset: Offset(4, 4),
//                     ),
//                   ],
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.only(left: 16, right: 16),
//                   child: Container(
//                     height: 48,
//                     child: Center(
//                       child: TextFormField(
//                         controller: emailController,
//                         validator: (value) {
//                           if (value.isEmpty) {
//                             return "Please Enter Email";
//                           }
//                           return null;
//                         },
//                         maxLines: 1,
//                         onChanged: (String txt) {},
//                         style: TextStyle(
//                           fontSize: 16,
//                         ),
//                         cursorColor: AppTheme.getTheme().primaryColor,
//                         decoration: new InputDecoration(
//                           errorText: null,
//                           border: InputBorder.none,
//                           hintText: 'Email',
//                           hintStyle: TextStyle(
//                               color: AppTheme.getTheme().disabledColor),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             Padding(
//               padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//               child: Container(
//                 decoration: BoxDecoration(
//                   color: AppTheme.getTheme().backgroundColor,
//                   borderRadius: BorderRadius.all(Radius.circular(38)),
//                   // border: Border.all(
//                   //   color: HexColor("#757575").withOpacity(0.6),
//                   // ),
//                   boxShadow: <BoxShadow>[
//                     BoxShadow(
//                       color: AppTheme.getTheme().dividerColor,
//                       blurRadius: 8,
//                       offset: Offset(4, 4),
//                     ),
//                   ],
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.only(left: 16, right: 16),
//                   child: Container(
//                     height: 48,
//                     child: Center(
//                       child: TextFormField(
//                         controller: cityController,
//                         maxLines: 1,
//                         onChanged: (String txt) {},
//                         style: TextStyle(
//                           fontSize: 16,
//                         ),
//                         cursorColor: AppTheme.getTheme().primaryColor,
//                         decoration: new InputDecoration(
//                           errorText: null,
//                           border: InputBorder.none,
//                           hintText: 'City',
//                           hintStyle: TextStyle(
//                               color: AppTheme.getTheme().disabledColor),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             Padding(
//               padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//               child: Container(
//                 decoration: BoxDecoration(
//                   color: AppTheme.getTheme().backgroundColor,
//                   borderRadius: BorderRadius.all(Radius.circular(38)),
//                   // border: Border.all(
//                   //   color: HexColor("#757575").withOpacity(0.6),
//                   // ),
//                   boxShadow: <BoxShadow>[
//                     BoxShadow(
//                       color: AppTheme.getTheme().dividerColor,
//                       blurRadius: 8,
//                       offset: Offset(4, 4),
//                     ),
//                   ],
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.only(left: 16, right: 16),
//                   child: Container(
//                     height: 48,
//                     child: Center(
//                       child: TextFormField(
//                         controller: stateController,
//                         maxLines: 1,
//                         onChanged: (String txt) {},
//                         style: TextStyle(
//                           fontSize: 16,
//                         ),
//                         cursorColor: AppTheme.getTheme().primaryColor,
//                         decoration: new InputDecoration(
//                           errorText: null,
//                           border: InputBorder.none,
//                           hintText: 'State',
//                           hintStyle: TextStyle(
//                               color: AppTheme.getTheme().disabledColor),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             //country 1..
//             Padding(
//               padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//               child: Container(
//                 decoration: BoxDecoration(
//                   color: AppTheme.getTheme().backgroundColor,
//                   borderRadius: BorderRadius.all(Radius.circular(38)),
//                   // border: Border.all(
//                   //   color: HexColor("#757575").withOpacity(0.6),
//                   // ),
//                   boxShadow: <BoxShadow>[
//                     BoxShadow(
//                       color: AppTheme.getTheme().dividerColor,
//                       blurRadius: 8,
//                       offset: Offset(4, 4),
//                     ),
//                   ],
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.only(left: 16, right: 16),
//                   child: Container(
//                     height: 48,
//                     child: Center(
//                       child: TextFormField(
//                         controller: countryController,
//                         maxLines: 1,
//                         onChanged: (String txt) {},
//                         style: TextStyle(
//                           fontSize: 16,
//                         ),
//                         cursorColor: AppTheme.getTheme().primaryColor,
//                         decoration: new InputDecoration(
//                           errorText: null,
//                           border: InputBorder.none,
//                           hintText: 'Country',
//                           hintStyle: TextStyle(
//                               color: AppTheme.getTheme().disabledColor),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             // address 1
//             Padding(
//               padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//               child: Container(
//                 decoration: BoxDecoration(
//                   color: AppTheme.getTheme().backgroundColor,
//                   borderRadius: BorderRadius.all(Radius.circular(38)),
//                   // border: Border.all(
//                   //   color: HexColor("#757575").withOpacity(0.6),
//                   // ),
//                   boxShadow: <BoxShadow>[
//                     BoxShadow(
//                       color: AppTheme.getTheme().dividerColor,
//                       blurRadius: 8,
//                       offset: Offset(4, 4),
//                     ),
//                   ],
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.only(left: 16, right: 16),
//                   child: Container(
//                     height: 48,
//                     child: Center(
//                       child: TextFormField(
//                         controller: address1Controller,
//                         maxLines: 1,
//                         onChanged: (String txt) {},
//                         style: TextStyle(
//                           fontSize: 16,
//                         ),
//                         cursorColor: AppTheme.getTheme().primaryColor,
//                         decoration: new InputDecoration(
//                           errorText: null,
//                           border: InputBorder.none,
//                           hintText: 'Address1',
//                           hintStyle: TextStyle(
//                               color: AppTheme.getTheme().disabledColor),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             Padding(
//               padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//               child: Container(
//                 decoration: BoxDecoration(
//                   color: AppTheme.getTheme().backgroundColor,
//                   borderRadius: BorderRadius.all(Radius.circular(38)),
//                   // border: Border.all(
//                   //   color: HexColor("#757575").withOpacity(0.6),
//                   // ),
//                   boxShadow: <BoxShadow>[
//                     BoxShadow(
//                       color: AppTheme.getTheme().dividerColor,
//                       blurRadius: 8,
//                       offset: Offset(4, 4),
//                     ),
//                   ],
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.only(left: 16, right: 16),
//                   child: Container(
//                     height: 48,
//                     child: Center(
//                       child: TextFormField(
//                         controller: address2Controller,
//                         maxLines: 1,
//                         onChanged: (String txt) {},
//                         style: TextStyle(
//                           fontSize: 16,
//                         ),
//                         cursorColor: AppTheme.getTheme().primaryColor,
//                         decoration: new InputDecoration(
//                           errorText: null,
//                           border: InputBorder.none,
//                           hintText: 'Address2',
//                           hintStyle: TextStyle(
//                               color: AppTheme.getTheme().disabledColor),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             //FAX
//             Padding(
//               padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//               child: Container(
//                 decoration: BoxDecoration(
//                   color: AppTheme.getTheme().backgroundColor,
//                   borderRadius: BorderRadius.all(Radius.circular(38)),
//                   // border: Border.all(
//                   //   color: HexColor("#757575").withOpacity(0.6),
//                   // ),
//                   boxShadow: <BoxShadow>[
//                     BoxShadow(
//                       color: AppTheme.getTheme().dividerColor,
//                       blurRadius: 8,
//                       offset: Offset(4, 4),
//                     ),
//                   ],
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.only(left: 16, right: 16),
//                   child: Container(
//                     height: 48,
//                     child: Center(
//                       child: TextFormField(
//                         controller: faxController,
//                         maxLines: 1,
//                         onChanged: (String txt) {},
//                         style: TextStyle(
//                           fontSize: 16,
//                         ),
//                         cursorColor: AppTheme.getTheme().primaryColor,
//                         decoration: new InputDecoration(
//                           errorText: null,
//                           border: InputBorder.none,
//                           hintText: 'FAX',
//                           hintStyle: TextStyle(
//                               color: AppTheme.getTheme().disabledColor),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             //Zippp
//
//             Padding(
//               padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//               child: Container(
//                 decoration: BoxDecoration(
//                   color: AppTheme.getTheme().backgroundColor,
//                   borderRadius: BorderRadius.all(Radius.circular(38)),
//                   // border: Border.all(
//                   //   color: HexColor("#757575").withOpacity(0.6),
//                   // ),
//                   boxShadow: <BoxShadow>[
//                     BoxShadow(
//                       color: AppTheme.getTheme().dividerColor,
//                       blurRadius: 8,
//                       offset: Offset(4, 4),
//                     ),
//                   ],
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.only(left: 16, right: 16),
//                   child: Container(
//                     height: 48,
//                     child: Center(
//                       child: TextFormField(
//                         controller: zipController,
//                         maxLines: 1,
//                         onChanged: (String txt) {},
//                         style: TextStyle(
//                           fontSize: 16,
//                         ),
//                         cursorColor: AppTheme.getTheme().primaryColor,
//                         decoration: new InputDecoration(
//                           errorText: null,
//                           border: InputBorder.none,
//                           hintText: 'Postal Code',
//                           hintStyle: TextStyle(
//                               color: AppTheme.getTheme().disabledColor),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//
//             //Passowrd
//
//             Padding(
//               padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//               child: Container(
//                 decoration: BoxDecoration(
//                   color: AppTheme.getTheme().backgroundColor,
//                   borderRadius: BorderRadius.all(Radius.circular(38)),
//                   // border: Border.all(
//                   //   color: HexColor("#757575").withOpacity(0.6),
//                   // ),
//                   boxShadow: <BoxShadow>[
//                     BoxShadow(
//                       color: AppTheme.getTheme().dividerColor,
//                       blurRadius: 8,
//                       offset: Offset(4, 4),
//                     ),
//                   ],
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.only(left: 16, right: 16),
//                   child: Container(
//                     height: 48,
//                     child: Center(
//                       child: TextFormField(
//                         controller: passwordController,
//                         maxLines: 1,
//                         onChanged: (String txt) {},
//                         style: TextStyle(
//                           fontSize: 16,
//                         ),
//                         cursorColor: AppTheme.getTheme().primaryColor,
//                         decoration: new InputDecoration(
//                           errorText: null,
//                           border: InputBorder.none,
//                           hintText: 'Password',
//                           hintStyle: TextStyle(
//                               color: AppTheme.getTheme().disabledColor),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//
//             //  Confirm  //Passowrd
//
//             Padding(
//               padding: const EdgeInsets.only(left: 24, right: 24, top: 15),
//               child: Container(
//                 decoration: BoxDecoration(
//                   color: AppTheme.getTheme().backgroundColor,
//                   borderRadius: BorderRadius.all(Radius.circular(38)),
//                   // border: Border.all(
//                   //   color: HexColor("#757575").withOpacity(0.6),
//                   // ),
//                   boxShadow: <BoxShadow>[
//                     BoxShadow(
//                       color: AppTheme.getTheme().dividerColor,
//                       blurRadius: 8,
//                       offset: Offset(4, 4),
//                     ),
//                   ],
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.only(left: 16, right: 16),
//                   child: Container(
//                     height: 48,
//                     child: Center(
//                       child: TextFormField(
//                         controller: confirmPasswordController,
//                         maxLines: 1,
//                         onChanged: (String txt) {},
//                         style: TextStyle(
//                           fontSize: 16,
//                         ),
//                         cursorColor: AppTheme.getTheme().primaryColor,
//                         decoration: new InputDecoration(
//                           errorText: null,
//                           border: InputBorder.none,
//                           hintText: 'Confirm Password',
//                           hintStyle: TextStyle(
//                               color: AppTheme.getTheme().disabledColor),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             SizedBox(
//               height: 30,
//             ),
//             Padding(
//               padding: const EdgeInsets.only(left: 50, right: 50, bottom: 30),
//               child: Container(
//                 height: 45,
//                 width: 230,
//                 child: isLoading
//                     ? Center(
//                   child: CircularProgressIndicator(
//                     valueColor:
//                     AlwaysStoppedAnimation(Colors.indigo[800]),
//                   ),
//                 )
//                     : RaisedButton(
//                   onPressed: () {
//                     if (imageFile == null) {
//                       return Fluttertoast.showToast(
//                           msg: "Please Select Image",
//                           toastLength: Toast.LENGTH_SHORT,
//                           gravity: ToastGravity.BOTTOM,
//                           timeInSecForIosWeb: 2,
//                           backgroundColor: Colors.indigo,
//                           textColor: Colors.white,
//                           fontSize: 16.0);
//                     } else {
//                       _uploadPhoto();
//                     }
//                     if (_key.currentState.validate()) {
//                       updateProfile();
//                     } else {
//                       setState(() {
//                         _autoValidate = true;
//                       });
//                     }
//                   },
//                   color: Colors.indigo[800],
//                   child: Text(
//                     "Update",
//                     style: TextStyle(fontSize: 15, color: Colors.white),
//                   ),
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(20),
//                   ),
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget bottomSheet() {
//     return ClipRRect(
//       borderRadius: BorderRadius.circular(25),
//       child: Container(
//         height: 100.0,
//         width: MediaQuery.of(context).size.width,
//         margin: EdgeInsets.symmetric(
//           horizontal: 20,
//           vertical: 20,
//         ),
//         child: Column(
//           children: <Widget>[
//             Text(
//               ('Choose Profile Photo'),
//               style: TextStyle(
//                 fontSize: 20.0,
//               ),
//             ),
//             SizedBox(
//               height: 20,
//             ),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: <Widget>[
//                 FlatButton.icon(
//                   icon: Icon(Icons.camera),
//                   onPressed: () {
//                     _openPhoto(context, ImageSource.camera);
//                     Navigator.pop(context);
//                   },
//                   label: Text("Camera"),
//                 ),
//                 FlatButton.icon(
//                   icon: Icon(Icons.image),
//                   onPressed: () {
//                     Navigator.pop(context);
//                     _openPhoto(context, ImageSource.gallery);
//                   },
//                   label: Text("Gallery"),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
