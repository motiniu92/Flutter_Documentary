// import 'dart:convert';
//
// import 'package:new_motel/model/profile_model.dart';
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
//
// class ProfileService {
//   List<ProfileData> userFromData(String jsonString) {
//     final data = json.decode(jsonString);
//     return List<ProfileData>.from(
//         data.map((item) => ProfileData.fromJson(item)));
//   }
//
//   Future<List<ProfileData>> getUser() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     String token = prefs.getString('apiToken');
//     Map<String, String> requestHeaders = {
//       'Content-type': 'application/json',
//       'Accept': 'application/json',
//       'authorization': token
//     };
//     final response = await http.get(
//       "https://deshitour.com/api/login/profile?appKey=DeshiTour",
//       headers: requestHeaders,
//     );
//     if (response.statusCode == 200) {
//       List<ProfileData> data = userFromData(response.body);
//       print(response.body);
//       return data;
//     } else {
//       return List<ProfileData>();
//     }
//   }
// }
