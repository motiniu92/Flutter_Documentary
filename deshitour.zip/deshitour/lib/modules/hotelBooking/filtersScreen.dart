import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:new_motel/models/hotelAmenities/filterAmenities.dart';
import 'package:new_motel/models/hotelAmenities/filterFun.dart';
import 'package:new_motel/models/hotelAmenities/filterProperty.dart';
import 'package:new_motel/models/hotelAmenities/starCount.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';

import '../../appTheme.dart';
import '../../loaderPage.dart';
import '../../models/popularFilterList.dart';
import 'RangeSliderView.dart';

class FiltersScreen extends StatefulWidget {
  @override
  _FiltersScreenState createState() => _FiltersScreenState();
}

class _FiltersScreenState extends State<FiltersScreen> {
  // ProgressBar _sendingMsgProgressBar=ProgressBar();
  List<PopularFilterListData> popularFilterListData =
      PopularFilterListData.popularFList;
  List<PopularFilterListData> accomodationListData =
      PopularFilterListData.accomodationList;
  List<StarCountListData> startListData = StarCountListData.starList;

  String starCount = "";
  String amenities = "";
  String funThings = "";
  String propertiesTypes = "";

  List<String> selectedAmenities = [];
  List<String> selectedFun = [];
  List<String> selectedPropertyTypes = [];
  int startSelectedRadio;

  RangeValues _values = RangeValues(100, 600);
  double distValue = 50.0;
  bool loading;
  List<AmenitiesResponse> _listAmenities;
  List<PropertyResponse> _listProperty;
  List<FunResponse> _listFun;

  Future<String> getJSONData() async {
    // showSendingProgressBar();
    loading = true;
    var response = await http
        .get("https://deshitour.com//api/hotels/amenities?appKey=DeshiTour");
    var response1 = await http
        .get("https://deshitour.com//api/hotels/property?appKey=DeshiTour");
    var response2 = await http
        .get("https://deshitour.com//api/hotels/funs?appKey=DeshiTour");
    setState(() {
      //hideSendingProgressBar();
      loading = false;
      _listAmenities =
          AmenitiesList.fromJson(json.decode(response.body)).response;
      _listProperty =
          PropertyList.fromJson(json.decode(response1.body)).response;
      _listFun = FunList.fromJson(json.decode(response2.body)).response;

      print("_listAmenities ${_listAmenities.length}");
      print("_listProperty ${_listProperty.length}");
      print("_listProperty ${_listFun.length}");
    });
    //print(data);
    return "data";
  }

  FilterData filterData;

  // void showSendingProgressBar() {
  //   _sendingMsgProgressBar.show(context);
  // }
  //
  // void hideSendingProgressBar() {
  //   _sendingMsgProgressBar.hide();
  // }

  @override
  void initState() {
    getJSONData();
    // _sendingMsgProgressBar = ProgressBar();
    super.initState();
    startSelectedRadio = 0;
  }

  setSelectedRdio(val) {
    setState(() {
      startSelectedRadio = val;
      starCount = "${startSelectedRadio}";
    });
  }

  @override
  Widget build(BuildContext context) {
    // filterData=FilterData(star: starCount, isSearch: 0);
    return SafeArea(
      child: Container(
        color: AppTheme.getTheme().backgroundColor,
        child: Scaffold(
          appBar: AppBar(
            leading: IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.black,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            backgroundColor: Colors.white,
            elevation: 1,
            title: RichText(
              text: TextSpan(
                  text: DESHI,
                  style: TextStyle(
                    fontSize: 30,
                    fontFamily: 'Impact',
                    color: HexColor("#26408A"),
                  ),
                  children: <TextSpan>[
                    TextSpan(
                        text: TOUR,
                        style: TextStyle(
                          fontSize: 30,
                          fontFamily: 'Impact',
                          color: HexColor("#118ACB"),
                        )),
                  ]),
            ),

            // RichText(
            //   text: TextSpan(
            //       text: Vromon,
            //       style: TextStyle(
            //         fontSize: 30,
            //         fontFamily: 'Impact',
            //         color: HexColor("#26408A"),
            //       ),
            //       children: <TextSpan>[
            //         TextSpan(
            //             text: TOUR,
            //             style: TextStyle(
            //               fontSize: 30,
            //               fontFamily: 'Impact',
            //               color: HexColor("#118ACB"),
            //             )),
            //       ]),
            // ),
          ),
          backgroundColor: Colors.transparent,
          body: loading
              ? Center(
                  child: LoaderPage(),
                )
              : new Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      child: SingleChildScrollView(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 16, right: 16),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.only(
                                    top: 18, left: 4, bottom: 06),
                                child: Text(
                                  FILTERS,
                                  style: new TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                              //   priceBarFilter(),
                              Divider(
                                height: 1,
                              ),
                              amenitiesFilter(),
                              // Divider(
                              //   height: 1,
                              // ),
                              // distanceViewUI(),
                              // Divider(
                              //   height: 1,
                              // ),
                              //  allAccommodationUI()
                            ],
                          ),
                        ),
                      ),
                    ),
                    // Divider(
                    //   height: 1,
                    // ),
                    Padding(
                      padding: EdgeInsets.only(
                          left: 16,
                          right: 16,
                          bottom: 16 + MediaQuery.of(context).padding.bottom,
                          top: 8),
                      child: Container(
                        height: 48,
                        decoration: BoxDecoration(
                          color: AppTheme.getTheme().primaryColor,
                          borderRadius: BorderRadius.all(Radius.circular(24.0)),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: AppTheme.getTheme().dividerColor,
                              blurRadius: 8,
                              offset: Offset(4, 4),
                            ),
                          ],
                        ),
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            borderRadius:
                                BorderRadius.all(Radius.circular(24.0)),
                            highlightColor: Colors.transparent,
                            onTap: () {
                              // Navigator.pop(context,filterData );

                              for (String id in selectedAmenities) {
                                if (amenities == "") {
                                  amenities = id;
                                } else {
                                  amenities = amenities + "," + id;
                                }
                              }

                              print("Amenities: $amenities");

                              for (String id in selectedFun) {
                                if (funThings == "") {
                                  funThings = id;
                                } else {
                                  funThings = funThings + "," + id;
                                }
                              }
                              print("funs: $funThings");

                              for (String id in selectedPropertyTypes) {
                                if (propertiesTypes == "") {
                                  propertiesTypes = id;
                                } else {
                                  propertiesTypes = propertiesTypes + "," + id;
                                }
                              }
                              print("propertiesTypes: $propertiesTypes");

                              Map<String, dynamic> yourMap = {
                                "star": starCount,
                                "amenities": amenities,
                                "type": propertiesTypes,
                                "funType": funThings,
                              };

                              Navigator.pop(context, yourMap);

                              // Navigator.push(
                              //   context,
                              //   MaterialPageRoute(
                              //       builder: (context) => HotelListHomeScreen(
                              //             from: FILTER_SEARCH,
                              //             isSearch: 0,
                              //             starCount: starCount,
                              //              amenities: amenities,
                              //             funtodoThing: funThings,
                              //         propertyType: propertiesTypes,
                              //           )),
                              // );
                            },
                            child: Center(
                              child: Text(
                                APPLY,
                                style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    fontSize: 18,
                                    color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  // Widget allAccommodationUI() {
  //   return Column(
  //     mainAxisAlignment: MainAxisAlignment.center,
  //     crossAxisAlignment: CrossAxisAlignment.start,
  //     children: <Widget>[
  //       Padding(
  //         padding:
  //             const EdgeInsets.only(left: 16, right: 16, top: 16, bottom: 8),
  //         child: Text(
  //           "Property Type",
  //           textAlign: TextAlign.left,
  //           style: TextStyle(
  //               color: Colors.grey,
  //               fontSize: MediaQuery.of(context).size.width > 360 ? 18 : 16,
  //               fontWeight: FontWeight.normal),
  //         ),
  //       ),
  //       Padding(
  //         padding: const EdgeInsets.only(right: 16, left: 16),
  //         child: Column(
  //           children: getAccomodationListUI(),
  //         ),
  //       ),
  //       SizedBox(
  //         height: 8,
  //       ),
  //     ],
  //   );
  // }

  // List<Widget> getAccomodationListUI() {
  //   var len;
  //   List<Widget> noList = List<Widget>();
  //   if(_listProperty!=null){
  //     len=_listProperty.length;
  //   }else{
  //     len=0;
  //   }
  //   for (var i = 0; i < len; i++) {
  //     final date = _listProperty[i];
  //     noList.add(
  //       Material(
  //         color: Colors.transparent,
  //         child: InkWell(
  //           borderRadius: BorderRadius.all(Radius.circular(4.0)),
  //           onTap: () {
  //             setState(() {
  //               checkAppPosition(i);
  //             });
  //           },
  //           child: Padding(
  //             padding: const EdgeInsets.all(8.0),
  //             child: Row(
  //               children: <Widget>[
  //                 Expanded(
  //                   child: Text(
  //                     date.settName,
  //                     // style: TextStyle(color: Colors.white),
  //                   ),
  //                 ),
  //                 CupertinoSwitch(
  //                   activeColor: date.isSelect
  //                       ? AppTheme.getTheme().primaryColor
  //                       : Colors.grey.withOpacity(0.6),
  //                   onChanged: (value) {
  //                     setState(() {
  //                       checkAppPosition(i);
  //                     });
  //                   },
  //                   value: date.isSelect,
  //                 ),
  //               ],
  //             ),
  //           ),
  //         ),
  //       ),
  //     );
  //     if (i == 0) {
  //       noList.add(Divider(
  //         height: 1,
  //       ));
  //     }
  //   }
  //   return noList;
  // }

  // void checkAppPosition(int index) {
  //   if (index == 0) {
  //     if (_listProperty[0].isSelect) {
  //       _listProperty.forEach((d) {
  //         d.isSelected = false;
  //       });
  //     } else {
  //       _listProperty.forEach((d) {
  //         d.isSelected = true;
  //       });
  //     }
  //   } else {
  //     _listProperty[index].isSelected = !_listProperty[index].isSelect;

  //     var count = 0;
  //     for (var i = 0; i < _listProperty.length; i++) {
  //       if (i != 0) {
  //         var data = _listProperty[i];
  //         if (data.isSelect) {
  //           count += 1;
  //         }
  //       }
  //     }
  //     if (count == _listProperty.length - 1) {
  //       _listProperty[0].isSelected = true;
  //     } else {
  //       _listProperty[0].isSelected = false;
  //     }
  //   }
  // }

  // Widget distanceViewUI() {
  //   return Column(
  //     mainAxisAlignment: MainAxisAlignment.center,
  //     crossAxisAlignment: CrossAxisAlignment.start,
  //     children: <Widget>[
  //       Padding(
  //         padding:
  //             const EdgeInsets.only(left: 16, right: 16, top: 16, bottom: 8),
  //         child: Text(
  //           DISTANCE_CITY,
  //           textAlign: TextAlign.left,
  //           style: TextStyle(
  //               color: Colors.grey,
  //               fontSize: MediaQuery.of(context).size.width > 360 ? 18 : 16,
  //               fontWeight: FontWeight.normal),
  //         ),
  //       ),
  //       SliderView(
  //         distValue: distValue,
  //         onChnagedistValue: (value) {
  //           distValue = value;
  //         },
  //       ),
  //       SizedBox(
  //         height: 8,
  //       ),
  //     ],
  //   );
  // }

  bool isAmenitiesAdded(String id) {
    bool isExist = false;
    for (String amId in selectedAmenities) {
      if (amId == id) {
        isExist = true;
        break;
      }
    }
    return isExist;
  }

  // Method PopularFilter Implimenting
  Widget amenitiesFilter() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding:
              const EdgeInsets.only(left: 8.0, right: 8.0, top: 16, bottom: 8),
          child: Text(
            "Amenities",
            textAlign: TextAlign.left,
            style: TextStyle(
                color: Colors.black,
                fontSize: MediaQuery.of(context).size.width > 360 ? 18 : 16,
                fontWeight: FontWeight.w500),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(8.0, 0, 0, 8.0),
          child: Column(
            children: getPList(),
          ),
        ),
        SizedBox(
          height: 8,
        ),
        Padding(
          padding:
              const EdgeInsets.only(left: 8.0, right: 8.0, top: 8.0, bottom: 8),
          child: Text(
            STAR_GRADE,
            textAlign: TextAlign.left,
            style: TextStyle(
                color: Colors.black,
                fontSize: MediaQuery.of(context).size.width > 360 ? 18 : 16,
                fontWeight: FontWeight.w500),
          ),
        ),
        Divider(
          height: 1,
        ),
        SizedBox(
          height: 8,
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 0.0),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(right: 23.0),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Radio(
                          value: 1,
                          groupValue: startSelectedRadio,
                          onChanged: (val) {
                            setSelectedRdio(val);
                          },
                        ),
                        Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: SmoothStarRating(
                            allowHalfRating: true,
                            starCount: 5,
                            rating: 1,
                            size: 20,
                            isReadOnly: true,
                            color: Colors.amberAccent,
                            borderColor: Colors.amberAccent,
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Radio(
                          value: 2,
                          groupValue: startSelectedRadio,
                          onChanged: (val) {
                            setSelectedRdio(val);
                          },
                        ),
                        Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: SmoothStarRating(
                            allowHalfRating: true,
                            starCount: 5,
                            rating: 2,
                            size: 20,
                            isReadOnly: true,
                            color: Colors.amberAccent,
                            borderColor: Colors.amberAccent,
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Radio(
                          value: 3,
                          groupValue: startSelectedRadio,
                          onChanged: (val) {
                            setSelectedRdio(val);
                          },
                        ),
                        Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: SmoothStarRating(
                            allowHalfRating: true,
                            starCount: 5,
                            rating: 3,
                            size: 20,
                            isReadOnly: true,
                            color: Colors.amberAccent,
                            borderColor: Colors.amberAccent,
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Radio(
                          value: 4,
                          groupValue: startSelectedRadio,
                          onChanged: (val) {
                            setSelectedRdio(val);
                          },
                        ),
                        Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: SmoothStarRating(
                            allowHalfRating: true,
                            starCount: 5,
                            rating: 4,
                            size: 20,
                            isReadOnly: true,
                            color: Colors.amberAccent,
                            borderColor: Colors.amberAccent,
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Radio(
                          value: 5,
                          groupValue: startSelectedRadio,
                          onChanged: (val) {
                            setSelectedRdio(val);
                          },
                        ),
                        Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: SmoothStarRating(
                            allowHalfRating: true,
                            starCount: 5,
                            rating: 5,
                            size: 20,
                            isReadOnly: true,
                            color: Colors.amberAccent,
                            borderColor: Colors.amberAccent,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Divider(
          height: 1,
        ),
        SizedBox(
          height: 8,
        ),
        Padding(
          padding:
              const EdgeInsets.only(left: 12, right: 16, top: 16, bottom: 8),
          child: Text(
            FUN_THINGS,
            textAlign: TextAlign.left,
            style: TextStyle(
                color: Colors.black,
                fontSize: MediaQuery.of(context).size.width > 360 ? 18 : 16,
                fontWeight: FontWeight.w500),
          ),
        ),
        SizedBox(
          height: 8,
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(8.0, 0, 0, 8.0),
          child: Column(
            children: getFunList(),
          ),
        ),
        SizedBox(
          height: 8,
        ),
        Divider(
          height: 1,
        ),
        Padding(
          padding:
              const EdgeInsets.only(left: 12, right: 16, top: 16, bottom: 8),
          child: Text(
            PROPERTY_TYPE,
            textAlign: TextAlign.left,
            style: TextStyle(
                color: Colors.black,
                fontSize: MediaQuery.of(context).size.width > 360 ? 18 : 16,
                fontWeight: FontWeight.w500),
          ),
        ),
        SizedBox(
          height: 8,
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(8.0, 0, 0, 8.0),
          child: Column(
            children: getPropertyList(),
          ),
        ),
        SizedBox(
          height: 8,
        )
      ],
    );
  }

  // Method getPList Implimenting
  List<Widget> getPList() {
    List<Widget> noList = List<Widget>();
    var len;
    if (_listAmenities != null) {
      len = _listAmenities.length;
    } else {
      len = 0;
    }

    var cout = 0;
    final columCount = 2;
    for (var i = 0; i < len / columCount; i++) {
      List<Widget> listUI = List<Widget>();
      for (var i = 0; i < columCount; i++) {
        try {
          final date = _listAmenities[cout];
          listUI.add(Expanded(
            flex: 2,
            child: Row(
              children: <Widget>[
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.all(Radius.circular(4.0)),
                    onTap: () {
                      setState(() {
                        date.isSelected = !date.isSelect;
                        if (isAmenitiesAdded(date.settId)) {
                          selectedAmenities.remove(date.settId);
                        } else {
                          selectedAmenities.add(date.settId);
                        }
                      });
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(2.0),
                      child: Row(
                        children: <Widget>[
                          Icon(
                            date.isSelect
                                ? Icons.check_box
                                : Icons.check_box_outline_blank,
                            color: date.isSelect
                                ? AppTheme.getTheme().primaryColor
                                : Colors.grey.withOpacity(0.6),
                          ),
                          SizedBox(
                            width: 0,
                          ),
                          Padding(
                              padding: EdgeInsets.all(0),
                              child: Text(
                                date.settName,
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.black,
                                ),
                              )),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ));
          cout += 1;
        } catch (e) {
          print(e);
        }
      }
      noList.add(Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: listUI,
      ));
    }
    return noList;
  }

  // getStarList Method Implimenting
  // List<Widget> getStarList() {
  //   List<Widget> noList = List<Widget>();
  //   var cout = 0;
  //   final columCount = 1;
  //   for (var i = 0; i < startListData.length; i++) {
  //     List<Widget> listUI = List<Widget>();
  //     for (var i = 0; i < columCount; i++) {
  //       try {
  //         final date = startListData[cout];
  //
  //         listUI.add(Expanded(
  //           child: Row(
  //             children: <Widget>[
  //               Material(
  //                 color: Colors.transparent,
  //                 child: InkWell(
  //                   borderRadius: BorderRadius.all(Radius.circular(4.0)),
  //                   onTap: () {
  //                     setState(() {
  //                       date.isSelected = !date.isSelected;
  //                       starCount = date.starCount;
  //                     });
  //                   },
  //                   child: Padding(
  //                     padding: const EdgeInsets.all(2.0),
  //                     child: Row(
  //                       children: <Widget>[
  //                         Icon(
  //                           date.isSelected
  //                               ? Icons.radio_button_checked
  //                               : Icons.radio_button_off,
  //                           color: date.isSelected
  //                               ? AppTheme.getTheme().primaryColor
  //                               : Colors.grey.withOpacity(0.6),
  //                         ),
  //                         SizedBox(
  //                           width: 4,
  //                         ),
  //                         SmoothStarRating(
  //                           allowHalfRating: true,
  //                           starCount: 5,
  //                           rating: double.parse(date.starCount ?? 0),
  //                           size: 20,
  //                           isReadOnly: true,
  //                           color: Colors.amberAccent,
  //                           borderColor: Colors.amberAccent,
  //                         ),
  //                       ],
  //                     ),
  //                   ),
  //                 ),
  //               ),
  //             ],
  //           ),
  //         ));
  //         cout += 1;
  //       } catch (e) {
  //         print(e);
  //       }
  //     }
  //     noList.add(Row(
  //       mainAxisAlignment: MainAxisAlignment.center,
  //       crossAxisAlignment: CrossAxisAlignment.center,
  //       mainAxisSize: MainAxisSize.min,
  //       children: listUI,
  //     ));
  //   }
  //   return noList;
  // }

  bool isFunAddedList(String id) {
    bool isExistsFun = false;
    for (String funId in selectedFun) {
      if (funId == id) {
        isExistsFun = true;
        break;
      }
    }
    return isExistsFun;
  }

  bool isPropertyTypeExists(String id) {
    bool isExists = false;
    for (String pId in selectedPropertyTypes) {
      if (pId == id) {
        isExists = true;
        break;
      }
    }
    return isExists;
  }

  List<Widget> getFunList() {
    var len;
    List<Widget> noList = List<Widget>();
    var cout = 0;
    final columCount = 1;
    if (_listFun != null) {
      //hideSendingProgressBar();
      len = _listFun.length;
    } else {
      // hideSendingProgressBar();
      len = 0;
    }
    for (var i = 0; i < len; i++) {
      List<Widget> listUI = List<Widget>();
      for (var i = 0; i < columCount; i++) {
        try {
          final date = _listFun[cout];
          listUI.add(Expanded(
            child: Row(
              children: <Widget>[
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.all(Radius.circular(4.0)),
                    onTap: () {
                      setState(() {
                        date.isSelected = !date.isSelect;
                        if (isFunAddedList(date.settId)) {
                          selectedFun.remove(date.settId);
                        } else {
                          selectedFun.add(date.settId);
                        }
                      });
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(2.0),
                      child: Row(
                        children: <Widget>[
                          Icon(
                            date.isSelect
                                ? Icons.check_box
                                : Icons.check_box_outline_blank,
                            color: date.isSelect
                                ? AppTheme.getTheme().primaryColor
                                : Colors.grey.withOpacity(0.6),
                          ),
                          SizedBox(
                            width: 4,
                          ),
                          Text(
                            date.settName,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ));
          cout += 1;
        } catch (e) {
          print(e);
        }
      }
      noList.add(Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: listUI,
      ));
    }
    return noList;
  }

  // Method getPropertyList Implimenting
  List<Widget> getPropertyList() {
    var len;
    List<Widget> noList = List<Widget>();
    var cout = 0;
    final columCount = 1;
    if (_listProperty != null) {
      //hideSendingProgressBar();
      len = _listProperty.length;
    } else {
      // hideSendingProgressBar();
      len = 0;
    }
    for (var i = 0; i < len; i++) {
      List<Widget> listUI = List<Widget>();
      for (var i = 0; i < columCount; i++) {
        try {
          final date = _listProperty[cout];
          listUI.add(Expanded(
            child: Row(
              children: <Widget>[
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.all(Radius.circular(4.0)),
                    onTap: () {
                      setState(() {
                        date.isSelected = !date.isSelect;
                        if (isPropertyTypeExists(date.settId)) {
                          selectedPropertyTypes.remove(date.settId);
                        } else {
                          selectedPropertyTypes.add(date.settId);
                        }
                      });
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(2.0),
                      child: Row(
                        children: <Widget>[
                          Icon(
                            date.isSelect
                                ? Icons.check_box
                                : Icons.check_box_outline_blank,
                            color: date.isSelect
                                ? AppTheme.getTheme().primaryColor
                                : Colors.grey.withOpacity(0.6),
                          ),
                          SizedBox(
                            width: 4,
                          ),
                          Text(
                            date.settName,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ));
          cout += 1;
        } catch (e) {
          print(e);
        }
      }
      noList.add(Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: listUI,
      ));
    }
    return noList;
  }

  // Method PriceBar Filter Implimenting
  Widget priceBarFilter() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            PRICE_NIGHT,
            textAlign: TextAlign.left,
            style: TextStyle(
                color: Colors.grey,
                fontSize: MediaQuery.of(context).size.width > 360 ? 18 : 16,
                fontWeight: FontWeight.normal),
          ),
        ),
        RangeSliderView(
          values: _values,
          onChnageRangeValues: (values) {
            _values = values;
          },
        ),
        SizedBox(
          height: 8,
        )
      ],
    );
  }

  Widget startBarFilter() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            PRICE_NIGHT,
            textAlign: TextAlign.left,
            style: TextStyle(
                color: Colors.grey,
                fontSize: MediaQuery.of(context).size.width > 360 ? 18 : 16,
                fontWeight: FontWeight.normal),
          ),
        ),
        RangeSliderView(
          values: _values,
          onChnageRangeValues: (values) {
            _values = values;
          },
        ),
        SizedBox(
          height: 8,
        )
      ],
    );
  }

  // Widget getAppBarUI() {
  //   return Container(
  //     decoration: BoxDecoration(
  //       color: AppTheme.getTheme().backgroundColor,
  //       boxShadow: <BoxShadow>[
  //         BoxShadow(color: Colors.grey.withOpacity(0.2), offset: Offset(0, 2), blurRadius: 4.0),
  //       ],
  //     ),
  //     child: Padding(
  //       padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top, left: 8, right: 8),
  //       child: Row(
  //         children: <Widget>[
  //           Container(
  //             alignment: Alignment.centerLeft,
  //             width: AppBar().preferredSize.height + 40,
  //             height: AppBar().preferredSize.height,
  //             child: Material(
  //               color: Colors.transparent,
  //               child: InkWell(
  //                 borderRadius: BorderRadius.all(
  //                   Radius.circular(32.0),
  //                 ),
  //                 onTap: () {
  //                   Navigator.pop(context);
  //                 },
  //                 child: Padding(
  //                   padding: const EdgeInsets.all(8.0),
  //                   child: Icon(Icons.close),
  //                 ),
  //               ),
  //             ),
  //           ),
  //           Expanded(
  //             child: Center(
  //               child: Text(
  //                 "Filters",
  //                 style: TextStyle(
  //                   fontWeight: FontWeight.w600,
  //                   fontSize: 22,
  //                 ),
  //               ),
  //             ),
  //           ),
  //           Container(
  //             width: AppBar().preferredSize.height + 40,
  //             height: AppBar().preferredSize.height,
  //           )
  //         ],
  //       ),
  //     ),
  //   );
  // }

  // Method AppBar Implements
  Widget appBar() {
    return Row(
      children: <Widget>[
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            SizedBox(
              height: AppBar().preferredSize.height,
              child: Padding(
                padding: EdgeInsets.only(top: 8, left: 8),
                child: Container(
                  width: AppBar().preferredSize.height - 8,
                  height: AppBar().preferredSize.height - 8,
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.all(
                        Radius.circular(32.0),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(Icons.close),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 4, left: 24, bottom: 16),
              child: Text(
                FILTERS,
                style: new TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class FilterData {
  int star;
  int isSearch;

  FilterData({this.star, this.isSearch});
}
