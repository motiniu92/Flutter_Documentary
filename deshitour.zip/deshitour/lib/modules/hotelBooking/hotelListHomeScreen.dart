import 'dart:async';
import 'dart:convert';
import 'dart:ui';

import 'package:autocomplete_textfield/autocomplete_textfield.dart';
import 'package:date_range_picker/date_range_picker.dart' as DateRagePicker;
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get_connect/http/src/response/response.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:new_motel/authenticating/login.dart';
import 'package:new_motel/global/custom_function.dart';
import 'package:new_motel/global/handle_error.dart';
import 'package:new_motel/global/internet_check_screen.dart';
import 'package:new_motel/global/locator.dart';
import 'package:new_motel/global/something_wrong_screen.dart';
import 'package:new_motel/models/home/home.dart';
import 'package:new_motel/models/hotelList/hotelList.dart';
import 'package:new_motel/modules/hotelDetailes/hotelDetailes.dart';
import 'package:new_motel/modules/profile/profile_page.dart';
import 'package:new_motel/service/apiService.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:new_motel/widget/customDrawer.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';

import '../../appTheme.dart';
import '../../loaderPage.dart';
import '../hotelBooking/roomPopupView.dart';
import '../hotelDetailes/roomBookingScreen.dart';
import 'filtersScreen.dart';
import 'hotelListView.dart';

var funcfileHomeHotel = locator<CustomFunction>();

class HotelListHomeScreen extends StatefulWidget {
  final String locaton_id;
  final String locaton_name;
  final String checkIn;
  final String checkOut;
  final int isSearch;
  final List<AllLocation> allLocation;
  final String starCount;
  final String amenities;
  final String funtodoThing;
  final String propertyType;
  final int locationId;
  final int location_property;
  final int room;
  final int adults;
  final int child;
  final int from;

  HotelListHomeScreen(
      {Key key,
      @required this.from,
      @required this.locaton_id,
      @required this.locaton_name,
      @required this.checkIn,
      @required this.checkOut,
      @required this.isSearch,
      @required this.allLocation,
      @required this.starCount,
      @required this.amenities,
      @required this.funtodoThing,
      @required this.propertyType,
      @required this.locationId,
      @required this.location_property,
      @required this.room,
      @required this.adults,
      @required this.child})
      : super(key: key);

  @override
  _HotelHomeScreenState createState() => _HotelHomeScreenState();
}

class _HotelHomeScreenState extends State<HotelListHomeScreen>
    with TickerProviderStateMixin {
  AnimationController animationController;
  AnimationController _animationController;

  AutoCompleteTextField searchTextField;
  GlobalKey<AutoCompleteTextFieldState<AllLocation>> key = new GlobalKey();

  //var hotelList = HotelListData.hotelList;
  List<HostelData> hotelList;
  List<Response> hotelList1;
  ScrollController scrollController = new ScrollController();
  int room = 0;
  int ad = 1;
  int child = 0;
  bool loading = false;
  DateTime _startDate = DateTime.now();
  DateTime _endDate = DateTime.now().add(Duration(days: 1));

  // DateTime startDate = DateTime.now();
  // DateTime endDate = DateTime.now().add(Duration(days: 5));

  bool isMap = false;

  final searchBarHieght = 158.0;
  final filterBarHieght = 52.0;
  FilterData data1;

  String location;
  String locationname;
  int isSearch = 1;
  String checkIn, checkOut, finalCheckIn, finalCheckout;

  String errorMsg;
  List<AllLocation> allLocation;
  FiltersScreen filtersScreen;
  HotelList hotel;

  var result;
  int star = 0;
  int days = 1;

  // int internet = 1;
  // int empty = 2;
  // int init = 3;
  // int other = 4;
  // int content = 5;
  // int error = 6;
  //
  // int type = 3;

  TextEditingController _controller = TextEditingController();

  Future displayDateRangePicker(BuildContext context) async {
    final List<DateTime> picked = await DateRagePicker.showDatePicker(
        context: context,
        initialFirstDate: _startDate,
        initialLastDate: _endDate,
        firstDate: new DateTime(DateTime.now().year - 50),
        lastDate: new DateTime(DateTime.now().year + 50));
    if (picked != null && picked.length == 2) {
      setState(() {
        _startDate = picked[0];
        _endDate = picked[1];
        finalCheckIn = getCheckInDate();
        finalCheckout = getCheckOutDate();
        Duration dur = _endDate.difference(_startDate);
        days = dur.inDays;
      });
    }
  }

  bool isLoading = false;
  //hotel List
  // ignore: missing_return
  Future<HomeHotelList> getJSONData() async {
    int res = 1;
    int errors = 2;
    int others = 3;

    String url = ApiService.hotelList;
    var response = await http.get(ApiService.hotelList);
    print("GetJson URL: $url");
    try {
      if (response.statusCode == 200) {
        setState(() {
          isLoading = true;
        });
        loading = true;
        hotel = HotelList.fromJson(json.decode(response.body));
        print("GET JSON LIST ${json.decode(response.body)}");
        print("GET JSON LIST ${json.encode(response.body)}");
        setState(() {
          hotelList = hotel.response;
        });

        print("getJSONDATA...>> $hotel}");
        //    _hotelListError = hotel.error;
        // var responseListener = HotelListResponseLitener(res, "", hotel);
        // setState(() {});

        //return "response";

        var responseListener = HomeHotelList(res, "", hotel);

        return responseListener;
      } else {
        var responseListener =
            HomeHotelList(errors, "Something went wrong!", null);
        return responseListener;
      }
    } catch (e) {
      var responseListener =
          HomeHotelList(others, "Something went wrong!", null);
      return responseListener;
    }
  }

  //search list
  Future<String> getSearchJSONData(
      String location, String checkIn, String checkOut) async {
    //loading = true;
    String url = ApiService.hotelSearch +
        "&checkin=$checkIn&checkout=$checkOut&searching=$location";
    var response = await http.get(url);
    print("Search URL: $url");
    setState(() {
      //loading = false;
      hotel = HotelList.fromJson(json.decode(response.body));
      print("getSearchJSONData ${json.decode(response.body)}");
      print("getSearchJSONData ${json.encode(response.body)}");
      hotelList = hotel.response;
      //print("getSearchJSONData JsonData...> $hotel");
      // Get the JSON data
      return 'response';
      // hotelList=homeData.response;
    });
  }

  //location wise search
  Future<String> getLocationJSONData(int location) async {
    //loading = true;
    String url = ApiService.homeLocation + "&loc_id=$location";
    var response = await http.get(url);
    print("Location URL:  $url");
    setState(() {
      //loading = false;
      hotel = HotelList.fromJson(json.decode(response.body));
      print("getLocationJSONData ${json.decode(response.body)}");
      print("getLocationJSONData ${json.encode(response.body)}");
      hotelList = hotel.response;

      return 'response';
      // Get the JSON data

      // hotelList=homeData.response;
    });
  }

  //  HotelsFilter JsonData
  Future<String> getHotelsFilterData(
      String stars,
      String checkIn,
      String checkOut,
      String amenities,
      String propertiesTypes,
      String funThings,
      String location) async {
    //loading = true;
    String url = ApiService.hotelsFilter +
        "&checkin=$checkIn&checkout=$checkOut&loc_id=" +
        location;
    // ignore: unrelated_type_equality_checks
    if (stars != "") {
      url = url + "&stars=$stars";
    }
    if (amenities != "") {
      url = url + "&amenities=$amenities";
    }
    if (propertiesTypes != "") {
      url = url + "&type=$propertiesTypes";
    }
    if (funThings != "") {
      url = url + "&f_type=$funThings";
    }

    print("URL:  $url");
    var response = await http.get(url);

    // print("GET Hotel Filter Data Request...>$jsonList");
    // print("GET Hotel Filter Data Response...>${response.body}");

    setState(() {
      //loading = false;
      hotel = HotelList.fromJson(json.decode(response.body));

      print("getHotelsFilterData ${json.decode(response.body)}");
      print("getHotelsFilterData ${json.encode(response.body)}");
      hotelList = hotel.response;
      print("GetHotelFilterData  $hotel");
      return 'response';
      // hotelList=homeData.response;
    });
  }

  String token;
  String profile;

  Future<String> getToken() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    print("TOkennn...$token");
    token = sharedPreferences.getString("token");
    profile = sharedPreferences.getString("photo");
    setState(() {});
  }

  Future<bool> internetcheck() async {
    bool isConnected = false;
    var theInternet = await funcfileHomeHotel.isInternet();
    var theInternet2 = await funcfileHomeHotel.checkInternetAccess();

    if (theInternet && theInternet2) {
      isConnected = true;
    }
    return isConnected;
  }

  int TYPE = 3;
  bool connected = false;
  Timer timer;
  var _scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  void initState() {
    setState(() {
      TYPE = INIT;
    });

    internetcheck().then((value) {
      if (value) {
        getJSONData().then((value) {
          if (value.type == 1) {
            if (value.hotel.response.isEmpty) {
              TYPE = EMPTY;
            } else {
              TYPE = CONTENT;
            }
          } else {
            TYPE = ERROR;
          }
        });
      } else {
        TYPE = INTERNETEE;
      }
    });
    getToken();
    getDaValue();
    getSearchApi();
    getJSONData();
    finalCheckIn = getCheckInDate();
    finalCheckout = getCheckOutDate();

    print("final check in  $finalCheckIn");
    print("final check out $finalCheckout");

    //
    // if (widget.from == HOME_SEARCH){
    //   LOCATION_SEARCH =
    // }

    Duration dur = _endDate.difference(_startDate);
    days = dur.inDays;

    print("Init state: Days: $days");

    animationController = AnimationController(
        duration: Duration(milliseconds: 1000), vsync: this);
    _animationController =
        AnimationController(duration: Duration(milliseconds: 0), vsync: this);
    scrollController.addListener(() {
      if (context != null) {
        if (scrollController.offset <= 0) {
          _animationController.animateTo(0.0);
        } else if (scrollController.offset > 0.0 &&
            scrollController.offset < searchBarHieght) {
          // we need around searchBarHieght scrolling values in 0.0 to 1.0
          _animationController
              .animateTo((scrollController.offset / searchBarHieght));
        } else {
          _animationController.animateTo(1.0);
        }
      }
    });

    super.initState();
    setState(() {});
  }

  @override
  void dispose() {
    timer?.cancel();
    animationController.dispose();

    super.dispose();
  }

  Future<bool> getData() async {
    await Future.delayed(const Duration(milliseconds: 200));
    return true;
  }

  Widget hotelListScreen(int type) {
    if (type == INIT) {
      return Center(
        child: LoaderPage(msg: ""),
      );
    } else {
      if (type == CONTENT) {
        return Stack(
          children: <Widget>[
            InkWell(
              splashColor: Colors.transparent,
              focusColor: Colors.transparent,
              highlightColor: Colors.transparent,
              hoverColor: Colors.transparent,
              onTap: () {
                FocusScope.of(context).requestFocus(FocusNode());
              },
              child: hotelList == null
                  ? Center(child: LoaderPage())
                  : Column(
                      children: <Widget>[
                        // getAppBarUI(),
                        isMap
                            ? Expanded(
                                child: Column(
                                  children: <Widget>[
                                    getSearchBarUI(),
                                    getTimeDateUI(),
                                    Expanded(
                                      child: Stack(
                                        children: <Widget>[
                                              SizedBox(
                                                width: MediaQuery.of(context)
                                                    .size
                                                    .width,
                                                child: Image.asset(
                                                  "assets/images/mapImage.png",
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                              Container(
                                                height: 80,
                                                decoration: BoxDecoration(
                                                  gradient: LinearGradient(
                                                    colors: [
                                                      AppTheme.getTheme()
                                                          .scaffoldBackgroundColor
                                                          .withOpacity(1.0),
                                                      AppTheme.getTheme()
                                                          .scaffoldBackgroundColor
                                                          .withOpacity(0.0),
                                                    ],
                                                    begin: Alignment.topCenter,
                                                    end: Alignment.bottomCenter,
                                                  ),
                                                ),
                                              ),
                                            ] +
                                            getMapPinUI() +
                                            [
                                              Positioned(
                                                bottom: 0,
                                                right: 0,
                                                left: 0,
                                                child: Container(
                                                  height: 156,
                                                  // color: Colors.green,
                                                  child: ListView.builder(
                                                    itemCount: hotelList.length,
                                                    padding: EdgeInsets.only(
                                                        top: 8,
                                                        bottom: 8,
                                                        right: 16),
                                                    scrollDirection:
                                                        Axis.horizontal,
                                                    itemBuilder:
                                                        (context, index) {
                                                      return MapHotelListView(
                                                        callback: () {
                                                          Navigator.push(
                                                            context,
                                                            MaterialPageRoute(
                                                              builder: (context) =>
                                                                  RoomBookingScreen(
                                                                days: days,
                                                                hotelName:
                                                                    hotelList[
                                                                            index]
                                                                        .title,
                                                              ),
                                                            ),
                                                          );
                                                        },
                                                        hotelData:
                                                            hotelList[index],
                                                      );
                                                    },
                                                  ),
                                                ),
                                              ),
                                            ],
                                      ),
                                    )
                                  ],
                                ),
                              )
                            : Expanded(
                                child: Stack(
                                  children: <Widget>[
                                    Container(
                                      color:
                                          AppTheme.getTheme().backgroundColor,
                                      child: hotelList.length == 0
                                          ? Center(
                                              child: dataNOtAvailable(
                                                  hotel.error.msg),
                                            )
                                          : ListView.builder(
                                              controller: scrollController,
                                              itemCount: hotelList.length,
                                              padding: EdgeInsets.only(
                                                top: 8 + 180 + 52.0,
                                              ),
                                              scrollDirection: Axis.vertical,
                                              itemBuilder: (context, index) {
                                                var count =
                                                    hotelList.length > 10
                                                        ? 10
                                                        : hotelList.length;
                                                var animation = Tween(
                                                        begin: 0.0, end: 1.0)
                                                    .animate(CurvedAnimation(
                                                        parent:
                                                            animationController,
                                                        curve: Interval(
                                                            (1 / count) * index,
                                                            1.0,
                                                            curve: Curves
                                                                .fastOutSlowIn)));
                                                animationController.forward();
                                                print("Index= $index");
                                                return HotelListView(
                                                  callback: () {
                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                        builder: (context) =>
                                                            HotelDetailes(
                                                          hotel:
                                                              hotelList[index]
                                                                  .id,
                                                          days: days,
                                                          relatedItems: null,
                                                        ),
                                                      ),
                                                    );
                                                  },
                                                  hotelData: hotelList[index],
                                                  days: days,
                                                  animation: animation,
                                                  animationController:
                                                      _animationController,
                                                );
                                              },
                                            ),
                                    ),
                                    AnimatedBuilder(
                                      animation: _animationController,
                                      builder:
                                          (BuildContext context, Widget child) {
                                        return Positioned(
                                          top: -searchBarHieght *
                                              (_animationController.value),
                                          left: 0,
                                          right: 0,
                                          child: Column(
                                            children: <Widget>[
                                              Container(
                                                color: AppTheme.getTheme()
                                                    .scaffoldBackgroundColor,
                                                child: Column(
                                                  children: <Widget>[
                                                    getSearchBarUI(),
                                                    getTimeDateUI(),
                                                  ],
                                                ),
                                              ),
                                              getFilterBarUI(),
                                            ],
                                          ),
                                        );
                                      },
                                    ),
                                  ],
                                ),
                              )
                      ],
                    ),
            ),
          ],
        );
      } else {
        if (type == ERROR) {
          return SomethingWentWrongPage();
        } else {
          if (type == INTERNETEE) {
            return InternetException();
          }
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    //  print(widget.locationId);
    // print(

    // print(" start ${data}");
    // getJSONData();
    _controller.text = locationname;
    return SafeArea(
      child: Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          actions: [
            InkWell(
              onTap: () async {
                SharedPreferences sharedPreferences =
                    await SharedPreferences.getInstance();
                String token = sharedPreferences.getString("token");

                if (token == null) {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => LoginWidget()));
                } else {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ProfilePage(),
                      fullscreenDialog: true,
                    ),
                  );
                }
              },
              child: Padding(
                padding: const EdgeInsets.only(right: 20),
                child: CircleAvatar(
                  backgroundColor: Colors.grey[600],
                  radius: 20.0,
                  child: Center(
                    child: CircleAvatar(
                      backgroundColor: Colors.white,
                      radius: 17.0,
                      backgroundImage: profile == null
                          ? AssetImage("assets/images/person.png")
                          : NetworkImage("https://deshitour.com/" + profile),
                    ),
                  ),
                ),
              ),
            )
          ],
          iconTheme: IconThemeData(color: Colors.black),
          title: RichText(
            text: TextSpan(
                text: DESHI,
                style: TextStyle(
                  fontSize: 30,
                  fontFamily: 'Impact',
                  color: HexColor("#26408A"),
                ),
                children: <TextSpan>[
                  TextSpan(
                      text: TOUR,
                      style: TextStyle(
                        fontSize: 30,
                        fontFamily: 'Impact',
                        color: HexColor("#118ACB"),
                      )),
                ]),
          ),
          // RichText(
          //   text: TextSpan(
          //       text: Vromon,
          //       style: TextStyle(
          //         fontSize: 30,
          //         fontFamily: 'Impact',
          //         color: HexColor("#26408A"),
          //       ),
          //       children: <TextSpan>[
          //         TextSpan(
          //             text: TOUR,
          //             style: TextStyle(
          //               fontSize: 30,
          //               fontFamily: 'Impact',
          //               color: HexColor("#118ACB"),
          //             )),
          //       ]),
          // ),
          backgroundColor: Colors.white,
          elevation: 1,
        ),
        drawer: widget.from == HOME_SEARCH || widget.from == POPULAR_SEARCH
            ? null
            : CustomDrawer(),
        backgroundColor: Colors.white,
        body: hotelListScreen(TYPE),
      ),
    );
  }

  Widget dataNOtAvailable(String item) {
    return Container(
      height: 40,
      child: new Center(
        child: Text(
          item,
          style: TextStyle(
              color: Colors.red, fontWeight: FontWeight.bold, fontSize: 25),
        ),
      ),
    );
  }

  List<Widget> getMapPinUI() {
    List<Widget> list = List<Widget>();

    for (var i = 0; i < hotelList.length; i++) {
      double top;
      double left;
      double right;
      double bottom;
      if (i == 0) {
        top = 150;
        left = 50;
      } else if (i == 1) {
        top = 50;
        right = 50;
      } else if (i == 2) {
        top = 40;
        left = 10;
      } else if (i == 3) {
        bottom = 260;
        right = 140;
      } else if (i == 4) {
        bottom = 160;
        right = 20;
      }
      list.add(
        Positioned(
          top: top,
          left: left,
          right: right,
          bottom: bottom,
          child: Container(
            decoration: BoxDecoration(
              // color: hotelList[i].isSelected
              //     ? AppTheme.getTheme().primaryColor
              //     : AppTheme.getTheme().backgroundColor,
              borderRadius: BorderRadius.all(Radius.circular(24.0)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: AppTheme.getTheme().dividerColor,
                  blurRadius: 16,
                  offset: Offset(4, 4),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.all(Radius.circular(24.0)),
                onTap: () {
                  // if (hotelList[i].isSelected == false) {
                  //   setState(() {
                  //     hotelList.forEach((f) {
                  //       f.isSelected = false;
                  //     });
                  //     hotelList[i].isSelected = true;
                  //   });
                  // }
                },
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 16, right: 16, top: 8, bottom: 8),
                  child: Text(
                    "${hotelList[i].currCode} ${hotelList[i].price}",
                    style: TextStyle(
                        // color: hotelList[i].isSelected
                        //     ? AppTheme.getTheme().backgroundColor
                        //     : AppTheme.getTheme().primaryColor,
                        fontSize: 18,
                        fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    }
    return list;
  }

  Widget getListUI() {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.getTheme().backgroundColor,
        boxShadow: <BoxShadow>[
          BoxShadow(
              color: AppTheme.getTheme().dividerColor,
              offset: Offset(0, -2),
              blurRadius: 8.0),
        ],
      ),
      child: Column(
        children: <Widget>[
          Container(
            height: MediaQuery.of(context).size.height - 156 - 50,
            child: FutureBuilder(
              future: getData(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return SizedBox();
                } else {
                  return ListView.builder(
                    itemCount: hotelList.length,
                    scrollDirection: Axis.vertical,
                    itemBuilder: (context, index) {
                      var count = hotelList.length > 10 ? 10 : hotelList.length;
                      var animation = Tween(begin: 0.0, end: 1.0).animate(
                          CurvedAnimation(
                              parent: animationController,
                              curve: Interval((1 / count) * index, 1.0,
                                  curve: Curves.fastOutSlowIn)));
                      animationController.forward();
                      return HotelListView(
                        callback: () {},
                        hotelData: hotelList[index],
                        days: days,
                        animation: animation,
                        animationController: animationController,
                      );
                    },
                  );
                }
              },
            ),
          )
        ],
      ),
    );
  }

  // hotel List
  Widget getHotelViewList() {
    List<Widget> hotelListViews = List<Widget>();
    for (var i = 0; i < hotelList.length; i++) {
      var count = hotelList.length;
      var animation = Tween(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(
          parent: animationController,
          curve: Interval((1 / count) * i, 1.0, curve: Curves.fastOutSlowIn),
        ),
      );
      hotelListViews.add(
        HotelListView(
          callback: () {},
          hotelData: hotelList[i],
          days: days,
          animation: animation,
          animationController: animationController,
        ),
      );
    }
    animationController.forward();
    return Column(
      children: hotelListViews,
    );
  }

  //choose time & date
  Widget getTimeDateUI() {
    // final f = new DateFormat('MM/dd/yyyy');
    // checkIn = f.format(startDate);
    // checkOut = f.format(endDate);
    return Padding(
      padding: const EdgeInsets.only(
        left: 18,
        bottom: 45,
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Row(
              children: <Widget>[
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    focusColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    hoverColor: Colors.transparent,
                    splashColor: Colors.grey.withOpacity(0.2),
                    borderRadius: BorderRadius.all(
                      Radius.circular(4.0),
                    ),
                    onTap: () {
                      //FocusScope.of(context).requestFocus(FocusNode());
                      // showDemoDialog(context: context);
                      displayDateRangePicker(context);
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(4),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            CHOOSE_DATE,
                            style: TextStyle(
                                fontWeight: FontWeight.w100,
                                fontSize: 16,
                                color: Colors.grey.withOpacity(0.8)),
                          ),
                          SizedBox(
                            height: 8,
                          ),
                          Text(
                            "${DateFormat("dd, MMM").format(_startDate)} - ${DateFormat("dd, MMM").format(_endDate)}",
                            // getCheckInDate() + "-" + getCheckOutDate(),
                            style: TextStyle(fontSize: 16, color: Colors.black),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              right: 8,
            ),
            child: Container(
              width: 1,
              height: 42,
              color: Colors.grey.withOpacity(0.8),
            ),
          ),
          Expanded(
            child: Row(
              children: <Widget>[
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    focusColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    hoverColor: Colors.transparent,
                    splashColor: Colors.grey.withOpacity(0.2),
                    borderRadius: BorderRadius.all(
                      Radius.circular(4.0),
                    ),
                    onTap: () {
                      FocusScope.of(context).requestFocus(FocusNode());
                      showDialog(
                        context: context,
                        builder: (BuildContext context) => RoomPopupView(
                          ad: ad,
                          room: room,
                          ch: child,
                          barrierDismissible: true,
                          onChnage: (ro, a, c) {
                            setState(() {
                              room = ro;
                              ad = a;
                              child = c;
                            });
                          },
                        ),
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(4),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            NUMBER_OF_ROOMS,
                            style: TextStyle(
                                fontWeight: FontWeight.w100,
                                fontSize: 16,
                                color: Colors.grey),
                          ),
                          SizedBox(
                            height: 8,
                          ),
                          Padding(
                            padding: const EdgeInsets.all(4),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  "${ad ?? 0} $ADULTS - ${child ?? 0} $CHILDREN",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.black),
                                ),
                              ],
                            ),
                          )
                          // Text(
                          //   "$room $ROOM - $ad $ADULTS - $child $CHILDREN",
                          //   style: TextStyle(
                          //     fontWeight: FontWeight.w100,
                          //     fontSize: 16,
                          //   ),
                          // ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // search bar Method15/02/2021
  Widget getSearchBarUI() {
    return Padding(
      padding: const EdgeInsets.only(left: 16, right: 16, top: 8, bottom: 8),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(right: 16, top: 8, bottom: 8),
              child: Container(
                decoration: BoxDecoration(
                  color: AppTheme.getTheme().backgroundColor,
                  borderRadius: BorderRadius.all(
                    Radius.circular(38.0),
                  ),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                        color: AppTheme.getTheme().dividerColor,
                        offset: Offset(0, 2),
                        blurRadius: 8.0),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 16, right: 16, top: 4, bottom: 4),
                  child:
                      // TextField(
                      //   onChanged: (String txt) {},
                      //   onTap: () {
                      //     FocusScope.of(context).requestFocus(FocusNode());
                      //     Navigator.push(
                      //       context,
                      //       MaterialPageRoute(
                      //           builder: (context) => SearchScreen(),
                      //           fullscreenDialog: true),
                      //     );
                      //   },
                      //   style: TextStyle(
                      //     fontSize: 18,
                      //   ),
                      //   cursorColor: AppTheme.getTheme().primaryColor,
                      //   decoration: new InputDecoration(
                      //     border: InputBorder.none,
                      //     hintText: location_name ?? LOCATION_SEARCH,
                      //   ),
                      // ),
                      searchTextField = AutoCompleteTextField<AllLocation>(
                    key: key,
                    clearOnSubmit: false,
                    suggestions: allLocation,
                    controller: _controller,
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 16.0,
                        fontWeight: FontWeight.bold),
                    // decoration: InputDecoration(
                    //   // border: new OutlineInputBorder(
                    //   //   borderRadius: const BorderRadius.all(
                    //   //     const Radius.circular(10.0),
                    //   //   ),
                    //   // ),
                    //   border: OutlineInputBorder(
                    //     borderRadius: BorderRadius.circular(8),
                    //     borderSide: BorderSide(
                    //       width: 0,
                    //       style: BorderStyle.none,
                    //     ),
                    //   ),
                    //   filled: true,
                    //   contentPadding: EdgeInsets.all(16),
                    //   fillColor: Colors.grey,
                    //  // contentPadding: EdgeInsets.fromLTRB(30.0, 30.0, 30.0, 20.0),
                    //   hintText: "Search Name",
                    //   hintStyle: new TextStyle(color: Colors.white),
                    // ),

                    decoration: new InputDecoration(
                      prefixIcon: Icon(
                        Icons.search,
                        color: Colors.grey,
                        size: 20,
                      ),
                      hintText: locationname,
                      // widget.locaton_name ?? LOCATION_SEARCH
                      hintStyle: new TextStyle(color: Colors.black26),
                      enabledBorder: InputBorder.none,
                      disabledBorder: InputBorder.none,
                      // focusedBorder: OutlineInputBorder(
                      //   borderRadius: BorderRadius.all(Radius.circular(4.0)),
                      //   borderSide: BorderSide(color: Colors.blue),
                      // ),
                    ),
                    itemFilter: (item, query) {
                      return item.location
                          .toLowerCase()
                          .startsWith(query.toLowerCase());
                    },
                    itemSorter: (a, b) {
                      return a.location.compareTo(b.location);
                    },
                    itemSubmitted: (item) {
                      setState(() {
                        searchTextField.textField.controller.text =
                            item.location;
                        location = item.id;
                        locationname = item.location;
                        // Location().locationId=location_id;
                        // Location().locaton_name =location_name;

                        print("Location  Id -> ${item.id}");
                      });
                    },
                    itemBuilder: (context, item) {
                      // ui for the autocompelete row
                      return row(item);
                    },
                  ),
                ),
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: AppTheme.getTheme().primaryColor,
              borderRadius: BorderRadius.all(
                Radius.circular(38.0),
              ),
              boxShadow: <BoxShadow>[
                BoxShadow(
                    color: AppTheme.getTheme().dividerColor,
                    offset: Offset(0, 2),
                    blurRadius: 8.0),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.all(
                  Radius.circular(32.0),
                ),
                onTap: () {
                  isSearch = HOME_SEARCH;
                  FocusScope.of(context).requestFocus(FocusNode());
                  if (location != 0) {
                    getSearchApi();
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //       builder: (context) => HotelListHomeScreen(
                    //           locaton_id: location,
                    //           locaton_name: locationname,
                    //           checkIn: checkIn,
                    //           checkOut: checkOut,
                    //           isSearch: 1,
                    //           allLocation: allLocation),
                    //       fullscreenDialog: true),
                    // );
                  } else {
                    Fluttertoast.showToast(
                        msg: ('Please Select Your Location!'),
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.BOTTOM,
                        timeInSecForIosWeb: 2,
                        backgroundColor: Colors.indigo[800],
                        textColor: Colors.white,
                        fontSize: 16.0);
                  }
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Icon(FontAwesomeIcons.search,
                      size: 20, color: AppTheme.getTheme().backgroundColor),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  //Row Method
  Widget row(AllLocation item) {
    return Container(
      height: 40,
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
              item != null ? item.location : LOCATION_NOT_FOUND,
              style: TextStyle(fontSize: 18.0, color: Colors.black),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(item != null ? item.country : " ",
                style: TextStyle(
                  fontSize: 18.0,
                  color: Colors.black,
                )),
          )
        ],
      ),
    );
  }

  Widget getFilterBarUI() {
    return Stack(
      children: <Widget>[
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          child: Container(
            height: 24,
            decoration: BoxDecoration(
              color: AppTheme.getTheme().backgroundColor,
              boxShadow: <BoxShadow>[
                BoxShadow(
                    color: AppTheme.getTheme().dividerColor,
                    offset: Offset(0, -2),
                    blurRadius: 8.0),
              ],
            ),
          ),
        ),
        Container(
          color: AppTheme.getTheme().backgroundColor,
          child: Padding(
            padding:
                const EdgeInsets.only(left: 16, right: 16, top: 8, bottom: 4),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      "${hotelList.length ?? hotel.error.msg} $EXPLORE_HOTEL ",
                      style: TextStyle(
                        fontWeight: FontWeight.w100,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ),
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    focusColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    hoverColor: Colors.transparent,
                    splashColor: Colors.grey.withOpacity(0.2),
                    borderRadius: BorderRadius.all(
                      Radius.circular(4.0),
                    ),
                    onTap: () {
                      FocusScope.of(context).requestFocus(FocusNode());
                      _navigateAndDisplaySelection(context);

                      // Navigator.push(
                      //   context,
                      //   // Create the SelectionScreen in the next step.
                      //   MaterialPageRoute(
                      //       builder: (context) => FiltersScreen(),
                      //       fullscreenDialog: true),
                      // );
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8),
                      child: Row(
                        children: <Widget>[
                          Text(
                            FILTER,
                            style: TextStyle(
                              fontWeight: FontWeight.w100,
                              fontSize: 16,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Icon(Icons.sort,
                                color: AppTheme.getTheme().primaryColor),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          child: Divider(
            height: 1,
          ),
        )
      ],
    );
  }

//   _navigateAndDisplaySelection(BuildContext context) async {
//     // Navigator.push returns a Future that completes after calling
//     // Navigator.pop on the Selection Screen.
// //     final data = await Navigator.push(
// //       context,
// //       // Create the SelectionScreen in the next step.
// //       MaterialPageRoute(builder: (context) => FiltersScreen(),
// //           fullscreenDialog: true),
// //     ) as FilterData;
// //    //  star = data.star;
// //    // isSearch = data.isSearch;
// //     final snackBar = SnackBar(content: Text("${star} ${isSearch}"));
// //
// // // Find the Scaffold in the widget tree and use it to show a SnackBar.
// //     Scaffold.of(context).showSnackBar(snackBar);
//     // data1.text = dataFromSecondPage.text;
//   }

  _navigateAndDisplaySelection(BuildContext context) async {
    // Navigator.push returns a Future that completes after calling
    // Navigator.pop on the Selection Screen.
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => FiltersScreen()),
    );
    Map<String, dynamic> data = result;

    debugPrint(" hotel star: ${data['star']}");
    debugPrint("hotel amenities: ${data['amenities']}");
    debugPrint("hotel amenities: ${data['amenities']}");

    String star = data['star'];
    String amenities = data['amenities'];
    String fun = data['funType'];
    String type = data['type'];

    getHotelsFilterData(
        star, checkIn, checkOut, amenities, type, fun, location);
  }

  //Calender dialog
  void showDemoDialog({BuildContext context}) {
    showDialog(
      context: context,
      builder: (BuildContext context) => getTimeDateUI(),
    );
  }

  // Widget getAppBarUI() {
  //   return Container(
  //     decoration: BoxDecoration(
  //       color: AppTheme.getTheme().backgroundColor,
  //       boxShadow: <BoxShadow>[
  //         BoxShadow(
  //             color: AppTheme.getTheme().dividerColor,
  //             offset: Offset(0, 2),
  //             blurRadius: 8.0),
  //       ],
  //     ),
  //     child: Padding(
  //       padding: EdgeInsets.only(
  //           top: MediaQuery.of(context).padding.top, left: 8, right: 8),
  //       child: Row(
  //         children: <Widget>[
  //           Container(
  //             alignment: Alignment.centerLeft,
  //             width: AppBar().preferredSize.height + 40,
  //             height: AppBar().preferredSize.height,
  //             child: Material(
  //               color: Colors.transparent,
  //               child: InkWell(
  //                 borderRadius: BorderRadius.all(
  //                   Radius.circular(32.0),
  //                 ),
  //                 onTap: () {
  //                   Navigator.pushNamedAndRemoveUntil(context, Routes.TabScreen,
  //                       (Route<dynamic> route) => false);
  //                 },
  //                 child: Padding(
  //                   padding: const EdgeInsets.all(8.0),
  //                   child: Icon(Icons.arrow_back),
  //                 ),
  //               ),
  //             ),
  //           ),
  //
  //           // //Expanded(
  //           //   child: Center(
  //           //     child: Text(
  //           //       "",
  //           //       style: TextStyle(
  //           //         fontWeight: FontWeight.w600,
  //           //         fontSize: 22,
  //           //       ),
  //           //     ),
  //           //   ),
  //           // ),
  //           // Container(
  //           //   width: AppBar().preferredSize.height + 40,
  //           //   height: AppBar().preferredSize.height,
  //           //   child: Row(
  //           //     crossAxisAlignment: CrossAxisAlignment.center,
  //           //     mainAxisAlignment: MainAxisAlignment.end,
  //           //     children: <Widget>[
  //           //       Material(
  //           //         color: Colors.transparent,
  //           //         child: InkWell(
  //           //           borderRadius: BorderRadius.all(
  //           //             Radius.circular(32.0),
  //           //           ),
  //           //           onTap: () {},
  //           //           child: Padding(
  //           //             padding: const EdgeInsets.all(8.0),
  //           //             child: Icon(Icons.favorite_border),
  //           //           ),
  //           //         ),
  //           //       ),
  //           //       // Material(
  //           //       //   color: Colors.transparent,
  //           //       //   child: InkWell(
  //           //       //     borderRadius: BorderRadius.all(
  //           //       //       Radius.circular(32.0),
  //           //       //     ),
  //           //       //     onTap: () {
  //           //       //       setState(() {
  //           //       //         isMap = !isMap;
  //           //       //       });
  //           //       //     },
  //           //       //     // child: Padding(
  //           //       //     //   padding: const EdgeInsets.all(8.0),
  //           //       //     //   child: Icon(
  //           //       //     //       isMap ? Icons.sort : FontAwesomeIcons.mapMarkedAlt),
  //           //       //     // ),
  //           //       //   ),
  //           //       // ),
  //           //     ],
  //           //   ),
  //           // )
  //         ],
  //       ),
  //     ),
  //   );
  // }

  void getDaValue() {
    isSearch = widget.isSearch;
    location = widget.locaton_id;
    locationname = widget.locaton_name;
    print(" HLHS: location id: $location , location name: $locationname");
    allLocation = widget.allLocation;

    if (widget.checkIn != null) {
      checkIn = widget.checkIn;
      DateTime checkInParseDate = new DateFormat("dd/MM/yyyy").parse(checkIn);
      _startDate = DateTime.parse(checkInParseDate.toString());
    } else {
      checkIn = DateFormat("dd/MM/yyyy").format(_startDate);
    }

    if (widget.checkOut != null) {
      checkOut = widget.checkOut;
      DateTime checkOutParseDate = new DateFormat("dd/MM/yyyy").parse(checkOut);
      _endDate = DateTime.parse(checkOutParseDate.toString());
    } else {
      checkOut = DateFormat("dd/MM/yyyy").format(_endDate);
    }

    if (widget.room == 0) {
      room = 0;
      ad = 1;
      child = 0;
    } else {
      room = widget.room;
      ad = widget.adults;
      child = widget.child;
    }
    setState(() {});
  }

  String getCheckInDate() {
    // checkIn=widget.checkIn;
    DateTime parseDate;
    var output;
    if (checkIn != null) {
      parseDate = new DateFormat("dd/MM/yyyy").parse(checkIn);
      var inputDate = DateTime.parse(parseDate.toString());
      var outputFormat = DateFormat("dd, MMM");
      output = outputFormat.format(inputDate);
    } else {
      output = DateFormat("dd, MMM").format(_startDate);
    }

    return output;
  }

  String getCheckOutDate() {
    // checkOut=widget.checkOut;
    DateTime parseDate;
    var output;
    if (checkOut != null) {
      parseDate = new DateFormat("dd/MM/yyyy").parse(checkOut);
      var inputDate = DateTime.parse(parseDate.toString());
      var outputFormat = DateFormat('dd, MMM');
      output = outputFormat.format(inputDate);
    } else {
      output = DateFormat("dd, MMM").format(_endDate);
    }

    return output;
  }

  String getDatefinalCheckInForApi() {
    DateTime parseDate = new DateFormat('dd, MMM').parse(finalCheckIn);

    var inputDate = DateTime.parse(parseDate.toString());
    var outputFormat = DateFormat('dd/MM/yyyy');
    var output = outputFormat.format(inputDate);
    return output;
  }

  String getDatefinalCheckOutForApi() {
    DateTime parseDate = new DateFormat('dd, MMM').parse(finalCheckout);
    var inputDate = DateTime.parse(parseDate.toString());
    var outputFormat = DateFormat('dd/MM/yyyy');
    var output = outputFormat.format(inputDate);
    return output;
  }

  String getStringDate(DateTime dateTime) {
    // DateTime parseDate = new DateFormat('MM/dd/yyyy').parse(dateTime);
    var inputDate = DateTime.parse(dateTime.toString());
    var outputFormat = DateFormat('MM/dd/yyyy');
    var output = outputFormat.format(inputDate);
    return output;
  }

  void getSearchApi() {
    print("getHotelsFilterData  date picker ${finalCheckIn} ${finalCheckout}");

    switch (isSearch) {
      case 0:
        {
          getHotelsFilterData(
              widget.starCount,
              getStringDate(_startDate),
              getStringDate(_endDate),
              widget.amenities,
              widget.propertyType,
              widget.funtodoThing,
              "${widget.locationId}");
          print(
              "getHotelsFilterData  date picker $finalCheckIn $finalCheckout");
          break;
        }
      case 1:
        {
          getSearchJSONData(
              location, getStringDate(_startDate), getStringDate(_endDate));
          print("getSearchJSONData  date picker $finalCheckIn $finalCheckIn");

          break;
        }
      case 2:
        {
          getLocationJSONData(widget.locationId);
          break;
        }
      default:
        {
          getJSONData();
        }
    }
  }
}

class MapHotelListView extends StatelessWidget {
  final VoidCallback callback;
  final HostelData hotelData;

  const MapHotelListView({Key key, this.hotelData, this.callback})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 0, right: 8, top: 8, bottom: 0),
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.getTheme().backgroundColor,
          borderRadius: BorderRadius.all(Radius.circular(10.0)),
          boxShadow: <BoxShadow>[
            BoxShadow(
              color: AppTheme.getTheme().dividerColor,
              offset: Offset(4, 4),
              blurRadius: 16,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.all(Radius.circular(16.0)),
          child: AspectRatio(
            aspectRatio: 2.7,
            child: Stack(
              children: <Widget>[
                Row(
                  children: <Widget>[
                    AspectRatio(
                      aspectRatio: 0.90,
                      child: Image.network(
                        hotelData.thumbnail,
                        fit: BoxFit.cover,
                      ),
                    ),
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.all(8),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              hotelData.title,
                              maxLines: 2,
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 16,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              hotelData.address,
                              style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.grey.withOpacity(0.8)),
                            ),
                            Expanded(
                              child: SizedBox(),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: <Widget>[
                                Container(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(
                                            FontAwesomeIcons.mapMarkerAlt,
                                            size: 12,
                                            color: AppTheme.getTheme()
                                                .primaryColor,
                                          ),
                                          Text(
                                            " ${hotelData.citycenterDistance ?? "0"} km to city",
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                                fontSize: 14,
                                                color: Colors.grey
                                                    .withOpacity(0.8)),
                                          ),
                                        ],
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(top: 4),
                                        child: SmoothStarRating(
                                          allowHalfRating: true,
                                          starCount: 5,
                                          isReadOnly: true,
                                          rating: double.parse(
                                              hotelData.starsCount),
                                          size: 20,
                                          color: AppTheme.starColor,
                                          borderColor: AppTheme.starColor,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(right: 8),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: <Widget>[
                                      Text(
                                        "${hotelData.currCode} ${hotelData.price}",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          fontSize: 16,
                                        ),
                                      ),
                                      Text(
                                        "${hotelData.currCode} ${hotelData.basicprice}",
                                        style: TextStyle(
                                            fontSize: 14,
                                            decoration:
                                                TextDecoration.lineThrough,
                                            color: Colors.red.withOpacity(0.8)),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    highlightColor: Colors.transparent,
                    splashColor:
                        AppTheme.getTheme().primaryColor.withOpacity(0.1),
                    onTap: () {
                      callback();
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class HomeHotelList {
  int type;
  String msg;
  HotelList hotel;

  HomeHotelList(
    this.type,
    this.msg,
    this.hotel,
  );
}
