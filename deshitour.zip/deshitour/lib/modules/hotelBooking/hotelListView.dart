import 'package:flutter/material.dart';
import 'package:new_motel/models/hotelList/hotelList.dart';
import '../../appTheme.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';

class HotelListView extends StatelessWidget {
  final VoidCallback callback;
  final HostelData hotelData;
  final int days;
  final AnimationController animationController;
  final Animation animation;

  const HotelListView(
      {Key key,
      this.hotelData,
      this.days,
      this.animationController,
      this.animation,
      this.callback})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animationController,
      builder: (BuildContext context, Widget child) {
        return FadeTransition(
          opacity: animation,
          child: new Transform(
            transform: new Matrix4.translationValues(
                0.0, 50 * (1.0 - animation.value), 0.0),
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 24, right: 24, top: 8, bottom: 16),
              child: InkWell(
                splashColor: Colors.transparent,
                onTap: () {
                  callback();
                },
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(16.0)),
                    boxShadow: <BoxShadow>[
                      BoxShadow(
                        color: AppTheme.getTheme().dividerColor,
                        offset: Offset(4, 4),
                        blurRadius: 16,
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(16.0)),
                    child: Stack(
                      children: <Widget>[
                        Column(
                          children: <Widget>[
                            AspectRatio(
                              aspectRatio: 2,
                              child: FadeInImage(
                                placeholder:
                                    AssetImage('assets/images/bp_loading.gif'),
                                image: hotelData.thumbnail == null
                                    ? Image.asset(
                                        'assets/images/hotel_room_1.png')
                                    : NetworkImage(hotelData.thumbnail),
                                fit: BoxFit.cover,
                                // loadingBuilder: (BuildContext context, Widget child,
                                //     ImageChunkEvent loadingProgress) {
                                //   if (loadingProgress == null) return child;
                                //   return Center(
                                //     child: CircularProgressIndicator(
                                //       value: loadingProgress.expectedTotalBytes != null
                                //           ? loadingProgress.cumulativeBytesLoaded /
                                //           loadingProgress.expectedTotalBytes
                                //           : null,
                                //     ),
                                //   );
                                //  },
                              ),
                            ),
                            Container(
                              color: AppTheme.getTheme().backgroundColor,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Expanded(
                                    child: Container(
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 16, top: 8, bottom: 8),
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: <Widget>[
                                            Text(
                                              hotelData.title ?? "",
                                              textAlign: TextAlign.left,
                                              style: TextStyle(
                                                fontWeight: FontWeight.w600,
                                                fontSize: 20,
                                              ),
                                            ),
                                            Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                Text(
                                                  hotelData.address ?? "",
                                                  style: TextStyle(
                                                      fontSize: 11,
                                                      color: Colors.grey
                                                          .withOpacity(0.8)),
                                                ),
                                                SizedBox(
                                                  width: 4,
                                                ),
                                                // Icon(
                                                //   FontAwesomeIcons.mapMarkerAlt,
                                                //   size: 12,
                                                //   color: AppTheme.getTheme()
                                                //       .primaryColor,
                                                // ),
                                                // Expanded(
                                                //   child: Text(
                                                //     "${hotelData.citycenterDistance??"0"} km to city",
                                                //     overflow:
                                                //         TextOverflow.ellipsis,
                                                //     style: TextStyle(
                                                //         fontSize: 14,
                                                //         color: Colors.grey
                                                //             .withOpacity(0.8)),
                                                //   ),
                                                // ),
                                              ],
                                            ),
                                            Padding(
                                              padding:
                                                  const EdgeInsets.only(top: 4),
                                              child: Row(
                                                children: <Widget>[
                                                  SmoothStarRating(
                                                    allowHalfRating: true,
                                                    starCount: 5,
                                                    rating: double.parse(
                                                        hotelData.starsCount),
                                                    size: 15,
                                                    isReadOnly: true,
                                                    color: AppTheme.starColor,
                                                    borderColor:
                                                        AppTheme.starColor,
                                                  ),
                                                  Text(
                                                    " ${hotelData.avgReviews.totalReviews ?? "0"} Reviews",
                                                    style: TextStyle(
                                                        fontSize: 14,
                                                        color: Colors.grey
                                                            .withOpacity(0.8)),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        right: 16, top: 8),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: <Widget>[
                                        Text(
                                          "${hotelData.currCode} ${hotelData.basicprice * days}",
                                          textAlign: TextAlign.left,
                                          style: TextStyle(
                                            fontWeight: FontWeight.w600,
                                            decoration:
                                                TextDecoration.lineThrough,
                                            fontSize: 16,
                                            color: Colors.red.withOpacity(0.5),
                                          ),
                                        ),
                                        Text(
                                          "${hotelData.currCode} ${int.parse(hotelData.price.replaceAll(",", "")) * days}",
                                          textAlign: TextAlign.left,
                                          style: TextStyle(
                                            fontWeight: FontWeight.w600,
                                            fontSize: 18,
                                          ),
                                        ),
                                        // Text(
                                        //   "/per night",
                                        //   style: TextStyle(
                                        //       fontSize: 14,
                                        //       color:
                                        //           Colors.grey.withOpacity(0.8)),
                                        // ),
                                        // // ignore: unrelated_type_equality_checks
                                        // if(hotelData.payarr==1){
                                        //
                                        // }
                                        if (hotelData.payarr == "0")
                                          ...[]
                                        else ...[
                                          Row(
                                            children: <Widget>[
                                              ImageIcon(
                                                AssetImage(
                                                    "assets/icons/circle.png"),
                                                color: AppTheme.getTheme()
                                                    .primaryColor,
                                              ),
                                              Text(
                                                "Pay at hotel",
                                                style: TextStyle(
                                                    fontSize: 14,
                                                    fontWeight: FontWeight.bold,
                                                    color: Colors.grey),
                                              ),
                                            ],
                                          ),
                                        ],
                                        // Row(
                                        //   children: <Widget>[
                                        //     ImageIcon(
                                        //       AssetImage("assets/icons/circle.png"),
                                        //       color: AppTheme.getTheme().primaryColor,
                                        //     ),
                                        //     Text(
                                        //       " City center ${hotelData.citycenterDistance??"0"} km ",
                                        //       style: TextStyle(
                                        //           fontSize: 14,
                                        //           fontWeight: FontWeight.bold,
                                        //           color: Colors.grey),
                                        //     ),
                                        //   ],
                                        // ),
                                      ],
                                    ),
                                  ),
                                  // Padding(
                                  //   padding: const EdgeInsets.only(
                                  //       right: 16, top: 8),
                                  //   child: Column(
                                  //     mainAxisAlignment:
                                  //         MainAxisAlignment.center,
                                  //     crossAxisAlignment:
                                  //         CrossAxisAlignment.end,
                                  //     children: <Widget>[
                                  //       Text(
                                  //         "${hotelData.currCode} ${hotelData.price}",
                                  //         textAlign: TextAlign.left,
                                  //         style: TextStyle(
                                  //           fontWeight: FontWeight.w600,
                                  //           fontSize: 18,
                                  //         ),
                                  //       ),
                                  //       // Text(
                                  //       //   "/per night",
                                  //       //   style: TextStyle(
                                  //       //       fontSize: 14,
                                  //       //       color:
                                  //       //           Colors.grey.withOpacity(0.8)),
                                  //       // ),
                                  //    // // ignore: unrelated_type_equality_checks
                                  //    // if(hotelData.payarr==1){
                                  //    //
                                  //    // }
                                  //       if (hotelData.payarr == "0") ...[
                                  //       ] else ...[
                                  //         Row(
                                  //           children: <Widget>[
                                  //             ImageIcon(
                                  //                 AssetImage("assets/icons/circle.png"),
                                  //               color: Colors.blue,
                                  //             ),
                                  //             Text(
                                  //               " Pay at hotel",
                                  //               style: TextStyle(
                                  //                   fontSize: 14,
                                  //                   color: Colors.blue),
                                  //             ),
                                  //           ],
                                  //         ),
                                  //       ],
                                  //       Row(
                                  //         children: <Widget>[
                                  //           ImageIcon(
                                  //             AssetImage("assets/icons/circle.png"),
                                  //             color: Colors.blue,
                                  //           ),
                                  //           Text(
                                  //             " City center ${hotelData.citycenterDistance??"0"} km ",
                                  //             style: TextStyle(
                                  //                 fontSize: 14,
                                  //                 color: Colors.blue),
                                  //           ),
                                  //         ],
                                  //       ),
                                  //
                                  //     ],
                                  //   ),
                                  // ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
