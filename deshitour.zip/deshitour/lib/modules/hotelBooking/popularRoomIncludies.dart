import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:new_motel/models/hotelList/hotelDetails.dart';
import 'package:new_motel/utils/constants.dart';
import '../../appTheme.dart';

class PopularRoomIncludies extends StatelessWidget {
  final AnimationController animationController;
  final List<PopularRoomAmenities> popular;

  const PopularRoomIncludies({Key key, this.animationController, this.popular})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    print("popular  ${popular.length}");
    return   Container(
      height: MediaQuery.of(context).size.height / 4,
      padding: PAD_ALL_4,
      decoration: BoxDecoration(
        color: AppTheme.getTheme().backgroundColor,
        borderRadius: BorderRadius.all(Radius.circular(16.0)),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: AppTheme.getTheme().dividerColor,
            blurRadius: 8,
            offset: Offset(4, 4),
          ),
        ],
      ),
      child: GridView.builder(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: MediaQuery.of(context).size.width /
              (MediaQuery.of(context).size.height / 7),
        ),
        itemCount: popular.length,
        itemBuilder: (context, index) {
          return GridTile(
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Icon(
                          Icons.check,
                        color: Colors.blue.withOpacity(0.5),
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 4),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                popular[index].name,
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  fontWeight: FontWeight.normal,
                                  fontSize: 14,
                                  color:Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                ],
              ));
        },
      ),
    );
  }
}
// Container(
// height: MediaQuery.of(context).size.height/7,
// padding: PAD_ALL_16,
// decoration: BoxDecoration(
// color: AppTheme.getTheme().backgroundColor,
// borderRadius: BorderRadius.all(Radius.circular(16.0)),
// boxShadow: <BoxShadow>[
// BoxShadow(
// color: AppTheme.getTheme().dividerColor,
// blurRadius: 8,
// offset: Offset(4, 4),
// ),
// ],
// ),
// child: GridView.builder(
// gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
// crossAxisCount: 3,
// childAspectRatio: MediaQuery.of(context).size.width /
// (MediaQuery.of(context).size.height / 6),
//
// ),
// itemCount: popular.length,
// itemBuilder: (context, index) {
// return GridTile(child: Column(
// children: <Widget>[
// Row(
// children: <Widget>[
// SizedBox(
// width: 30,
// child:Image.network(
// popular[index].icon,
// width: 24,
// height: 24,
// color: AppTheme.getTheme().primaryColor,
// )
// ),
// Expanded(
// child: Padding(
// padding: const EdgeInsets.only(left: 8),
// child: Column(
// mainAxisAlignment: MainAxisAlignment.center,
// crossAxisAlignment: CrossAxisAlignment.start,
// children: <Widget>[
// Text(
// popular[index].name,
// textAlign: TextAlign.left,
// style: TextStyle(
// fontWeight: FontWeight.w500,
// fontSize: 14,
// color: AppTheme.getTheme()
//     .primaryColor,
// ),
// ),
// ],
// ),
// ),
// )
// ],
// ),
// ],
// )
// );
// },
// ),
// );
