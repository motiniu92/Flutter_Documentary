import 'package:flutter/material.dart';
import 'package:new_motel/utils/constants.dart';
import '../../appTheme.dart';

class ChangepasswordScreen extends StatefulWidget {
  @override
  _ChangepasswordScreenState createState() => _ChangepasswordScreenState();
}

class _ChangepasswordScreenState extends State<ChangepasswordScreen> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Scaffold(
        appBar: AppBar(
          title: RichText(
            text: TextSpan(
                text: DESHI,
                style: TextStyle(
                  fontSize: 30,
                  fontFamily: 'Impact',
                  color: HexColor("#26408A"),
                ),
                children: <TextSpan>[
                  TextSpan(
                      text: TOUR,
                      style: TextStyle(
                        fontSize: 30,
                        fontFamily: 'Impact',
                        color: HexColor("#118ACB"),
                      )),
                ]),
          ),
          backgroundColor: Colors.white,
          elevation: 1,
          leading: IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.black,
              ),
              onPressed: () {
                Navigator.pop(context);
                // Navigator.push(
                //     context,
                //     MaterialPageRoute(
                //         builder: (context) => ProfileScreen()));
              }),
        ),
        backgroundColor: Colors.white,
        body: InkWell(
          splashColor: Colors.transparent,
          highlightColor: Colors.transparent,
          focusColor: Colors.transparent,
          onTap: () {
            FocusScope.of(context).requestFocus(FocusNode());
          },
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Expanded(
                  child: SingleChildScrollView(
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          // Padding(
                          //   padding: const EdgeInsets.only(
                          //       top: 16.0, bottom: 16.0, left: 24, right: 24),
                          //   child: Row(
                          //     children: <Widget>[
                          //       Text(
                          //         "Enter your new password and\nconfirm your password",
                          //         textAlign: TextAlign.start,
                          //         style: TextStyle(
                          //           fontSize: 14,
                          //           fontWeight: FontWeight.w500,
                          //           color: AppTheme.getTheme().disabledColor,
                          //         ),
                          //       ),
                          //     ],
                          //   ),
                          // ),
                          SizedBox(
                            height: 120,
                          ),

                          Padding(
                            padding: const EdgeInsets.only(left: 24, right: 24),
                            child: Container(
                              decoration: BoxDecoration(
                                color: AppTheme.getTheme().backgroundColor,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(38)),
                                // border: Border.all(
                                //   color: HexColor("#757575").withOpacity(0.6),
                                // ),
                                boxShadow: <BoxShadow>[
                                  BoxShadow(
                                    color: AppTheme.getTheme().dividerColor,
                                    blurRadius: 8,
                                    offset: Offset(4, 4),
                                  ),
                                ],
                              ),

                              // Current Password TextFields
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(left: 16, right: 16),
                                child: Container(
                                  height: 48,
                                  child: Center(
                                    child: TextField(
                                      maxLines: 1,
                                      onChanged: (String txt) {},
                                      style: TextStyle(
                                        fontSize: 16,
                                      ),
                                      cursorColor:
                                          AppTheme.getTheme().primaryColor,
                                      decoration: new InputDecoration(
                                        errorText: null,
                                        border: InputBorder.none,
                                        hintText: CURRENT_PASSWORD,
                                        hintStyle: TextStyle(
                                          color:
                                              AppTheme.getTheme().disabledColor,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 16,
                          ),

                          // New Password TextFields
                          Padding(
                            padding: const EdgeInsets.only(left: 24, right: 24),
                            child: Container(
                              decoration: BoxDecoration(
                                color: AppTheme.getTheme().backgroundColor,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(38)),
                                // border: Border.all(
                                //   color: HexColor("#757575").withOpacity(0.6),
                                // ),
                                boxShadow: <BoxShadow>[
                                  BoxShadow(
                                    color: AppTheme.getTheme().dividerColor,
                                    blurRadius: 8,
                                    offset: Offset(4, 4),
                                  ),
                                ],
                              ),
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(left: 16, right: 16),
                                child: Container(
                                  height: 48,
                                  child: Center(
                                    child: TextField(
                                      maxLines: 1,
                                      onChanged: (String txt) {},
                                      style: TextStyle(
                                        fontSize: 16,
                                      ),
                                      cursorColor:
                                          AppTheme.getTheme().primaryColor,
                                      decoration: new InputDecoration(
                                        errorText: null,
                                        border: InputBorder.none,
                                        hintText: NEW_PASSWORD,
                                        hintStyle: TextStyle(
                                            color: AppTheme.getTheme()
                                                .disabledColor),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),

                          SizedBox(
                            height: 16,
                          ),
                          // Confirm Password TextFields
                          Padding(
                            padding: const EdgeInsets.only(left: 24, right: 24),
                            child: Container(
                              decoration: BoxDecoration(
                                color: AppTheme.getTheme().backgroundColor,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(38)),
                                // border: Border.all(
                                //   color: HexColor("#757575").withOpacity(0.6),
                                // ),
                                boxShadow: <BoxShadow>[
                                  BoxShadow(
                                    color: AppTheme.getTheme().dividerColor,
                                    blurRadius: 8,
                                    offset: Offset(4, 4),
                                  ),
                                ],
                              ),
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(left: 16, right: 16),
                                child: Container(
                                  height: 48,
                                  child: Center(
                                    child: TextField(
                                      maxLines: 1,
                                      onChanged: (String txt) {},
                                      style: TextStyle(
                                        fontSize: 16,
                                      ),
                                      cursorColor:
                                          AppTheme.getTheme().primaryColor,
                                      decoration: new InputDecoration(
                                        errorText: null,
                                        border: InputBorder.none,
                                        hintText: CONFIRM_PASSWORD,
                                        hintStyle: TextStyle(
                                            color: AppTheme.getTheme()
                                                .disabledColor),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                left: 24, right: 24, bottom: 8, top: 16),
                            child: Container(
                              height: 48,
                              decoration: BoxDecoration(
                                color: AppTheme.getTheme().primaryColor,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(24.0)),
                                boxShadow: <BoxShadow>[
                                  BoxShadow(
                                    color: AppTheme.getTheme().dividerColor,
                                    blurRadius: 8,
                                    offset: Offset(4, 4),
                                  ),
                                ],
                              ),
                              child: Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(24.0)),
                                  highlightColor: Colors.transparent,
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                  child: Center(
                                    child: Text(
                                      APPLY,
                                      style: TextStyle(
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16,
                                          color: Colors.white),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget appBar() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: [
            SizedBox(
              height: AppBar().preferredSize.height,
              child: Padding(
                padding: EdgeInsets.only(top: 8, left: 8),
                child: Container(
                    width: AppBar().preferredSize.height - 8,
                    height: AppBar().preferredSize.height - 8,
                    child: Material(
                      color: Colors.transparent,
                      elevation: 0,
                      child: InkWell(
                        borderRadius: BorderRadius.all(
                          Radius.circular(32.0),
                        ),
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Icon(Icons.arrow_back),
                        ),
                      ),
                    )),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 8.0, left: 60),
              child: Center(
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    CHANGE_PASSWORD,
                    style: new TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
