import 'package:flutter/material.dart';
import 'package:new_motel/models/hotelList/hotelDetails.dart';

import '../../appTheme.dart';

class HotelExpandableListView extends StatefulWidget {
  final String title;
  final List<HotelDetailsPopularAmenities> popularAmenities;
  final List<PopularRoomAmenities> popularRoomAmenities;

  const HotelExpandableListView({
    Key key,
    @required this.title,
    @required this.popularAmenities,
    @required this.popularRoomAmenities,
  }) : super(key: key);

  @override
  _HotelExpandableListViewState createState() =>
      _HotelExpandableListViewState();
}

class _HotelExpandableListViewState extends State<HotelExpandableListView> {
  bool expandFlag = false;
  List<HotelDetailsPopularAmenities> popularAmenities;
  List<PopularRoomAmenities> popularRoomAmenities;
  var expandableListItem;

  @override
  Widget build(BuildContext context) {
    if (widget.popularAmenities != null) {
      expandableListItem = widget.popularAmenities;
    } else {
      expandableListItem = widget.popularRoomAmenities;
    }
    return new Container(
      margin: new EdgeInsets.symmetric(vertical: 1.0),
      child: new Column(
        children: <Widget>[
          GestureDetector(
            onTap: () {
              setState(() {
                expandFlag = !expandFlag;
              });
            },
            child: new Container(
              color: Colors.white,
              padding: new EdgeInsets.symmetric(horizontal: 4.0),
              child: new Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  new Text(
                    widget.title,
                    style: new TextStyle(
                        fontWeight: FontWeight.w300,
                        color: Colors.black,
                        fontSize: 17),
                  ),
                  new IconButton(
                      icon: new Container(
                        height: 40.0,
                        width: 40.0,
                        decoration: new BoxDecoration(
                          color: Colors.blue,
                          shape: BoxShape.circle,
                        ),
                        child: new Center(
                          child: new Icon(
                            expandFlag
                                ? Icons.keyboard_arrow_up
                                : Icons.keyboard_arrow_down,
                            color: Colors.white,
                            size: 30.0,
                          ),
                        ),
                      ),
                      onPressed: () {
                        setState(() {
                          expandFlag = !expandFlag;
                        });
                      })
                ],
              ),
            ),
          ),
          new ExpandableContainer(
              expanded: expandFlag,
              child: ListView(
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                primary: false,
                children: [
                  ListView.builder(
                    scrollDirection: Axis.vertical,
                    shrinkWrap: true,
                    primary: false,
                    itemBuilder: (BuildContext context, int index) {
                      return ListTile(
                          title: new Text(
                            expandableListItem[index].name,
                            style: new TextStyle(
                                color: Colors.black87, fontSize: 16),
                          ),
                          leading: widget.popularAmenities == null
                              ? new Icon(
                                  Icons.check,
                                  color: Colors.blue,
                                )
                              : new Image.network(
                                  expandableListItem[index].icon,
                                  width: 24,
                                  height: 24,
                                  color: AppTheme.getTheme().primaryColor,
                                ));
                    },
                    itemCount: expandableListItem.length,
                  ),
                ],
              ))
        ],
      ),
    );
  }
}

class ExpandableContainer extends StatelessWidget {
  final bool expanded;
  final double collapsedHeight;
  final double expandedHeight;
  final Widget child;

  ExpandableContainer({
    @required this.child,
    this.collapsedHeight = 0.0,
    this.expandedHeight = 200.0,
    this.expanded = true,
  });

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double h = MediaQuery.of(context).size.height;
    double j = MediaQuery.of(context).size.height / 50;
    return new AnimatedContainer(
      duration: new Duration(milliseconds: 500),
      curve: Curves.easeInOut,
      width: screenWidth,
      height: expanded ? h : j,
      child: new Container(
        child: child,
      ),
    );
  }
}
