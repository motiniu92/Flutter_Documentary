import 'package:flutter/material.dart';
import 'package:new_motel/models/hotelList/hotelDetails.dart';
import '../../appTheme.dart';

class HotelRoomeList extends StatefulWidget {
  List<SliderImages> _slider;

  HotelRoomeList(this._slider);

  @override
  _HotelRoomeListState createState() => _HotelRoomeListState();
}

class _HotelRoomeListState extends State<HotelRoomeList> {
  // List<String> photosList = [
  //   "assets/images/hotel_room_1.jpg",
  //   "assets/images/hotel_room_2.jpg",
  //   "assets/images/hotel_room_3.jpg",
  //   "assets/images/hotel_room_4.jpg",
  //   "assets/images/hotel_room_5.jpg",
  //   "assets/images/hotel_room_6.jpg",
  //   "assets/images/hotel_room_7.jpg",
  // ];

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 160,
      child: ListView.builder(
        padding: const EdgeInsets.only(top: 0, bottom: 0, right: 16, left: 0),
        itemCount: widget._slider.length,
        scrollDirection: Axis.horizontal,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              decoration: BoxDecoration(
                color: AppTheme.getTheme().primaryColor,
                borderRadius: BorderRadius.all(Radius.circular(5.0)),
                boxShadow: <BoxShadow>[
                  BoxShadow(
                    color: AppTheme.getTheme().dividerColor,
                    blurRadius: 8,
                    offset: Offset(4, 4),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.all(Radius.circular(8.0)),
                child: AspectRatio(
                  aspectRatio: 1,
                  child: Image.network(
                    widget._slider[index].fullImage,
                    fit: BoxFit.cover,
                    loadingBuilder: (BuildContext context, Widget child,
                        ImageChunkEvent loadingProgress) {
                      if (loadingProgress == null) return child;
                      return Center(
                        child: CircularProgressIndicator(
                          value: loadingProgress.expectedTotalBytes != null
                              ? loadingProgress.cumulativeBytesLoaded /
                                  loadingProgress.expectedTotalBytes
                              : null,
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
