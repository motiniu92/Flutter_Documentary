import 'package:flutter/material.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:flutter/cupertino.dart';

import '../../appTheme.dart';

class WriteReviews extends StatefulWidget {
  @override
  _WriteReviewsState createState() => _WriteReviewsState();
}

class _WriteReviewsState extends State<WriteReviews> {
  ScrollController scrollController = ScrollController(initialScrollOffset: 0);

  String clean, facilities, comfort, stuff, location, valueforMoney;
  String overAll;
  List<String> cityListies = [
    'Ajman',
    'Al Ain',
    'Dubai',
    'Fujairah',
    'Ras Al Khaimah',
    'Sharjah',
    'Umm Al Quwain'
  ];
// =======
//   String clean  ,
//       facilities,
//       comfort ,
//       stuff ,
//       location ,
//       valueforMoney;
//   int overAll=3;
// >>>>>>> towfiq_dev

  List<String> reviewList = ['3', '4', '5', '6', '7', '8', '9', '10'];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    UpdateUI();
  }

  @override
  Widget build(BuildContext context) {
    // overallCalculation("3");

    return Scaffold(
      body: new Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          //appbar
          Padding(
            padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
            child: appBar(),
          ),

          Expanded(
            child: SingleChildScrollView(
              // Main Container
              child: Container(
                decoration: BoxDecoration(
                    color: Colors.grey[200],
                    border: Border.all(
                      color: Colors.grey[500],
                      width: 2,
                    )),
                padding: const EdgeInsets.all(5),
                margin: const EdgeInsets.all(5),
                child: Column(
                  children: <Widget>[
                    //Container One

                    Container(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            height: 48,
                            decoration: new BoxDecoration(
                              shape: BoxShape.rectangle,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(5.0)),
                            ),
                            child: Material(
                              color: Colors.transparent,
                              child: InkWell(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(5)),
                                highlightColor: Colors.transparent,
                                child: Center(
                                  child: Text(
                                    OVERALL,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Container(
                            height: 48,
                            decoration: new BoxDecoration(
                              shape: BoxShape.rectangle,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(5.0)),
                            ),
                            child: Material(
                              color: Colors.transparent,
                              child: InkWell(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(5)),
                                highlightColor: Colors.transparent,
                                child: Center(
                                  child: Text(
                                    "frtyfwdtyw",
                                    //overallCalculation(3),
                                  // overallCalculation("3") + " / 10",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                           SizedBox(
                             width: 10,
                           ),
                         UpdateUI()

                        ],
                      ),
                    ),

                    //Container Two
                    new Container(
                      child: new Row(
                        children: [
                          // Left Expanded
                          Expanded(
                            child: Column(
                              children: [
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    CLEAN,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                    ),
                                    textAlign: TextAlign.right,
                                  ),
                                ),
                                SizedBox(
                                  width: MediaQuery.of(context).size.width / 2,
                                  height: 55,
                                  child: DropdownButtonFormField(
                                    isDense: false,
                                    itemHeight: 65,
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                          borderRadius: const BorderRadius.all(
                                            const Radius.circular(5.0),
                                          ),
                                        ),
                                        filled: true,
                                        hintStyle: TextStyle(
                                            fontSize: 15, color: Colors.black),
                                        hintText: DROPDOWN_TEXT,
                                        fillColor: Colors.white),
                                    value: clean,
                                    onChanged: (String Value) {
                                      setState(() {
                                        clean = Value;
                                        overallCalculation(clean);
                                        UpdateUI(overALLValue: int.parse(clean));

                                      });
                                    },
                                    items: reviewList
                                        .map((cityTitle) => DropdownMenuItem(
                                            value: cityTitle,
                                            child: Text("$cityTitle")))
                                        .toList(),
                                  ),
                                ),
                              ],
                            ),
                          ),

                          SizedBox(
                            width: 30,
                          ),

                          // Right Expanded
                          Expanded(
                            child: Container(
                              width: MediaQuery.of(context).size.width / 2,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      FACILITIES,
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 18,
                                      ),
                                      textAlign: TextAlign.right,
                                    ),
                                  ),
                                  SizedBox(
                                    width:
                                        MediaQuery.of(context).size.width / 2,
                                    height: 55,
                                    child: DropdownButtonFormField(
                                      isDense: false,
                                      itemHeight: 65,
                                      decoration: InputDecoration(
                                          border: OutlineInputBorder(
                                            borderRadius:
                                                const BorderRadius.all(
                                              const Radius.circular(5.0),
                                            ),
                                          ),
                                          filled: true,
                                          hintStyle: TextStyle(
                                              fontSize: 15,
                                              color: Colors.black),
                                          hintText: DROPDOWN_TEXT,
                                          fillColor: Colors.white),
                                      value: facilities,
                                      onChanged: (String Value) {
                                        setState(() {
                                          facilities = Value;
                                          UpdateUI(overALLValue: int.parse(facilities));

                                        });
                                      },
                                      items: reviewList
                                          .map((cityTitle) => DropdownMenuItem(
                                              value: cityTitle,
                                              child: Text("$cityTitle")))
                                          .toList(),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    //Container Threee
                    new Container(
                      child: new Row(
                        children: [
                          // Left Expanded
                          Expanded(
                            child: Column(
                              children: [
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    COMFORT,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                    ),
                                    textAlign: TextAlign.right,
                                  ),
                                ),
                                SizedBox(
                                  width: MediaQuery.of(context).size.width / 2,
                                  height: 55,
                                  child: DropdownButtonFormField(
                                    isDense: false,
                                    itemHeight: 65,
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                          borderRadius: const BorderRadius.all(
                                            const Radius.circular(5.0),
                                          ),
                                        ),
                                        filled: true,
                                        hintStyle: TextStyle(
                                            fontSize: 15, color: Colors.black),
                                        hintText: DROPDOWN_TEXT,
                                        fillColor: Colors.white),
                                    value: comfort,
                                    onChanged: (String Value) {
                                      setState(() {
                                        comfort = Value;
                                      });
                                    },
                                    items: reviewList
                                        .map((cityTitle) => DropdownMenuItem(
                                            value: cityTitle,
                                            child: Text("$cityTitle")))
                                        .toList(),
                                  ),
                                ),
                              ],
                            ),
                          ),

                          SizedBox(
                            width: 30,
                          ),

                          // Right Expanded
                          Expanded(
                            child: Container(
                              width: MediaQuery.of(context).size.width / 2,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      STUFF,
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 18,
                                      ),
                                      textAlign: TextAlign.right,
                                    ),
                                  ),
                                  SizedBox(
                                    width:
                                        MediaQuery.of(context).size.width / 2,
                                    height: 55,
                                    child: DropdownButtonFormField(
                                      isDense: false,
                                      itemHeight: 65,
                                      decoration: InputDecoration(
                                          border: OutlineInputBorder(
                                            borderRadius:
                                                const BorderRadius.all(
                                              const Radius.circular(5.0),
                                            ),
                                          ),
                                          filled: true,
                                          hintStyle: TextStyle(
                                              fontSize: 15,
                                              color: Colors.black),
                                          hintText: DROPDOWN_TEXT,
                                          fillColor: Colors.white),
                                      value: stuff,
                                      onChanged: (String Value) {
                                        setState(() {
                                          stuff = Value;
                                        });
                                      },
                                      items: reviewList
                                          .map((cityTitle) => DropdownMenuItem(
                                              value: cityTitle,
                                              child: Text("$cityTitle")))
                                          .toList(),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    //Container Four
                    new Container(
                      child: new Row(
                        children: [
                          // Left Expanded
                          Expanded(
                            child: Column(
                              children: [
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    LOCATION_RD,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                    ),
                                    textAlign: TextAlign.right,
                                  ),
                                ),
                                SizedBox(
                                  width: MediaQuery.of(context).size.width,
                                  height: 55,
                                  child: DropdownButtonFormField(
                                    isDense: false,
                                    itemHeight: 65,
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                          borderRadius: const BorderRadius.all(
                                            const Radius.circular(5.0),
                                          ),
                                        ),
                                        filled: true,
                                        hintStyle: TextStyle(
                                            fontSize: 15, color: Colors.black),
                                        hintText: DROPDOWN_TEXT,
                                        fillColor: Colors.white),
                                    value: location,
                                    onChanged: (String Value) {
                                      setState(() {
                                        location = Value;
                                      });
                                    },
                                    items: reviewList
                                        .map((cityTitle) => DropdownMenuItem(
                                            value: cityTitle,
                                            child: Text("$cityTitle")))
                                        .toList(),
                                  ),
                                ),
                              ],
                            ),
                          ),

                          SizedBox(
                            width: 30,
                          ),

                          // Right Expanded
                          Expanded(
                            child: Container(
                              width: MediaQuery.of(context).size.width / 2,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      VALUE_FOR_MONEY,
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 18,
                                      ),
                                      textAlign: TextAlign.right,
                                    ),
                                  ),
                                  SizedBox(
                                    width:
                                        MediaQuery.of(context).size.width / 2,
                                    height: 55,
                                    child: DropdownButtonFormField(
                                      isDense: false,
                                      itemHeight: 65,
                                      decoration: InputDecoration(
                                          border: OutlineInputBorder(
                                            borderRadius:
                                                const BorderRadius.all(
                                              const Radius.circular(5.0),
                                            ),
                                          ),
                                          filled: true,
                                          hintStyle: TextStyle(
                                              fontSize: 15,
                                              color: Colors.black),
                                          hintText: DROPDOWN_TEXT,
                                          fillColor: Colors.white),
                                      value: valueforMoney,
                                      onChanged: (String Value) {
                                        setState(() {
                                          valueforMoney = Value;
                                        });
                                      },
                                      items: reviewList
                                          .map((cityTitle) => DropdownMenuItem(
                                              value: cityTitle,
                                              child: Text("$cityTitle")))
                                          .toList(),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Container Five
                    new Container(
                      child: Column(
                        children: [
                          Align(
                            alignment: Alignment.center,
                            child: Container(
                              height: 48,
                              decoration: new BoxDecoration(
                                shape: BoxShape.rectangle,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(5.0)),
                              ),
                              child: Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(5)),
                                  highlightColor: Colors.transparent,
                                  child: Center(
                                    child: Text(
                                      DEFAULT_SCORE,
                                      style: TextStyle(
                                        fontSize: 15,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    //  allAccommodationUI()
                  ],
                ),
              ),
            ),
          ),

          // Details Review
          Expanded(
            child: SingleChildScrollView(
              // Main Container Details
              child: Container(
                decoration: BoxDecoration(
                    color: Colors.grey[100],
                    border: Border.all(
                      color: Colors.grey[500],
                      width: 2,
                    )),
                padding: const EdgeInsets.all(5),
                margin: const EdgeInsets.all(5),
                child: Column(
                  children: <Widget>[
                    // Details Container One
                    new Container(
                      child: Column(
                        children: [
                          Align(
                            alignment: Alignment.center,
                            child: Container(
                              height: 48,
                              decoration: new BoxDecoration(
                                shape: BoxShape.rectangle,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(5.0)),
                              ),
                              child: Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(5)),
                                  highlightColor: Colors.transparent,
                                  child: Center(
                                    child: Text(
                                      DETAILS,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 25,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Details Gest Name
                    Padding(
                      padding: const EdgeInsets.all(5),
                      child: Container(
                        decoration: BoxDecoration(
                          color: AppTheme.getTheme().backgroundColor,
                          borderRadius: BorderRadius.all(Radius.circular(5)),
                          // border: Border.all(
                          //   color: HexColor("#757575").withOpacity(0.6),
                          // ),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: AppTheme.getTheme().dividerColor,
                              blurRadius: 8,
                              offset: Offset(4, 4),
                            ),
                          ],
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 16, right: 16),
                          child: Container(
                            height: 48,
                            child: Center(
                              child: TextField(
                                maxLines: 1,
                                onChanged: (String txt) {},
                                style: TextStyle(
                                  fontSize: 16,
                                  // color: AppTheme.dark_grey,
                                ),
                                cursorColor: AppTheme.getTheme().primaryColor,
                                decoration: new InputDecoration(
                                  suffixIcon:
                                      IconButton(icon: Icon(Icons.person)),
                                  errorText: null,
                                  border: InputBorder.none,
                                  hintText: GEST_NAME,
                                  hintStyle: TextStyle(
                                      color: AppTheme.getTheme().disabledColor),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),

                    // Details Email
                    Padding(
                      padding: const EdgeInsets.all(5),
                      child: Container(
                        decoration: BoxDecoration(
                          color: AppTheme.getTheme().backgroundColor,
                          borderRadius: BorderRadius.all(Radius.circular(5)),
                          // border: Border.all(
                          //   color: HexColor("#757575").withOpacity(0.6),
                          // ),
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: AppTheme.getTheme().dividerColor,
                              blurRadius: 8,
                              offset: Offset(4, 4),
                            ),
                          ],
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 16, right: 16),
                          child: Container(
                            height: 48,
                            child: Center(
                              child: TextField(
                                maxLines: 1,
                                onChanged: (String txt) {},
                                style: TextStyle(
                                  fontSize: 16,
                                  // color: AppTheme.dark_grey,
                                ),
                                cursorColor: AppTheme.getTheme().primaryColor,
                                decoration: new InputDecoration(
                                  suffixIcon:
                                      IconButton(icon: Icon(Icons.email)),
                                  errorText: null,
                                  border: InputBorder.none,
                                  hintText: EMAIL,
                                  hintStyle: TextStyle(
                                      color: AppTheme.getTheme().disabledColor),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),

                    // Details Phone number
                    Padding(
                      //margin: EdgeInsets.symmetric(vertical:1.0),
                      padding: EdgeInsets.all(5),

                      child: Expanded(
                        flex: 4,
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              flex: 1,
                              child: Container(
                                alignment: Alignment.centerLeft,
                                height: 55,
                                child: DropdownButtonFormField(
                                  isDense: false,
                                  itemHeight: 65,
                                  decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderRadius: const BorderRadius.all(
                                          const Radius.circular(5.0),
                                        ),
                                      ),
                                      filled: true,
                                      hintStyle: TextStyle(
                                          fontSize: 13, color: Colors.black),
                                      hintText: NUM,
                                      fillColor: Colors.white),
                                  value: facilities,
                                  onChanged: (String Value) {
                                    setState(() {
                                      facilities = Value;
                                    });
                                  },
                                  items: reviewList
                                      .map((cityTitle) => DropdownMenuItem(
                                          value: cityTitle,
                                          child: Text("$cityTitle")))
                                      .toList(),
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 3,
                              child: Container(
                                height: 55,
                                alignment: Alignment.centerLeft,
                                padding: const EdgeInsets.only(
                                    left: 20, top: 0, right: 0, bottom: 0),
                                decoration: BoxDecoration(
                                  color: AppTheme.getTheme().backgroundColor,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(5)),
                                  // border: Border.all(
                                  //   color: HexColor("#757575").withOpacity(0.6),
                                  // ),
                                  boxShadow: <BoxShadow>[
                                    BoxShadow(
                                      color: AppTheme.getTheme().dividerColor,
                                      blurRadius: 8,
                                      offset: Offset(4, 4),
                                    ),
                                  ],
                                ),
                                child: TextField(
                                  maxLines: 1,
                                  onChanged: (String txt) {},
                                  style: TextStyle(
                                    fontSize: 16,

                                    // color: AppTheme.dark_grey,
                                  ),
                                  cursorColor: AppTheme.getTheme().primaryColor,
                                  decoration: new InputDecoration(
                                    suffixIcon: IconButton(
                                        icon: Icon(Icons.phone_android)),
                                    errorText: null,
                                    border: InputBorder.none,
                                    hintText: PHONE,
                                    hintStyle: TextStyle(
                                        color:
                                            AppTheme.getTheme().disabledColor),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Details Country Name
                    Padding(
                      //margin: EdgeInsets.symmetric(vertical:1.0),
                      padding: EdgeInsets.all(5),

                      child: Expanded(
                        flex: 4,
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              flex: 1,
                              child: Container(
                                alignment: Alignment.centerLeft,
                                height: 55,
                                child: DropdownButtonFormField(
                                  isDense: false,
                                  itemHeight: 65,
                                  decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderRadius: const BorderRadius.all(
                                          const Radius.circular(5.0),
                                        ),
                                      ),
                                      filled: true,
                                      hintStyle: TextStyle(
                                          fontSize: 13, color: Colors.black),
                                      hintText: GIVE,
                                      fillColor: Colors.white),
                                  value: facilities,
                                  onChanged: (String Value) {
                                    setState(() {
                                      facilities = Value;
                                    });
                                  },
                                  items: reviewList
                                      .map((cityTitle) => DropdownMenuItem(
                                          value: cityTitle,
                                          child: Text("$cityTitle")))
                                      .toList(),
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 3,
                              child: Container(
                                height: 55,
                                alignment: Alignment.centerLeft,
                                padding: const EdgeInsets.only(
                                    left: 20, top: 0, right: 0, bottom: 0),
                                decoration: BoxDecoration(
                                  color: AppTheme.getTheme().backgroundColor,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(5)),
                                  // border: Border.all(
                                  //   color: HexColor("#757575").withOpacity(0.6),
                                  // ),
                                  boxShadow: <BoxShadow>[
                                    BoxShadow(
                                      color: AppTheme.getTheme().dividerColor,
                                      blurRadius: 8,
                                      offset: Offset(4, 4),
                                    ),
                                  ],
                                ),
                                child: TextField(
                                  maxLines: 1,
                                  onChanged: (String txt) {},
                                  style: TextStyle(
                                    fontSize: 16,

                                    // color: AppTheme.dark_grey,
                                  ),
                                  cursorColor: AppTheme.getTheme().primaryColor,
                                  decoration: new InputDecoration(
                                    suffixIcon: IconButton(
                                        icon: Icon(Icons.map_rounded)),
                                    errorText: null,
                                    border: InputBorder.none,
                                    hintText: COUNTRY_NAME,
                                    hintStyle: TextStyle(
                                        color:
                                            AppTheme.getTheme().disabledColor),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Details Comments Box
                    SizedBox(
                      height: MediaQuery.of(context).size.height / 6,
                      child: Padding(
                        padding: const EdgeInsets.all(5),
                        child: Container(
                          alignment: Alignment.topCenter,
                          decoration: BoxDecoration(
                            color: AppTheme.getTheme().backgroundColor,
                            borderRadius: BorderRadius.all(Radius.circular(5)),
                            // border: Border.all(
                            //   color: HexColor("#757575").withOpacity(0.6),
                            // ),
                            boxShadow: <BoxShadow>[
                              BoxShadow(
                                color: AppTheme.getTheme().dividerColor,
                                blurRadius: 8,
                                offset: Offset(4, 4),
                              ),
                            ],
                          ),
                          child: Padding(
                            padding: const EdgeInsets.only(left: 16, right: 16),
                            child: Container(
                              height: 48,
                              child: Center(
                                child: TextField(
                                  keyboardType: TextInputType.multiline,
                                  maxLines: 5,
                                  onChanged: (String txt) {},
                                  style: TextStyle(
                                    fontSize: 16,
                                    // color: AppTheme.dark_grey,
                                  ),
                                  cursorColor: AppTheme.getTheme().primaryColor,
                                  decoration: new InputDecoration(
                                    errorText: null,
                                    border: InputBorder.none,
                                    hintText: COMMENTS_BOX,
                                    hintStyle: TextStyle(
                                        color:
                                            AppTheme.getTheme().disabledColor),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),

                    // Details maximum character
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 10, top: 0, right: 150, bottom: 10),
                      child: Expanded(
                        child: Container(
                          width: MediaQuery.of(context).size.width / 2,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  CHARACTERS,
                                  style: TextStyle(
                                    fontSize: 13,
                                  ),
                                  textAlign: TextAlign.left,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    //  allAccommodationUI()
                  ],
                ),
              ),
            ),
          ),

          //////////////===============
          Divider(
            height: 1,
          ),
          Padding(
            padding: EdgeInsets.only(
                left: 16,
                right: 16,
                bottom: 16 + MediaQuery.of(context).padding.bottom,
                top: 8),
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                color: AppTheme.getTheme().primaryColor,
                borderRadius: BorderRadius.all(Radius.circular(24.0)),
                boxShadow: <BoxShadow>[
                  BoxShadow(
                    color: AppTheme.getTheme().dividerColor,
                    blurRadius: 8,
                    offset: Offset(4, 4),
                  ),
                ],
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.all(Radius.circular(24.0)),
                  highlightColor: Colors.transparent,
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Center(
                    child: Text(
                      SUBMIT.toUpperCase(),
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 22,
                          color: Colors.white),
                    ),
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  // Method Overall Calculation
  void overallCalculation(String s) {
    var clean1 = int.parse(s);
    var facilities1 = int.parse(s);
    var comfort1 = int.parse(s);
    var stuff1 = int.parse(s);
    var location1 = int.parse(s);
    var valueforMoney1 = int.parse(s);

    var sum =
        clean1 + facilities1 + comfort1 + stuff1 + location1 + valueforMoney1;
    var calcualteValue = sum / 6;
    print("calculation ${calcualteValue}");

   // return calcualteValue.toString();
// =======
//     var sum=clean1+facilities1+comfort1+stuff1+location1+valueforMoney1;
//     overAll=(sum/6) as int;
//     print("calculation ${overAll}");
//
//
// >>>>>>> towfiq_dev
  }

  // App Bar Method
  Widget appBar() {
    return Row(
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            SizedBox(
              height: AppBar().preferredSize.height,
              child: Padding(
                padding: EdgeInsets.only(top: 8, left: 0),
                child: Container(
                  width: AppBar().preferredSize.height - 8,
                  height: AppBar().preferredSize.height - 8,
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      borderRadius: BorderRadius.all(
                        Radius.circular(32.0),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(Icons.arrow_back),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 18, left: 20, bottom: 0),
              child: Text(
                WRITE_REVIEWED,
                textAlign: TextAlign.center,
                style: new TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class UpdateUI extends StatefulWidget {
  final int overALLValue;
  const UpdateUI(
      {Key key, @required this.overALLValue})
      : super(key: key);
  @override
  _UpdateUIState createState() => _UpdateUIState();
}

class _UpdateUIState extends State<UpdateUI> {
  @override
  Widget build(BuildContext context) {
    return   Container(
      height: 48,
      decoration: new BoxDecoration(
        shape: BoxShape.rectangle,
        borderRadius:
        BorderRadius.all(Radius.circular(5.0)),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius:
          BorderRadius.all(Radius.circular(5)),
          highlightColor: Colors.transparent,
          child: Center(
            child: Text(
               "${widget.overALLValue}  / 10",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 25,
              ),
            ),
          ),
        ),
      ),
    );
  }
}


// body:Stack(
// children: <Widget>[
// Container(
// alignment: Alignment.centerLeft,
// width: AppBar().preferredSize.height + 40,
// height: AppBar().preferredSize.height,
// child: Material(
// color: Colors.transparent,
// child: InkWell(
// borderRadius: BorderRadius.all(
// Radius.circular(32.0),
// ),
// onTap: () {
// // Navigator.pop(context);
// },
// // child: Padding(
// //   padding: const EdgeInsets.all(8.0),
// //   child: Icon(Icons.arrow_back),
// // ),
// ),
// ),
// ),
// Expanded(
//
// child: Text(
// WRITE_REVIEWED,
// style: TextStyle(
// fontWeight: FontWeight.w600,
// fontSize: 22,
// ),
// ),
// ),
// // Container(
// //   width: AppBar().preferredSize.height + 40,
// //   height: AppBar().preferredSize.height,
// //   child: Row(
// //     crossAxisAlignment: CrossAxisAlignment.center,
// //     mainAxisAlignment: MainAxisAlignment.end,
// //     children: <Widget>[
// //       Material(
// //         color: Colors.transparent,
// //         child: InkWell(
// //           borderRadius: BorderRadius.all(
// //             Radius.circular(32.0),
// //           ),
// //           onTap: () {},
// //           child: Padding(
// //             padding: const EdgeInsets.all(8.0),
// //             child: Icon(Icons.favorite_border),
// //           ),
// //         ),
// //       ),
// //       Material(
// //         color: Colors.transparent,
// //         child: InkWell(
// //           borderRadius: BorderRadius.all(
// //             Radius.circular(32.0),
// //           ),
// //           onTap: () {
// //             setState(() {
// //               isMap = !isMap;
// //             });
// //           },
// //           child: Padding(
// //             padding: const EdgeInsets.all(8.0),
// //             child: Icon(
// //                 isMap ? Icons.sort : FontAwesomeIcons.mapMarkedAlt),
// //           ),
// //         ),
// //       ),
// //     ],
// //   ),
// // )
// ],
// ),
