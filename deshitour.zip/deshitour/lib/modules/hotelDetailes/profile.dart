// import 'package:flutter/material.dart';
// import 'package:new_motel/provider/profile_provider.dart';
// import 'package:provider/provider.dart';
//
// class Profile extends StatefulWidget {
//   @override
//   _ProfileState createState() => _ProfileState();
// }
//
// class _ProfileState extends State<Profile> {
//   @override
//   void initState() {
//     final model = Provider.of<ProductListProvider>(context, listen: false);
//     model.productListDataListFetchData();
//     super.initState();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text(" Profile Provider "),
//         centerTitle: true,
//         backgroundColor: Colors.indigo[800],
//       ),
//       body: Consumer<ProductListProvider>(
//         builder: (_, auth, child) {
//           return ListView.builder(
//             itemCount: auth.productListDataList.length,
//             itemBuilder: (_, index) {
//               return Center(
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Text(
//                       auth.productListDataList[index].response.accountsEmail
//                           .toString(),
//                       style: TextStyle(fontSize: 25),
//                     )
//                   ],
//                 ),
//               );
//             },
//           );
//         },
//       ),
//     );
//   }
// }
