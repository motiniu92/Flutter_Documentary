// import 'dart:ui';

// import 'package:flutter/widgets.dart';
// import 'package:new_motel/model/hotel_details_room_model.dart';
// import 'package:new_motel/models/hotelList/hotelDetails.dart';

// import 'package:new_motel/screens/hotel_room_details_screen.dart';
// import 'package:new_motel/utils/constants.dart';
// import '../../appTheme.dart';
// import 'package:flutter/material.dart';

// class RoomBookingScreen extends StatefulWidget {
//   final String hotelName;
//   final List<Rooms> rooms;

//   const RoomBookingScreen({Key key, this.hotelName, this.rooms})
//       : super(key: key);

//   @override
//   _RoomBookingScreenState createState() => _RoomBookingScreenState();
// }

// class _RoomBookingScreenState extends State<RoomBookingScreen>
//     with TickerProviderStateMixin {
//   List<Rooms> romeList;
//   AnimationController animationController;
//   var total_price = 0, roomNumber = 0;

//   @override
//   void initState() {
//     animationController = AnimationController(
//         duration: Duration(milliseconds: 2000), vsync: this);
//     super.initState();
//   }

//   @override
//   void dispose() {
//     animationController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     romeList = widget.rooms;
//     return Scaffold(
//       backgroundColor: AppTheme.getTheme().backgroundColor,
//       body: Column(
//         children: <Widget>[
//           getAppBarUI(),
//           getRoomScreenHeader(),
//           Expanded(
//             child: romeList.length == 0
//                 ? Center(
//                     child: Text(
//                       "No Room Available!!",
//                       style: TextStyle(
//                           color: Colors.red,
//                           fontWeight: FontWeight.w300,
//                           fontSize: 25),
//                     ),
//                   )
//                 : ListView.builder(
//                     padding: EdgeInsets.all(0.0),
//                     itemCount: romeList.length,
//                     itemBuilder: (context, index) {
//                       var count = romeList.length > 10 ? 10 : romeList.length;
//                       var animation = Tween(begin: 0.0, end: 1.0).animate(
//                           CurvedAnimation(
//                               parent: animationController,
//                               curve: Interval((1 / count) * index, 1.0,
//                                   curve: Curves.fastOutSlowIn)));
//                       animationController.forward();
//                       return RoomeBookView(
//                         callBack: (String price, int value) {
//                           setState(() {
//                             total_price = int.parse(price);
//                             roomNumber = value;
//                           });
//                         },
//                         roomData: romeList[index],
//                         hotelName: widget.hotelName,
//                         animation: animation,
//                         animationController: animationController,
//                         controller: null,
//                       );
//                     },
//                   ),
//           ),
//           Padding(
//             padding: EdgeInsets.only(
//                 left: 16,
//                 right: 16,
//                 bottom: 16 + MediaQuery.of(context).padding.bottom,
//                 top: 8),
//             child: Container(
//               height: 48,
//               decoration: BoxDecoration(
//                 color: AppTheme.getTheme().primaryColor,
//                 borderRadius: BorderRadius.all(Radius.circular(24.0)),
//                 boxShadow: <BoxShadow>[
//                   BoxShadow(
//                     color: AppTheme.getTheme().dividerColor,
//                     blurRadius: 8,
//                     offset: Offset(4, 4),
//                   ),
//                 ],
//               ),
//               child: Material(
//                 color: Colors.transparent,
//                 child: InkWell(
//                   borderRadius: BorderRadius.all(Radius.circular(24.0)),
//                   highlightColor: Colors.transparent,
//                   onTap: () {
//                     Navigator.push(
//                         context,
//                         MaterialPageRoute(
//                             builder: (context) => HotelRoomFormPage()));
//                   },
//                   child: Center(
//                     child: Text(
//                       BOOK_NOW.toUpperCase(),
//                       style: TextStyle(
//                           fontWeight: FontWeight.bold,
//                           fontSize: 22,
//                           color: Colors.white),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   Widget getAppBarUI() {
//     return Container(
//       decoration: BoxDecoration(
//         color: AppTheme.getTheme().backgroundColor,
//         boxShadow: <BoxShadow>[
//           BoxShadow(
//               color: AppTheme.getTheme().dividerColor,
//               offset: Offset(0, 2),
//               blurRadius: 8.0),
//         ],
//       ),
//       child: Padding(
//         padding: EdgeInsets.only(
//             top: MediaQuery.of(context).padding.top, left: 8, right: 8),
//         child: Row(
//           children: <Widget>[
//             Container(
//               alignment: Alignment.centerLeft,
//               width: AppBar().preferredSize.height,
//               height: AppBar().preferredSize.height,
//               child: Material(
//                 color: Colors.transparent,
//                 child: InkWell(
//                   borderRadius: BorderRadius.all(
//                     Radius.circular(32.0),
//                   ),
//                   onTap: () {
//                     Navigator.pop(context);
//                   },
//                   child: Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: Icon(Icons.arrow_back),
//                   ),
//                 ),
//               ),
//             ),
//             Expanded(
//               child: Center(
//                 child: Text(
//                   widget.hotelName,
//                   style: TextStyle(
//                     fontWeight: FontWeight.w600,
//                     fontSize: 22,
//                   ),
//                   overflow: TextOverflow.ellipsis,
//                 ),
//               ),
//             ),
//             Container(
//               width: AppBar().preferredSize.height,
//               height: AppBar().preferredSize.height,
//               child: Material(
//                 color: Colors.transparent,
//                 child: InkWell(
//                   borderRadius: BorderRadius.all(
//                     Radius.circular(32.0),
//                   ),
//                   onTap: () {
//                     final snackBar = SnackBar(content: Text("Tap"));
//                     Scaffold.of(context).showSnackBar(snackBar);
//                   },
//                   child: Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: Icon(Icons.favorite_border),
//                   ),
//                 ),
//               ),
//             )
//           ],
//         ),
//       ),
//     );
//   }

//   // getRoomSreenHeader Method
//   Widget getRoomScreenHeader() {
//     return Container(
//       decoration: BoxDecoration(
//         color: Colors.black12,
//         borderRadius: BorderRadius.all(Radius.circular(2)),
//         boxShadow: <BoxShadow>[
//           BoxShadow(
//             color: AppTheme.getTheme().dividerColor,
//             blurRadius: 8,
//             offset: Offset(4, 4),
//           ),
//         ],
//       ),
//       height: 55,
//       child: new Row(
//         children: [
//           // Left Expanded
//           Expanded(
//             child: Container(
//               width: MediaQuery.of(context).size.width / 2,
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.end,
//                 children: [
//                   Align(
//                     alignment: Alignment.center,
//                     child: Text(
//                       ROOMS,
//                       style: TextStyle(
//                         fontWeight: FontWeight.bold,
//                         fontSize: 18,
//                       ),
//                       textAlign: TextAlign.center,
//                     ),
//                   ),
//                   SizedBox(
//                     width: MediaQuery.of(context).size.width / 2,
//                     child: Text(
//                       "${roomNumber}",
//                       // widget.rooms,
//                       style: TextStyle(
//                         fontWeight: FontWeight.bold,
//                         fontSize: 18,
//                       ),
//                       textAlign: TextAlign.center,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),

//           VerticalDivider(
//             width: 20,
//             color: Colors.white,
//           ),

//           // Right Expanded
//           Expanded(
//             child: Container(
//               width: MediaQuery.of(context).size.width / 2,
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.end,
//                 children: [
//                   Align(
//                     alignment: Alignment.center,
//                     child: Text(
//                       "BDT",
//                       style: TextStyle(
//                         fontWeight: FontWeight.bold,
//                         fontSize: 18,
//                       ),
//                       textAlign: TextAlign.center,
//                     ),
//                   ),
//                   SizedBox(
//                     width: MediaQuery.of(context).size.width / 2,
//                     child: Text(
//                       total_price.toString(),
//                       style: TextStyle(
//                         fontWeight: FontWeight.bold,
//                         fontSize: 18,
//                       ),
//                       textAlign: TextAlign.center,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// class RoomeBookView extends StatefulWidget {
//   final MyController controller;
//   final Function(String, int) callBack;
//   final Rooms roomData;
//   final AnimationController animationController;
//   final Animation animation;
//   final String hotelName;

//   const RoomeBookView(
//       {Key key,
//       this.roomData,
//       this.animationController,
//       this.animation,
//       @required this.callBack,
//       @required this.controller,
//       this.hotelName})
//       : super(key: key);

//   @override
//   _RoomeBookViewState createState() => _RoomeBookViewState();
// }

// class _RoomeBookViewState extends State<RoomeBookView> {
//   var pageController = PageController(initialPage: 0);
//   List<String> maxAvailablity;
//   String facilities;
//   var valueChange;
//   var price1 = 0, total_room = 0;

//   HotelDetailsResponse _hotelDetailsResponse;

//   ScrollController scrollController = ScrollController(initialScrollOffset: 0);

//   @override
//   void initState() {
//     super.initState();
//     // MyController _controller = widget.controller;
//     // if (_controller != null) {
//     //   _controller.myFunction = firstFunction ;
//     // }
//   }

//   // String firstFunction(int value, String price) {
//   //   var str = price;
//   //   var parts = str.split(',');
//   //   var prefix = parts[0].trim(); // prefix: "date"
//   //   var prefix1 = parts[1].trim(); // prefix: "date"
//   //   var date = prefix + prefix1;
//   //
//   //   setState(() {
//   //     int price = int.parse(date);
//   //     valueChange = value * price;
//   //     print(" value change ${valueChange.toString()}");
//   //   });
//   //   return valueChange;
//   // }

//   @override
//   Widget build(BuildContext context) {
//     maxAvailablity = new List<String>();
//     int num = int.parse(widget.roomData.maxAvailablity);
//     for (var i = 0; i < num + 1; i++) {
//       maxAvailablity.add(i.toString());
//     }

//     return AnimatedBuilder(
//       animation: widget.animationController,
//       builder: (BuildContext context, Widget child) {
//         return FadeTransition(
//           opacity: widget.animation,
//           child: new Transform(
//             transform: new Matrix4.translationValues(
//                 0.0, 40 * (1.0 - widget.animation.value), 0.0),
//             child: Column(
//               children: <Widget>[
//                 Stack(
//                   alignment: Alignment.bottomCenter,
//                   children: <Widget>[
//                     AspectRatio(
//                         aspectRatio: 1.5,
//                         child:Image.network(
//                           widget.roomData.thumbnail,
//                           fit: BoxFit.cover,
//                         )),

//                     ////////////////////////======================
//                     Padding(
//                       padding: const EdgeInsets.only(bottom: 28.0),
//                       child: Center(
//                         child: ClipRRect(
//                           borderRadius: BorderRadius.all(Radius.circular(24)),
//                           child: new BackdropFilter(
//                             filter: new ImageFilter.blur(
//                                 sigmaX: 10.0, sigmaY: 10.0),
//                             child: Container(
//                               color: HexColor("#0f346c"),
//                               child: Material(
//                                 color: Colors.transparent,
//                                 child: InkWell(
//                                   highlightColor: Colors.transparent,
//                                   splashColor: AppTheme.getTheme()
//                                       .primaryColor
//                                       .withOpacity(0.2),
//                                   borderRadius:
//                                       BorderRadius.all(Radius.circular(38)),
//                                   onTap: () {
//                                     try {
//                                       scrollController.animateTo(
//                                           MediaQuery.of(context).size.height -
//                                               MediaQuery.of(context)
//                                                       .size
//                                                       .height /
//                                                   5,
//                                           duration: Duration(milliseconds: 500),
//                                           curve: Curves.fastOutSlowIn);
//                                     } catch (e) {}
//                                   },
//                                   child: Padding(
//                                     padding: const EdgeInsets.only(
//                                         left: 16, right: 16, top: 4, bottom: 4),
//                                     child: Row(
//                                       mainAxisSize: MainAxisSize.min,
//                                       mainAxisAlignment:
//                                           MainAxisAlignment.center,
//                                       crossAxisAlignment:
//                                           CrossAxisAlignment.center,
//                                       children: <Widget>[
//                                         Padding(
//                                           padding: const EdgeInsets.all(8.0),
//                                           child: Text(
//                                             'More Details',
//                                             style: TextStyle(
//                                               color: Colors.white,
//                                               fontWeight: FontWeight.w600,
//                                             ),
//                                           ),
//                                         ),
//                                         Padding(
//                                           padding:
//                                               const EdgeInsets.only(top: 2),
//                                           child: Icon(
//                                             Icons.keyboard_arrow_down,
//                                             color: Colors.white,
//                                             size: 24,
//                                           ),
//                                         )
//                                       ],
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),

//                     //////////////////////========================
//                   ],
//                 ),

//                 // Modifi Here 16/02/2021
//                 Padding(
//                   padding: const EdgeInsets.only(
//                       left: 12, right: 12, bottom: 16, top: 16),
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: <Widget>[
//                       // Row ONe
//                       Row(
//                         children: <Widget>[
//                           Expanded(
//                             child: Text(
//                               widget.roomData.title,
//                               maxLines: 2,
//                               textAlign: TextAlign.left,
//                               style: TextStyle(
//                                 fontWeight: FontWeight.bold,
//                                 fontSize: 16,
//                               ),
//                               overflow: TextOverflow.ellipsis,
//                             ),
//                           ),
//                           Container(
//                             width: MediaQuery.of(context).size.width / 2.5,
//                             child: Column(
//                               mainAxisAlignment: MainAxisAlignment.end,
//                               children: [
//                                 Align(
//                                   alignment: Alignment.center,
//                                   child: Padding(
//                                     padding: const EdgeInsets.only(left: 10),
//                                     child: Text(
//                                       "Select Rooms",
//                                       style: TextStyle(
//                                         fontWeight: FontWeight.bold,
//                                         fontSize: 16,
//                                       ),
//                                       textAlign: TextAlign.right,
//                                     ),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),

//                       SizedBox(
//                         height: 7,
//                       ),

//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.start,
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Padding(
//                             padding: const EdgeInsets.only(top: 18.0),
//                             child: Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceAround,
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: <Widget>[
//                                 Padding(
//                                   padding: const EdgeInsets.only(
//                                       left: 0.0,
//                                       top: 0.0,
//                                       right: 4.0,
//                                       bottom: 0.0),
//                                   child: Text(
//                                     "${widget.roomData.currCode} ${widget.roomData.price}",
//                                     textAlign: TextAlign.left,
//                                     style: TextStyle(
//                                       fontWeight: FontWeight.w600,
//                                       fontSize: 22,
//                                     ),
//                                   ),
//                                 ),
//                                 Padding(
//                                   padding: const EdgeInsets.only(
//                                       bottom: 4, right: 60),
//                                   child: Text(
//                                     "/per night",
//                                     style: TextStyle(
//                                         fontSize: 14,
//                                         color: AppTheme.getTheme()
//                                             .disabledColor
//                                             .withOpacity(0.8)),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                           SizedBox(
//                             width: MediaQuery.of(context).size.width / 3.5,
//                             height: 55,
//                             child: DropdownButtonFormField(
//                               isDense: false,
//                               itemHeight: 65,
//                               decoration: InputDecoration(
//                                   border: OutlineInputBorder(
//                                     borderRadius: const BorderRadius.all(
//                                       const Radius.circular(5.0),
//                                     ),
//                                   ),
//                                   filled: true,
//                                   hintStyle: TextStyle(
//                                       fontSize: 15, color: Colors.black),
//                                   hintText: maxAvailablity[0],
//                                   fillColor: Colors.white),
//                               value: facilities,
//                               onChanged: (String Value) {
//                                 setState(() {
//                                   facilities = Value;
//                                   //    firstFunction(int.parse(facilities), widget.roomData.price);
//                                 });

//                                 setState(() {
//                                   var value1 = int.parse(facilities);
//                                   var str = widget.roomData.price;
//                                   var parts = str.split(',');
// var prefix =
//     parts[0].trim(); // prefix: "date"
// var prefix1 =
//     parts[1].trim(); // prefix: "date"
// var date = prefix + prefix1;
//                                   if (value1 != null)
//                                     total_room += value1;
//                                   else
//                                     total_room -= value1;

//                                   int price = int.parse(date);
//                                   var total_price = total_room * price;

//                                   if (total_price != null)
//                                     price1 += total_price;
//                                   else
//                                     price1 -= total_price;
//                                   print(
//                                       " value change ${total_price.toString()}");
//                                 });

//                                 print("room ${total_room}");

//                                 widget.callBack(price1.toString(), total_room);
//                               },
//                               items: maxAvailablity
//                                   .map((cityTitle) => DropdownMenuItem(
//                                       value: cityTitle,
//                                       child: Text("$cityTitle")))
//                                   .toList(),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),

//                 Divider(
//                   height: 1,
//                 )
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   }
// }

// class MyController {
//   VoidCallback myFunction;
//   VoidCallback mySecondFunction;

//   void dispose() {
//     //Remove any data that's will cause a memory leak/render errors in here
//     myFunction = null;
//     mySecondFunction = null;
//   }
// }
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:new_motel/authenticating/login.dart';
import 'package:new_motel/models/bookingDetails.dart';
import 'package:new_motel/models/hotelList/hotelDetails.dart';
import 'package:new_motel/screens/hotel_room_details_screen.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../appTheme.dart';

class RoomBookingScreen extends StatefulWidget {
  final String hotelName;
  final int days;
  final List<Rooms> rooms;
  final HotelDetailsResponse hotel;

  const RoomBookingScreen(
      {Key key, this.days, this.hotelName, this.rooms, @required this.hotel})
      : super(key: key);

  @override
  _RoomBookingScreenState createState() => _RoomBookingScreenState();
}

class _RoomBookingScreenState extends State<RoomBookingScreen>
    with TickerProviderStateMixin {
  List<Rooms> romeList;
  List<BookingDetails> bookingList = List<BookingDetails>();
  List<BookingDetails> finalBookingList = List<BookingDetails>();
  AnimationController animationController;
  var total_price = 0, roomNumber = 0;
  SharedPreferences _sharedPreferences;
  Map<String, int> roomCountMap = {};
  Map<String, int> roomPriceMap = {};

  Map<String, String> roomBooking = {};
  Map<String, String> idBooking = {};

  // Map<String, String> roomMaxAdults = {};

  List<Map<String, String>> bookingMap;
  var calculation;
  List<String> name;
  List<String> ids;

  BookingDetails bookingDetails;

  // loadToken() async {
  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   prefs.getString('apiToken');
  //   return prefs.getString('apiToken');
  // }

  @override
  void initState() {
    // loadToken();
    name = List<String>();
    ids = List<String>();
    bookingMap = List<Map<String, String>>();
    romeList = widget.rooms;
    animationController = AnimationController(
        duration: Duration(milliseconds: 2000), vsync: this);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.getTheme().backgroundColor,
      body: Column(
        children: <Widget>[
          getAppBarUI(),
          getRoomScreenHeader(),
          Expanded(
            child: romeList.length == 0
                ? Center(
                    child: Text(
                      NO_ROOM,
                      style: TextStyle(
                          color: Colors.red,
                          fontWeight: FontWeight.w300,
                          fontSize: 25),
                    ),
                  )
                : ListView.builder(
                    padding: EdgeInsets.all(0.0),
                    itemCount: romeList.length,
                    itemBuilder: (context, index) {
                      var count = romeList.length > 10 ? 10 : romeList.length;
                      var animation = Tween(begin: 0.0, end: 1.0).animate(
                          CurvedAnimation(
                              parent: animationController,
                              curve: Interval((1 / count) * index, 1.0,
                                  curve: Curves.fastOutSlowIn)));
                      animationController.forward();
                      return RoomeBookView(
                        roomCountCallback: (String id,
                            String room_name,
                            String adults,
                            String roomPrice,
                            int roomCount,
                            int days) {
                          setState(() {
                            // for (var name = 0;
                            //     name < widget.hotelName.length;
                            //     name++) {
                            //   print("RoomBook Name..... : $room_name");
                            // }
                            //
                            // for (int price = 0;
                            //     price < roomPrice.length;
                            //     price++) {
                            //   print("RoomBook Price..... : $roomPrice");
                            // }

                            roomCountMap['$index'] = roomCount;
                            // print("Room Count AA.......$roomCount");
                            // pri
                            //
                            // nt("RoomPrice......>>>>> $roomPrice");
                            var parts = roomPrice.split(',');
                            var bbb = parts[0].trim(); // prefix: "date"
                            var bbb1 = parts[1].trim(); // prefix: "date"
                            calculation = int.parse(bbb + bbb1) * days;
                            int price = calculation;
                            var total_price = roomCount * price;
                            roomPriceMap['$index'] = total_price;
                            // print("RoomTotalPrice......>>>>> $roomCountMap");

                            ///   roomBooking['$index'] = room_name;
                            idBooking['$index'] = id;
                            // roomMaxAdults['$index'] = adults;

                            // print("jfshfhslf;sfdffd+>>>>>>${name}");
                            roomBooking['$index'] = room_name;
                            // roomMaxAdults['$index'] = adults;

                            bookingMap.add(roomBooking);
                            //   roomBooking['$index'] = roomCount.toString();
                            //  roomBooking['$index'] = room_name;
                            // print("Room count : $roomCount");
                            // print("Room Name : $room_name");

                            roomBooking.forEach((key, value) {
                              print(" room booking $key : $value");
                            });

                            bookingMap.add(roomBooking);

                            roomCountMap.forEach((key, value) {
                              print("roomPrice $value");
                            });

                            print("RoomCount......>>>>> ${bookingMap.length}");
                          });

                          bookingDetails = BookingDetails(
                              id, roomCount, room_name, calculation);

                          if (bookingList.isEmpty) {
                            bookingList.add(bookingDetails);
                          } else {
                            var isExist = isRoomExists(bookingList, id);
                            if (isExist) {
                              var position = roomPosition(bookingList, id);
                              bookingList.removeAt(position);
                              bookingList.add(bookingDetails);
                            } else {
                              bookingList.add(bookingDetails);
                            }
                          }
                          print("booklist size: ${bookingList.length}");
                          for (int a = 0; a < bookingList.length; a++) {
                            BookingDetails dd = bookingList[a];
                            print(
                                "Room count:  $a , ${dd.book_room_count} , ${dd.book_room_name}");
                          }

                          //   bookingList.add(bookingDetails);
                          print(
                              "RoomCountnjsndjshfjks......>>>>> ${bookingList.length}");
                          print("Days 831: ${widget.days}");
                        },
                        roomData: romeList[index],
                        day: widget.days,
                        hotelName: widget.hotelName,
                        roomlist: romeList,
                        animation: animation,
                        animationController: animationController,
                      );
                    },
                  ),
          ),
          Padding(
            padding: EdgeInsets.only(
                left: 16,
                right: 16,
                bottom: 16 + MediaQuery.of(context).padding.bottom,
                top: 8),
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                color: AppTheme.getTheme().primaryColor,
                borderRadius: BorderRadius.all(Radius.circular(24.0)),
                boxShadow: <BoxShadow>[
                  BoxShadow(
                    color: AppTheme.getTheme().dividerColor,
                    blurRadius: 8,
                    offset: Offset(4, 4),
                  ),
                ],
              ),
              // Toufiq Cowlick, [21.02.21 23:32]
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.all(Radius.circular(24.0)),
                  highlightColor: Colors.transparent,
                  onTap: () async {
                    SharedPreferences sharedPreferences =
                        await SharedPreferences.getInstance();
                    String token = sharedPreferences.getString("token");
                    print("Room Booking... Screen Token.....$token");

                    finalBookingList.clear();
                    int pos = 0;
                    for (int a = 0; a < bookingList.length; a++) {
                      BookingDetails dd = bookingList[a];
                      print(
                          "Room count:  $a , ${dd.book_room_count} , ${dd.book_room_name}");
                      if (dd.book_room_count > 1) {
                        for (int b = 0; b < dd.book_room_count; b++) {
                          finalBookingList.add(BookingDetails(dd.id, b + 1,
                              dd.book_room_name, dd.bookingPrice));
                        }
                      } else if (dd.book_room_count == 1) {
                        finalBookingList.add(BookingDetails(
                            dd.id, 1, dd.book_room_name, dd.bookingPrice));
                      }
                    }
                    print(" ABir.....${finalBookingList.length}");
                    if (finalBookingList.isEmpty) {
                      Fluttertoast.showToast(
                          msg: ('Select at least 1 room'),
                          toastLength: Toast.LENGTH_SHORT,
                          gravity: ToastGravity.BOTTOM,
                          timeInSecForIosWeb: 2,
                          backgroundColor: Colors.indigo,
                          textColor: Colors.white,
                          fontSize: 16.0);
                    } else {
                      if (token == null) {
                        print("BBBBBBBBBBBBBBB$bookingList");
                        print("CCCCCCCCCCCCCC${widget.hotel}");
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => LoginWidget(
                                      days: widget.days,
                                      rr: bookingList,
                                      hotelDetails: widget.hotel,
                                      type: "hotel",
                                    )));
                      } else {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => HotelRoomFormPage(
                                      days: widget.days,
                                      rr: bookingList,
                                      hotel: widget.hotel,
                                    )));
                      }
                    }
                    /*   var roomBookingValue;
                    var idBookingValue;
=======
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => HotelRoomFormPage(
                                rr: bookingList,
                                )));
                    var roomBookingValue;
>>>>>>> eb97ea6175e87be590ec82b7c0a50f5c54ba92ab
                    // var roomCountValue = roomCountMap.values
                    //     .reduce((value, element) => element);
                    roomBookingValue =
                        roomBooking.values.reduce((value, element) => element);

                    idBookingValue =
                        idBooking.values.reduce((value, element) => element);

                    var countValue = 0;
                    //     roomCountMap.values.reduce((value, element) => value);
                    var id;
                    var roomvooking;
                    roomBookingValue =
                        roomBooking.values.reduce((value, element) => value);
                    idBookingValue =
                        idBooking.values.reduce((value, element) => value);

                    roomBooking.entries.forEach((e) => name.add(e.value));
                    idBooking.entries.forEach((e) => ids.add(e.value));

                    print(
                        "hchsghvbjlsvdhjvlbdfhjkvbhdkjbvkd ln ${roomBookingValue}");
                    print(
                        "hhshfshdsjfbshjbfshbfhsbfhsjfhsjfgshjfgshfgsfsjfsfjsfsfsd${name}");

                    // ignore: unnecessary_statements
                    roomCountMap.forEach((key, value) {
                      print("dksjfjskfhsj===> $value");
                      countValue += value;
                    });
                    roomBooking.forEach((key, value) {
                      print(
                          "mhhcshgshuvsuvusbvsuhvbsuhvbshubvsjvbsjhvbsjvbsjv $value");
                      name.add(value);
                    });

                    print(
                        "hfushfkslhfjkslhgjkdlhgkdjghjkdghjdgr${name.length}");
                    for (int j = 0; j < name.length; j++) {
                      roomvooking = name[j];

                      print("rooom name $roomvooking");
                    }
                    for (int j = 0; j < ids.length; j++) {
                      id = ids[j];
                      print("rooom id $id");
                    }

                    if (countValue != 0) {
                   //   bookingList.clear();
                      for (int i = 0; i < countValue; i++) {
                        bookingDetails =
                            BookingDetails(id, i + 1, roomvooking + id);
                        bookingList.add(bookingDetails);
                      }
<<<<<<< HEAD
                    }*/

                    // print("booklist size 22 : ${bookingList.length}");
                    // for (int a = 0; a < bookingList.length; a++) {
                    //   BookingDetails dd = bookingList[a];
                    //   print(
                    //       "Room count 22 :  $a , ${dd.book_room_count} , ${dd.book_room_name}");
                    // }
//
// =======
//                     }
//
//                     // Print For Testing
//                     for(int a = 0; a<bookingList.length; a++){
//
//                       print(bookingList[a].book_room_name);
//                       print(bookingList[a].book_room_count);
//
//                     }
// >>>>>>> eb97ea6175e87be590ec82b7c0a50f5c54ba92ab
                    // print("coount value ===> ${bookingList.length}");
                    // print("coount value jhj value ===> ${countValue}");
                    // print("coount value jhj value ===> ${countValue1}");
                    // print("roomBookingValue value jhj value ===> ${roomBookingValue}");
                    // print("roomCountValue value jhj value ===> ${roomCountValue}");
                    // if(roomCountValue!=0){
                    //   for (int i = 0; i < roomCountValue; i++) {
                    //     bookingDetails =
                    //         BookingDetails(i + 1, roomBookingValue);
                    //     bookingList.add(bookingDetails);
                    //     print("=====>>>> room count ${bookingList.length}");
                    //     print("=====>>>> room count value $roomCountValue");
                    //   }

                    // var roomCountValue = roomCountMap.values
                    //     .reduce((value, element) => element);
                    // var roomBookingValue = roomBooking.values
                    //     .reduce((value, element) => element);
                    // var countAdults1 = roomMaxAdults.values
                    //     .reduce((value, element) => element);
                    //
                    // var countValue =
                    //     roomCountMap.values.reduce((value, element) => value);
                    // var countValue1 =
                    //     roomBooking.values.reduce((value, element) => value);
                    // var countAdults = roomMaxAdults.values
                    //     .reduce((value, element) => value);

                    //   print("Adults====>>$countAdults $countAdults1");

//                       bookingDetails = BookingDetails(
//
//                   Toufiq Cowlick, [21.02.21 23:32]
//                           countValue, countValue1, int.parse(countAdults));
//                       bookingList.add(bookingDetails);
//                       // for(int i=0;i<countValue;i++){
//                       // }
//
//                       bookingDetails = BookingDetails(roomCountValue,
//                           roomBookingValue, int.parse(countAdults1));
//                       bookingList.add(bookingDetails);
//                       // for(int i=0;i<roomCountValue;i++){
// >>>>>>> dd440ce80db8ea61a44e490a67705a7b1d2e7807
//}

                    // Navigator.push(
                    //     context,
                    //     MaterialPageRoute(
                    //         builder: (context) => LoginWidget(
                    //             // rr: bookingList,
                    //             )));

                    // bookingList.add(BookingDetails(
                    //     roomCountMap.values.reduce((value, element) => element),
                    //     roomBooking.values
                    //         .reduce((value, element) => element)));

                    // //;

                    print("onclick====>>> ${bookingList.length}");
                  },
                  child: Center(
                    child: Text(
                      BOOK_NOW,
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 22,
                          color: Colors.white),
                    ),
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget getAppBarUI() {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.getTheme().backgroundColor,
        boxShadow: <BoxShadow>[
          BoxShadow(
              color: AppTheme.getTheme().dividerColor,
              offset: Offset(0, 2),
              blurRadius: 8.0),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.only(
            top: MediaQuery.of(context).padding.top, left: 8, right: 60),
        child: Row(
          children: <Widget>[

            Container(
              alignment: Alignment.centerLeft,
              width: AppBar().preferredSize.height,
              height: AppBar().preferredSize.height,
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.all(
                    Radius.circular(32.0),
                  ),
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Icon(Icons.arrow_back),
                  ),
                ),
              ),


            ),
            Expanded(

                child: Center(
                  child: Text(
                    widget.hotelName,
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 22,
                      color: HexColor("#26408A"),
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),

            ),
            // Container(
            //   width: AppBar().preferredSize.height,
            //   height: AppBar().preferredSize.height,
            //   child: Material(
            //     color: Colors.transparent,
            //     child: InkWell(
            //       borderRadius: BorderRadius.all(
            //         Radius.circular(32.0),
            //       ),
            //       onTap: () {
            //         final snackBar = SnackBar(content: Text("Tap"));
            //         Scaffold.of(context).showSnackBar(snackBar);
            //       },
            //       child: Padding(
            //         padding: const EdgeInsets.all(8.0),
            //         child: Icon(Icons.favorite_border),
            //       ),
            //     ),
            //   ),
            // )
          ],
        ),
      ),
    );
  }

  // getRoomSreenHeader Method
  Widget getRoomScreenHeader() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.black12,
        borderRadius: BorderRadius.all(Radius.circular(2)),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: AppTheme.getTheme().dividerColor,
            blurRadius: 8,
            offset: Offset(4, 4),
          ),
        ],
      ),
      height: 55,
      child: new Row(
        children: [
          // Left Expanded
          Expanded(
            child: Container(
              width: MediaQuery.of(context).size.width / 2,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      ROOMS,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  SizedBox(
                    width: MediaQuery.of(context).size.width / 2,
                    child: Text(
                      "${roomCountMap.isEmpty ? 0 : roomCountMap.values.reduce((a, b) => a + b)}",
                      // "0",
                      // widget.rooms,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          ),

          VerticalDivider(
            width: 20,
            color: Colors.white,
          ),

          // Right Expanded
          Expanded(
            child: Container(
              width: MediaQuery.of(context).size.width / 2,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "BDT",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  SizedBox(
                    width: MediaQuery.of(context).size.width / 2,
                    child: Text(
                      "${roomPriceMap.isEmpty ? 0 : roomPriceMap.values.reduce((a, b) => a + b)}",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  bool isRoomExists(List<BookingDetails> bookingList, String id) {
    var isExist = false;
    for (BookingDetails dd in bookingList) {
      if (dd.id == id) {
        isExist = true;
        break;
      }
    }
    return isExist;
  }

  int roomPosition(List<BookingDetails> bookingList, String id) {
    var pos = 0;
    for (int i = 0; i < bookingList.length; i++) {
      if (bookingList[i].id == id) {
        pos = i;
        break;
      }
    }
    return pos;
  }
}

class RoomeBookView extends StatefulWidget {
  final Function(String) callBack;
  final Function(String, String, String, String, int, int) roomCountCallback;
  final Rooms roomData;
  final AnimationController animationController;
  final Animation animation;
  final String hotelName;
  final List<Rooms> roomlist;
  final int day;

  const RoomeBookView(
      {Key key,
      this.roomData,
      this.animationController,
      this.animation,
      this.day,
      @required this.callBack,
      @required this.roomlist,
      @required this.roomCountCallback,
      this.hotelName})
      : super(key: key);

  @override
  _RoomeBookViewState createState() => _RoomeBookViewState();
}

class _RoomeBookViewState extends State<RoomeBookView> {
  var pageController = PageController(initialPage: 0);
  List<String> maxAvailablity;
  String facilities;
  var price1 = 0, total_room = 0;
  String bbb;

  // Map<String, dynamic> dropdownData;

  HotelDetailsResponse _hotelDetailsResponse;

  ScrollController scrollController = ScrollController(initialScrollOffset: 0);

  @override
  void initState() {
    super.initState();
    // MyController _controller = widget.controller;
    // if (_controller != null) {
    //   _controller.myFunction = firstFunction ;
    // }
  }

  // String firstFunction(int value, String price) {
  //   var str = price;
  //   var parts = str.split(',');
  //   var prefix = parts[0].trim(); // prefix: "date"
  //   var prefix1 = parts[1].trim(); // prefix: "date"
  //   var date = prefix + prefix1;
  //
  //   setState(() {
  //     int price = int.parse(date);
  //     valueChange = value * price;
  //     print(" value change ${valueChange.toString()}");
  //   });
  //   return valueChange;
  // }

  @override
  Widget build(BuildContext context) {
    maxAvailablity = List<String>();
    int num = int.parse(widget.roomData.maxAvailablity);
    for (var i = 0; i < num + 1; i++) {
      setState(() {
        maxAvailablity.add(i.toString());
      });
    }
    return AnimatedBuilder(
      animation: widget.animationController,
      builder: (BuildContext context, Widget child) {
        return FadeTransition(
          opacity: widget.animation,
          child: new Transform(
            transform: new Matrix4.translationValues(
                0.0, 40 * (1.0 - widget.animation.value), 0.0),
            child: Column(
              children: <Widget>[
                Stack(
                  alignment: Alignment.bottomCenter,
                  children: <Widget>[
                    AspectRatio(
                        aspectRatio: 1.5,
                        child: Image.network(
                          widget.roomData.thumbnail,
                          fit: BoxFit.cover,
                        )),

                    // More Info Button
                    // GestureDetector(
                    //   onTap: () {
                    //     print("");
                    //   },
                    //   child: Padding(
                    //     padding: const EdgeInsets.only(bottom: 28.0),
                    //     child: Center(
                    //       child: ClipRRect(
                    //         borderRadius: BorderRadius.all(Radius.circular(24)),
                    //         child: new BackdropFilter(
                    //           filter: new ImageFilter.blur(
                    //               sigmaX: 10.0, sigmaY: 10.0),
                    //           child: Container(
                    //             color: HexColor("#0f346c"),
                    //             child: Material(
                    //               color: Colors.transparent,
                    //               child: InkWell(
                    //                 highlightColor: Colors.transparent,
                    //                 splashColor: AppTheme.getTheme()
                    //                     .primaryColor
                    //                     .withOpacity(0.2),
                    //                 borderRadius:
                    //                     BorderRadius.all(Radius.circular(38)),
                    //                 onTap: () {
                    //                   print("Hello Motin");
                    //
                    //                   try {
                    //                     scrollController.animateTo(
                    //                         MediaQuery.of(context).size.height -
                    //                             MediaQuery.of(context)
                    //                                     .size
                    //                                     .height /
                    //                                 5,
                    //                         duration:
                    //                             Duration(milliseconds: 500),
                    //                         curve: Curves.fastOutSlowIn);
                    //                   } catch (e) {}
                    //                 },
                    //                 child: Padding(
                    //                   padding: const EdgeInsets.only(
                    //                       left: 16,
                    //                       right: 16,
                    //                       top: 4,
                    //                       bottom: 4),
                    //                   child: Row(
                    //                     mainAxisSize: MainAxisSize.min,
                    //                     mainAxisAlignment:
                    //                         MainAxisAlignment.center,
                    //                     crossAxisAlignment:
                    //                         CrossAxisAlignment.center,
                    //                     children: <Widget>[
                    //                       Padding(
                    //                         padding: const EdgeInsets.all(8.0),
                    //                         child: Text(
                    //                           'More Info',
                    //                           style: TextStyle(
                    //                             color: Colors.white,
                    //                             fontWeight: FontWeight.w600,
                    //                           ),
                    //                         ),
                    //                       ),
                    //                       Padding(
                    //                         padding:
                    //                             const EdgeInsets.only(top: 2),
                    //                         child: Icon(
                    //                           Icons.keyboard_arrow_down,
                    //                           color: Colors.white,
                    //                           size: 24,
                    //                         ),
                    //                       )
                    //                     ],
                    //                   ),
                    //                 ),
                    //               ),
                    //             ),
                    //           ),
                    //         ),
                    //       ),
                    //     ),
                    //   ),
                    // ),
                  ],
                ),

                // Modifi Here 16/02/2021
                Padding(
                  padding: const EdgeInsets.only(
                      left: 12, right: 12, bottom: 16, top: 16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      // Row ONe
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Expanded(
                            child: Text(
                              widget.roomData.title,
                              maxLines: 2,
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width / 2.8,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    SELECT_ROOM,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                    textAlign: TextAlign.right,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),

                      SizedBox(
                        height: 7,
                      ),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top: 18.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 0.0,
                                      top: 0.0,
                                      right: 4.0,
                                      bottom: 0.0),
                                  child: Text(
                                    "${widget.roomData.currCode} ${int.parse(widget.roomData.price.replaceAll(",", "")) * widget.day}",
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 22,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: MediaQuery.of(context).size.width / 3.0,
                            height: 55,
                            child: DropdownButtonFormField(
                              isDense: true,
                              itemHeight: 55,
                              decoration: InputDecoration(
                                  border: OutlineInputBorder(
                                    borderRadius: const BorderRadius.all(
                                      const Radius.circular(5.0),
                                    ),
                                  ),
                                  filled: true,
                                  hintStyle: TextStyle(
                                      fontSize: 15, color: Colors.black),
                                  hintText: maxAvailablity[0],
                                  fillColor: Colors.white),
                              value: facilities,
                              onChanged: (String value) {
                                setState(() {
                                  facilities = value;
                                  widget.roomCountCallback(
                                      widget.roomData.id,
                                      widget.roomData.title,
                                      widget.roomData.maxAdults,
                                      widget.roomData.price,
                                      int.parse(facilities),
                                      widget.day);
                                  // _storeLoggedInStatus(widget.roomData.id);
                                  // _storeData(facilities);
                                  // getFunction(widget.roomData.id, facilities);
                                  //    firstFunction(int.parse(facilities), widget.roomData.price);
                                });

                                // print(
                                //     "RommTitle....>>>${widget.roomData.title}");
                                //
                                // print(
                                //     "Room Price.....>${widget.roomData.price}");
                                //
                                // print("Room Count .....$facilities");

                                //     setState(() {
                                //String room_id= await _getLoggedInStatus();
                                //   var value1 = int.parse(facilities);
                                //   var str = widget.roomData.price;
                                //
                                //
                                //    int price = int.parse(c);
                                //   var total_price = value1 * price;
                                //
                                //   if (total_price != null)
                                //     price1 += total_price;
                                //   else
                                //     price1 -= total_price;
                                //   print(
                                //       " value change ${total_price.toString()}");
                                // });
                                //
                                // print("room ${price1}");
                                //
                                // widget.callBack(price1);
                              },
                              items: maxAvailablity
                                  .map((cityTitle) => DropdownMenuItem(
                                      onTap: () {},
                                      value: cityTitle,
                                      child: Text("$cityTitle")))
                                  .toList(),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                Divider(
                  height: 1,
                )
              ],
            ),
          ),
        );
      },
    );
  }

  void getFunction(String roomId, String facilities) async {
    var total = 0;
    //

    String room_id = await _getLoggedInStatus();

    if (room_id != roomId) {
      total += int.parse(facilities);
      print("hotel====> $total");
    } else {
      print("hotel====> $total");
    }

    // for(int i=0; i<widget.roomlist.length;i++){
    //   if(hotel_name!=widget.roomlist[i].id){
    //     total+=int.parse(facilities);
    //     print("room Number1111==>$total $hotel_name $price" );
    //   }else{
    //     print("room Number==>$total $hotel_name $price" );
    //
    //   }
    // }

    // setState(() {
    //   if(hotel_name!=widget.roomData.title){
    //
    //   }else{
    //     //total=int.parse(facilities);
    //
    //   }
    // });

    // print("${rooms.id} ${facilities}");
    setState(() {});
  }

  void _storeLoggedInStatus(String isLoggedIn) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    pref.setString('dropDownValue', isLoggedIn);
  }

  // Gets the logged in status
  Future<String> _getLoggedInStatus() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    return pref.getString('dropDownValue') ?? "";
  }

  void _storeData(String isLoggedIn) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    pref.setString('dropDown', isLoggedIn);
  }

  // Gets the logged in status
  Future<String> _getData() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    return pref.getString('dropDown') ?? "";
  }
}

//
