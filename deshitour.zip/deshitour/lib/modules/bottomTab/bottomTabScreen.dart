import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:connectivity/connectivity.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:new_motel/authenticating/login.dart';
import 'package:new_motel/models/home/home.dart';
import 'package:new_motel/modules/explore/deshitour_prferences.dart';
import 'package:new_motel/modules/hotelBooking/hotelListHomeScreen.dart';
import 'package:new_motel/modules/profile/profile_page.dart';
import 'package:new_motel/screens/bus_screen.dart';
import 'package:new_motel/screens/flight.dart';
import 'package:new_motel/service/apiService.dart';
import 'package:new_motel/tourBooking/tourListScreen.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../appTheme.dart';
import '../../loaderPage.dart';
import '../explore/homeExplore.dart';

class BottomTabScreen extends StatefulWidget {
  const BottomTabScreen({Key key}) : super(key: key);

  @override
  _BottomTabScreenState createState() => _BottomTabScreenState();
}

class _BottomTabScreenState extends State<BottomTabScreen>
    with TickerProviderStateMixin {
  AnimationController animationController;
  bool isFirstTime = true;
  Widget indexView = Container();

  BottomBarType bottomBarType = BottomBarType.Explore;
  HomeData homeData;

  // Future<HomeData> getJSONData() async {
  //
  //
  // }

  StreamSubscription connectivitySubscription;

  ConnectivityResult _previousResult;

  bool dialogshown = false;
  Future<bool> checkinternet() async {
    try {
      final result = await InternetAddress.lookup('google.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        return Future.value(true);
      }
    } on SocketException catch (_) {
      return Future.value(false);
    }
  }

  @override
  void initState() {
    super.initState();
    checkinternet();
    animationController =
        AnimationController(duration: Duration(milliseconds: 0), vsync: this);
    indexView = Container();
    WidgetsBinding.instance.addPostFrameCallback((_) => _startLoadScreen());
  }

  Future _startLoadScreen() async {
    var response = await http.get(ApiService.home_all_data);
    setState(() {
      isFirstTime = false;

      if (response.statusCode == 200) {
        homeData = HomeData.fromJson(json.decode(response.body)[0]);
        print("fornt Location faf:${homeData.frontLocation.length}");
        print("all Location faa:${homeData.allLocation.length}");
        print("front hotel affa:${homeData.frontHotel.length}");
        print("front tour affa :${homeData.frontTour.length}");
        indexView = HomeExploreScreen(
            animationController: animationController, homeData: homeData);
      } else {
        print("failed");
      }
    });
    animationController..forward();

    connectivitySubscription = Connectivity()
        .onConnectivityChanged
        .listen((ConnectivityResult connresult) {
      if (connresult == ConnectivityResult.none) {
        dialogshown = true;
        showDialog(
          context: context,
          barrierDismissible: false, builder: (BuildContext context) {},
          // child: AlertDialog(
          //   title: Text(
          //     "Error",
          //   ),
          //   content: Text(
          //     "No Data Connection Available.",
          //   ),
          //   actions: <Widget>[
          //     FlatButton(
          //       onPressed: () => {
          //         Navigator.pop(context),
          //       },
          //       child: Text("Exit."),
          //     ),
          //   ],
          // ),
        );
      } else if (_previousResult == ConnectivityResult.none) {
        checkinternet().then((result) {
          if (result == true) {
            if (dialogshown == true) {
              dialogshown = false;
              Navigator.pop(context);
            }
          }
        });
      }

      _previousResult = connresult;
    });
  }

  @override
  void dispose() {
    super.dispose();

    connectivitySubscription.cancel();
  }

  Widget cards(String src) {
    return Card(
      elevation: 5.0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
      clipBehavior: Clip.antiAlias,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Image.network(src),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // bottomBarType=widget.tab_name;
    return Container(
      child: Scaffold(
        backgroundColor: AppTheme.getTheme().backgroundColor,
        bottomNavigationBar: Container(
            height: 58 + MediaQuery.of(context).padding.bottom,
            child: getBottomBarUI(bottomBarType)),
        body: isFirstTime
            ? Center(
                child: LoaderPage(),
              )
            : indexView,
      ),
    );
  }

  void tabClick(BottomBarType tabType, String id, String lName, String chIn,
      String chOut) {
    if (tabType != bottomBarType) {
      bottomBarType = tabType;
      animationController.reverse().then((f) {
        if (tabType == BottomBarType.Explore) {
          //  MaterialPageRoute(builder: (context) => BottomTabScreen());
          setState(() {
            _startLoadScreen();
            indexView = HomeExploreScreen(
              animationController: animationController,
              homeData: homeData,
            );
          });
        } else if (tabType == BottomBarType.Hotels) {
          setState(() {
            //  hideSendingProgressBar();
            indexView = HotelListHomeScreen(
              isSearch: HOME_SEARCH,
              allLocation: homeData.allLocation,
              adults: 1,
              locaton_name: lName,
            );
          });
        } else if (tabType == BottomBarType.Trips) {
          setState(() {
            indexView = TourListScreen(
              allLocation: homeData.allLocation,
              // animationController: animationController,
            );
          });
        } else if (tabType == BottomBarType.Flights) {
          setState(() {
            indexView = FlightScreen();
            // indexView = MyTripsScreen(
            //   animationController: animationController,
            // );
          });
        } else if (tabType == BottomBarType.bus) {
          setState(() {
            indexView = BusScreen();
          });
        }
      });
    }
  }

  Widget getBottomBarUI(BottomBarType tabType) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.getTheme().backgroundColor,
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: AppTheme.getTheme().dividerColor,
            blurRadius: 4,
            offset: Offset(0, -2),
          ),
        ],
      ),
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              // Visibility(
              //     visible: Provider.of<DataConnectionStatus>(context) ==
              //         DataConnectionStatus.disconnected,
              //     child: InternetNotAvailable()),
              Expanded(
                child: Material(
                  child: InkWell(
                    highlightColor: Colors.transparent,
                    splashColor:
                        AppTheme.getTheme().primaryColor.withOpacity(0.2),
                    onTap: () {
                      //  Navigator.pop(context);
                      _startLoadScreen();
                      tabClick(BottomBarType.Explore, "", "", "", "");
                    },
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          height: 4,
                        ),
                        Container(
                          width: 40,
                          height: 32,
                          child: Icon(
                            Icons.home,
                            size: 26,
                            color: tabType == BottomBarType.Explore
                                ? AppTheme.getTheme().primaryColor
                                : AppTheme.getTheme().disabledColor,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Text(
                            HOME ?? "",
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: tabType == BottomBarType.Explore
                                    ? AppTheme.getTheme().primaryColor
                                    : AppTheme.getTheme().disabledColor),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
              // Expanded(
              //   child: Material(
              //     color: Colors.transparent,
              //     child: InkWell(
              //       highlightColor: Colors.transparent,
              //       splashColor:
              //           AppTheme.getTheme().primaryColor.withOpacity(0.2),
              //       onTap: () {
              //         tabClick(BottomBarType.Hotels);
              //       },
              //       child: Column(
              //         children: <Widget>[
              //           SizedBox(
              //             height: 4,
              //           ),
              //           Container(
              //             width: 40,
              //             height: 32,
              //             child: Icon(
              //               Icons.hotel,
              //               size: 26,
              //               color: tabType == BottomBarType.Hotels
              //                   ? AppTheme.getTheme().primaryColor
              //                   : AppTheme.getTheme().disabledColor,
              //             ),
              //           ),
              //           Padding(
              //             padding: const EdgeInsets.only(bottom: 6),
              //             child: Text(
              //               HOTEL ?? " ",
              //               style: TextStyle(
              //                   fontWeight: FontWeight.w500,
              //                   color: tabType == BottomBarType.Hotels
              //                       ? AppTheme.getTheme().primaryColor
              //                       : AppTheme.getTheme().disabledColor),
              //             ),
              //           )
              //         ],
              //       ),
              //     ),
              //   ),
              // ),
              Expanded(
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    highlightColor: Colors.transparent,
                    splashColor:
                        AppTheme.getTheme().primaryColor.withOpacity(0.2),
                    onTap: () async {
                      SharedPreferences sharedPreferences =
                          await SharedPreferences.getInstance();
                      String locationId = sharedPreferences
                          .getString(DeshiTourPreference.LOCATION_ID);
                      String locationName = sharedPreferences
                          .getString(DeshiTourPreference.LOCATION_NAME);
                      String checkIn = sharedPreferences
                          .getString(DeshiTourPreference.CHECKIN);
                      String checkOut = sharedPreferences
                          .getString(DeshiTourPreference.CHECKOUT);

                      if (locationId == null) {
                        final snackBar = SnackBar(
                            content: Text("Please select a location "));
                        ScaffoldMessenger.of(context).showSnackBar(snackBar);
                      } else {
                        tabClick(BottomBarType.Hotels, locationId, locationName,
                            checkIn, checkOut);
                      }
                    },
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          height: 4,
                        ),
                        Container(
                          width: 40,
                          height: 32,
                          child: Icon(
                            Icons.hotel,
                            size: 26,
                            color: tabType == BottomBarType.Hotels
                                ? AppTheme.getTheme().primaryColor
                                : AppTheme.getTheme().disabledColor,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Text(
                            HOTEL ?? " ",
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: tabType == BottomBarType.Hotels
                                    ? AppTheme.getTheme().primaryColor
                                    : AppTheme.getTheme().disabledColor),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),

              Expanded(
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    highlightColor: Colors.transparent,
                    splashColor:
                        AppTheme.getTheme().primaryColor.withOpacity(0.2),
                    onTap: () {
                      tabClick(BottomBarType.Flights, "", "", "", "");
                    },
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          height: 4,
                        ),
                        Container(
                          width: 40,
                          height: 32,
                          child: Icon(
                            Icons.airplanemode_active,
                            color: tabType == BottomBarType.Flights
                                ? AppTheme.getTheme().primaryColor
                                : AppTheme.getTheme().disabledColor,
                            size: 20,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Text(
                            FLIGHT ?? " ",
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: tabType == BottomBarType.Flights
                                    ? AppTheme.getTheme().primaryColor
                                    : AppTheme.getTheme().disabledColor),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    highlightColor: Colors.transparent,
                    splashColor:
                        AppTheme.getTheme().primaryColor.withOpacity(0.2),
                    onTap: () {
                      tabClick(BottomBarType.bus, "", "", "", "");
                    },
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          height: 4,
                        ),
                        Container(
                          width: 40,
                          height: 32,
                          child: Icon(
                            Icons.directions_bus_outlined,
                            color: tabType == BottomBarType.bus
                                ? AppTheme.getTheme().primaryColor
                                : AppTheme.getTheme().disabledColor,
                            size: 20,
                          ),

                          // ImageIcon(
                          //   AssetImage("assets/icons/bus.png"),
                          //   color: tabType == BottomBarType.bus
                          //       ? AppTheme.getTheme().primaryColor
                          //       : AppTheme.getTheme().disabledColor,
                          //   size: 20,
                          // ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Text(
                            "Bus",
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: tabType == BottomBarType.bus
                                    ? AppTheme.getTheme().primaryColor
                                    : AppTheme.getTheme().disabledColor),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    highlightColor: Colors.transparent,
                    splashColor:
                        AppTheme.getTheme().primaryColor.withOpacity(0.2),
                    onTap: () {
                      tabClick(BottomBarType.Trips, "", "", "", "");
                    },
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          height: 4,
                        ),
                        Container(
                          width: 40,
                          height: 32,
                          child: ImageIcon(
                            AssetImage("assets/icons/tour.png"),
                            color: tabType == BottomBarType.Trips
                                ? AppTheme.getTheme().primaryColor
                                : AppTheme.getTheme().disabledColor,
                            size: 20,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Text(
                            TOURS ?? " ",
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: tabType == BottomBarType.Trips
                                    ? AppTheme.getTheme().primaryColor
                                    : AppTheme.getTheme().disabledColor),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
              // Expanded(
              //   child: Material(
              //     color: Colors.transparent,
              //     child: InkWell(
              //       highlightColor: Colors.transparent,
              //       splashColor:
              //           AppTheme.getTheme().primaryColor.withOpacity(0.2),
              //       onTap: () async {
              //         tabClick(BottomBarType.Profile);
              //         // setState(() async {
              //         //   SharedPreferences sharedPreferences =
              //         //       await SharedPreferences.getInstance();
              //         //   String token = sharedPreferences.getString("token");
              //         //   if (token == null) {
              //         //     _navigateAndDisplaySelection(context);
              //         //     // Navigator.push(
              //         //     //   context,
              //         //     //   MaterialPageRoute(
              //         //     //     builder: (context) =>
              //         //     //         LoginWidget(type: "profile"),
              //         //     //     fullscreenDialog: true,
              //         //     //   ),
              //         //     // );
              //         //   } else {
              //         //     setState(() {
              //         //       Navigator.push(
              //         //           context,
              //         //           MaterialPageRoute(
              //         //               builder: (context) => ProfileScreen()));
              //         //     });
              //         //
              //         //     // Navigator.pop(context);
              //         //   }
              //         // });
              //       },
              //       child: Column(
              //         children: <Widget>[
              //           SizedBox(
              //             height: 4,
              //           ),
              //           Container(
              //             width: 40,
              //             height: 32,
              //             child: Icon(
              //               FontAwesomeIcons.user,
              //               color: tabType == BottomBarType.Profile
              //                   ? AppTheme.getTheme().primaryColor
              //                   : AppTheme.getTheme().disabledColor,
              //               size: 22,
              //             ),
              //           ),
              //           Padding(
              //             padding: const EdgeInsets.only(bottom: 6),
              //             child: Text(
              //               PROFILE ?? " ",
              //               style: TextStyle(
              //                   fontWeight: FontWeight.w500,
              //                   color: tabType == BottomBarType.Profile
              //                       ? AppTheme.getTheme().primaryColor
              //                       : AppTheme.getTheme().disabledColor),
              //             ),
              //           )
              //         ],
              //       ),
              //     ),
              //   ),
              // )
            ],
          ),
          SizedBox(
            height: MediaQuery.of(context).padding.bottom,
          )
        ],
      ),
    );
  }

  _navigateAndDisplaySelection(BuildContext context) async {
    // Navigator.push returns a Future that completes after calling
    // Navigator.pop on the Selection Screen.
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => LoginWidget(type: "bottom")),
    );

    print(Text("$result"));
    // ignore: unrelated_type_equality_checks
    if ("$result" == "1") {
      setState(() {
        indexView = ProfilePage();
      });
    }

    // // After the Selection Screen returns a result, hide any previous snackbars
    // // and show the new result.
    // Scaffold.of(context)
    //   ..removeCurrentSnackBar()
    //   ..showSnackBar(SnackBar(content: Text("$result")));
  }
}

enum BottomBarType { Explore, Hotels, Trips, Flights, bus }
