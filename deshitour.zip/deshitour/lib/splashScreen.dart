import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:connectivity/connectivity.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:new_motel/service/apiService.dart';

import 'appTheme.dart';
import 'main.dart';
import 'models/home/home.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  HomeData homeData;

  // handle internet Check....

  ConnectivityResult previous;
  @override
  void initState() {
    super.initState();
    // put();
    try {
      InternetAddress.lookup('google.com').then((result) {
        if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
          setState(() {
            startTimer();
            route;
          });
          // internet conn available

        } else {
          // no conn
          _showdialog();
        }
      }).catchError((error) {
        // no conn
        _showdialog();
      });
    } on SocketException catch (_) {
      // no internet
      _showdialog();
    }

    Connectivity()
        .onConnectivityChanged
        .listen((ConnectivityResult connresult) {
      if (connresult == ConnectivityResult.none) {
      } else if (previous == ConnectivityResult.none) {
        // internet conn
        Navigator.pushNamedAndRemoveUntil(
            context, Routes.TabScreen, (Route<dynamic> route) => false);
      }

      previous = connresult;
    });
  }

  void _showdialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('ERROR'),
        content: Text("No Internet Connection."),
        actions: <Widget>[
          FlatButton(
            // method to exit application programitacally
            onPressed: () =>
                SystemChannels.platform.invokeMethod('Systemnavigator.pop'),
            child: Text("Exit"),
          ),
        ],
      ),
    );
  }

  Future<String> getJSONData() async {
    var response = await http.get(ApiService.home_all_data);
    if (response.statusCode == 200) {
      homeData = HomeData.fromJson(json.decode(response.body)[0]);
      print("fornt Location faf:${homeData.frontLocation.length}");
      print("all Location faa:${homeData.allLocation.length}");
      print("front hotel affa:${homeData.frontHotel.length}");
      print("front tour affa :${homeData.frontTour.length}");
      return "200";
    } else {
      print("failed");
    }
  }

  // @override
  // void initState() {
  //   super.initState();
  //   put();
  //   getConnect();
  // }

  startTimer() async {
    var duration = Duration(seconds: 2);
    return new Timer(duration, route);
  }

  // bool put() {
  //   InternetConnection().check().then((internet) {
  //     if (internet != null && internet) {
  //       intrnet = internet;
  //       startTimer();
  //     } else {
  //       //InternetNotAvailable();
  //     }
  //   });
  //   return true;
  // }

  route() {
    Navigator.pushNamedAndRemoveUntil(
        context, Routes.TabScreen, (Route<dynamic> route) => false);
    // Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) =>
    //     BottomTabScreen(homeData: homeData)), (Route<dynamic> route) => false);
  }

  @override
  Widget build(BuildContext context) {
    return initScreen(context);
  }

  initScreen(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.white,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Center(
              child: RichText(
                text: TextSpan(
                    text: "Deshi",
                    style: TextStyle(
                      fontSize: 40,
                      fontFamily: 'Impact',
                      color: HexColor("#26408A"),
                    ),
                    children: <TextSpan>[
                      TextSpan(
                          text: "Tour",
                          style: TextStyle(
                            fontSize: 40,
                            fontFamily: 'Impact',
                            color: HexColor("#118ACB"),
                          )),
                    ]),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: CircularProgressIndicator(
                backgroundColor: Colors.white,
                strokeWidth: 5,
              ),
            )
          ],
        ),
      ),
    );
  }

  // void getConnect() async {
  //   var connectivityResult = await (Connectivity().checkConnectivity());
  //   if (connectivityResult == ConnectivityResult.none) {
  //     setState(() {
  //       isInternetOn = false;
  //     });
  //   } else if (connectivityResult == ConnectivityResult.mobile) {
  //     iswificonnected = false;
  //   } else if (connectivityResult == ConnectivityResult.wifi) {
  //     iswificonnected = true;
  //     setState(() async {
  //       startTimer();
  //     });
  //   }
  // }

  // Center ShowWifi(BuildContext context) {
  //   return Center(
  //     child: Column(
  //       mainAxisAlignment: MainAxisAlignment.center,
  //       children: <Widget>[
  //         Text('Check your Internet Connection',
  //             style: TextStyle(
  //                 color: Colors.blueAccent,
  //                 fontSize: 18,
  //                 fontWeight: FontWeight.bold)),
  //         RaisedButton(
  //           shape: RoundedRectangleBorder(
  //               borderRadius: BorderRadius.circular(18.0),
  //               side: BorderSide(color: Colors.red)),
  //           onPressed: () {
  //             startTimer();
  //           },
  //           color: Colors.red,
  //           textColor: Colors.white,
  //           child: Text("Retry".toUpperCase(), style: TextStyle(fontSize: 14)),
  //         ),
  //       ],
  //     ),
  //   );
  // }
}
// Container(
// child: Scaffold(
// body: Stack(
// children: <Widget>[
// Container(
// foregroundDecoration: !AppTheme.isLightTheme
// ? BoxDecoration(
// color:
// AppTheme.getTheme().backgroundColor.withOpacity(0.4))
// : null,
// width: MediaQuery.of(context).size.width,
// height: MediaQuery.of(context).size.height,
// child: Image.asset('assets/images/introduction.jpg',
// fit: BoxFit.cover),
// ),
// Column(
// children: <Widget>[
// Expanded(
// flex: 1,
// child: SizedBox(),
// ),
// // Center(
// //   child: Container(
// //     width: 60,
// //     height: 60,
// //     decoration: BoxDecoration(
// //       borderRadius: BorderRadius.all(
// //         Radius.circular(8.0),
// //       ),
// //       boxShadow: <BoxShadow>[
// //         BoxShadow(
// //             color: AppTheme.getTheme().dividerColor,
// //             offset: Offset(1.1, 1.1),
// //             blurRadius: 10.0),
// //       ],
// //     ),
// //     // child: ClipRRect(
// //     //   borderRadius: BorderRadius.all(
// //     //     Radius.circular(8.0),
// //     //   ),
// //     // //  child: Image.asset('assets/images/appIcon.png'),
// //     // ),
// //   ),
// // ),
// SizedBox(
// height: 16,
// ),
// Image.asset('assets/images/deshiTour.png'),
// SizedBox(
// height: 16,
// ),
// // Text(
// //   "Deshi Tour ",
// //   textAlign: TextAlign.left,
// //   style: TextStyle(
// //     fontWeight: FontWeight.w600,
// //     fontSize: 24,
// //   ),
// // ),
// // SizedBox(
// //   height: 8,
// // ),
// // Text(
// //   "Best hotel deals for your holiday",
// //   textAlign: TextAlign.left,
// //   style: TextStyle(
// //     fontSize: 14,
// //   ),
// // ),
// Expanded(
// flex: 4,
// child: SizedBox(),
// ),
// Padding(
// padding: EdgeInsets.only(
// left: 20,
// right: 20,
// bottom: 24.0 + MediaQuery.of(context).padding.bottom,
// top: 30),
// // padding: const EdgeInsets.only(
// //     left: 48, right: 48, bottom: 8, top: 8),
// child: Container(
// height: 48,
// decoration: BoxDecoration(
// color: AppTheme.getTheme().primaryColor,
// borderRadius: BorderRadius.all(Radius.circular(24.0)),
// boxShadow: <BoxShadow>[
// BoxShadow(
// color: AppTheme.getTheme().dividerColor,
// blurRadius: 8,
// offset: Offset(4, 4),
// ),
// ],
// ),
// child: Material(
// color: Colors.transparent,
// child: InkWell(
// borderRadius: BorderRadius.all(Radius.circular(24.0)),
// highlightColor: Colors.transparent,
// onTap: () {
// Navigator.pushNamedAndRemoveUntil(
// context,
// Routes.TabScreen,
// (Route<dynamic> route) => false);
// // Navigator.push(
// //   context,
// //   MaterialPageRoute(
// //       builder: (context) => HomeExploreScreen()),
// // );
// },
// child: Center(
// child: Text(
// "Get started",
// style: TextStyle(
// fontWeight: FontWeight.w500,
// fontSize: 16,
// color: Colors.white),
// ),
// ),
// ),
// ),
// ),
// ),
// // Padding(
// //     padding: EdgeInsets.only(
// //         bottom: 24.0 + MediaQuery.of(context).padding.bottom,
// //         top: 16),
// //     child: Material(
// //       color: Colors.transparent,
// //       child: InkWell(
// //         borderRadius: BorderRadius.all(Radius.circular(24.0)),
// //         highlightColor: Colors.transparent,
// //         onTap: () {
// //           Navigator.push(
// //             context,
// //             MaterialPageRoute(
// //                 builder: (context) => LoginScreen()),
// //           );
// //         },
// //         child: Center(
// //           child: Text(
// //             "Already have account? Log in",
// //             textAlign: TextAlign.left,
// //             style: TextStyle(
// //                 fontSize: 14,
// //                 color: Colors.white,
// //                 fontWeight: FontWeight.bold),
// //           ),
// //         ),
// //       ),
// //     )),
// ],
// ),
// ],
// ),
// ),
// );

/*
Center(child: Container(
alignment: Alignment.center,
color: Colors.grey,
padding: EdgeInsets.all(16.0),
child: Column(
mainAxisAlignment: MainAxisAlignment.center,
children: [
Text('Check your Internet Connection', style: TextStyle(color: Colors.white, fontSize: 18,
fontWeight: FontWeight.bold)),
RaisedButton(
shape: RoundedRectangleBorder(
borderRadius: BorderRadius.circular(18.0),
side: BorderSide(color: Colors.red)),
onPressed: () {
setState(() {

});
},
color: Colors.red,
textColor: Colors.white,
child: Text("Retry".toUpperCase(),
style: TextStyle(fontSize: 14)),
),
],
),
),)*/
