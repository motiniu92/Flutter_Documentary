import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:new_motel/models/hotelList/hotelList.dart';
import 'package:new_motel/service/apiService.dart';

class Services {
  // Future<String> getJSONData() async {
  //  loading = true;
  //  var response = await http.get(ApiService.home_all_data);
  //  setState(() {
  //   loading = false;
  //   HomeData homeData = HomeData.fromJson(json.decode(response.body)[0]);
  //   fron_location = homeData.frontLocation;
  //   all_location=homeData.allLocation;
  //   front_hotel=homeData.frontHotel;
  //   front_tour=homeData.frontTour;
  //   // Get the JSON data
  //
  //  });
  //  //print(data);
  //  return "data";
  // }
  Future<HotelList> getJSONData(
      String checkIn, String checkout, int locaton_id) async {
    var response = await http.get(ApiService.hotelSearch +
        "&checkin=$checkIn&checkout=$checkout&searching=$locaton_id");
    if (response.statusCode == 200) {
      HotelList homeData = HotelList.fromJson(json.decode(response.body));
      return homeData;
    } else {
      print("failed");
    }
  }
}
