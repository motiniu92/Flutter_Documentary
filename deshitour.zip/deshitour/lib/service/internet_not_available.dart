import 'package:flutter/material.dart';
import 'package:new_motel/utils/constants.dart';

class InternetNotAvailable extends StatelessWidget {
  const InternetNotAvailable({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      color: Colors.grey,
      
      padding: EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
              INTERNET,
              style: TextStyle(color: Colors.white, fontSize: 18,
              fontWeight: FontWeight.bold)),
          RaisedButton(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18.0),
                side: BorderSide(color: Colors.red)),
            onPressed: () {
            },
            color: Colors.red,
            textColor: Colors.white,
            child: Text("Retry".toUpperCase(),
                style: TextStyle(fontSize: 14)),
          ),
        ],
      ),
    );
  }
}
