// import 'package:dio/dio.dart';
// import 'package:new_motel/model/profile_model.dart';
//
// class ProfileServices {
//   Future<List<ProfileModel>> getProducts() async {
//     final _dio = Dio();
//     try {
//       final Response response = await _dio
//           .get("https://deshitour.com/api/login/profile?appKey=DeshiTour");
//       print(response.data);
//
//       return (response.data['response'] as List)
//           .map((e) => ProfileModel.fromJson(e))
//           .toList();
//     } on DioError catch (dioError) {
//       print(dioError);
//     }
//   }
// }
