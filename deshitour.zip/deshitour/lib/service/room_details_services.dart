import 'package:dio/dio.dart';
import 'package:new_motel/models/hotelList/hotelDetails.dart';

class RoomDetailsServices {
  Future<List<Rooms>> getProductList() async {
    final _dio = Dio();

    try {
      final response = await _dio.get(
        "https://deshitour.com/api/hotels/hoteldetails?appKey=DeshiTour",
      );
      print(response.data);

      return (response.data['response']['hotel'] as List)
          .map((e) => Rooms.fromJson(e))
          .toList();
    } on DioError catch (dioError) {
      print(dioError);
    }
  }
}
