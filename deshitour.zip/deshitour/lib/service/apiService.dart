class ApiService {
  static final String _baseUrl = "https://deshitour.com/api";
  static final String _appKey = "DeshiTour";

  // ignore: non_constant_identifier_names
  static var home_all_data = "$_baseUrl/home/alldata?appKey=$_appKey";
  static var tour = "$_baseUrl/tours/list?appKey=$_appKey";
  static var location = "$_baseUrl/locations/front?appKey=$_appKey";
  static var hotelList = "$_baseUrl/hotels/list?appKey=$_appKey";
  static var hotelDetails = "$_baseUrl/hotels/hoteldetails?appKey=$_appKey";
  static var hotelAmenities = "$_baseUrl/hotels/amenities?appKey=$_appKey";
  static var hotelProperty = "$_baseUrl/hotels/property?appKey=$_appKey";
  static var hotelFun = "$_baseUrl/hotels/funs?appKey=$_appKey";
  static var hotelSearch = "$_baseUrl/hotels/search?appKey=$_appKey";

  //===
  static var tourDetails = "$_baseUrl/tours/details?appKey=$_appKey";
  static var hotelsFilter = "$_baseUrl/hotels/filter?appKey=$_appKey";
  static var homeLocation = "$_baseUrl/hotels/searchByLoc?appKey=$_appKey";
  static var login = "$_baseUrl/login/check?=$_appKey";
  static var register = "$_baseUrl/login/signup?appKey=$_appKey";
  static var profile = "$_baseUrl/login/profile=$_appKey";
  static var mybooking = "$_baseUrl/login/mybookings?appKey=$_appKey";
  static var cancelbooking = "$_baseUrl/login/cancelbooking?appKey=$_appKey";
  static var changeBookingDate = "$_baseUrl/login/changeDate?appKey=$_appKey";
}
