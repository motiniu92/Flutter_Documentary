
class SplashScreenInterface{
  void setBoolean(bool internet){}
}