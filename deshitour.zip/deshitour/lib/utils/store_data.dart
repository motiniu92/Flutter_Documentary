import 'package:shared_preferences/shared_preferences.dart';

class DataStore {
  final _sharedPreferences = SharedPreferences.getInstance();
  static String TOKEN = 'token';
  static String USERID = 'userId';
  static String EMAIL = 'email';
  static String FIRSTNAME = 'firstName';
  static String LASTNAME = 'lastname';
}
