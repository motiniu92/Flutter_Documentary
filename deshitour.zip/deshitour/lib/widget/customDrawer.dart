import 'package:flutter/material.dart';
import 'package:new_motel/widget/privacyPolicyWebView.dart';
import 'package:new_motel/widget/termsConditionWebView.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../splashScreen.dart';
import 'aboutUsWebView.dart';
import 'contactUsScreen.dart';
import 'custom_drawer2.dart';

class CustomDrawer extends StatefulWidget {
  final String title;

  const CustomDrawer({Key key, this.title}) : super(key: key);

  @override
  _CustomDrawerState createState() => _CustomDrawerState();
}

class _CustomDrawerState extends State<CustomDrawer> {
  String name;
  String lastName;
  String email;
  String profileImage;

  Future loadToken() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    name = prefs.getString("firstName");
    lastName = prefs.getString("lastName");
    email = prefs.getString("email");
    profileImage = prefs.getString("photo");

    setState(() {});
  }

  String token = "token";

  Future<SharedPreferences> getData() async {
    return await SharedPreferences.getInstance();
  }

  // ignore: missing_return
  Future<String> logOut() async {
    SharedPreferences sharedPreferces = await SharedPreferences.getInstance();
    String token = sharedPreferces.getString('token');
    if (token != null) {
      await sharedPreferces.clear();
      Navigator.of(context).popUntil((route) => route.isFirst);
      Navigator.pop(context);
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => SplashScreen()));
      setState(() {});
    } else {
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => SplashScreen()));
      return token;
    }
  }

  //   signOut(SharedPreferences sharedPreferences) async {
  //   String token = sharedPreferences.getString('token');
  //   debugPrint('token is: $token');
  //   final response = await http.get(BaseURL.LOGOUT).then((value) async {
  //     await sharedPreferences.clear();
  //     Navigator.of(context).popUntil((route) => route.isFirst);
  //     Navigator.pop(context);

  //     Navigator.push(context, MaterialPageRoute(builder: (context) => Login()));
  //   });
  //   return response;
  // }

  @override
  void initState() {
    super.initState();

    loadToken();
    //  logOut();

    //setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: FutureBuilder(
        future: getData(),
        builder: (BuildContext cobtxt, snapshot) {
          if (snapshot.hasData && snapshot.data.containsKey('token')) {
            return ListView(
              // Important: Remove any padding from the ListView.
              // padding: EdgeInsets.zero,

              children: <Widget>[
                UserAccountsDrawerHeader(
                  decoration: BoxDecoration(color: Colors.indigo[800]),
                  accountName: Text(
                    "$name $lastName",
                    style: TextStyle(fontSize: 17, color: Colors.white),
                  ),
                  accountEmail: Text(
                    "$email",
                    style: TextStyle(fontSize: 17, color: Colors.white),
                  ),
                  currentAccountPicture: CircleAvatar(
                    backgroundImage: profileImage == null
                        ? AssetImage("assets/images/person.png")
                        : NetworkImage("https://deshitour.com/" + profileImage),
                    backgroundColor: Colors.white,
                  ),
                ),

                ListTile(
                  leading: Icon(
                    Icons.attribution_rounded,
                    color: Colors.black,
                    size: 30,
                  ),
                  title: Text("About Us"),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AboutUsWebView(),
                      ),
                    );
                  },
                ),
                ListTile(
                  leading: Icon(
                    Icons.policy,
                    color: Colors.black,
                    size: 30,
                  ),
                  title: Text("Privacy Policy"),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PrivacyPolicyWebView(),
                      ),
                    );

                    // Navigator.push(
                    //     context,
                    //     MaterialPageRoute(
                    //         builder: (context) => PrivacyPolicyScreen()));
                  },
                ),
                ListTile(
                  leading: Icon(
                    Icons.security,
                    color: Colors.black,
                    size: 30,
                  ),
                  title: Text("Terms & Condition"),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => TermsAndConditionWebView(),
                      ),
                    );

                    // InAppWebViewController _webViewController;
                    // InAppWebView(
                    //     initialUrl: "https://deshitour.com/About-Us",
                    //     initialOptions: InAppWebViewGroupOptions(
                    //       crossPlatform: InAppWebViewOptions(
                    //         mediaPlaybackRequiresUserGesture: false,
                    //         debuggingEnabled: true,
                    //       ),
                    //     ),
                    //     onWebViewCreated: (InAppWebViewController controller) {
                    //       _webViewController = controller;
                    //     },
                    //     androidOnPermissionRequest: (InAppWebViewController controller, String origin, List<String> resources) async {
                    //       return PermissionRequestResponse(resources: resources, action: PermissionRequestResponseAction.GRANT);
                    //     }
                    // );
                    // Navigator.push(
                    //     context,
                    //     MaterialPageRoute(
                    //         builder: (context) => TermsConditionScreen()));
                  },
                ),

                ListTile(
                  leading: Icon(
                    Icons.phone,
                    color: Colors.black,
                    size: 30,
                  ),
                  title: Text(
                    "Contact Us",
                  ),
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ContactUsScreen()));
                  },
                ),
                ListTile(
                  leading: Icon(
                    Icons.person_outline,
                    color: Colors.black,
                  ),
                  title: Text("Logout"),
                  onTap: () {
                    _dialogLogOut();

                    // InAppWebViewController _webViewController;
                    // InAppWebView(
                    //     initialUrl: "https://deshitour.com/About-Us",
                    //     initialOptions: InAppWebViewGroupOptions(
                    //       crossPlatform: InAppWebViewOptions(
                    //         mediaPlaybackRequiresUserGesture: false,
                    //         debuggingEnabled: true,
                    //       ),
                    //     ),
                    //     onWebViewCreated: (InAppWebViewController controller) {
                    //       _webViewController = controller;
                    //     },
                    //     androidOnPermissionRequest: (InAppWebViewController controller, String origin, List<String> resources) async {
                    //       return PermissionRequestResponse(resources: resources, action: PermissionRequestResponseAction.GRANT);
                    //     }
                    // );
                    // Navigator.push(
                    //     context,
                    //     MaterialPageRoute(
                    //         builder: (context) => TermsConditionScreen()));
                  },
                ),

                // ListTile(
                //   leading: Icon(Icons.home),
                //   title: Text(
                //     HOME,
                //   ),
                //   onTap: () {
                //     Navigator.pop(context);
                //   },
                // ),
                // ListTile(
                //   leading: Icon(Icons.settings),
                //   title: Text("Settings"),
                //   onTap: () {
                //     Navigator.pop(context);
                //   },
                // ),
                // ListTile(
                //   leading: Icon(Icons.contacts),
                //   title: Text("Contact Us"),
                //   onTap: () {
                //     Navigator.pop(context);
                //   },
                // ),
                // ListTile(
                //   leading: Icon(Icons.credit_card),
                //   title: Text("Documtents"),
                //   onTap: () {
                //     Navigator.pop(context);
                //   },
                // ),
                // ListTile(
                //   leading: Icon(Icons.credit_card),
                //   title: Text("Confirmation Screen"),
                //   onTap: () {
                //     Navigator.push(
                //         context,
                //         MaterialPageRoute(
                //             builder: (context) => HotelConfirmationScreen()));
                //   },
                // ),
              ],
            );
          } else {
            return CustomDrawerTwo();
          }
        },
      ),
    );
  }

  _dialogLogOut() async {
    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(('Logout!')),
          content: Text(('Do you want to logout?')),
          actions: <Widget>[
            // ignore: deprecated_member_use
            FlatButton(
              child: Text(
                ('No'),
                style: TextStyle(color: Colors.red),
              ),
              onPressed: () {
                Navigator.of(context).pop(false); //Will not exit the App
              },
            ),
            // ignore: deprecated_member_use
            FlatButton(
              child: Text(
                ('Yes'),
                style: TextStyle(color: Colors.indigo[800]),
              ),
              onPressed: () {
                logOut();
              },
            )
          ],
        );
      },
    );
  }
}
