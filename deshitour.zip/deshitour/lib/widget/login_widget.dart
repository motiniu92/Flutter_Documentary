// // import 'package:flutter/material.dart';
// // import 'package:new_motel/authenticating/login.dart';
// // import 'package:new_motel/model/profile.dart';
// // import 'package:new_motel/models/hotelList/hotelDetails.dart';
// // import 'package:new_motel/modules/bottomTab/bottomTabScreen.dart';
// // import 'package:new_motel/modules/hotelDetailes/profile.dart';
// // import 'package:new_motel/modules/profile/profileScreen.dart';
// // import 'package:new_motel/provider/authenticate.dart';
// // import 'package:new_motel/screens/hotel_room_details_screen.dart';
// // import 'package:new_motel/screens/profile_page.dart';
// // import 'package:new_motel/splashScreen.dart';
// // import 'package:new_motel/widget/register_widget.dart';
// // import 'package:provider/provider.dart';
// //
// // class Login extends StatefulWidget {
// //   @override
// //   _LoginState createState() => _LoginState();
// // }
// //
// // class _LoginState extends State<Login> {
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       body: Consumer<Auth>(
// //         // ignore: missing_return
// //         builder: (context, auth, child) {
// //           switch (auth.status) {
// //             case AuthStatus.unauthenticated:
// //               return LoginWidget();
// //               break;
// //             case AuthStatus.authenticated:
// //               return ProfilePage();
// //               break;
// //           }
// //         },
// //         child: LoginWidget(),
// //       ),
// //     );
// //   }
// // }
// import 'package:flutter/material.dart';
// import 'package:new_motel/authenticating/login.dart';
// import 'package:new_motel/model/profile.dart';
// import 'package:new_motel/models/hotelList/hotelDetails.dart';
// import 'package:new_motel/modules/bottomTab/bottomTabScreen.dart';
// import 'package:new_motel/modules/hotelDetailes/profile.dart';
// import 'package:new_motel/modules/profile/profileScreen.dart';
// import 'package:new_motel/provider/authenticate.dart';
// import 'package:new_motel/screens/hotel_room_details_screen.dart';
// import 'package:new_motel/screens/profile_page.dart';
// import 'package:new_motel/splashScreen.dart';
// import 'package:provider/provider.dart';
//
// class Login extends StatefulWidget {
//   @override
//   _LoginState createState() => _LoginState();
// }
//
// class _LoginState extends State<Login> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Consumer<Auth>(
//         // ignore: missing_return
//         builder: (context, auth, child) {
//           switch (auth.status) {
//             case AuthStatus.unauthenticated:
//               return LoginWidget();
//
//             case AuthStatus.authenticated:
//               return ProfileScreenPage();
//               break;
//           }
//         },
//         child: LoginWidget(),
//       ),
//     );
//   }
// }
