import 'dart:async';
import 'package:flutter/material.dart';
import 'package:new_motel/modules/bottomTab/bottomTabScreen.dart';

import 'package:webview_flutter/webview_flutter.dart';

import '../appTheme.dart';


class PrivacyPolicyWebView extends StatefulWidget {

  @override
  _PrivacyPolicyWebViewState createState() => _PrivacyPolicyWebViewState();
}

class _PrivacyPolicyWebViewState extends State<PrivacyPolicyWebView> {


  final Completer<WebViewController> _controller =
  Completer<WebViewController>();

  num position = 1 ;

  final key = UniqueKey();

  doneLoading(String A) {
    setState(() {
      position = 0;
    });
  }

  startLoading(String A){
    setState(() {
      position = 1;
    });
  }

  @override
  Widget build(BuildContext context) {
    return 
      SafeArea(
        child: Scaffold(

          appBar: AppBar(
            title: RichText(
              text: TextSpan(
                  text: 'Privacy',
                  style: TextStyle(
                      fontSize: 30,
                      fontFamily: 'Impact',
                    color: HexColor("#26408A"),
                  ),
                  children: <TextSpan>[
                    TextSpan(
                        text: ' Policy',
                        style: TextStyle(
                            fontSize: 30,
                            fontFamily: 'Impact',
                          color: HexColor("#26408A"),
                        )),
                  ]),
            ),
            backgroundColor: Colors.white,
            elevation: 1,
            leading: IconButton(
                icon: Icon(
                  Icons.arrow_back,
                  color: Colors.black,
                ),
                onPressed: () {
                  Navigator.pop(context);
                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //         builder: (context) => ProfileScreen()));
                }),
          ),
          backgroundColor: Colors.white,

            body: IndexedStack(
                index: position,
                children: <Widget>[

                  WebView(
                    initialUrl: 'https://deshitour.com/Privacy-Policy/?app',
                    javascriptMode: JavascriptMode.unrestricted,

                    userAgent:
                    'Mozilla/5.0 (Linux; <Android Version>; <Build Tag etc.>) AppleWebKit/<WebKit Rev> (KHTML, like Gecko) Chrome/<Chrome Rev> Mobile Safari/<WebKit Rev>',
                    onWebViewCreated: (WebViewController webViewController) {
                      _controller.complete(webViewController);
                    },

                    key: key ,
                    onPageFinished: doneLoading,
                    onPageStarted: startLoading,
                  ),

                  Container(
                    color: Colors.white,
                    child: Center(
                        child: CircularProgressIndicator()),
                  ),

                ]
            )

          // body: WebView(
          //   initialUrl:"https://deshitour.com/Privacy-Policy/?app",
          //   javascriptMode: JavascriptMode.unrestricted,
          //   userAgent:
          //   'Mozilla/5.0 (Linux; <Android Version>; <Build Tag etc.>) AppleWebKit/<WebKit Rev> (KHTML, like Gecko) Chrome/<Chrome Rev> Mobile Safari/<WebKit Rev>',
          //   onWebViewCreated: (WebViewController webViewController) {
          //     _controller.complete(webViewController);
          //   },
          // )
        ),
      );
  }
}
