import 'dart:async';
import 'package:flutter/material.dart';
import 'package:new_motel/modules/bottomTab/bottomTabScreen.dart';
import 'package:new_motel/utils/constants.dart';

import 'package:webview_flutter/webview_flutter.dart';

import '../appTheme.dart';


class TermsAndConditionWebView extends StatefulWidget {

  @override
  _TermsAndConditionWebViewState createState() => _TermsAndConditionWebViewState();
}

class _TermsAndConditionWebViewState extends State<TermsAndConditionWebView> {


  final Completer<WebViewController> _controller =
  Completer<WebViewController>();

  num position = 1 ;
  final key = UniqueKey();

  doneLoading(String A) {
    setState(() {
      position = 0;
    });
  }

  startLoading(String A){
    setState(() {
      position = 1;
    });
  }


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(

        appBar: AppBar(
          title: RichText(
            text: TextSpan(
                text: 'Terms &',
                style: TextStyle(
                  fontSize: 30,
                  fontFamily: 'Impact',
                  color: HexColor("#26408A"),
                ),
                children: <TextSpan>[
                  TextSpan(
                      text: ' Condition',
                      style: TextStyle(
                        fontSize: 30,
                        fontFamily: 'Impact',
                        color: HexColor("#26408A"),
                      )),
                ]),
          ),
          backgroundColor: Colors.white,
          elevation: 1,
          leading: IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.black,
              ),
              onPressed: () {
                Navigator.pop(context);
                // Navigator.push(
                //     context,
                //     MaterialPageRoute(
                //         builder: (context) => ProfileScreen()));
              }),
        ),
          backgroundColor: Colors.white,


          body: IndexedStack(
              index: position,
              children: <Widget>[

                WebView(
                  initialUrl: 'https://deshitour.com/Terms-of-Use/?app',
                  javascriptMode: JavascriptMode.unrestricted,

                  userAgent:
                  'Mozilla/5.0 (Linux; <Android Version>; <Build Tag etc.>) AppleWebKit/<WebKit Rev> (KHTML, like Gecko) Chrome/<Chrome Rev> Mobile Safari/<WebKit Rev>',
                  onWebViewCreated: (WebViewController webViewController) {
                    _controller.complete(webViewController);
                  },

                  key: key ,
                  onPageFinished: doneLoading,
                  onPageStarted: startLoading,
                ),

                Container(
                  color: Colors.white,
                  child: Center(
                      child: CircularProgressIndicator()),
                ),

              ]
          )

          // body: WebView(
          //   initialUrl:"https://deshitour.com/Terms-of-Use/?app",
          //   javascriptMode: JavascriptMode.unrestricted,
          //   userAgent:
          //   'Mozilla/5.0 (Linux; <Android Version>; <Build Tag etc.>) AppleWebKit/<WebKit Rev> (KHTML, like Gecko) Chrome/<Chrome Rev> Mobile Safari/<WebKit Rev>',
          //   onWebViewCreated: (WebViewController webViewController) {
          //     _controller.complete(webViewController);
          //   },
          // ),

      ),
    );
  }
}
