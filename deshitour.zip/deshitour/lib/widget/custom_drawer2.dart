import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:new_motel/authenticating/login.dart';
import 'package:new_motel/utils/constants.dart';
import 'package:new_motel/widget/aboutUsWebView.dart';
import 'package:new_motel/widget/privacyPolicyWebView.dart';
import 'package:new_motel/widget/termsConditionWebView.dart';

import 'contactUsScreen.dart';

class CustomDrawerTwo extends StatefulWidget {
  @override
  _CustomDrawerTwoState createState() => _CustomDrawerTwoState();
}

class _CustomDrawerTwoState extends State<CustomDrawerTwo> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        // Important: Remove any padding from the ListView.
        padding: EdgeInsets.zero,

        children: <Widget>[
          SizedBox(
            height: 50,
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.only(left: 0.0),
              child: RichText(
                text: TextSpan(
                    text: DESHI,
                    style: TextStyle(
                      fontSize: 30,
                      fontFamily: 'Impact',
                      color: HexColor("#26408A"),
                    ),
                    children: <TextSpan>[
                      TextSpan(
                          text: TOUR,
                          style: TextStyle(
                            fontSize: 30,
                            fontFamily: 'Impact',
                            color: HexColor("#118ACB"),
                          )),
                    ]),
              ),
            ),
          ),

          SizedBox(
            height: 10,
          ),

          Padding(
            padding: const EdgeInsets.only(left: 68.0, right: 68, top: 20),
            child: Container(
              height: 40,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: Colors.indigo,
                borderRadius: BorderRadius.all(Radius.circular(24.0)),
                boxShadow: <BoxShadow>[
                  // BoxShadow(
                  //   color: AppTheme.getTheme()
                  //       .dividerColor,
                  //   blurRadius: 8,
                  //   offset: Offset(4, 4),
                  // ),
                ],
              ),
              child: FlatButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => LoginWidget()));
                },
                child: const Text('Sign In',
                    style: TextStyle(
                        fontSize: 20,
                        // fontFamily: 'Impact' ,
                        // backgroundColor:Colors.indigo,
                        color: Colors.white)),
              ),
            ),
          ),

          SizedBox(
            height: 30,
          ),
          // UserAccountsDrawerHeader(
          //   decoration: BoxDecoration(color: Colors.indigo[800]),
          //   accountName: Text(
          //     "User Name",
          //     style: TextStyle(fontSize: 17, color: Colors.white),
          //   ),
          //   accountEmail: Text(
          //     "user.name@gmail.com",
          //     style: TextStyle(fontSize: 17, color: Colors.white),
          //   ),
          //   currentAccountPicture: CircleAvatar(
          //     backgroundColor: Colors.white,
          //     child: Text(
          //       "A",
          //       style: TextStyle(fontSize: 40.0),
          //     ),
          //   ),
          // ),
          ListTile(
            leading: Icon(
              Icons.attribution_rounded,
              color: Colors.black,
              size: 30,
            ),
            title: Text("About Us"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => AboutUsWebView(),
                ),
              );
            },
          ),

          ListTile(
            leading: Icon(
              Icons.policy,
              color: Colors.black,
              size: 30,
            ),
            title: Text("Privacy Policy"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => PrivacyPolicyWebView(),
                ),
              );

              // Navigator.push(
              //     context,
              //     MaterialPageRoute(
              //         builder: (context) => PrivacyPolicyScreen()));
            },
          ),
          ListTile(
            leading: Icon(
              Icons.security,
              color: Colors.black,
              size: 30,
            ),
            title: Text("Terms & Condition"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => TermsAndConditionWebView(),
                ),
              );

              // InAppWebViewController _webViewController;
              // InAppWebView(
              //     initialUrl: "https://deshitour.com/About-Us",
              //     initialOptions: InAppWebViewGroupOptions(
              //       crossPlatform: InAppWebViewOptions(
              //         mediaPlaybackRequiresUserGesture: false,
              //         debuggingEnabled: true,
              //       ),
              //     ),
              //     onWebViewCreated: (InAppWebViewController controller) {
              //       _webViewController = controller;
              //     },
              //     androidOnPermissionRequest: (InAppWebViewController controller, String origin, List<String> resources) async {
              //       return PermissionRequestResponse(resources: resources, action: PermissionRequestResponseAction.GRANT);
              //     }
              // );
              // Navigator.push(
              //     context,
              //     MaterialPageRoute(
              //         builder: (context) => TermsConditionScreen()));
            },
          ),

          ListTile(
            leading: Icon(
              Icons.phone,
              color: Colors.black,
              size: 30,
            ),
            title: Text(
              "Contact Us",
            ),
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => ContactUsScreen()));
            },
          ),

          // ListTile(
          //   leading: Icon(Icons.person_outline),
          //   title: Text('LogOut'),
          //   onTap: () async {
          //     SharedPreferences sharedPreferces =
          //         await SharedPreferences.getInstance();
          //     String token = sharedPreferces.getString('token');
          //     if (token != null) {
          //       await sharedPreferces.clear();
          //       Navigator.of(context).popUntil((route) => route.isFirst);
          //       Navigator.pop(context);
          //       Navigator.push(context,
          //           MaterialPageRoute(builder: (context) => SplashScreen()));
          //     } else {
          //       Navigator.push(context,
          //           MaterialPageRoute(builder: (context) => SplashScreen()));
          //       return;
          //     }
          //   },
          // ),
        ],
      ),
    );
  }
}
