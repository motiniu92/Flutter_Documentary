// import 'package:flutter/material.dart';
// import 'package:new_motel/authenticating/login.dart';
// import 'package:new_motel/authenticating/register.dart';
// import 'package:new_motel/models/bookingDetails.dart';
// import 'package:new_motel/models/hotelList/hotelDetails.dart';
// import 'package:new_motel/provider/authenticate.dart';
// import 'package:provider/provider.dart';

// class Register extends StatefulWidget {
//   @override
//   _RegisterState createState() => _RegisterState();
// }

// class _RegisterState extends State<Register> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Consumer<Auth>(
//         // ignore: missing_return
//         builder: (context, authaa, child) {
//           switch (authaa.status) {
//             case AuthStatus.unauthenticated:
//               return RegisterWidget();
//               break;
//             case AuthStatus.authenticated:
//               return LoginWidget();
//               break;
//           }
//         },
//         child: RegisterWidget(),
//       ),
//     );
//   }
// }
