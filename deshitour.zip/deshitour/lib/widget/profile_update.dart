import 'package:flutter/material.dart';
import 'package:new_motel/utils/constants.dart';

  class ProfileUpdate extends StatefulWidget {
    @override
    _ProfileUpdateState createState() => _ProfileUpdateState();
  }

  class _ProfileUpdateState extends State<ProfileUpdate> {
    @override
    Widget build(BuildContext context) {
      return Scaffold(
        appBar: AppBar(
          title: Text(
            UPDATE_PROFILE,
          ),
          
        ),
      );
    }
  }
