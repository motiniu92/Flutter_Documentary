import 'package:flutter/material.dart';
import 'package:new_motel/utils/constants.dart';

class CustomTextField extends StatelessWidget {
  final TextEditingController controller;
  final IconData data;
  final IconData suffixIconData;
  final String hintText;
  bool isObsecure = true;

  CustomTextField(
      {Key key,
      this.controller,
      this.data,
      this.hintText,
      this.isObsecure,
      this.suffixIconData})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Padding(
      padding: const EdgeInsets.only(left: 0.0, top: 10),
      child: Center(
        child: Container(
          margin: EdgeInsets.symmetric(vertical: 7),
          width: size.width * 0.8,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
          ),
          child: TextFormField(
            validator: (value) {
              if (value.isEmpty) {
                return DOCUMENT;
              }
              return null;
            },
            obscureText: isObsecure,
            controller: controller,
            decoration: InputDecoration(
              hintText: hintText,
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(5)),
              prefixIcon: Icon(
                data,
                color: Colors.black,
              ),
              suffixIcon: Icon(
                suffixIconData,
                color: Colors.black,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
