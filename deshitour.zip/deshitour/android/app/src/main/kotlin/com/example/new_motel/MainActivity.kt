package com.example.new_motel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
